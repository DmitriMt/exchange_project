"""Native Python scheduling and validation; no JavaScript runtime is used."""
from __future__ import annotations
import copy
import datetime as dt
import math
import re
import uuid
from bisect import bisect_left
from collections import defaultdict, deque
from functools import lru_cache

MIN, MAX = '2000-01-01', '2100-12-31'
ID = re.compile(r'^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$')
HOLIDAYS = {'01-01','01-02','01-03','01-04','01-05','01-06','01-07','01-08','02-23','03-08','05-01','05-09','06-12','11-04'}
COLUMNS = {'expander','num','name','duration','percent','start','finish','preds','owner','note',*(f'custom{i}' for i in range(1,6))}

def uid(): return str(uuid.uuid4())
def now(): return dt.datetime.now(dt.timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
def today(): return dt.date.today().isoformat()
def clone(v): return copy.deepcopy(v)
def fail(message): raise ValueError(message)
def valid_id(value):
    if not isinstance(value,str) or not ID.fullmatch(value): fail('Недопустимый ID.')
    return value

def date(value):
    if not isinstance(value,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',value): return None
    try: parsed=dt.date.fromisoformat(value)
    except ValueError: return None
    return value if MIN <= value <= MAX and parsed.isoformat()==value else None

def integer(value,label='Число',minimum=0,maximum=20000):
    if isinstance(value,bool): fail(label+': ожидается число.')
    try: n=float(value)
    except (ValueError,TypeError,OverflowError): fail(label+': ожидается число.')
    if not math.isfinite(n) or not n.is_integer() or not minimum<=n<=maximum: fail(label+': значение вне диапазона.')
    return int(n)

def number(value,label='Число',minimum=0,maximum=1e9):
    if isinstance(value,bool): fail(label+': ожидается число.')
    try: n=float(value)
    except (ValueError,TypeError,OverflowError): fail(label+': ожидается число.')
    if not math.isfinite(n) or not minimum<=n<=maximum: fail(label+': значение вне диапазона.')
    return int(n) if n.is_integer() else n

def text(value,limit,label):
    if not isinstance(value,str) or len(value)>limit: fail(label+': некорректный текст.')
    return value

class Calendar:
    def __init__(self,kind,week,non,working):
        yes,no=set(working),set(non); self.days=[]
        d=dt.date.fromisoformat(MIN); last=dt.date.fromisoformat(MAX)
        while d<=last:
            iso=d.isoformat(); jsday=(d.weekday()+1)%7
            if iso in yes or (jsday in week and not(kind=='rf' and iso[5:] in HOLIDAYS) and iso not in no): self.days.append(iso)
            d+=dt.timedelta(days=1)
        if not self.days: fail('Календарь не содержит рабочих дат.')
        self.index={s:i for i,s in enumerate(self.days)}
    def ensure(self,s):
        if not date(s): fail('Некорректная дата или выход за диапазон 2000–2100: '+str(s))
        i=bisect_left(self.days,s)
        if i>=len(self.days): fail('Нет рабочих дат в заданном диапазоне.')
        return self.days[i]
    def serial(self,s): return self.index[self.ensure(s)]
    def from_index(self,n):
        if not isinstance(n,int) or not 0<=n<len(self.days): fail('Расчёт выходит за диапазон календаря 2000–2100.')
        return self.days[n]

@lru_cache(maxsize=24)
def _calendar(kind,week,non,working): return Calendar(kind,week,non,working)
def calendar(p):
    week=list(range(7)) if p.get('calendar_id')=='7day' else p.get('working_days',[1,2,3,4,5]); non=p.get('exceptions',[]); working=p.get('working_exceptions',[])
    if not isinstance(week,list) or not week or any(type(x) is not int or not 0<=x<=6 for x in week): fail('Укажите хотя бы один корректный рабочий день недели.')
    if not isinstance(non,list) or not isinstance(working,list) or any(not date(x) for x in non+working): fail('Некорректная дата исключения календаря.')
    return _calendar(p.get('calendar_id') or 'rf',tuple(sorted(set(week))),tuple(sorted(set(non))),tuple(sorted(set(working))))

def task_calendar_project(p,t):
    return {**p,'calendar_id':'7day','working_days':list(range(7)),'exceptions':[],'working_exceptions':[]} if t.get('schedule_calendar')=='all_days' else p

def task_calendar(p,t): return calendar(task_calendar_project(p,t))

def tree(p):
    by={t['id']:t for t in p['tasks']}; children=defaultdict(list)
    for t in p['tasks']: children[t.get('parent_id') or None].append(t)
    for a in children.values(): a.sort(key=lambda t:t.get('sort_order',0))
    flat=[]; seen=set(); active=set()
    def walk(t,level):
        if level>50: fail('Глубина структуры больше 50.')
        if t['id'] in active: fail('Цикл в структуре задач.')
        if t['id'] in seen: return
        active.add(t['id']); seen.add(t['id']); flat.append({**t,'level':level,'hasChildren':bool(children[t['id']])})
        for ch in children[t['id']]: walk(ch,level+1)
        active.remove(t['id'])
    for t in children[None]: walk(t,0)
    if len(seen)!=len(p['tasks']): fail('Цикл или недоступный родитель в структуре задач.')
    return by,children,flat

def project_code(name):
    import re
    s=re.sub(r'[^A-Za-zА-Яа-яЁё0-9]+',' ',str(name or '')).upper().strip()
    words=[w for w in s.split() if w]
    letters=''.join(w[0] for w in words)
    return (letters or 'ПР')[:4]

def renumber(p,layout=None):
    by,children,flat=layout if layout is not None else tree(p)
    code=project_code(p.get('name'))
    for i,row in enumerate(flat):
        t=by[row['id']];t['level']=row['level'];t['external_number']=code+'-'+str(i+1)
    return p

def normalize(source):
    if not isinstance(source,dict): fail('Ожидается объект проекта.')
    p=clone(source); p['id']=valid_id(p.get('id') or uid()); p['name']=text(p.get('name') or 'Новый проект',500,'Название')
    p['description']=text(p.get('description') or '',20000,'Описание'); p['calendar_id']=p.get('calendar_id') or 'rf'
    p.setdefault('working_days',[1,2,3,4,5]); p.setdefault('exceptions',[]); p.setdefault('working_exceptions',[])
    if p['calendar_id']=='7day': p['working_days']=list(range(7))
    cal=calendar(p); p['start_date']=cal.ensure(p.get('start_date') or today()); p['status_date']=p.get('status_date') or today()
    if not date(p['status_date']): fail('Некорректная статусная дата.')
    if 'hours_per_day' in p: p['hours_per_day']=number(p['hours_per_day'],'Часов в дне',1,24)
    p.setdefault('tasks',[]); p.setdefault('dependencies',[])
    if not isinstance(p['tasks'],list) or len(p['tasks'])>5000 or not isinstance(p['dependencies'],list) or len(p['dependencies'])>20000: fail('Лимит: 5000 задач и 20000 связей.')
    ids=set()
    for i,t in enumerate(p['tasks']):
        if not isinstance(t,dict): fail('Некорректная задача.')
        t['id']=valid_id(t.get('id') or uid())
        if t['id'] in ids: fail('Повторяющийся ID задачи.')
        ids.add(t['id']); t['project_id']=p['id']; t['parent_id']=t.get('parent_id') or None
        for k,default,limit,label in [('name','Задача',1000,'Задача'),('note','',30000,'Примечание'),('owner','',200,'Ответственный')]: t[k]=text(t.get(k) or default,limit,label)
        t['sort_order']=number(t.get('sort_order',i),'Порядок',-1e9,1e9)
        t['duration_days']=integer(t.get('duration_days',1),'Длительность'); t['is_milestone']=bool(t.get('is_milestone')) or t['duration_days']==0
        t['is_manual']=bool(t.get('is_manual')); t['percent_complete']=number(t.get('percent_complete') or 0,'Процент',0,100)
        for k in ['start_date','finish_date','constraint_snet','actual_start','actual_finish','deadline']:
            if t.get(k) and not date(t[k]): fail('Некорректная дата '+k)
        if t.get('actual_finish') and (not t.get('actual_start') or t['actual_finish']<t['actual_start']): fail('Фактическое окончание раньше начала.')
        if t.get('remaining_days') is not None: t['remaining_days']=integer(t['remaining_days'],'Остаток')
        for k in ['effort_hours','remaining_hours']:
            if t.get(k) is not None: t[k]=number(t[k],k)
        if t.get('kanban_column_id'): valid_id(t['kanban_column_id'])
        if t.get('assignee_id'): valid_id(t['assignee_id'])
        if 'schedule_calendar' in t and t['schedule_calendar'] not in ['project','all_days']: fail('Неизвестный календарь задачи.')
        t['status']=str(t.get('status') or '')
        for n in range(1,6): t[f'custom{n}']=str(t.get(f'custom{n}') or '')
    for t in p['tasks']:
        if t['parent_id'] and (t['parent_id'] not in ids or t['parent_id']==t['id']): fail('Некорректный родитель задачи.')
    by,children,flat=tree(p)
    renumber(p,(by,children,flat))
    for row in flat:
        t=by[row['id']]
        if row['hasChildren']: t['is_milestone']=False
        elif t['is_milestone']: t['duration_days']=0
        t['start_date']=t.get('start_date') or p['start_date']; t['finish_date']=t.get('finish_date') or t['start_date']
        if t['is_manual'] and t['finish_date']<t['start_date']: fail('Окончание раньше начала.')
    dep_ids=set()
    for d in p['dependencies']:
        if not isinstance(d,dict): fail('Некорректная связь.')
        d['id']=valid_id(d.get('id') or uid())
        if d['id'] in dep_ids: fail('Повторяющийся ID связи.')
        dep_ids.add(d['id'])
        if d.get('pred_id') not in ids or d.get('succ_id') not in ids or d['pred_id']==d['succ_id']: fail('Связь содержит неизвестную задачу или ссылку на себя.')
        d['type']=d.get('type') or 'FS'
        if d['type'] not in ['FS','SS','FF','SF']: fail('Неизвестный тип связи.')
        d['lag_workdays']=number(d.get('lag_workdays') or 0,'Лаг',-20000,20000); d['project_id']=p['id']
    p['createdAt']=str(p.get('createdAt') or p.get('created_at') or now()); p['updatedAt']=str(p.get('updatedAt') or p.get('updated_at') or p['createdAt']); p['revision']=integer(p.get('revision') or 1,'Ревизия',1,2**53-1)
    view=p.get('view_settings') or {}
    if not isinstance(view,dict) or not isinstance(view.get('columnWidths',{}),dict): fail('Некорректные настройки вида.')
    widths={k:number(v,'Ширина колонки',30,2000) for k,v in view.get('columnWidths',{}).items() if k in COLUMNS}
    order=view.get('columnOrder',[]); order=order if isinstance(order,list) else []
    p['view_settings']={**view,'leftWidth':number(view.get('leftWidth') or 760,'Ширина панели',200,5000),'columnWidths':widths,'columnOrder':[k for k in order if k in COLUMNS],'scale':view.get('scale') if view.get('scale') in ['day','week','month','quarter'] else 'day'}
    p['custom_fields']=[str(x) for x in (p.get('custom_fields') or [])[:5]]
    for k in ['changeLog','transferLog','baselines','appliedPackages']: p[k]=p.get(k) if isinstance(p.get(k),list) else []
    baselines=p['baselines']+([p['baseline']] if p.get('baseline') else [])
    for b in baselines:
        if not isinstance(b,dict): fail('Некорректный базовый план.')
        b['id']=valid_id(b.get('id') or uid()); b['name']=str(b.get('name') or 'Базовый план')
        try: dt.datetime.fromisoformat(b['savedAt'].replace('Z','+00:00'))
        except (ValueError,KeyError,AttributeError): fail('Некорректная дата базового плана.')
        if not isinstance(b.get('dates'),dict): fail('Некорректный базовый план.')
        for id,v in b['dates'].items():
            valid_id(id)
            if not isinstance(v,dict) or not date(v.get('start')) or not date(v.get('finish')) or v['finish']<v['start']: fail('Некорректные даты базового плана.')
    if p.get('baseline') and not any(b['id']==p['baseline']['id'] for b in p['baselines']): p['baselines'].append(clone(p['baseline']))
    return p

def graph(p):
    by,children,flat=tree(p); leaves=[by[r['id']] for r in flat if not r['hasChildren']]; leaf_ids={t['id'] for t in leaves}; descendants={}
    def leafs(id):
        if id not in descendants: descendants[id]=[id] if id in leaf_ids else [v for ch in children[id] for v in leafs(ch['id'])]
        return descendants[id]
    edges=[]
    for d in p['dependencies']:
        summary=d['pred_id'] not in leaf_ids or d['succ_id'] not in leaf_ids
        if summary and any(by[id]['is_manual'] and id not in leaf_ids for id in [d['pred_id'],d['succ_id']]): fail('Связи с ручными этапами не поддерживаются.')
        if summary and d['type']!='FS': fail('Для связей с этапами поддерживается только FS.')
        for a in leafs(d['pred_id']):
            for b in leafs(d['succ_id']):
                if len(edges)>=60000: fail('Слишком много связей после раскрытия этапов.')
                edges.append({**d,'pred_id':a,'succ_id':b})
    inc=defaultdict(list); out=defaultdict(list); degree={t['id']:0 for t in leaves}
    for d in edges: inc[d['succ_id']].append(d); out[d['pred_id']].append(d); degree[d['succ_id']]+=1
    queue=deque(t['id'] for t in leaves if not degree[t['id']]); order=[]
    while queue:
        id=queue.popleft(); order.append(id)
        for d in out[id]:
            degree[d['succ_id']]-=1
            if not degree[d['succ_id']]: queue.append(d['succ_id'])
    if len(order)!=len(leaves): fail('Циклическая зависимость. Связи сохранены; устраните цикл перед расчётом.')
    return by,children,flat,leaves,inc,out,order

def weight(d,a,b):
    po,so,lag=max(a['dur']-1,0),max(b['dur']-1,0),d['lag_workdays']
    return math.ceil({'SS':lag,'FF':po+lag-so,'SF':lag-so,'FS':po+lag+1}[d['type']])

def progress(tasks):
    total=sum(1 if t['is_milestone'] else max(t['duration_days'],1) for t in tasks)
    return math.floor(sum((1 if t['is_milestone'] else max(t['duration_days'],1))*t['percent_complete'] for t in tasks)/total+.5) if total else 0

def calculate(source,strict=False):
    p=normalize(source); cal=calendar(p); p['scheduleWarnings']=[]; p['cpmError']=''
    try: by,children,flat,leaves,inc,out,order=graph(p)
    except ValueError as e:
        if strict: raise
        p['cpmError']=str(e); return p
    if any(t.get('schedule_calendar')=='all_days' for t in leaves):
        from .mixed_calendar import calculate_mixed
        return calculate_mixed(p,(by,children,flat,leaves,inc,out,order))
    start=cal.serial(p['start_date']); calc={}
    for t in leaves:
        s=cal.serial(t['start_date']) if t['is_manual'] else start; dur=0 if t['is_milestone'] else (t['duration_days'] or 1)
        if t.get('constraint_snet') and not t['is_manual']: s=max(s,cal.serial(t['constraint_snet']))
        f=cal.serial(t['finish_date']) if t['is_manual'] else s+max(dur-1,0)
        calc[t['id']]={'ES':s,'EF':f,'dur':f-s+1 if t['is_manual'] and not t['is_milestone'] else dur,'manual':t['is_manual'],'reason':'Ограничение начала' if t.get('constraint_snet') else 'Начало проекта'}
    for id in order:
        c=calc[id]; t=by[id]
        for d in inc[id]:
            candidate=calc[d['pred_id']]['ES']+weight(d,calc[d['pred_id']],c)
            if candidate>c['ES']:
                if c['manual']: p['scheduleWarnings'].append(f'«{t["name"]}»: ручная дата нарушает связь от «{by[d["pred_id"]]["name"]}», начало не ранее {cal.from_index(candidate)}.')
                else: c['ES']=candidate; c['reason']=f'Связь {d["type"]} от «{by[d["pred_id"]]["name"]}»'
        if not c['manual']: c['EF']=c['ES']+max(c['dur']-1,0)
        cal.from_index(c['ES']); cal.from_index(c['EF'])
    end=max([start]+[c['EF'] for c in calc.values()])
    for c in calc.values(): c['LS']=c['ES'] if c['manual'] else end-max(c['dur']-1,0)
    for id in reversed(order):
        c=calc[id]
        if not c['manual']:
            for d in out[id]: c['LS']=min(c['LS'],calc[d['succ_id']]['LS']-weight(d,c,calc[d['succ_id']]))
    forecast={}; asof=cal.serial(p['status_date'])
    for id in order:
        t,c=by[id],calc[id]
        s=cal.serial(t['actual_start']) if t.get('actual_start') else c['ES'] if t['is_manual'] else max(start,asof,cal.serial(t['constraint_snet']) if t.get('constraint_snet') else start)
        rem=t.get('remaining_days'); rem=rem if rem is not None else max(0 if t['is_milestone'] else 1,math.ceil(c['dur']*(1-t['percent_complete']/100)))
        if t.get('actual_finish'): s=cal.serial(t['actual_start']); f=cal.serial(t['actual_finish'])
        elif t.get('actual_start'): f=max(s,asof)+max(rem-1,0)
        else:
            for d in inc[id]: s=max(s,forecast[d['pred_id']]['ES']+weight(d,forecast[d['pred_id']],{'dur':0 if t['is_milestone'] else rem}))
            f=s+max(rem-1,0)
        forecast[id]={'ES':s,'EF':f,'dur':max(f-s+1,0 if t['is_milestone'] else 1)}
        t.update(start_date=cal.from_index(c['ES']),finish_date=cal.from_index(c['EF']),duration_days=c['dur'],total_float=c['LS']-c['ES'],free_float=min(calc[d['succ_id']]['ES']-c['ES']-weight(d,c,calc[d['succ_id']]) for d in out[id]) if out[id] else end-c['EF'],critical=c['LS']-c['ES']<=0,schedule_reason=c['reason'],forecast_start=cal.from_index(s),forecast_finish=cal.from_index(f))
        if t.get('deadline') and t['forecast_finish']>t['deadline']: p['scheduleWarnings'].append(f'«{t["name"]}»: прогноз позже целевого срока {t["deadline"]}.')
    for row in reversed(flat):
        t=by[row['id']]; ch=children[t['id']]
        if not ch: continue
        manual=(t['start_date'],t['finish_date']) if t['is_manual'] else None
        t.update(start_date=min(x['start_date'] for x in ch),finish_date=max(x['finish_date'] for x in ch),forecast_start=min(x.get('forecast_start',x['start_date']) for x in ch),forecast_finish=max(x.get('forecast_finish',x['finish_date']) for x in ch),percent_complete=progress(ch),critical=any(x['critical'] for x in ch),is_milestone=False)
        t['duration_days']=cal.serial(t['finish_date'])-cal.serial(t['start_date'])+1
        if manual:
            t['start_date'],t['finish_date']=manual; t['duration_days']=cal.serial(manual[1])-cal.serial(manual[0])+1; end=max(end,cal.serial(manual[1]))
            if any(x['start_date']<manual[0] or x['finish_date']>manual[1] for x in ch): p['scheduleWarnings'].append('Работы выходят за ручные даты этапа «'+t['name']+'».')
    p.update(finish_date=cal.from_index(end),forecast_finish=max([t['forecast_finish'] for t in leaves],default=p['start_date']),percent_complete=progress(leaves))
    return p

DERIVED={'start_date','finish_date','forecast_start','forecast_finish','total_float','free_float','critical','schedule_reason','external_number','level','project_id'}
PROJECT_FIELDS=['name','description','start_date','status_date','calendar_id','working_days','exceptions','working_exceptions','custom_fields','baseline','baselines','hours_per_day','require_plan_approval']
def diff(local,incoming):
    changes=[]
    for kind,key in [('task','tasks'),('dependency','dependencies')]:
        lm={x['id']:x for x in local.get(key,[])}; rm={x['id']:x for x in incoming.get(key,[])}
        for id in dict.fromkeys([*lm,*rm]):
            l,r=lm.get(id),rm.get(id)
            if l is None or r is None: changes.append(dict(kind=kind,id=id,field='*',before=l,after=r)); continue
            for field in dict.fromkeys([*l,*r]):
                if kind=='task' and field in DERIVED and not l.get('is_manual') and not r.get('is_manual'): continue
                if l.get(field)!=r.get(field): changes.append(dict(kind=kind,id=id,field=field,before=l.get(field),after=r.get(field)))
    for k in PROJECT_FIELDS:
        if local.get(k)!=incoming.get(k): changes.append(dict(kind='project',id=local['id'],field=k,before=local.get(k),after=incoming.get(k)))
    return changes

def merge(base,local,incoming):
    result=clone(local); conflicts=[]; local_diff=diff(base,local)
    for c in diff(base,incoming):
        collision=next((v for v in local_diff if v['kind']==c['kind'] and v['id']==c['id'] and (v['field']==c['field'] or '*' in [v['field'],c['field']])),None)
        if collision and collision['after']!=c['after']: conflicts.append(c); continue
        if c['kind']=='project': result[c['field']]=clone(c['after']); continue
        key='tasks' if c['kind']=='task' else 'dependencies'; item=next((x for x in result[key] if x['id']==c['id']),None)
        if c['field']=='*':
            result[key]=[x for x in result[key] if x['id']!=c['id']]
            if c['after'] is not None: result[key].append(clone(c['after']))
        elif item is not None: item[c['field']]=clone(c['after'])
        else: conflicts.append(c)
    return {'project':local,'conflicts':conflicts} if conflicts else {'project':calculate(result,strict=True),'conflicts':[]}

def actual(project,task_id,data):
    if not isinstance(data,dict): fail('Ожидается объект факта.')
    p=clone(project); t=next((t for t in p['tasks'] if t['id']==task_id),None)
    if not t: fail('Задача не найдена.')
    if any(x.get('parent_id')==task_id for x in p['tasks']): fail('Факт вводится для конечной задачи.')
    start,finish=data.get('actual_start') or '',data.get('actual_finish') or ''
    if (start and not date(start)) or (finish and not date(finish)): fail('Некорректные фактические даты.')
    if finish and (not start or finish<start): fail('Окончание раньше начала.')
    if start>today() or finish>today(): fail('Фактическая дата не может быть в будущем.')
    percent=number(data.get('percent_complete'),'Процент',0,100); remaining=integer(data.get('remaining_days'),'Остаток')
    if (finish or percent==100) and (not finish or not start or percent!=100 or remaining!=0): fail('Для завершения нужны начало, окончание, 100% и нулевой остаток.')
    if percent>0 and not start: fail('Укажите фактическое начало.')
    if 'kanban_column_id' in data: t['kanban_column_id']=valid_id(data['kanban_column_id'])
    elif (data.get('status') and data['status']!=t.get('status')) or (t.get('actual_finish') and not finish): t.pop('kanban_column_id',None)
    t.update(actual_start=start,actual_finish=finish,percent_complete=percent,remaining_days=remaining,status='Завершено' if finish else str(data.get('status') or t.get('status') or ''),blocker=str(data.get('blocker') or '')[:2000])
    if re.fullmatch(r'custom[1-5]',t.get('legacy_status_source') or ''): t[t['legacy_status_source']]=t['status']
    return calculate(p,strict=True)
