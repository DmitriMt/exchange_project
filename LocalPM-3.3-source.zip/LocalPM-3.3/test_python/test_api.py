import base64
import concurrent.futures
import copy
import datetime as dt
import hashlib
import http.client
import json
import secrets
import tempfile
import threading
import unittest
from pathlib import Path
from localpm import core
from localpm.application import Application,COOKIE,password_hash,verify_password
from localpm.http_server import Server
from localpm.storage import APIError,Repository,atomic_write,json_text
from test_core import sample

ROOT=Path(__file__).resolve().parents[1]
class Client:
    def __init__(self,port): self.port=port; self.cookie=''; self.csrf=''
    def call(self,method,path,data=None,expected=200,headers=None):
        conn=http.client.HTTPConnection('127.0.0.1',self.port,timeout=20)
        h={'Cookie':self.cookie,'X-LocalPM-CSRF':self.csrf}
        body=None
        if method not in ['GET','HEAD']: body=json.dumps(data if data is not None else {}).encode(); h['Content-Type']='application/json'
        h.update(headers or {}); conn.request(method,path,body,h); r=conn.getresponse(); payload=r.read(); status=r.status
        cookie=r.getheader('Set-Cookie'); content_type=r.getheader('Content-Type','')
        if cookie: self.cookie=cookie.split(';')[0]
        out=json.loads(payload) if 'application/json' in content_type and payload else payload
        conn.close()
        if status!=expected: raise AssertionError(f'{method} {path}: {status} != {expected}: {out}')
        if isinstance(out,dict) and 'csrf' in out: self.csrf=out['csrf']
        return out

class APITests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.app=Application(Path(self.tmp.name)/'data'); self.server=Server(('127.0.0.1',0),self.app,ROOT/'web'); self.thread=threading.Thread(target=self.server.serve_forever,kwargs={'poll_interval':.01},daemon=True); self.thread.start()
        self.manager=Client(self.server.server_port); self.password=secrets.token_urlsafe(24); self.admin_name='admin'+secrets.token_hex(4)
        self.manager.call('POST','/api/setup',{'code':self.app.bootstrap_code,'username':self.admin_name,'name':'Руководитель','password':self.password},201)
        self.admin=self.manager.call('POST','/api/login',{'username':self.admin_name,'password':self.password})['user']
    def tearDown(self):
        self.server.shutdown(); self.server.server_close(); self.thread.join(); self.app.close(); self.tmp.cleanup()
    def worker(self,role='contributor',doc=None):
        username='worker'+secrets.token_hex(4); password=secrets.token_urlsafe(24)
        user=self.manager.call('POST','/api/users',{'username':username,'password':password,'name':'Сотрудник'},201)
        client=Client(self.server.server_port); client.call('POST','/api/login',{'username':username,'password':password})
        if doc: doc=self.manager.call('POST',f'/api/projects/{doc["project"]["id"]}/members',{'userId':user['id'],'role':role})
        return user,client,doc
    def project(self,p=None): return self.manager.call('POST','/api/projects',{'project':p or sample()},201)
    def put(self,client,doc,change=None,expected=200,op=None):
        p=copy.deepcopy(doc['project'])
        if change: change(p)
        return client.call('PUT','/api/projects/'+p['id'],{'project':p,'expectedVersion':doc['version'],'operationId':op or core.uid()},expected)
    def actual(self,percent=50): return {'actual_start':(dt.date.today()-dt.timedelta(days=2)).isoformat(),'actual_finish':'','percent_complete':percent,'remaining_days':3,'status':'В работе'}
    def test_status_login_csrf_origin_and_hash_privacy(self):
        c=Client(self.server.server_port); status=c.call('GET','/api/status'); self.assertEqual(status['backend'],'python'); self.assertFalse(status['setupRequired'])
        c.call('GET','/api/projects',expected=401); c.call('POST','/api/setup',{},409)
        self.manager.call('POST','/api/projects',{'project':sample()},403,headers={'X-LocalPM-CSRF':''})
        self.manager.call('POST','/api/projects',{'project':sample()},403,headers={'Origin':'https://untrusted.example'})
        self.assertNotIn('hash',self.manager.call('GET','/api/users')[0]); self.assertIn(COOKIE,self.manager.cookie)
        self.manager.call('POST','/api/logout'); self.manager.call('GET','/api/projects',expected=401)
    def test_login_throttling(self):
        c=Client(self.server.server_port)
        for _ in range(8): c.call('POST','/api/login',{'username':'not-present','password':secrets.token_urlsafe(20)},401)
        c.call('POST','/api/login',{'username':'not-present','password':secrets.token_urlsafe(20)},429)
    def test_roles_assignments_fact_comments_attachments_notifications(self):
        doc=self.project(); worker,c,doc=self.worker(doc=doc); viewer,v,doc=self.worker('viewer',doc)
        self.put(c,doc,expected=403); v.call('POST','/api/projects/project-test/comments',{'text':'Read only'},403)
        c.call('POST','/api/projects/project-test/updates',{'taskId':'a','actual':self.actual()},403)
        doc=self.put(self.manager,doc,lambda p:p['tasks'][0].update(assignee_id=worker['id']))
        submitted=c.call('POST','/api/projects/project-test/updates',{'taskId':'a','actual':self.actual(),'operationId':core.uid()},201)
        self.assertEqual(submitted['project']['tasks'][0]['percent_complete'],0); update=submitted['updates'][-1]
        doc=self.manager.call('POST',f'/api/projects/project-test/updates/{update["id"]}/review',{'decision':'accepted'}); self.assertEqual(doc['project']['tasks'][0]['percent_complete'],50)
        c.call('POST','/api/projects/project-test/comments',{'text':'Проверка','mentions':[self.admin['id']]},201)
        attached=c.call('POST','/api/projects/project-test/attachments',{'name':'note.txt','type':'text/plain','data':base64.b64encode(b'proof').decode()},201)
        self.assertNotIn('data',attached['attachments'][0]); self.assertEqual(c.call('GET','/api/projects/project-test/attachments/'+attached['attachments'][0]['id']),b'proof')
        self.assertTrue(c.call('GET','/api/projects/project-test')['notifications']); c.call('POST','/api/projects/project-test/notifications/read')
    def test_parallel_put_one_winner_and_idempotency(self):
        doc=self.project(); p1=copy.deepcopy(doc['project']); p2=copy.deepcopy(p1); p1['name']='first'; p2['name']='second'; ops=[core.uid(),core.uid()]
        def save(i):
            c=Client(self.server.server_port); c.cookie=self.manager.cookie; c.csrf=self.manager.csrf
            payload={'project':[p1,p2][i],'expectedVersion':doc['version'],'operationId':ops[i]}
            try: return i,c.call('PUT','/api/projects/project-test',payload),payload
            except AssertionError as e:
                if '409 != 200' not in str(e): raise
                return i,None,payload
        with concurrent.futures.ThreadPoolExecutor(2) as pool: results=list(pool.map(save,[0,1]))
        winners=[x for x in results if x[1]]; self.assertEqual(len(winners),1); i,saved,payload=winners[0]
        replay=self.manager.call('PUT','/api/projects/project-test',payload); self.assertEqual(replay['version'],saved['version'])
        payload['project']['name']='changed payload'; self.manager.call('PUT','/api/projects/project-test',payload,409)
    def test_stale_actual_rejected(self):
        doc=self.project(); u,c,doc=self.worker(doc=doc); doc=self.put(self.manager,doc,lambda p:p['tasks'][0].update(assignee_id=u['id']))
        submitted=c.call('POST','/api/projects/project-test/updates',{'taskId':'a','actual':self.actual()},201); doc=self.put(self.manager,submitted,lambda p:p['tasks'][0].update(percent_complete=10))
        self.manager.call('POST','/api/projects/project-test/updates/'+submitted['updates'][-1]['id']+'/review',{'decision':'accepted'},409)
    def test_editor_proposal_merges_independent_manager_edit(self):
        p=sample(); p['require_plan_approval']=True; doc=self.project(p); editor,c,doc=self.worker('editor',doc)
        proposed=self.put(c,doc,lambda p:p['tasks'][1].update(name='Предложение'),expected=202); self.assertEqual(proposed['project']['tasks'][1]['name'],'B')
        doc=self.manager.call('GET','/api/projects/project-test'); doc=self.put(self.manager,doc,lambda p:p['tasks'][0].update(note='Сохранить'))
        request=proposed['changeRequests'][-1]; self.assertNotIn('baseProject',request)
        accepted=self.manager.call('POST','/api/projects/project-test/changes/'+request['id']+'/review',{'decision':'accepted'})
        self.assertEqual(accepted['project']['tasks'][1]['name'],'Предложение'); self.assertEqual(accepted['project']['tasks'][0]['note'],'Сохранить')
    def test_editor_conflicting_proposal_rejected(self):
        p=sample(); p['require_plan_approval']=True; doc=self.project(p); u,c,doc=self.worker('editor',doc)
        proposed=self.put(c,doc,lambda p:p['tasks'][0].update(name='Editor'),202); current=self.manager.call('GET','/api/projects/project-test'); self.put(self.manager,current,lambda p:p['tasks'][0].update(name='Manager'))
        self.manager.call('POST','/api/projects/project-test/changes/'+proposed['changeRequests'][-1]['id']+'/review',{'decision':'accepted'},409)
    def test_revocation_and_disable_sessions(self):
        doc=self.project(); u,c,doc=self.worker(doc=doc); self.manager.call('DELETE','/api/projects/project-test/members/'+u['id']); c.call('GET','/api/projects/project-test',expected=403)
        self.manager.call('PATCH','/api/users/'+u['id'],{'active':False}); c.call('GET','/api/users',expected=401)
        self.manager.call('PATCH','/api/users/'+self.admin['id'],{'active':False},422)
    def test_backup_restore_and_bad_checksum(self):
        self.project(); backup=self.manager.call('POST','/api/backup')
        with tempfile.TemporaryDirectory() as tmp:
            repo=Repository(tmp); self.addCleanup(repo.close); bad=copy.deepcopy(backup); bad['content']['users'][0]['name']='tampered'
            with self.assertRaises(APIError): repo.restore(bad)
            repo.restore(backup); self.assertEqual(repo.count_users(),1); self.assertTrue(verify_password(self.password,repo.users(hashes=True)[0]['hash'])); self.assertEqual(len(repo.list()),1)
            with self.assertRaises(APIError): repo.restore(backup)
    def test_history_restore_preserves_acl(self):
        doc=self.project(); u,c,doc=self.worker('viewer',doc); doc=self.put(self.manager,doc,lambda p:p.update(name='New'))
        history=self.manager.call('GET','/api/projects/project-test/history'); old=history[-1]['version']
        restored=self.manager.call('POST','/api/projects/project-test/restore',{'version':old,'expectedVersion':doc['version']}); self.assertEqual(restored['acl'][u['id']],'viewer'); self.assertGreater(restored['version'],doc['version'])
    def test_static_allowlist_and_json_validation(self):
        self.assertIn(b'LocalPM',self.manager.call('GET','/'))
        self.manager.call('GET','/server.py',expected=404); self.manager.call('GET','/../server.py',expected=404)
        self.manager.call('POST','/api/projects',[],422); self.manager.call('POST','/api/projects',{},415,headers={'Content-Type':'text/plain'})
    def test_attachment_limit(self):
        self.project(); payload={'name':'large.txt','type':'text/plain','data':base64.b64encode(b'x'*(2*1024*1024+1)).decode()}
        self.manager.call('POST','/api/projects/project-test/attachments',payload,422)
    def test_shared_folder_coordinator_and_owner_loss(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp); r=Repository(base/'db',base/'share'); self.addCleanup(r.close)
            with self.assertRaises(APIError): Repository(base/'other',base/'share')
            doc={'project':core.calculate(sample()),'version':1,'acl':{self.admin['id']:'manager'}}; r.save(doc,0); self.assertEqual(r.load('project-test')['version'],1)
            doc['version']=2; r.save(doc,1); self.assertEqual(len(r.versions('project-test')),1)
            atomic_write(base/'share/.localpm-service-lock/owner.json',{'token':'another-owner'})
            with self.assertRaises(APIError): r.save(doc,2)
    def test_http_board_configuration_admin_roles_and_versions(self):
        anonymous=Client(self.server.server_port); anonymous.call('GET','/api/kanban',expected=401)
        current=self.manager.call('GET','/api/kanban'); cfg=copy.deepcopy(current['config']); cfg['columns'][0]['name']='Queue'
        saved=self.manager.call('PUT','/api/kanban',{'config':cfg,'expectedVersion':current['version']}); self.assertEqual(saved['version'],1)
        user,client,_=self.worker('manager'); self.assertEqual(client.call('GET','/api/kanban'),saved)
        client.call('PUT','/api/kanban',{'config':cfg,'expectedVersion':1},403)
        self.manager.call('PUT','/api/kanban',{'config':cfg,'expectedVersion':0},409)
        self.manager.call('PUT','/api/kanban',{'config':{'columns':[]},'expectedVersion':1},422)
    def test_binding_all_interfaces_dev(self):
        with tempfile.TemporaryDirectory() as tmp:
            app=Application(tmp,dev=True); server=Server(('0.0.0.0',0),app,ROOT/'web'); thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
            try:
                self.assertEqual(server.server_address[0],'0.0.0.0'); result=Client(server.server_port).call('GET','/api/status'); self.assertEqual(result['mode'],'development')
            finally: server.shutdown(); server.server_close(); thread.join(); app.close()

class BootstrapRaceTest(unittest.TestCase):
    def test_parallel_setup_one_administrator(self):
        with tempfile.TemporaryDirectory() as tmp:
            app=Application(tmp); server=Server(('127.0.0.1',0),app,ROOT/'web'); thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
            def setup(i):
                try: Client(server.server_port).call('POST','/api/setup',{'code':app.bootstrap_code,'username':'new'+str(i),'name':'First','password':secrets.token_urlsafe(24)},201); return True
                except AssertionError as e:
                    if '409 != 201' not in str(e): raise
                    return False
            try:
                with concurrent.futures.ThreadPoolExecutor(2) as pool: results=list(pool.map(setup,[0,1]))
                self.assertEqual(results.count(True),1); self.assertEqual(app.repo.count_users(),1)
            finally: server.shutdown(); server.server_close(); thread.join(); app.close()
