#!/bin/zsh
cd "${0:A:h}" || exit 1
localpm_node="$(command -v node)"
if [[ -z "$localpm_node" && -x "${HOME}/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node" ]]; then
  localpm_node="${HOME}/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node"
fi
if [[ -z "$localpm_node" ]]; then
  echo "Для запуска общей базы установите Node.js 24 или новее."
  read -r "?Нажмите Enter для закрытия."
  exit 1
fi
"$localpm_node" server.js "$@"
read -r "?Нажмите Enter для закрытия."
