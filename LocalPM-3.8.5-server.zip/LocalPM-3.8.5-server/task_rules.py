"""Canonical task limits shared by Python, browser validation and MCP schemas."""
import json
import math
from pathlib import Path

LIMITS = json.loads((Path(__file__).resolve().parent / 'task-rules.json').read_text(encoding='utf-8'))

def metadata(task):
    priority = task.get('priority', 0)
    if type(priority) not in [int, float] or not math.isfinite(priority) or not 0 <= priority <= LIMITS['priorityMax']:
        raise ValueError('Приоритет должен быть от 0 до ' + str(LIMITS['priorityMax']) + '.')
    tags = task.get('tags', [])
    if not isinstance(tags, list) or len(tags) > LIMITS['tagCount'] or any(not isinstance(t, str) or len(t) > LIMITS['tagLength'] for t in tags):
        raise ValueError('Некорректные метки.')
    author = task.get('author', '')
    if not isinstance(author, str) or len(author) > LIMITS['authorLength']:
        raise ValueError('Некорректный инициатор.')
