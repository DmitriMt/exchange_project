"""Authenticated, bounded API client. Never redirects credentials to another URL."""
from __future__ import annotations
import json
import http.client
import os
import re
import ssl
import stat
import urllib.error
import urllib.request
from pathlib import Path
from urllib.parse import urlsplit

MAX_RESPONSE=12*1024*1024
class ClientError(Exception):
    def __init__(self,message,status=0,current_version=None):
        super().__init__(message);self.status=status;self.current_version=current_version

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl): return None

def server_url(value,allow_http=False):
    try:
        u=urlsplit(value);port=u.port
        if (u.scheme not in ['https','http'] or not u.hostname or u.username or u.password or
            u.path not in ['','/'] or u.query or u.fragment or any(c.isspace() for c in value)):
            raise ValueError()
        if u.scheme=='http' and u.hostname not in ['127.0.0.1','localhost','::1'] and not allow_http:
            raise ClientError('Для сетевого сервера нужен HTTPS. --allow-http разрешает HTTP явно только для разработки.')
        host=u.hostname.encode('idna').decode('ascii').lower()
        if ':' in host:host='['+host+']'
        return u.scheme+'://'+host+(':'+str(port) if port is not None and port!={'http':80,'https':443}[u.scheme] else '')
    except (ValueError,TypeError,UnicodeError):
        raise ClientError('Укажите адрес сервера http(s)://host:port без пути, логина и параметров.') from None

def load_session(path):
    p=Path(path).expanduser()
    try:
        info=p.lstat()
        if not stat.S_ISREG(info.st_mode) or (os.name!='nt' and (info.st_mode&0o077 or info.st_uid!=os.getuid())):
            raise ClientError('Файл сессии должен принадлежать вам и иметь права 600. Символические ссылки не разрешены.')
        if info.st_size>8192:raise ClientError('Некорректный файл сессии.')
        value=json.loads(p.read_text(encoding='utf-8'))
        if not isinstance(value,dict) or not re.fullmatch(r'[a-f0-9]{64}',value.get('token','')) or not re.fullmatch(r'[a-f0-9]{48}',value.get('csrf','')):
            raise ClientError('Некорректный файл сессии. Выполните login заново.')
        return value
    except (OSError,ValueError,TypeError):
        raise ClientError('Файл сессии не прочитан. Выполните mcp_server.py login.') from None

def save_session(path,value):
    p=Path(path).expanduser();p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists() or p.is_symlink():load_session(p)
    temp=p.with_name(p.name+'.'+os.urandom(12).hex()+'.tmp')
    try:
        fd=os.open(temp,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
        with os.fdopen(fd,'w',encoding='utf-8') as out:
            json.dump(value,out,ensure_ascii=False);out.write('\n');out.flush();os.fsync(out.fileno())
        os.replace(temp,p)
    finally:
        if temp.exists():temp.unlink()

class APIClient:
    def __init__(self,url,session=None,allow_http=False,ca_file=None,timeout=15):
        self.url=server_url(url,allow_http);self.token='';self.csrf='';self.timeout=timeout;self._sensitive=[]
        if session:
            if server_url(session.get('server_url',''),allow_http)!=self.url:raise ClientError('Адрес не совпадает с адресом сохранённой сессии. Выполните login для нужного сервера.')
            self.token=session['token'];self.csrf=session['csrf']
        self.opener=urllib.request.build_opener(NoRedirect(),urllib.request.HTTPSHandler(context=ssl.create_default_context(cafile=ca_file)))
    def redact(self,text):
        for secret in [self.token,self.csrf,*self._sensitive]:
            if secret:text=text.replace(secret,'[redacted]')
        return text
    def request(self,method,path,body=None,authenticated=True):
        if not path.startswith('/api/') or any(c in path for c in ['?','#','\\','\r','\n']):raise ClientError('Некорректный путь API.')
        if authenticated and not self.token:raise ClientError('Сессия отсутствует. Выполните mcp_server.py login.',401)
        headers={'Accept':'application/json','Origin':self.url,'X-LocalPM-Client':'desktop-v1','X-LocalPM-Source':'mcp'}
        if authenticated:headers.update({'Authorization':'Bearer '+self.token,'X-LocalPM-CSRF':self.csrf})
        data=None
        if body is not None:
            data=json.dumps(body,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode('utf-8');headers['Content-Type']='application/json'
            if len(data)>MAX_RESPONSE:raise ClientError('Пакет превышает допустимый размер.')
        req=urllib.request.Request(self.url+path,data=data,headers=headers,method=method)
        try:
            with self.opener.open(req,timeout=self.timeout) as response:
                if response.headers.get_content_type()!='application/json':raise ClientError('Сервер вернул ответ не в формате JSON.')
                raw=response.read(MAX_RESPONSE+1)
                if len(raw)>MAX_RESPONSE:raise ClientError('Ответ сервера слишком большой.')
                return json.loads(raw,parse_constant=lambda _:(_ for _ in ()).throw(ValueError()))
        except urllib.error.HTTPError as error:
            raw=error.read(16385)
            if 300<=error.code<400:raise ClientError('Перенаправление отклонено. Укажите конечный адрес LocalPM.',error.code) from None
            current=None;message='Запрос LocalPM отклонён.'
            try:
                obj=json.loads(raw);current=obj.get('currentVersion');message=str(obj.get('error',message))[:2000]
            except (ValueError,AttributeError):pass
            if error.code==401:message='Сессия завершена или отозвана. Повторите mcp_server.py login.'
            raise ClientError(self.redact(message),error.code,current) from None
        except (urllib.error.URLError,OSError,TimeoutError,http.client.HTTPException):
            raise ClientError('Нет соединения с LocalPM или сертификат не прошёл проверку. После неопределённого результата записи повторите тот же operation_id и тот же пакет.') from None
        except (ValueError,UnicodeError):raise ClientError('Некорректный JSON в ответе LocalPM.') from None
    def status(self):
        info=self.request('GET','/api/status',authenticated=False)
        if not isinstance(info,dict) or info.get('backend')!='python' or info.get('clientApiVersion')!=1 or info.get('productApiVersion')!=1 or info.get('scheduleModelVersion')!=3:
            raise ClientError('Нужен совместимый Python-сервер LocalPM 3.6.0 или новее.')
        return info
    def login_key(self,secret):
        import hashlib
        if not re.fullmatch(r'[a-f0-9]{64}',secret): raise ClientError('Некорректный ключ агента.')
        self.token=secret; self.csrf=hashlib.sha256(('localpm-agent-csrf:'+secret).encode()).hexdigest()[:48]
        self.status(); self.request('GET','/api/session')
        return {'server_url':self.url,'token':self.token,'csrf':self.csrf,'kind':'agent'}
    def login(self,username,password):
        self.status()
        self._sensitive=[password]
        try:result=self.request('POST','/api/client/login',{'username':username,'password':password},authenticated=False)
        finally:self._sensitive=[]
        if not re.fullmatch(r'[a-f0-9]{64}',result.get('sessionToken','')) or not re.fullmatch(r'[a-f0-9]{48}',result.get('csrf','')):
            raise ClientError('LocalPM вернул некорректную сессию.')
        self.token=result['sessionToken'];self.csrf=result['csrf']
        return {'server_url':self.url,'token':self.token,'csrf':self.csrf}
