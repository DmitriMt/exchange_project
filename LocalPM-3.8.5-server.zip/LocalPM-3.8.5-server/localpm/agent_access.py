"""Persistent, hashed and project-scoped credentials for unattended agents."""
import hashlib
import hmac
import re
import secrets
import time
from .storage import APIError

SETTING='agent-keys'

def csrf(secret): return hashlib.sha256(('localpm-agent-csrf:'+secret).encode()).hexdigest()[:48]

def authenticate(app, secret):
    if not re.fullmatch(r'[a-f0-9]{64}',secret): return None
    digest=hashlib.sha256(secret.encode()).hexdigest()
    entry=next((k for k in app.repo.setting(SETTING,[])['value'] if hmac.compare_digest(k['hash'],digest)),None)
    if not entry or entry.get('revokedAt') or entry['expires']<=time.time(): return None
    user=app.repo.user(entry['userId'])
    if not user or not user['active']: raise APIError(401,'Учётная запись отключена.')
    user={**user,'admin':False,'_agent_admin':bool(user['admin']),'_agent_projects':entry['projects']}
    session={'userId':user['id'],'kind':'agent','csrf':csrf(secret),'expires':entry['expires'],'agent':{k:v for k,v in entry.items() if k!='hash'}}
    return secret,session,user

def authorize(session,method,path,body):
    if session.get('kind')!='agent': return
    if method=='GET' and path in ['/api/session','/api/projects/index','/api/kanban']: return
    if method=='POST' and path=='/api/agent-read': return
    match=re.fullmatch(r'/api/projects/([A-Za-z0-9_.:-]+)/(task-changes|actions)',path)
    if match and match[1] in session['agent']['projects'] and method=='POST':
        if match[2]=='task-changes' and body.get('dryRun') is True: return
        if session['agent']['access']=='write' and (match[2]=='task-changes' or body.get('kind') in ['actual','comment','worklog']): return
    raise APIError(403,'Ключ агента не разрешает это действие.')

def public(entry): return {k:v for k,v in entry.items() if k!='hash'}

def route(app,method,path,body,user,session):
    if path not in ['/api/agent-keys','/api/agent-keys/revoke']: return None
    if session.get('kind')=='agent': raise APIError(403,'Ключ агента не может управлять ключами.')
    setting=app.repo.setting(SETTING,[]); entries=setting['value']
    if method=='GET' and path=='/api/agent-keys':
        return 200,[public(k) for k in entries if k['userId']==user['id']],{}
    if method=='POST' and path=='/api/agent-keys/revoke':
        entry=next((k for k in entries if k['id']==body.get('id') and k['userId']==user['id']),None)
        if entry is None: raise APIError(404,'Ключ не найден.')
        entry['revokedAt']=time.time(); app.repo.save_setting(SETTING,entries,setting['version'])
        return 200,{'ok':True},{}
    if method=='POST' and path=='/api/agent-keys':
        name=body.get('name'); projects=body.get('projects'); days=body.get('days',30); access=body.get('access','read')
        if not isinstance(name,str) or not 1<=len(name.strip())<=80 or not isinstance(projects,list) or not 1<=len(projects)<=200 or any(not isinstance(p,str) for p in projects) or len(set(projects))!=len(projects) or type(days) is not int or not 1<=days<=365 or access not in ['read','write']:
            raise APIError(422,'Укажите имя, проекты, доступ и срок от 1 до 365 дней.')
        for id in projects: app.document(id,user)
        if len(entries)>=1000: raise APIError(422,'Достигнут лимит ключей. Обратитесь к администратору.')
        secret=secrets.token_hex(32)
        entry={'id':secrets.token_hex(16),'hash':hashlib.sha256(secret.encode()).hexdigest(),'name':name.strip(),'userId':user['id'],'projects':projects,'access':access,'createdAt':time.time(),'expires':time.time()+days*86400,'revokedAt':None}
        entries.append(entry); app.repo.save_setting(SETTING,entries,setting['version'])
        return 201,{'key':secret,**public(entry)},{}
    raise APIError(405,'Метод не разрешён.')
