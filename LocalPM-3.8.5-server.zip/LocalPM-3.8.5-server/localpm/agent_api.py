"""Small server-side project projections; pagination never transfers a whole project."""
from . import core, kanban
from .storage import APIError

BRIEF = ['id','external_number','parent_id','name','status','kanban_column_id','assignee_id','owner','author',
         'start_date','finish_date','forecast_finish','duration_days','percent_complete','priority','critical','schedule_calendar']
PROJECT = ['id','name','description','start_date','finish_date','forecast_finish','status_date','percent_complete',
           'calendar_id','working_days','exceptions','working_exceptions','hours_per_day','require_plan_approval','workflow','field_definitions','custom_fields']

def page(rows, args):
    offset, limit = args.get('offset',0), args.get('limit',50)
    if type(offset) is not int or not 0 <= offset <= 1000000 or type(limit) is not int or not 1 <= limit <= 100:
        raise APIError(422,'Проверьте размер и смещение страницы.')
    return {'total':len(rows),'offset':offset,'items':rows[offset:offset+limit],
            'next_offset':offset+limit if offset+limit<len(rows) else None}

def task(doc, id):
    result = next((t for t in doc['project']['tasks'] if t['id']==id),None)
    if result is None: raise APIError(404,'Задача не найдена.')
    return result

def brief(t): return {k:t.get(k) for k in BRIEF}

def mutation(result, task_id=None):
    """The same compact receipt is used by the API and the MCP adapter."""
    if 'project_id' in result: return result
    receipt=result.get('actionReceipt',{}); p=result['project']
    proposal=next((r for r in result.get('changeRequests',[]) if r.get('user_id')==receipt.get('user') and r.get('baseVersion')==receipt.get('version',0)-1),None) if receipt.get('kind')=='plan_patch' else None
    return {'project_id':p['id'],'version':result['version'],'receipt':receipt,'replayed':result.get('replayed',False),
            'plan_submission':result.get('planSubmission') or (proposal or {}).get('id'),
            'plan_approval_status':(proposal or {}).get('status'),
            'approval_pending':bool(result.get('planSubmission')) or (proposal or {}).get('status')=='pending' or any(r.get('operationId')==receipt.get('id') and r.get('status')=='pending' for r in result.get('updates',[])),
            'task':brief(task(result,task_id)) if task_id else None,'warnings':p.get('scheduleWarnings',[])}

def read(app, user, args):
    from .application import role, actual_snapshot
    if not isinstance(args,dict): raise APIError(422,'Ожидается объект.')
    for flag in ['overdue','include_summaries']:
        if flag in args and type(args[flag]) is not bool: raise APIError(422,'Некорректный фильтр.')
    if 'expected_version' in args and (type(args['expected_version']) is not int or args['expected_version']<1): raise APIError(422,'Некорректная версия.')
    resource=args.get('resource'); id=core.valid_id(args.get('project_id'))
    doc=app.document(id,user); p=doc['project']; common={'project_id':id,'version':doc['version']}
    if args.get('expected_version') is not None and args['expected_version']!=doc['version']:
        raise APIError(409,'Проект изменился между страницами.',currentVersion=doc['version'])
    if resource=='project': return {**common,'role':role(doc,user),'project':{k:p.get(k) for k in PROJECT},'task_count':len(p['tasks']),'dependency_count':len(p['dependencies'])}
    if resource=='task':
        t=task(doc,args.get('task_id'))
        return {**common,'task':{k:v for k,v in t.items() if k!='work_logs'},'work_log_count':len(t.get('work_logs',[])),'base_actual':actual_snapshot(t)}
    if resource=='dependencies': rows=p['dependencies']
    elif resource=='comments':
        if args.get('task_id'): task(doc,args['task_id'])
        rows=[c for c in doc.get('comments',[]) if not args.get('task_id') or c.get('task_id')==args['task_id']]
    elif resource=='audit':
        if role(doc,user) not in ['manager','editor']: raise APIError(403,'История доступна руководителю и редактору.')
        rows=[r for r in reversed(doc.get('audit',[])) if not args.get('source') or r.get('source')==args['source']]
    elif resource=='members':
        return {**common,'members':[{k:u.get(k) for k in ['id','name','active','capacity']}|{'role':doc['acl'][u['id']]} for u in app.repo.users() if u['id'] in doc['acl']]}
    elif resource=='board':
        board=app.repo.board_setting() or {'version':0,'config':kanban.defaults()}; workflow=p.get('workflow',{})
        return {**common,'board':workflow.get('columns') or board['config'],'workflow':workflow,'global_board_version':board['version']}
    elif resource=='tasks':
        for key in ['query','owner','author','status','assignee_id']:
            if key in args and (not isinstance(args[key],str) or len(args[key])>500): raise APIError(422,'Некорректный фильтр.')
        parents={t.get('parent_id') for t in p['tasks']}; today=core.today(); rows=[]
        for t in p['tasks']:
            if not args.get('include_summaries',True) and t['id'] in parents: continue
            if any(args.get(k) and t.get(k)!=args[k] for k in ['owner','author','assignee_id','status']): continue
            if args.get('overdue') and (t.get('percent_complete',0)>=100 or (t.get('forecast_finish') or t['finish_date'])>=today): continue
            if args.get('query') and args['query'].casefold() not in ' '.join(str(t.get(k,'')) for k in ['name','note','external_number','owner','author']).casefold(): continue
            rows.append(brief(t))
    else: raise APIError(422,'Неизвестный ресурс.')
    return {**common,**page(rows,args)}
