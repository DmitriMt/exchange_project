"""Bounded development HTTP server. Production requires an approved reverse proxy/WSGI adaptation."""
from __future__ import annotations
import json
import logging
import socketserver
import sqlite3
import ssl
import threading
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
from .storage import APIError,json_text
from . import client_access, __version__

MAX_BODY=1536*1024*1024
STATIC={'/client.html':'client.html','/':'index.html','/index.html':'index.html','/app.js':'app.js','/core.js':'core.js','/styles.css':'styles.css'}
CSP="default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; object-src 'none'"

class Server(ThreadingHTTPServer):
    daemon_threads=False
    block_on_close=True
    allow_reuse_address=True
    def __init__(self,address,app,web_dir):
        self.app=app; self.web_dir=Path(web_dir).resolve(); self.slots=threading.BoundedSemaphore(32)
        super().__init__(address,Handler)
    def process_request(self,request,client_address):
        if not self.slots.acquire(blocking=False):
            request.close(); return
        try: super().process_request(request,client_address)
        except BaseException: self.slots.release(); raise
    def process_request_thread(self,request,client_address):
        try: super().process_request_thread(request,client_address)
        finally: self.slots.release()

class Handler(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    server_version='LocalPM-Python/'+__version__
    sys_version=''
    def setup(self): super().setup(); self.connection.settimeout(15)
    def log_message(self,fmt,*args): logging.getLogger('localpm.http').info('%s %s',self.client_address[0],fmt%args)
    def respond(self,status,payload,headers=None,api=True):
        headers=headers or {}
        binary=payload if isinstance(payload,bytes) else json_text(payload).encode('utf-8')
        self.send_response(status)
        merged={'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store' if api else 'no-cache','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin','Content-Security-Policy':CSP,'Content-Length':str(len(binary)),'Connection':'close',**headers}
        if self.path.startswith('/api/') and self.server.app.client_origin_allowed(self.headers,isinstance(self.connection,ssl.SSLSocket)) and (client_access.is_client(self.headers) or self.command=='OPTIONS'):
            merged.update({'Access-Control-Allow-Origin':self.headers['Origin'],'Vary':'Origin'})
        for k,v in merged.items(): self.send_header(k,v)
        self.end_headers(); self.close_connection=True
        if self.command!='HEAD': self.wfile.write(binary)
    def route(self):
        try:
            if len(self.path)>8192: raise APIError(414,'Слишком длинный адрес.')
            path=urlsplit(self.path).path; secure=isinstance(self.connection,ssl.SSLSocket)
            if path.startswith('/api/'):
                if self.command=='OPTIONS':
                    self.server.app.check_origin('GET',{'Host':self.headers.get('Host','')},secure)
                    if not self.server.app.client_origin_allowed(self.headers,secure): raise APIError(403,'Этот клиент не разрешён на сервере.')
                    requested={x.strip().lower() for x in self.headers.get('Access-Control-Request-Headers','').split(',') if x.strip()}
                    if self.headers.get('Access-Control-Request-Method') not in client_access.METHODS or 'x-localpm-client' not in requested or not requested<=client_access.HEADERS: raise APIError(403,'Запрос клиента не разрешён.')
                    cors={'Access-Control-Allow-Methods':', '.join(sorted(client_access.METHODS)),'Access-Control-Allow-Headers':', '.join(sorted(client_access.HEADERS)),'Access-Control-Max-Age':'300'}
                    if self.headers.get('Access-Control-Request-Private-Network')=='true': cors['Access-Control-Allow-Private-Network']='true'
                    return self.respond(204,b'',cors)
                body={}
                if self.command not in ['GET','HEAD']:
                    if self.headers.get('Transfer-Encoding'): raise APIError(400,'Chunked-запросы не поддерживаются.')
                    if not self.headers.get('Content-Type','').startswith('application/json'): raise APIError(415,'Ожидается JSON.')
                    try: length=int(self.headers.get('Content-Length','-1'))
                    except ValueError: raise APIError(400,'Некорректная длина запроса.')
                    if length<0: raise APIError(411,'Требуется Content-Length.')
                    if length>MAX_BODY: raise APIError(413,'Слишком большой запрос.')
                    raw=self.rfile.read(length)
                    if len(raw)!=length: raise APIError(400,'Неполное тело запроса.')
                    try: body=json.loads(raw or b'{}',parse_constant=lambda v:(_ for _ in ()).throw(ValueError('Non-finite JSON')))
                    except (ValueError,UnicodeDecodeError): raise APIError(400,'Некорректный JSON.')
                    if not isinstance(body,dict): raise APIError(422,'Ожидается JSON-объект.')
                status,payload,headers=self.server.app.handle(self.command,path,self.headers,body,self.client_address[0],secure)
                return self.respond(status,payload,headers)
            self.server.app.check_origin('GET',self.headers,secure)
            if self.command not in ['GET','HEAD']: raise APIError(405,'Метод не разрешён.')
            if path not in STATIC: raise APIError(404,'Файл не найден.')
            file=self.server.web_dir/STATIC[path]
            types={'.html':'text/html','.js':'text/javascript','.css':'text/css'}
            self.respond(200,file.read_bytes(),{'Content-Type':types[file.suffix]+'; charset=utf-8'},api=False)
        except APIError as e: self.respond(e.status,{'error':str(e),**e.extra})
        except sqlite3.IntegrityError: self.respond(409,{'error':'Запись с таким идентификатором или логином уже существует.'})
        except sqlite3.Error:
            logging.exception('Database error'); self.respond(503,{'error':'База временно недоступна.'})
        except (ValueError,TypeError,KeyError,RecursionError) as e: self.respond(422,{'error':str(e) or 'Некорректные данные.'})
        except OSError:
            logging.exception('Storage/network error'); self.respond(503,{'error':'Хранилище или соединение недоступно.'})
        except Exception:
            logging.exception('Unhandled request error'); self.respond(500,{'error':'Внутренняя ошибка сервера.'})
    do_OPTIONS=route
    do_GET=route
    do_HEAD=route
    do_POST=route
    do_PUT=route
    do_PATCH=route
    do_DELETE=route
