"""Bounded plan patches for integrations, using the normal plan/approval pipeline."""
import hashlib
from . import core
from .application import role, response_doc
from .storage import APIError, json_text

PLAN_FIELDS = {'name','duration_days','is_milestone','is_manual','start_date','finish_date',
               'parent_id','sort_order','owner','assignee_id','note','constraint_snet','deadline',
               'author','effort_hours','priority','tags','task_type','schedule_calendar','field_values',
               'custom1','custom2','custom3','custom4','custom5'}

def build_patch(project, changes, links):
    if not isinstance(changes,list) or not isinstance(links,list) or not 1 <= len(changes)+len(links) <= 100:
        raise APIError(422,'Нужно от 1 до 100 изменений задач и связей.')
    draft=core.clone(project); by={t['id']:t for t in draft['tasks']}; seen=set(); details=[]
    for change in changes:
        if not isinstance(change,dict) or set(change)-{'task_id','create','fields'}:
            raise APIError(422,'Некорректное изменение задачи.')
        id=core.valid_id(change.get('task_id')); fields=change.get('fields'); create=change.get('create',False)
        if type(create) is not bool or not isinstance(fields,dict) or not fields or set(fields)-PLAN_FIELDS:
            raise APIError(422,'Можно менять только поля плана. Статус и факт отправляются отдельно.')
        if id in seen: raise APIError(422,'Задача повторяется в одном пакете.')
        seen.add(id)
        if create:
            if id in by: raise APIError(409,'Задача с таким ID уже существует.')
            if not isinstance(fields.get('name'),str) or not fields['name'].strip(): raise APIError(422,'Новой задаче нужно название.')
            task={'id':id,'name':fields['name'],'duration_days':1,'sort_order':max([t.get('sort_order',0) for t in by.values()]+[-1])+1}
            draft['tasks'].append(task); by[id]=task
        else:
            task=by.get(id)
            if task is None: raise APIError(404,'Задача не найдена.')
        details.append({'task_id':id,'created':create,'before':None if create else {k:task.get(k) for k in fields},'after':fields})
        task.update(core.clone(fields))
    seen=set(); dependencies={d['id']:d for d in draft['dependencies']}
    for change in links:
        if not isinstance(change,dict) or set(change)-{'id','pred_id','succ_id','type','lag_workdays','remove'}:
            raise APIError(422,'Некорректное изменение связи.')
        id=core.valid_id(change.get('id')); remove=change.get('remove',False)
        if type(remove) is not bool or id in seen: raise APIError(422,'Проверьте ID и действие связи.')
        seen.add(id)
        if remove:
            if set(change)-{'id','remove'}: raise APIError(422,'Для удаления связи передайте только id и remove.')
            if id not in dependencies: raise APIError(404,'Связь не найдена.')
            del dependencies[id]
        else:
            if not {'pred_id','succ_id','type'} <= change.keys(): raise APIError(422,'Укажите обе задачи и тип связи.')
            dependencies[id]={k:v for k,v in change.items() if k!='remove'}
    draft['dependencies']=list(dependencies.values())
    return draft,details

def submit(app, doc, user, headers, body, secure):
    if role(doc,user) not in ['manager','editor']: raise APIError(403,'Изменять план может руководитель или редактор.')
    if set(body)-{'changes','dependency_changes','expectedVersion','operationId','dryRun'}: raise APIError(422,'Неизвестное поле пакета.')
    expected=body.get('expectedVersion'); dry=body.get('dryRun',False)
    if type(expected) is not int or expected<1 or type(dry) is not bool: raise APIError(422,'Нужны версия проекта и корректный dryRun.')
    changes=body.get('changes',[]); links=body.get('dependency_changes',[])
    operation=None if dry else core.valid_id(body.get('operationId'))
    fingerprint=hashlib.sha256(json_text({'kind':'plan_patch','user':user['id'],'expectedVersion':expected,'changes':changes,'dependency_changes':links},sort_keys=True).encode()).hexdigest()
    if not dry:
        previous=doc.get('action_receipts',{}).get(operation)
        if previous:
            if previous['hash']!=fingerprint: raise APIError(409,'ID операции использован с другим пакетом.')
            return 200,{**response_doc(doc,user),'actionReceipt':previous,'replayed':True},{}
        if len(doc.get('action_receipts',{}))>=20000: raise APIError(422,'Заполнен журнал повторов проекта.')
    if expected!=doc['version']: raise APIError(409,'Есть более свежая версия проекта.',currentVersion=doc['version'])
    draft,details=build_patch(doc['project'],changes,links)
    checked=core.calculate(draft,strict=True); app.validate_assignments(checked,doc['acl'])
    if dry:
        return 200,{'dryRun':True,'projectId':doc['project']['id'],'version':doc['version'],
                    'requiresPlanApproval':role(doc,user)=='editor' and bool(doc['project'].get('require_plan_approval')),
                    'changes':details,'dependencyChanges':links,'finish':checked['finish_date'],
                    'forecast':checked['forecast_finish'],'warnings':checked['scheduleWarnings'],
                    'tasks':[{k:t.get(k) for k in ['id','external_number','start_date','finish_date','critical','total_float']} for t in checked['tasks'] if t['id'] in {c['task_id'] for c in changes}]},{}
    previous_context=app.action_context
    app.action_context={'id':operation,'hash':fingerprint,'kind':'plan_patch','user':user['id'],'at':core.now(),'changes':[{'task_id':c['task_id'],'task_name':next(t['name'] for t in checked['tasks'] if t['id']==c['task_id']),'fields':sorted(c['fields'])} for c in changes],'preview':{'finish':checked['finish_date'],'forecast':checked['forecast_finish'],'warnings':checked['scheduleWarnings'][:20]}}
    try:
        status,result,extra=app._handle('PUT','/api/projects/'+doc['project']['id'],headers,
                                     {'project':draft,'expectedVersion':expected,'operationId':operation},'127.0.0.1',secure,internal=True)
        receipt=app.repo.load(doc['project']['id']).get('action_receipts',{}).get(operation)
        if not receipt: raise APIError(503,'Результат не подтверждён. Повторите тот же пакет с тем же ID.')
        return status,{**result,'actionReceipt':receipt,'replayed':False},extra
    finally:
        app.action_context=previous_context
