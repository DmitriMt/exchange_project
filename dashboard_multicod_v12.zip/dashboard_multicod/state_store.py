"""Durable snapshot history, planning audit and per-user saved views."""
import hashlib
import json
import re
import sqlite3
import uuid
import csv
import io
from contextlib import contextmanager
from datetime import datetime, timezone


def now():
    return datetime.now(timezone.utc).isoformat()


def stats(rows):
    entities = [r for r in rows if r['record_type'] == 'entity']
    budget = [r for r in rows if r['record_type'] == 'budget']
    return dict(objects=len(entities), as_count=sum(r['category'] == 'АС' for r in entities),
                fp_count=sum(r['category'] == 'ФП' for r in entities),
                **{k: sum(float(r[k]) for r in (entities if k.startswith('pshe_') else budget) if r.get(k) != '')
                   for k in ['budget_rub', 'cpu', 'ram_gb', 'disk_gb', 'pshe_change_standin', 'pshe_run_standin', 'pshe_vendor_standin']})


def clean_plan(value):
    if not isinstance(value, dict):
        raise ValueError('Неверный план')
    result = {k: str(value.get(k) or '').strip() for k in ['year', 'quarter', 'target_date', 'site', 'owner', 'status', 'notes']}
    if result['year'] and not re.fullmatch(r'20\d\d', result['year']):
        raise ValueError('Укажите год от 2000 до 2099')
    if result['quarter'] not in ['', '1', '2', '3', '4']:
        raise ValueError('Квартал должен быть от 1 до 4')
    if result['status'] not in ['', 'Запланировано', 'Подготовка', 'Развёрнуто', 'Принято', 'Приостановлено']:
        raise ValueError('Неизвестный статус')
    if result['target_date']:
        d = datetime.strptime(result['target_date'], '%Y-%m-%d')
        if result['year'] and int(result['year']) != d.year:
            raise ValueError('Год не совпадает с целевой датой')
        if result['quarter'] and int(result['quarter']) != (d.month - 1) // 3 + 1:
            raise ValueError('Квартал не совпадает с целевой датой')
    if len(result['notes']) > 4000 or any(len(result[k]) > 250 for k in ['owner', 'site']):
        raise ValueError('Слишком длинное поле плана')
    return result


class StateStore:
    def __init__(self, path):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        with self.db() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS snapshots(id TEXT PRIMARY KEY, at TEXT, date TEXT, name TEXT, hash TEXT, stats TEXT, csv BLOB, plans TEXT);
                CREATE TABLE IF NOT EXISTS plans(ci TEXT PRIMARY KEY, data TEXT);
                CREATE TABLE IF NOT EXISTS plan_events(id TEXT PRIMARY KEY, ci TEXT, at TEXT, data TEXT);
                CREATE TABLE IF NOT EXISTS views(user TEXT, page TEXT, name TEXT, data TEXT, PRIMARY KEY(user,page,name));
            ''')
            if 'page' not in {r['name'] for r in db.execute('PRAGMA table_info(views)')}:
                db.execute('BEGIN IMMEDIATE')
                db.execute('ALTER TABLE views RENAME TO views_legacy')
                db.execute('CREATE TABLE views(user TEXT,page TEXT,name TEXT,data TEXT,PRIMARY KEY(user,page,name))')
                for row in db.execute('SELECT * FROM views_legacy').fetchall():
                    value = json.loads(row['data'])
                    page = value.get('page') or 'overview'
                    page = 'overview' if page == 'saved' else page
                    value['page'] = page
                    db.execute('INSERT INTO views VALUES(?,?,?,?)', (row['user'], page, row['name'], json.dumps(value, ensure_ascii=False)))
                db.execute('DROP TABLE views_legacy')

    @contextmanager
    def db(self):
        db = sqlite3.connect(self.path, timeout=20)
        db.row_factory = sqlite3.Row
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def list(self):
        with self.db() as db:
            return [dict(id=r['id'], at=r['at'], date=r['date'], name=r['name'], hash=r['hash'], stats=json.loads(r['stats']))
                    for r in db.execute('SELECT id,at,date,name,hash,stats FROM snapshots ORDER BY date DESC,at DESC')]

    def snapshot(self, key):
        with self.db() as db:
            r = db.execute('SELECT * FROM snapshots WHERE id=?', (key,)).fetchone()
            if r is None:
                raise KeyError(key)
            return dict(id=r['id'], at=r['at'], date=r['date'], name=r['name'], csv=bytes(r['csv']), plans=json.loads(r['plans']))

    def commit(self, raw, rows, name, date, base=None):
        datetime.strptime(date, '%Y-%m-%d')
        digest = hashlib.sha256(raw).hexdigest()
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            latest = db.execute('SELECT id,hash,date FROM snapshots ORDER BY date DESC,at DESC LIMIT 1').fetchone()
            if base is not None and base != (latest['id'] if latest else ''):
                raise RuntimeError('Данные уже обновил другой пользователь. Повторите предпросмотр.')
            if latest and latest['hash'] == digest and latest['date'] == date:
                return latest['id']
            plans = {r['ci']: json.loads(r['data']) for r in db.execute('SELECT * FROM plans')}
            key = uuid.uuid4().hex
            db.execute('INSERT INTO snapshots VALUES(?,?,?,?,?,?,?,?)',
                       (key, now(), date, str(name)[:250], digest, json.dumps(stats(rows)), raw, json.dumps(plans)))
            return key

    def planning(self):
        with self.db() as db:
            return dict(plans={r['ci']: json.loads(r['data']) for r in db.execute('SELECT * FROM plans')},
                        events=[dict(ci=r['ci'], at=r['at'], **json.loads(r['data'])) for r in db.execute('SELECT * FROM plan_events ORDER BY at DESC')])

    def save_plan(self, ci, value, revision, user):
        if not re.fullmatch(r'CI\d+', ci):
            raise ValueError('Неверный CI-ID')
        plan = clean_plan(value)
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            old = db.execute('SELECT data FROM plans WHERE ci=?', (ci,)).fetchone()
            before = json.loads(old['data']) if old else {}
            if revision != before.get('revision', 0):
                raise RuntimeError('План изменён другим пользователем. Откройте карточку заново.')
            plan.update(revision=revision + 1, at=now(), user=user)
            db.execute('INSERT OR REPLACE INTO plans VALUES(?,?)', (ci, json.dumps(plan, ensure_ascii=False)))
            event = dict(before=before, after=plan, user=user)
            db.execute('INSERT INTO plan_events VALUES(?,?,?,?)', (uuid.uuid4().hex, ci, plan['at'], json.dumps(event, ensure_ascii=False)))
        return plan

    def views(self, user):
        with self.db() as db:
            return [dict(name=r['name'], value=json.loads(r['data'])) for r in db.execute('SELECT * FROM views WHERE user=? ORDER BY name', (user,))]

    def save_view(self, user, name, value):
        if not isinstance(name, str) or not name.strip() or len(name) > 100 or not isinstance(value, dict):
            raise ValueError('Неверное название представления')
        if len(json.dumps(value)) > 500000:
            raise ValueError('Слишком большое представление')
        page = str(value.get('page') or 'overview')
        if page == 'saved':
            page = 'overview'
        value = dict(value, page=page)
        with self.db() as db:
            db.execute('INSERT OR REPLACE INTO views VALUES(?,?,?,?)', (user, page, name.strip(), json.dumps(value, ensure_ascii=False)))

    def update_view(self, user, name, action, new_name=None, page='overview'):
        with self.db() as db:
            if action == 'delete':
                db.execute('DELETE FROM views WHERE user=? AND page=? AND name=?', (user, page, name))
            elif action == 'rename':
                if not isinstance(new_name, str) or not new_name.strip() or len(new_name) > 100:
                    raise ValueError('Неверное название закладки')
                if new_name != name and db.execute('SELECT 1 FROM views WHERE user=? AND page=? AND name=?', (user, page, new_name)).fetchone():
                    raise ValueError('Закладка с таким названием уже существует')
                db.execute('UPDATE views SET name=? WHERE user=? AND page=? AND name=?', (new_name.strip(), user, page, name))
            else:
                raise ValueError('Неизвестное действие')

    def import_backup(self, value, user, validator, fields):
        if not isinstance(value, dict) or value.get('format') != 'multicod-history' or value.get('version') != 1:
            raise ValueError('Неверный файл истории')
        snaps = value.get('snapshots')
        if not isinstance(snaps, list) or len(snaps) > 1000:
            raise ValueError('Неверное число версий')
        def timestamp(text):
            d = datetime.fromisoformat(str(text).replace('Z', '+00:00'))
            if d.tzinfo is None:
                raise ValueError('Не указан часовой пояс версии')
            return d.astimezone(timezone.utc).isoformat()
        def plans_map(source):
            result = {}
            for ci, p in source.items():
                if not re.fullmatch(r'CI\d+', ci):
                    raise ValueError('Неверный CI-ID плана')
                result[ci] = dict(clean_plan(p), revision=int(p.get('revision', 0)),
                                  at=timestamp(p.get('at')), user=str(p.get('user', user))[:100])
            return result
        added = 0
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            for s in snaps:
                if not isinstance(s, dict) or not re.fullmatch(r'[A-Za-z0-9_-]{1,150}', str(s.get('id', ''))):
                    raise ValueError('Неверный идентификатор версии')
                datetime.strptime(s['date'], '%Y-%m-%d')
                rows = validator(s['csv'].lstrip('\ufeff').encode('utf-8-sig'))
                out = io.StringIO(newline='')
                writer = csv.DictWriter(out, fieldnames=fields, delimiter=';')
                writer.writeheader()
                writer.writerows(rows)
                raw = out.getvalue().encode('utf-8-sig')
                existing = db.execute('SELECT csv FROM snapshots WHERE id=?', (s['id'],)).fetchone()
                if existing:
                    if bytes(existing['csv']) != raw:
                        raise ValueError('Конфликт идентификатора версии: ' + s['id'])
                    continue
                db.execute('INSERT INTO snapshots VALUES(?,?,?,?,?,?,?,?)',
                           (s['id'], timestamp(s['at']), s['date'], str(s.get('name', 'Импорт истории'))[:250],
                            hashlib.sha256(raw).hexdigest(), json.dumps(stats(rows)), raw,
                            json.dumps(plans_map(s.get('plans', {})), ensure_ascii=False)))
                added += 1
            workspace = value.get('workspace', {})
            for ci, p in plans_map(workspace.get('plans', {})).items():
                existing = db.execute('SELECT data FROM plans WHERE ci=?', (ci,)).fetchone()
                if not existing or p['at'] > json.loads(existing['data']).get('at', ''):
                    db.execute('INSERT OR REPLACE INTO plans VALUES(?,?)', (ci, json.dumps(p, ensure_ascii=False)))
            for e in workspace.get('events', []):
                ci, at = e['ci'], timestamp(e['at'])
                if not re.fullmatch(r'CI\d+', ci):
                    raise ValueError('Неверный CI-ID в журнале')
                body = dict(before=e.get('before', {}), after=e['after'], user=str(e.get('user', user))[:100])
                clean_plan(body['before'])
                clean_plan(body['after'])
                event_id = hashlib.sha256(json.dumps([ci, at, body], sort_keys=True).encode()).hexdigest()
                db.execute('INSERT OR IGNORE INTO plan_events VALUES(?,?,?,?)', (event_id, ci, at, json.dumps(body, ensure_ascii=False)))
            for v in workspace.get('views', []):
                if not isinstance(v.get('name'), str) or len(v['name']) > 100 or not isinstance(v.get('value'), dict):
                    raise ValueError('Неверная закладка')
                page = v['value'].get('page') or 'overview'
                page = 'overview' if page == 'saved' else page
                db.execute('INSERT OR IGNORE INTO views VALUES(?,?,?,?)', (user, page, v['name'], json.dumps(dict(v['value'], page=page), ensure_ascii=False)))
        return dict(added=added, message='История и планы перенесены; закладки закреплены за текущим пользователем')
