import json
import sqlite3
from pathlib import Path
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor

from server import ROOT, parse_data
from state_store import StateStore


class StateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = (ROOT / 'data/dashboard.csv').read_bytes()
        cls.rows = parse_data(cls.raw)

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / 'state.sqlite3'
        self.store = StateStore(self.path)
        self.first = self.store.commit(self.raw, self.rows, 'Initial', '2026-11-02', '')
        self.ci = next(r['id_ke'] for r in self.rows if r['record_type'] == 'entity')

    def tearDown(self):
        self.temp.cleanup()

    def test_persistent_history_dedupe_and_backfill(self):
        self.assertEqual(self.store.commit(self.raw, self.rows, 'Same', '2026-11-02', self.first), self.first)
        self.assertEqual(len(self.store.list()), 1)
        new = self.store.commit(self.raw, self.rows, 'New', '2026-11-03', self.first)
        self.store.commit(self.raw, self.rows, 'Backfill', '2026-10-01', new)
        reopened = StateStore(self.path)
        self.assertEqual(reopened.list()[0]['id'], new)
        self.assertEqual(len(reopened.list()), 3)
        self.assertEqual(reopened.snapshot(self.first)['csv'], self.raw)

    def test_snapshot_plan_is_frozen_and_events_survive(self):
        p = self.store.save_plan(self.ci, {'year': '2027', 'status': 'Подготовка'}, 0, 'operator')
        second = self.store.commit(self.raw, self.rows, 'Later', '2026-11-03', self.first)
        self.store.save_plan(self.ci, {'year': '2027', 'status': 'Принято'}, p['revision'], 'operator')
        self.assertEqual(self.store.snapshot(self.first)['plans'], {})
        self.assertEqual(self.store.snapshot(second)['plans'][self.ci]['status'], 'Подготовка')
        self.assertEqual(self.store.planning()['plans'][self.ci]['status'], 'Принято')
        self.assertEqual(len(StateStore(self.path).planning()['events']), 2)

    def test_concurrent_plan_edits_do_not_overwrite(self):
        def edit(owner):
            try:
                self.store.save_plan(self.ci, {'owner': owner}, 0, owner)
                return 'saved'
            except RuntimeError:
                return 'conflict'
        with ThreadPoolExecutor(2) as pool:
            self.assertCountEqual(list(pool.map(edit, ['one', 'two'])), ['saved', 'conflict'])
        self.assertEqual(len(self.store.planning()['events']), 1)

    def test_stale_upload_and_invalid_plan_rejected(self):
        self.store.commit(self.raw, self.rows, 'Later', '2026-11-03', self.first)
        with self.assertRaises(RuntimeError):
            self.store.commit(self.raw, self.rows, 'Stale', '2026-11-04', self.first)
        with self.assertRaises(ValueError):
            self.store.save_plan(self.ci, {'year': '2027', 'quarter': '2', 'target_date': '2027-02-01'}, 0, 'operator')
        self.assertEqual(self.store.planning()['events'], [])

    def test_saved_views_are_private_per_user(self):
        self.store.save_view('alice', 'Мой ДИТ', {'dit': 'A'})
        self.assertEqual(self.store.views('bob'), [])
        self.assertEqual(self.store.views('alice')[0]['value']['dit'], 'A')
        self.store.save_view('bob', 'Мой ДИТ', {'dit': 'B'})
        self.store.update_view('alice', 'Мой ДИТ', 'rename', 'Новое имя')
        self.assertEqual(self.store.views('bob')[0]['name'], 'Мой ДИТ')
        self.store.update_view('alice', 'Новое имя', 'delete')
        self.assertEqual(self.store.views('alice'), [])
        self.assertEqual(self.store.views('bob')[0]['value']['dit'], 'B')

    def test_bookmarks_allow_same_name_in_different_pages(self):
        self.store.save_view('alice', 'Мой ДИТ', {'page': 'volume', 'dit': 'A'})
        self.store.save_view('alice', 'Мой ДИТ', {'page': 'kts', 'dit': 'B'})
        self.assertEqual(len(self.store.views('alice')), 2)
        self.store.update_view('alice', 'Мой ДИТ', 'delete', page='volume')
        self.assertEqual(self.store.views('alice')[0]['value']['page'], 'kts')

    def test_old_bookmarks_schema_is_migrated_without_loss(self):
        old = Path(self.temp.name) / 'old.sqlite3'
        with sqlite3.connect(old) as db:
            db.execute('CREATE TABLE views(user TEXT,name TEXT,data TEXT,PRIMARY KEY(user,name))')
            db.execute('INSERT INTO views VALUES(?,?,?)', ('alice', 'Old', json.dumps({'page': 'volume', 'dit': 'A'})))
        migrated = StateStore(old)
        self.assertEqual(migrated.views('alice')[0]['name'], 'Old')
        migrated.save_view('alice', 'Old', {'page': 'kts'})
        self.assertEqual(len(migrated.views('alice')), 2)

    def test_browser_backup_migrates_to_server_atomically(self):
        date = '2026-11-03T10:00:00Z'
        backup = {'format': 'multicod-history', 'version': 1,
                  'snapshots': [{'id': 'browser-snapshot', 'at': date, 'date': '2026-11-03', 'name': 'HTML',
                                 'csv': self.raw.decode('utf-8-sig'), 'plans': {}}],
                  'workspace': {'plans': {self.ci: {'year': '2027', 'status': 'Подготовка', 'revision': 1, 'at': date}},
                                'events': [], 'views': [{'name': 'Личная', 'value': {'page': 'volume'}}]}}
        from prepare_data import FIELDS
        result = self.store.import_backup(backup, 'alice', parse_data, FIELDS)
        self.assertEqual(result['added'], 1)
        self.assertEqual(self.store.list()[0]['id'], 'browser-snapshot')
        self.assertEqual(self.store.views('bob'), [])
        self.assertEqual(len(self.store.views('alice')), 1)
        self.assertEqual(self.store.import_backup(backup, 'alice', parse_data, FIELDS)['added'], 0)
        backup['snapshots'].append({'id': 'bad', 'date': 'invalid'})
        with self.assertRaises(ValueError):
            self.store.import_backup(backup, 'alice', parse_data, FIELDS)
        self.assertEqual(len(self.store.list()), 2)

    def test_audit_rows_not_included_in_main_totals(self):
        meta = self.store.list()[0]['stats']
        self.assertEqual(meta['objects'], 1271)
        self.assertAlmostEqual(meta['budget_rub'], 8883691276.247816, places=3)
        self.assertEqual(sum(r['record_type'] == 'budget_outside' for r in self.rows), 1924)


if __name__ == '__main__':
    unittest.main()
