'use strict';
const planKeys=['year','quarter','target_date','site','owner','status','notes'];
const planStatuses=['Запланировано','Подготовка','Развёрнуто','Принято','Приостановлено'];
const stateFields=['block','dit','category','criticality','search'];
let stateRepo=null,versions=[],liveVersion='',viewVersion='',workspace={plans:{},events:[],views:[]},versionPlans={},stateReady=false,canEdit=false,storageMode='',pendingUpload=null,activeCard='';
let currentUser='Локальный пользователь';
const stateId=()=>Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,12);
function csvEncode(records){const quote=v=>/[";\r\n]/.test(String(v??''))?'"'+String(v??'').replace(/"/g,'""')+'"':String(v??'');return '\uFEFF'+[LOCAL_FIELDS_SAFE(),...records.map(r=>LOCAL_FIELDS_SAFE().map(k=>r[k]))].map(r=>r.map(quote).join(';')).join('\r\n')+'\r\n';}
function LOCAL_FIELDS_SAFE(){return typeof LOCAL_FIELDS!=='undefined'?LOCAL_FIELDS:CSV_FIELDS;}
function datasetStats(records){const e=records.filter(r=>r.record_type==='entity'),b=records.filter(r=>r.record_type==='budget');return {objects:e.length,as_count:e.filter(r=>r.category==='АС').length,fp_count:e.filter(r=>r.category==='ФП').length,...Object.fromEntries(exportFields.map(k=>[k,sum(k.startsWith('pshe_')?e:b,k)]))};}
function datasetDiff(before,after){
  function index(records){const map=new Map(records.filter(r=>r.record_type==='entity').map(r=>[r.id_ke,{row:r,budget:[]}]));for(const r of records)if(r.record_type==='budget'&&map.has(r.id_ke))map.get(r.id_ke).budget.push(r);return map;}
  const old=index(before),next=index(after),added=[],removed=[],changed=[];
  const signature=g=>JSON.stringify([Object.keys(g.row).filter(k=>k!=='snapshot').sort().map(k=>[k,g.row[k]]),g.budget.map(b=>[b.budget_consumption,b.stand,b.budget_rub,b.cpu,b.ram_gb,b.disk_gb]).map(JSON.stringify).sort()]);
  for(const [id,g]of next)if(!old.has(id))added.push(g.row);else if(signature(g)!==signature(old.get(id)))changed.push({id,name:g.row.name,before:old.get(id).row,after:g.row,budgetBefore:sum(old.get(id).budget,'budget_rub'),budgetAfter:sum(g.budget,'budget_rub')});
  for(const [id,g]of old)if(!next.has(id))removed.push(g.row);
  return {added,removed,changed,before:datasetStats(before),after:datasetStats(after)};
}
function cleanPlan(value){
  const p=Object.fromEntries(planKeys.map(k=>[k,String(value?.[k]??'').trim()]));
  if(p.year&&!/^20\d\d$/.test(p.year))throw new Error('Год должен быть от 2000 до 2099');
  if(p.quarter&&!['1','2','3','4'].includes(p.quarter))throw new Error('Квартал должен быть от 1 до 4');
  if(p.status&&!planStatuses.includes(p.status))throw new Error('Неизвестный статус');
  if(p.target_date){const d=new Date(p.target_date+'T12:00:00Z');if(Number.isNaN(d.valueOf())||d.toISOString().slice(0,10)!==p.target_date)throw new Error('Неверная целевая дата');if(p.year&&Number(p.year)!==d.getUTCFullYear())throw new Error('Год не совпадает с датой');if(p.quarter&&Number(p.quarter)!==Math.floor(d.getUTCMonth()/3)+1)throw new Error('Квартал не совпадает с датой');}
  if(p.notes.length>4000||p.owner.length>250||p.site.length>250)throw new Error('Слишком длинное поле плана');return p;
}
class BrowserRepo{
  constructor(db){this.db=db;this.memory=new Map();this.profile='Локальный пользователь';}
  async get(store,key){if(!this.db)return structuredClone(this.memory.get(store+':'+key));return new Promise((resolve,reject)=>{const r=this.db.transaction(store).objectStore(store).get(key);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
  async all(store){if(!this.db)return [...this.memory].filter(([k])=>k.startsWith(store+':')).map(([,v])=>structuredClone(v));return new Promise((resolve,reject)=>{const r=this.db.transaction(store).objectStore(store).getAll();r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
  async batch(items){if(!this.db){for(const [s,k,v]of items)this.memory.set(s+':'+k,structuredClone(v));return;}return new Promise((resolve,reject)=>{const tx=this.db.transaction([...new Set(items.map(r=>r[0]))],'readwrite');for(const [s,k,v]of items)tx.objectStore(s).put(v,k);tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||new Error('Запись отменена'));});}
  async list(){return (await this.all('meta')).sort((a,b)=>b.date.localeCompare(a.date)||b.at.localeCompare(a.at));}
  async getSnapshot(id){const s=await this.get('snapshots',id);if(!s)throw new Error('Версия не найдена');return {...s,rows:parseLocalCsv(s.csv)};}
  async settings(){const s=await this.get('settings','workspace')||{plans:{},events:[],views:[]};const map=s.viewsByUser||{'Локальный пользователь':s.views||[]};return {...s,viewsByUser:map,views:Object.prototype.hasOwnProperty.call(map,this.profile)?map[this.profile]:[],profiles:Object.keys(map)};}
  async mutateSettings(fn){
    if(!this.db){const s=await this.settings(),result=fn(s);await this.batch([['settings','workspace',s]]);return result;}
    return new Promise((resolve,reject)=>{let result;const tx=this.db.transaction('settings','readwrite'),store=tx.objectStore('settings'),get=store.get('workspace');get.onsuccess=()=>{try{const s=get.result||{plans:{},events:[],views:[]};result=fn(s);store.put(s,'workspace');}catch(e){tx.abort();reject(e);}};tx.oncomplete=()=>resolve(result);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||new Error('Запись отменена'));});
  }
  async commit(records,name,date,base){const list=await this.list();if(base!==undefined&&base!==(list[0]?.id||''))throw new Error('Появилась новая версия. Повторите предпросмотр.');const csv=csvEncode(records);if(list[0]){const old=await this.get('snapshots',list[0].id);if(old.csv===csv&&old.date===date)return old.id;}
    const id=stateId(),at=new Date().toISOString(),settings=await this.settings(),meta={id,at,date,name,stats:datasetStats(records)};await this.batch([['snapshots',id,{...meta,csv,plans:settings.plans}],['meta',id,meta]]);return id;
  }
  async savePlan(ci,value,revision){return this.mutateSettings(s=>{const before=s.plans[ci]||{};if((before.revision||0)!==revision)throw new Error('План изменён. Откройте карточку заново.');const after={...cleanPlan(value),revision:revision+1,at:new Date().toISOString(),user:this.profile};s.plans[ci]=after;s.events.unshift({id:stateId(),ci,at:after.at,before,after,user:after.user});return after;});}
  async saveView(name,value){return this.mutateSettings(s=>{s.viewsByUser=s.viewsByUser||{'Локальный пользователь':s.views||[]};const list=Object.prototype.hasOwnProperty.call(s.viewsByUser,this.profile)?s.viewsByUser[this.profile]:[];s.viewsByUser[this.profile]=[...list.filter(v=>v.name!==name||v.value.page!==value.page),{name,value}];});}
  async updateView(name,action,newName,section=page){return this.mutateSettings(s=>{s.viewsByUser=s.viewsByUser||{'Локальный пользователь':s.views||[]};const list=s.viewsByUser[this.profile]||[],match=v=>v.name===name&&v.value.page===section;if(action==='delete')s.viewsByUser[this.profile]=list.filter(v=>!match(v));else{if(list.some(v=>v.name===newName&&v.name!==name&&v.value.page===section))throw new Error('Закладка с таким названием уже существует');s.viewsByUser[this.profile]=list.map(v=>match(v)?{...v,name:newName}:v);}});}
  async changeProfile(name){name=String(name||'').trim();if(!name||name.length>80||['__proto__','constructor','prototype'].includes(name))throw new Error('Введите имя профиля до 80 символов');await this.mutateSettings(s=>{s.viewsByUser=s.viewsByUser||{'Локальный пользователь':s.views||[]};if(!Object.prototype.hasOwnProperty.call(s.viewsByUser,name))s.viewsByUser[name]=[];s.lastProfile=name;});this.profile=name;return this.settings();}
  async backup(){return {format:'multicod-history',version:1,snapshots:await this.all('snapshots'),workspace:await this.settings()};}
  async restore(value){
    if(value?.format!=='multicod-history'||value.version!==1||!Array.isArray(value.snapshots)||value.snapshots.length>1000)throw new Error('Неверный файл истории');
    const items=[];for(const s of value.snapshots){if(typeof s.id!=='string'||!s.id||s.id.length>150||typeof s.csv!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(s.date)||!Number.isFinite(Date.parse(s.at)))throw new Error('Неверная версия истории');const data=parseLocalCsv(s.csv),existing=await this.get('snapshots',s.id);if(existing&&existing.csv!==s.csv)throw new Error('Конфликт идентификаторов истории');const plans={};for(const [ci,p]of Object.entries(s.plans||{})){if(!/^CI\d+$/.test(ci))throw new Error('Неверный CI-ID плана');plans[ci]={...p,...cleanPlan(p)};}const snap={id:s.id,at:s.at,date:s.date,name:String(s.name||'Импорт истории').slice(0,250),csv:csvEncode(data),plans,stats:datasetStats(data)},meta={...snap};delete meta.csv;delete meta.plans;items.push(['snapshots',snap.id,snap],['meta',snap.id,meta]);}
    const current=await this.settings(),incoming=value.workspace||{};for(const [ci,p]of Object.entries(incoming.plans||{})){if(!/^CI\d+$/.test(ci))throw new Error('Неверный CI-ID');if(!current.plans[ci]||String(p.at)>String(current.plans[ci].at))current.plans[ci]={...p,...cleanPlan(p)};}
    current.viewsByUser=current.viewsByUser||{'Локальный пользователь':current.views||[]};
    const maps=incoming.viewsByUser||{[this.profile]:incoming.views||[]};
    for(const [profile,views]of Object.entries(maps)){if(!profile||profile.length>80||['__proto__','constructor','prototype'].includes(profile)||!Array.isArray(views))throw new Error('Неверный профиль закладок');if(!Object.prototype.hasOwnProperty.call(current.viewsByUser,profile))current.viewsByUser[profile]=[];const list=current.viewsByUser[profile];for(const v of views)if(typeof v.name==='string'&&v.name.length<=100&&!list.some(x=>x.name===v.name&&x.value.page===v.value.page))list.push({name:v.name,value:cleanView(v.value)});}
    const eventKey=e=>JSON.stringify([e.ci,e.at,e.before,e.after]);const known=new Set(current.events.map(eventKey));for(const e of incoming.events||[])if(/^CI\d+$/.test(e.ci)&&!known.has(eventKey(e))){cleanPlan(e.after);current.events.push(e);}items.push(['settings','workspace',current]);await this.batch(items);
  }
}
class ServerRepo{
  async list(){return api('/api/snapshots');}
  async getSnapshot(id){return api('/api/snapshots/'+encodeURIComponent(id));}
  async settings(){const [p,v]=await Promise.all([api('/api/planning'),api('/api/views')]);return {...p,views:v};}
  async commit(records,name,date,base){const backup=await ensurePreloadBackup(base);const r=await api('/api/upload',{method:'POST',headers:{'Content-Type':'text/csv','X-Source-Name':encodeURIComponent(name),'X-Snapshot-Date':date,'X-Base-Snapshot':base,'X-Backup-Id':backup},body:new TextEncoder().encode(csvEncode(records))});return r.snapshot_id;}
  async savePlan(ci,value,revision){return api('/api/planning',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ci,value,revision})});}
  async saveView(name,value){return api('/api/views',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,value})});}
  async updateView(name,action,new_name){return api('/api/views',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,action,new_name,page})});}
  async restore(value){const list=await this.list();const backup=await ensurePreloadBackup(list[0]?.id||'');return api('/api/state/import',{method:'POST',headers:{'Content-Type':'application/json','X-Backup-Id':backup},body:JSON.stringify(value)});}
}
async function openBrowserRepo(){
  return new Promise((resolve,reject)=>{if(typeof indexedDB==='undefined')return reject(new Error('Хранилище браузера недоступно'));const r=indexedDB.open('multicod-history-v1',1);r.onupgradeneeded=()=>{for(const s of ['snapshots','meta','settings'])if(!r.result.objectStoreNames.contains(s))r.result.createObjectStore(s);};r.onsuccess=()=>resolve(new BrowserRepo(r.result));r.onerror=()=>reject(r.error);r.onblocked=()=>reject(new Error('Закройте старые вкладки приложения для открытия истории'));});
}
function cleanView(v){const out={};for(const k of [...stateFields,'page','group','measure','chartMetric','asList'])if(v&&k in v)out[k]=typeof v[k]==='boolean'?v[k]:String(v[k]).slice(0,500);return out;}
function activePlans(){return viewVersion===liveVersion?workspace.plans:versionPlans;}
function setFilterValue(key,value){const field=$(key);if(value&&field.options&&!Array.from(field.options).some(o=>o.value===value)){const option=document.createElement('option');option.value=value;option.textContent='Нет в этой версии: '+value;field.append(option);}field.value=value||'';}
function isHistorical(){return Boolean(viewVersion&&viewVersion!==liveVersion);}
function setDataset(data){
  rows=data.rows;entities=rows.filter(r=>r.record_type==='entity');budgets=rows.filter(r=>r.record_type==='budget');
  if(typeof localRows!=='undefined'){localRows=rows;localCsv=csvEncode(rows);localUpdated=data.at;}
  const saved=Object.fromEntries(stateFields.map(k=>[k,$(k).value]));$('block').innerHTML=opts(entities.map(e=>e.business_block),'Все бизнес-блоки');$('dit').innerHTML=opts(entities.map(e=>e.dit),'Все ДИТ');for(const k of ['block','dit'])setFilterValue(k,saved[k]);
  $('snapshot').textContent='Дата состояния: '+data.date+' · '+data.name;$('updated').textContent='Версия: '+new Date(data.at).toLocaleString('ru-RU');offset=0;
}
async function selectVersion(id){const data=await stateRepo.getSnapshot(id);viewVersion=id;versionPlans=data.plans||{};if(!isHistorical())workspace=await stateRepo.settings();setDataset(data);render();}
async function stateInit(){
  const offline=typeof LOCAL_FIELDS!=='undefined';
  if(!stateRepo){
    if(offline){try{stateRepo=await openBrowserRepo();storageMode='История сохраняется в этом браузере';}catch(e){stateRepo=new BrowserRepo(null);storageMode='Только память вкладки: '+e.message;message(storageMode+'. Скачайте резервную копию перед закрытием.',true);}const s=await stateRepo.settings();stateRepo.profile=s.lastProfile||stateRepo.profile;currentUser=stateRepo.profile;canEdit=true;}
    else{stateRepo=new ServerRepo();storageMode='История и планы сохраняются на сервере';}
  }
  if(stateRepo instanceof ServerRepo){const me=await api('/api/me');currentUser=me.name;canEdit=me.role==='admin';}else currentUser=stateRepo.profile;
  versions=await stateRepo.list();if(!versions.length&&entities.length){await stateRepo.commit(rows,'Исходный набор',entities[0].snapshot,'');versions=await stateRepo.list();}
  if(!versions.length){workspace=await stateRepo.settings();stateReady=true;liveVersion=viewVersion='';render();return;}
  liveVersion=versions[0].id;workspace=await stateRepo.settings();stateReady=true;await selectVersion(liveVersion);
}
