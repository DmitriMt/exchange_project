'use strict';
let chartMetric='objects',chartShowAll=false;
const chartMetrics={
  objects:{label:'Объём работ: АС и ФП',unit:'объектов',source:'Каталог ИТ-услуг: уникальные CI-ID, ПРОМ, критичность MC+, MC, BC.'},
  as:{label:'Количество АС',unit:'АС',source:'Каталог ИТ-услуг: уникальные CI-ID автоматизированных систем.'},
  fp:{label:'Количество ФП',unit:'ФП',source:'Каталог ИТ-услуг: уникальные CI-ID функциональных подсистем.'},
  budget_rub:{label:'Стоимость КТС',unit:'₽ / год',source:measures.budget_rub.source},
  cpu:{label:'CPU',unit:'шт.',source:measures.cpu.source},
  ram_gb:{label:'RAM',unit:'ГБ',source:measures.ram_gb.source},
  disk_gb:{label:'Disk',unit:'ГБ',source:measures.disk_gb.source},
  pshe_change_standin:{label:'CHANGE',unit:'ПШЕ',source:'Калькулятор ПШЕ: лист «Объекты», S; пропуски дополнены моделью v4.3.'},
  pshe_run_standin:{label:'RUN',unit:'ПШЕ',source:'Калькулятор ПШЕ: лист «Объекты», T; пропуски дополнены моделью v4.3.'},
  pshe_vendor_standin:{label:'Вендоры CHANGE',unit:'₽ без НДС',source:'Калькулятор ПШЕ: лист «Объекты», U; пропуски дополнены моделью v4.3. В КТС не входят.'}
};
function chartRows(es,bs,axis,key){
  const grouped=new Map();
  for(const e of es){
    if(!grouped.has(e[axis]))grouped.set(e[axis],{name:e[axis],as:0,fp:0,entities:[],budgets:[]});
    const g=grouped.get(e[axis]);g[e.category==='АС'?'as':'fp']++;g.entities.push(e);
  }
  for(const b of bs)if(grouped.has(b[axis]))grouped.get(b[axis]).budgets.push(b);
  return [...grouped.values()].map(g=>({...g,value:key==='objects'?g.as+g.fp:key==='as'?g.as:key==='fp'?g.fp:sum(key.startsWith('pshe_')?g.entities:g.budgets,key)}))
    .sort((a,b)=>a.value===null&&b.value!==null?1:b.value===null&&a.value!==null?-1:Math.abs(b.value??0)-Math.abs(a.value??0)||a.name.localeCompare(b.name,'ru'));
}
function chartNumber(v){
  if(v===null)return 'нет строк';
  return fmt(v,Math.abs(v)<100?1:0);
}
function graphPanel(es,bs,axis,title){
  const data=chartRows(es,bs,axis,chartMetric),visible=chartShowAll?data:data.slice(0,10),config=chartMetrics[chartMetric];
  const known=data.filter(r=>r.value!==null),total=known.length?known.reduce((s,r)=>s+r.value,0):null;
  const max=Math.max(0,...known.map(r=>r.value)),min=Math.min(0,...known.map(r=>r.value));
  const scale=v=>(v-min)/(max-min||1)*600,zero=scale(0);
  const countMode=['objects','as','fp'].includes(chartMetric);
  const stack=chartMetric==='objects';
  return `<section class="panel graph-panel" aria-label="${esc(title)}"><div class="graph-head"><div><h3>${esc(title)}</h3><p>${chartShowAll?'Все':`Топ-${Math.min(10,data.length)}`} из ${fmt(data.length)} · ${esc(config.unit)}</p></div><div class="graph-total"><strong>${chartNumber(total)}</strong><span>в выбранном периметре</span></div></div>${stack?'<div class="graph-legend"><span><i class="key-as"></i>АС</span><span><i class="key-fp"></i>ФП</span></div>':''}<div class="graph-axis-note">${stack?'Каждая строка = 100%: доли АС и ФП внутри этой строки':min<0?'Отрицательные значения показаны слева от нуля':'Длина столбца соответствует значению'} · нажмите строку для фильтра</div><div class="graph-list">${visible.map((r,i)=>{
    let bars='';
    if(stack){const own=r.as+r.fp,a=own?r.as/own*600:0,f=own?r.fp/own*600:0;bars=`<rect x="0" y="2" width="${a}" height="10" rx="2" fill="#138a75"/><rect x="${a}" y="2" width="${f}" height="10" rx="2" fill="#6394bf"/>`;}
    else if(r.value!==null){const end=scale(r.value);bars=`<rect x="${Math.min(zero,end)}" y="2" width="${Math.abs(end-zero)}" height="10" rx="2" fill="${r.value<0?'#c57b4e':chartMetric==='fp'?'#6394bf':'#138a75'}"/><line x1="${zero}" x2="${zero}" y1="0" y2="14" stroke="#6c8591" stroke-width="1"/>`;}
    const desc=stack?`${fmt(r.as)} АС + ${fmt(r.fp)} ФП`:chartNumber(r.value)+' '+config.unit;
    return `<button class="graph-row" data-chart-axis="${axis}" data-chart-value="${esc(r.name)}" title="${esc(r.name)}: ${esc(desc)}"><span class="graph-row-top"><span class="graph-name"><span class="graph-rank">${i+1}.</span>${esc(r.name)}</span><strong>${chartNumber(r.value)}</strong></span><svg viewBox="0 0 600 14" preserveAspectRatio="none" aria-hidden="true"><rect x="0" y="2" width="600" height="10" rx="3" fill="#eef3f5"/>${bars}</svg>${stack?`<span class="graph-breakdown">${fmt(r.as)} АС (${fmt(r.as/(r.as+r.fp||1)*100,1)}%) <span>+</span> ${fmt(r.fp)} ФП (${fmt(r.fp/(r.as+r.fp||1)*100,1)}%)</span>`:''}</button>`;
  }).join('')||'<div class="empty">Нет объектов для выбранных фильтров</div>'}</div>${!chartShowAll&&data.length>10?`<p class="note graph-remainder">Ещё ${fmt(data.length-10)} ${axis==='dit'?'ДИТ':'блоков'} скрыто. Итог над графиком включает их значения.</p>`:''}${!countMode&&data.some(r=>r.value===null)?`<p class="note">У ${fmt(data.filter(r=>r.value===null).length)} групп нет строк источника; они не заменены нулями.</p>`:''}</section>`;
}
function infographics(es,bs){
  return `<section id="infographics" aria-label="Инфографика по ДИТ и бизнес-блокам"><div class="section-title graph-toolbar"><div><p class="eyebrow">РАСПРЕДЕЛЕНИЕ ПРОГРАММЫ</p><h2>ДИТ и бизнес-блоки</h2><p>Диаграммы учитывают фильтры и список «Выгрузка АС»</p></div><div class="graph-controls"><label>Показатель диаграмм<select id="chartMetric">${Object.entries(chartMetrics).map(([k,v])=>`<option value="${k}" ${k===chartMetric?'selected':''}>${esc(v.label)}${k==='objects'?'':' · '+esc(v.unit)}</option>`).join('')}</select></label><button id="chartAll">${chartShowAll?'Показать топ-10':'Показать все'}</button></div></div><div class="two-col graphs">${graphPanel(es,bs,'dit','По ДИТ')}${graphPanel(es,bs,'business_block','По бизнес-блокам')}</div><p class="note graph-source">Источник диаграмм: ${esc(chartMetrics[chartMetric].source)} Организационные разрезы — из актуального каталога.</p></section>`;
}
function bindInfographics(){
  if($('chartMetric'))$('chartMetric').onchange=()=>{chartMetric=$('chartMetric').value;render();};
  if($('chartAll'))$('chartAll').onclick=()=>{chartShowAll=!chartShowAll;render();};
  document.querySelectorAll('[data-chart-axis]').forEach(b=>b.onclick=()=>{
    $(b.dataset.chartAxis==='dit'?'dit':'block').value=b.dataset.chartValue;
    offset=0;render();
  });
}
