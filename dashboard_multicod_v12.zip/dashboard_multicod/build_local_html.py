"""Bundle the current dashboard and dataset into one file for offline debugging."""
import json
from datetime import datetime, timezone
from pathlib import Path
from prepare_data import FIELDS
from server import parse_data

ROOT = Path(__file__).resolve().parent
csv_path = ROOT / 'data' / 'dashboard.csv'
raw = csv_path.read_bytes()
parse_data(raw)


def js_literal(value):
    return json.dumps(value, ensure_ascii=False).replace('<', '\\u003c').replace('\u2028', '\\u2028').replace('\u2029', '\\u2029')


script = (ROOT / 'web' / 'app.js').read_text()
script = '\n'.join(line for line in script.splitlines() if not line.startswith(("async function api(", "$('loginForm').addEventListener", "$('logout').onclick", "$('download').onclick")))
download = """
$('download').onclick=()=>{
  const url=URL.createObjectURL(new Blob([localCsv],{type:'text/csv;charset=utf-8'}));
  const a=document.createElement('a');a.href=url;a.download='multicod_local.csv';a.click();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
};
$('user').textContent='Локальная отладка';$('logout').hidden=true;
$('uploadButton').hidden=false;
load().catch(err=>message(err.message,true));
"""
bootstrap = ('const LOCAL_FIELDS=' + js_literal(FIELDS) + ';\n'
             + 'const LOCAL_UPDATED=' + js_literal(datetime.fromtimestamp(csv_path.stat().st_mtime, timezone.utc).isoformat()) + ';\n'
             + 'let localCsv=' + js_literal(raw.decode('utf-8-sig')) + ';\n')
adapter = (ROOT / 'offline_adapter.js').read_text()
model = 'const CSV_FIELDS=' + js_literal(FIELDS) + ';\nconst PSHE_MODEL=' + js_literal(json.loads((ROOT / 'model_v4_3.json').read_text())) + ';\n'
model += (ROOT / 'web' / 'model_runtime.js').read_text()
(ROOT / 'web' / 'model.js').write_text(model)
v2 = (ROOT / 'web' / 'v2.js').read_text()
charts = (ROOT / 'web' / 'charts.js').read_text()
sections = (ROOT / 'web' / 'sections.js').read_text()
excel = (ROOT / 'web' / 'excel.js').read_text() + '\n' + (ROOT / 'web' / 'export.js').read_text()
state = (ROOT / 'web' / 'state.js').read_text() + '\n' + (ROOT / 'web' / 'workflows.js').read_text() + '\n' + (ROOT / 'web' / 'enhancements.js').read_text() + '\n' + (ROOT / 'web' / 'system.js').read_text()
(ROOT / 'web' / 'csv.js').write_text(adapter.split('let localRows=')[0].replace('LOCAL_FIELDS', 'CSV_FIELDS'))
page = (ROOT / 'web' / 'index.html').read_text()
start, end = page.index('<div id="login"'), page.index('<div id="shell"')
page = page[:start] + page[end:]
page = page.replace('<div id="shell" hidden>', '<div id="shell">')
page = page.replace('<link rel="stylesheet" href="/style.css">', '<style>' + (ROOT / 'web' / 'style.css').read_text() + '</style>')
for name in ['app.js', 'model.js', 'v2.js', 'charts.js', 'sections.js', 'excel.js', 'export.js', 'csv.js', 'state.js', 'workflows.js', 'enhancements.js', 'system.js']:
    page = page.replace(f'<script src="/{name}" defer></script>', '')
page = page.replace('<div class="statusline">', '<p class="note">Локальная версия: история, планы и представления сохраняются в браузере. Для переноса и резервного хранения скачайте историю. Проверка ролей выполняется только на сервере.</p><div class="statusline">')
page = page.replace('</body>', '<script>\n' + bootstrap + model + '\n' + adapter + '\n' + script + '\n' + v2 + '\n' + charts + '\n' + sections + '\n' + excel + '\n' + state + '\n' + download + '\n</script>\n</body>')
destination = ROOT.parent / 'outputs' / 'МультиЦОД_локальная_отладка.html'
destination.parent.mkdir(exist_ok=True)
destination.write_text(page)
print(destination)
