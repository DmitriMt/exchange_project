import base64
import csv
import io
import json
import zipfile
from pathlib import Path
import tempfile
import threading
import unittest
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from server import ROOT, make_server, parse_data, password_hash
from prepare_data import FIELDS


class DashboardTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.folder = Path(cls.temp.name)
        cls.original = (ROOT / 'data/dashboard.csv').read_bytes()
        cls.data = cls.folder / 'current.csv'
        cls.data.write_bytes(cls.original)
        salt = '12' * 16
        cls.users = cls.folder / 'users.json'
        cls.users.write_text(json.dumps({name: {'salt': salt, 'hash': password_hash('test-password-only', salt), 'role': role}
                                          for name, role in [('read', 'viewer'), ('write', 'uploader')]}))
        cls.server = make_server('127.0.0.1', 0, cls.users, cls.data)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.url = 'http://127.0.0.1:' + str(cls.server.server_address[1])

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.temp.cleanup()

    def request(self, path, user=None, raw=None, base_url=None, backup=False, extra=None):
        headers = {}
        if user:
            headers['Authorization'] = 'Basic ' + base64.b64encode((user + ':test-password-only').encode()).decode()
        if raw is not None:
            headers['Content-Type'] = 'text/csv'
        if backup:
            base = json.loads(self.request('/api/snapshots', user, base_url=base_url)[1])
            receipt = json.loads(self.request('/api/admin/backups/prepare', user, json.dumps({'base': base[0]['id'] if base else ''}).encode(), base_url=base_url)[1])
            self.assertEqual(self.request('/api/admin/backups/ack', user, json.dumps({'id': receipt['id'], 'sha256': receipt['sha256']}).encode(), base_url=base_url)[0], 200)
            headers['X-Backup-Id'] = receipt['id']
        headers.update(extra or {})
        try:
            with urlopen(Request((base_url or self.url) + path, data=raw, headers=headers)) as response:
                return response.status, response.read()
        except HTTPError as error:
            return error.code, error.read()

    def test_auth_and_role_enforced_on_server(self):
        self.assertEqual(self.request('/api/data')[0], 401)
        self.assertEqual(self.request('/api/data', 'read')[0], 200)
        before = self.data.read_bytes()
        self.assertEqual(self.request('/api/upload', 'read', self.original)[0], 403)
        self.assertEqual(self.data.read_bytes(), before)
        self.assertEqual(self.request('/private/users.json', 'write')[0], 404)

    def test_state_endpoints_and_edit_permissions(self):
        status, raw = self.request('/api/snapshots', 'read')
        self.assertEqual(status, 200)
        versions = json.loads(raw)
        self.assertGreaterEqual(len(versions), 1)
        self.assertEqual(self.request('/api/snapshots/' + versions[0]['id'], 'read')[0], 200)
        ci = next(r['id_ke'] for r in parse_data(self.original) if r['record_type'] == 'entity')
        payload = json.dumps({'ci': ci, 'value': {'year': '2027'}, 'revision': 0}).encode()
        self.assertEqual(self.request('/api/planning', 'read', payload)[0], 403)
        self.assertEqual(self.request('/api/planning', 'write', payload)[0], 200)
        self.assertEqual(self.request('/api/planning', 'write', payload)[0], 409)
        view = json.dumps({'name': 'My view', 'value': {'dit': 'A'}}).encode()
        self.assertEqual(self.request('/api/views', 'read', view)[0], 200)
        self.assertEqual(len(json.loads(self.request('/api/views', 'read')[1])), 1)
        self.assertEqual(json.loads(self.request('/api/views', 'write')[1]), [])

    def test_import_routes_require_uploader_and_keep_source_jobs_separate(self):
        self.assertEqual(self.request('/api/import/jobs', 'read')[0], 403)
        base = json.loads(self.request('/api/snapshots', 'write')[1])[0]['id']
        payload = json.dumps({'date': '2026-11-03', 'base': base}).encode()
        status, raw = self.request('/api/import/jobs', 'write', payload)
        self.assertEqual(status, 200)
        key = json.loads(raw)['id']
        zipped = io.BytesIO()
        with zipfile.ZipFile(zipped, 'w') as book:
            book.writestr('xl/workbook.xml', '<workbook/>')
        self.assertEqual(self.request('/api/import/jobs/' + key + '/files/catalog', 'write', zipped.getvalue())[0], 200)
        self.assertEqual(self.request('/api/import/jobs/' + key + '/run', 'write', b'{}')[0], 400)
        status, raw = self.request('/api/import/jobs/' + key, 'write')
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(raw)['status'], 'uploading')
        self.assertEqual(self.request('/api/state/import', 'read', b'{}')[0], 403)
        backup = {'format': 'multicod-history', 'version': 1, 'snapshots': [{
            'id': 'browser-import-http', 'at': '2026-11-01T10:00:00Z', 'date': '2026-11-01',
            'name': 'HTML old snapshot', 'csv': self.original.decode('utf-8-sig'), 'plans': {}}], 'workspace': {}}
        self.assertEqual(self.request('/api/state/import', 'write', json.dumps(backup).encode(), backup=True)[0], 200)
        self.assertEqual(self.request('/api/snapshots/browser-import-http', 'read')[0], 200)

    def test_first_upload_without_existing_data(self):
        folder = self.folder / 'empty-install'
        folder.mkdir(exist_ok=True)
        server = make_server('127.0.0.1', 0, self.users, folder / 'dashboard.csv')
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        url = 'http://127.0.0.1:' + str(server.server_address[1])
        try:
            self.assertEqual(self.request('/api/data', 'read', base_url=url)[0], 404)
            self.assertEqual(json.loads(self.request('/api/snapshots', 'read', base_url=url)[1]), [])
            self.assertEqual(self.request('/api/upload', 'write', self.original, base_url=url, backup=True)[0], 200)
            self.assertEqual(len(json.loads(self.request('/api/snapshots', 'read', base_url=url)[1])), 1)
            self.assertEqual(self.request('/api/data', 'read', base_url=url)[0], 200)
        finally:
            server.shutdown()
            server.server_close()

    def test_reject_bad_upload_preserving_current_data(self):
        before = self.data.read_bytes()
        for raw in [b'bad;csv\n1;2', self.original.replace(b'MC+', b'INVALID', 1)]:
            self.assertEqual(self.request('/api/upload', 'write', raw)[0], 400)
            self.assertEqual(self.data.read_bytes(), before)

    def test_valid_upload_and_history(self):
        self.assertEqual(self.request('/api/upload', 'write', self.original, backup=True)[0], 200)
        self.assertEqual(self.data.read_bytes(), self.original)
        self.assertTrue(list((self.folder / 'history').glob('*.csv')))
        self.assertEqual(self.request('/api/csv', 'read')[1], self.original)

    def test_admin_users_preferences_and_backup_gate(self):
        self.assertEqual(json.loads(self.request('/api/me', 'read')[1])['role'], 'user')
        self.assertEqual(self.request('/api/admin/users', 'read')[0], 403)
        self.assertEqual(self.request('/api/admin/backups/prepare', 'read', b'{}')[0], 403)
        before = self.server.store.list()
        self.assertEqual(self.request('/api/upload', 'write', self.original)[0], 400)
        self.assertEqual(before, self.server.store.list())
        pref = {'filters': {'dit': 'Personal'}, 'tables': {'a': {'filters': {'2': '>10'}}}}
        self.assertEqual(self.request('/api/preferences', 'read', json.dumps(pref).encode())[0], 200)
        self.assertEqual(json.loads(self.request('/api/preferences', 'read')[1]), pref)
        self.assertEqual(json.loads(self.request('/api/preferences', 'write')[1]), {})
        payload = {'name': 'new-user', 'role': 'user', 'password': 'test-password-only'}
        self.assertEqual(self.request('/api/admin/users', 'write', json.dumps(payload).encode())[0], 200)
        self.assertEqual(self.request('/api/data', 'new-user')[0], 200)
        self.assertEqual(self.request('/api/upload', 'new-user', self.original)[0], 403)
        payload.update(password='', active=False)
        self.assertEqual(self.request('/api/admin/users', 'write', json.dumps(payload).encode())[0], 200)
        self.assertEqual(self.request('/api/data', 'new-user')[0], 401)
        base = self.server.store.list()[0]['id']
        r = json.loads(self.request('/api/admin/backups/prepare', 'write', json.dumps({'base': base}).encode())[1])
        data = self.request('/api/admin/backups/file/' + r['id'], 'write')[1]
        import hashlib
        self.assertEqual(hashlib.sha256(data).hexdigest(), r['sha256'])
        self.assertEqual(self.request('/api/admin/backups/file/' + r['id'], 'read')[0], 403)
        self.assertEqual(self.request('/api/upload', 'write', self.original, extra={'X-Backup-Id': r['id']})[0], 400)
        self.assertEqual(self.request('/api/admin/backups/ack', 'write', json.dumps({'id': r['id'], 'sha256': 'bad'}).encode())[0], 400)
        self.assertEqual(self.request('/api/admin/backups/ack', 'write', json.dumps({'id': r['id'], 'sha256': r['sha256']}).encode())[0], 200)
        self.assertEqual(self.request('/api/upload', 'write', self.original, extra={'X-Backup-Id': r['id']})[0], 200)
        self.assertEqual(self.request('/api/upload', 'write', self.original, extra={'X-Backup-Id': r['id']})[0], 400)
        self.assertTrue(list((self.folder / 'backups').glob('*.sqlite3')))

    def test_perimeter_and_no_double_count(self):
        rows = parse_data(self.original)
        objects = [r for r in rows if r['record_type'] == 'entity']
        budgets = [r for r in rows if r['record_type'] == 'budget']
        self.assertEqual(len(objects), 1271)
        self.assertEqual(sum(r['category'] == 'АС' for r in objects), 420)
        self.assertEqual(sum(r['category'] == 'ФП' for r in objects), 851)
        self.assertEqual(sum(not r['pshe_change_main'] for r in objects), 0)
        self.assertEqual(sum(bool(r['pshe_model_inputs']) for r in objects), 152)
        self.assertEqual(sum(r['in_as_list'] == '1' for r in objects), 967)
        self.assertEqual(len(budgets), 8550)
        self.assertEqual(len(set(r['id_ke'] for r in budgets)), 288)
        self.assertTrue(all(not b['pshe_change_main'] for b in budgets))

    def test_duplicate_and_orphan_budget_rejected(self):
        rows = parse_data(self.original)
        def encode(values):
            out = io.StringIO()
            writer = csv.DictWriter(out, fieldnames=FIELDS, delimiter=';')
            writer.writeheader()
            writer.writerows(values)
            return out.getvalue().encode('utf-8-sig')
        with self.assertRaisesRegex(ValueError, 'Повтор объекта'):
            parse_data(encode(rows + [rows[0]]))
        b = dict(next(r for r in rows if r['record_type'] == 'budget'))
        b['id_ke'] = 'CI999999999999'
        b['budget_source_id'] = 'unique-test-row'
        with self.assertRaisesRegex(ValueError, 'не соответствует'):
            parse_data(encode(rows + [b]))

    def test_missing_pshe_is_calculated_without_overwriting_known(self):
        rows = parse_data(self.original)
        entity = next(r for r in rows if r['record_type'] == 'entity')
        known = entity['pshe_run_main']
        entity['pshe_change_main'] = ''
        entity['pshe_model_inputs'] = ''
        out = io.StringIO()
        writer = csv.DictWriter(out, fieldnames=FIELDS, delimiter=';')
        writer.writeheader()
        writer.writerows(rows)
        calculated = next(r for r in parse_data(out.getvalue().encode('utf-8-sig')) if r['id_ke'] == entity['id_ke'] and r['record_type'] == 'entity')
        self.assertNotEqual(calculated['pshe_change_main'], '')
        self.assertEqual(calculated['pshe_run_main'], known)
        self.assertIn('Средняя по типу', calculated['pshe_source_change'])


if __name__ == '__main__':
    unittest.main()
