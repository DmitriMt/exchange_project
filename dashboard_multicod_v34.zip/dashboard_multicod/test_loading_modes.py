import unittest,tempfile,zipfile,io,hashlib,json,copy
from pathlib import Path
from xml.sax.saxutils import escape
from prepare_data import prepare
from server import parse_data
from supplement import enrich,encode
from state_store import StateStore
from importer import ImportJobs
from fincontrol_model import resource_evidence,evidence_for

def xlsx(path,rows):
    xml='<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'+''.join('<row r="'+str(i)+'">'+''.join('<c r="'+k+str(i)+'" t="inlineStr"><is><t>'+escape(str(v))+'</t></is></c>' for k,v in r.items())+'</row>' for i,r in enumerate(rows,1))+'</sheetData></worksheet>'
    with zipfile.ZipFile(path,'w') as z:
        z.writestr('xl/workbook.xml','<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Опросник" sheetId="1" r:id="rId1"/></sheets></workbook>');z.writestr('xl/_rels/workbook.xml.rels','<Relationships><Relationship Id="rId1" Target="worksheets/sheet1.xml"/></Relationships>');z.writestr('xl/worksheets/sheet1.xml',xml)

class LoadingModes(unittest.TestCase):
    def test_only_two_sources_then_optional_update_same_snapshot(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);src=root/'sources';src.mkdir()
            xlsx(src/'Опросник перехода.xlsx',[{'A':'Обеспечивающее подразделение','C':'Наименование АС/ФП','D':'ID КЭ','F':'Категория','G':'Уровень критичности','H':'Этап ЖЦ','I':'Родительская АС','K':'Стратегия перехода в МультиЦОД +'}, {'A':'ДИТ','C':'АС','D':'CI00000001','F':'Автоматизированные системы','G':'Business Critical','H':'Промышленная эксплуатация','K':'A-A-A'}, {'A':'ДИТ','C':'ФП','D':'CI00000002','F':'Функциональная подсистема','G':'Business Critical','H':'Промышленная эксплуатация','I':'АС (CI00000001)'}])
            xlsx(src/'РСМ ДЭШ.xlsx',[{'D':'АС КЭ','L':'ФП КЭ','N':'Стенд Тип','AK':'кол-во Ядер'}, {'D':'CI00000001','L':'CI00000002','N':'ПРОМ (промышленная среда)','AK':'100','T':'CI5'}])
            dest=root/'snapshot.csv';prepare(src,dest,'2026-11-06',lambda _:None);rows=parse_data(dest.read_bytes())
            self.assertEqual(len(rows),2);self.assertEqual({r['rsm_presence'] for r in rows},{'1'});self.assertTrue(all('РСМ ДЭШ.xlsx=' in r['rsm_source'] for r in rows))
            evidence=resource_evidence(src,root/'evidence',lambda _:None);self.assertEqual(len(evidence['signature']),1);self.assertIsNotNone(evidence_for(rows,root/'evidence'))
            store=StateStore(root/'state.sqlite3');base=store.commit(dest.read_bytes(),rows,'Base','2026-11-06','');store.save_plan('CI00000001',{'year':'2027'},0,'admin');old=store.list()[0]
            extra=root/'extra';extra.mkdir();xlsx(extra/'Кошельки.xlsx',[{'N':'КЭ АС/ФП','AN':'ИТОГО'}, {'N':'CI00000002','AN':'1','W':'2'}])
            changed=enrich(rows,extra,lambda _:None);self.assertEqual(len(changed),3);self.assertEqual(changed[-1]['budget_rub'],'1000000')
            self.assertEqual(changed[:2],rows)
            store.update_optional(encode(changed),changed,base,old['hash'],'operator')
            self.assertEqual(len(store.list()),1);self.assertEqual(store.list()[0]['id'],base);self.assertEqual(store.list()[0]['date'],old['date']);self.assertEqual(store.list()[0]['at'],old['at']);self.assertEqual(store.planning()['plans']['CI00000001']['year'],'2027')
            with self.assertRaises(RuntimeError):store.update_optional(encode(rows),rows,base,old['hash'],'operator')
            invalid=copy.deepcopy(changed);invalid[0]['rsm_rows']='99'
            with self.assertRaises(ValueError):store.update_optional(encode(invalid),invalid,base,store.list()[0]['hash'],'operator')
            jobs=ImportJobs(root/'jobs',store,parse_data);job=jobs.create('operator',None,base,'supplement');self.assertEqual(job['date'],'2026-11-06')
            raw=(src/'РСМ ДЭШ.xlsx').read_bytes()
            with self.assertRaises(ValueError):jobs.upload(job['id'],'operator','rsm',io.BytesIO(raw),len(raw),'rsm.xlsx')
            # A wallet supplied at creation is applied immediately.
            (src/'Кошельки.xlsx').write_bytes((extra/'Кошельки.xlsx').read_bytes());prepare(src,dest,'2026-11-07',lambda _:None)
            self.assertEqual(len(parse_data(dest.read_bytes())),3)

    def test_optional_initiatives_commit_together_and_conflicts_roll_back(self):
        from server import ROOT
        from initiatives import prepare as parse_initiatives,read_report
        from test_initiatives import sample
        raw=(ROOT/'data/dashboard.csv').read_bytes();rows=parse_data(raw)
        report=parse_initiatives(sample(),[r for r in rows if r['record_type']=='entity'])
        with tempfile.TemporaryDirectory() as tmp:
            store=StateStore(Path(tmp)/'state.sqlite3')
            base=store.commit(raw,rows,'With MUI','2026-11-06','',report,'operator')
            self.assertEqual(read_report(store,base)['revision'],1)
            original=store.list()[0];changed=copy.deepcopy(rows);changed[0]['pshe_vendor_standin']='100'
            with self.assertRaises(RuntimeError):store.update_optional(encode(changed),changed,base,original['hash'],'operator',report,0)
            self.assertEqual(store.snapshot(base)['csv'],raw)
            store.update_optional(encode(changed),changed,base,original['hash'],'operator',report,1)
            self.assertEqual(read_report(store,base)['revision'],1)
            self.assertEqual(len(store.list()),1)

if __name__=='__main__':unittest.main()
