const fs=require('fs'),vm=require('vm'),assert=require('assert');
const c={Blob,File,DecompressionStream,TextDecoder,TextEncoder,console,crypto:globalThis.crypto};vm.createContext(c);vm.runInContext(fs.readFileSync(__dirname+'/web/excel.js','utf8')+'\n'+fs.readFileSync(__dirname+'/web/browser_import_core.js','utf8'),c);
(async()=>{
 const read=s=>vm.runInContext(s,c);
 const xml='<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1"><c r="A1" t="s"><v>0</v></c><c r="B1" t="inlineStr"><is><t>Блок &amp; &#x411;</t></is></c><c r="C1"><f>2+2</f><v>4</v></c></row><row r="2"><c r="A2"/><c r="B2" t="inlineStr"><is><r><t>один</t></r><r><t>два</t></r></is></c></row></sheetData></worksheet>';
 c.files=[['xl/workbook.xml','<workbook><sheets><sheet name="Объекты" r:id="rId1"/></sheets></workbook>'],['xl/_rels/workbook.xml.rels','<Relationships><Relationship Id="rId1" Target="/xl/worksheets/sheet1.xml"/></Relationships>'],['xl/sharedStrings.xml','<sst><si><t>КЭ &lt;один&gt;</t></si></sst>'],['xl/worksheets/sheet1.xml',xml]];
 c.file=new File([read('xZip(files)')],'example.xlsx');const book=await read('new BrowserXlsx(file).open()');const rows=[];for await(const row of book.rows('Объекты'))rows.push(row);
 assert.equal(rows[0][1].A,'КЭ <один>');assert.equal(rows[0][1].B,'Блок & Б');assert.equal(rows[0][1].C,'4');assert.equal(rows[1][1].B,'одиндва');assert.equal(rows[1][1].A,'');
 await assert.rejects(book.sheet('Отсутствует'),/Нет листа/);
 const original=new Uint8Array(await c.file.arrayBuffer());const corrupted=original.slice();let found=-1;for(let i=0;i<corrupted.length-3;i++)if(corrupted[i]===60&&corrupted[i+1]===119&&corrupted[i+2]===111){found=i;break;}assert(found>=0);corrupted[found+2]=120;
 c.bad=new File([corrupted],'bad.xlsx');const bad=await read('new BrowserXlsx(bad).open()');await assert.rejects(bad.xml('xl/workbook.xml'),/сумма/);
 c.empty=new File(['not XLSX'],'bad.xlsx');await assert.rejects(read('new BrowserXlsx(empty).open()'),/XLSX/);
 assert.equal(read("bxMoney('0.001234567890123456789')"),'1234.567890123456789000000');
 assert.equal(read("bxDisk('99999999.999999999999','0.000000000001')"),'100000000.000000000000');
 await assert.rejects(read("prepareBrowser({},'2026-11-03',{fields:[]})"),/RUNUP/);
 console.log('PASS: XLSX ZIP integrity, named sheets, shared/inline/rich strings, XML entities, cached formulas, malformed input and exact decimal money/disk.');
})().catch(e=>{console.error(e);process.exitCode=1;});
