import copy
import json
from pathlib import Path
import tempfile
import unittest

from initiatives import config, prepare, read_report, save_report
from server import ROOT, parse_data
from state_store import StateStore


def sample():
    codes = ['232517', '3197613', '3421627', '3457040', '4596809', '5306897']
    rows = [[1, config()['headers']], [2, {}]]
    for i, obj in enumerate(codes, 3):
        fte = .5 if obj == '3197613' else .3
        rows.append([i, dict(A='0', B='2027', C='2026081713121230', D='МультиЦОД+ Домклик', L='Приостановлена',
                             AG='1.2027', AH='4.2027', AY='IT', BB=obj, BC='Объект',
                             **{k: str(fte) for k in ['BL', 'BM', 'BN', 'BO', 'BP']}, BY='100', BZ='100')])
    return dict(sheets={'Общая информация и затраты': rows}, source='Test.xlsx', mappings={})


class InitiativeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.store = StateStore(Path(self.tmp.name) / 'state.sqlite3')
        self.raw = (ROOT / 'data/dashboard.csv').read_bytes()
        self.registry = [r for r in parse_data(self.raw) if r['record_type'] == 'entity']
        self.base = self.store.commit(self.raw, parse_data(self.raw), 'Test', '2026-11-03', '')

    def tearDown(self):
        self.tmp.cleanup()

    def test_own_ci_matches_both_types_and_preserves_outside(self):
        report = prepare(sample(), self.registry)
        self.assertEqual(report['errors'], [])
        self.assertEqual(len(report['initiatives']), 1)
        self.assertEqual(sum(l['numbers']['BP'] for l in report['lines']), 2)
        self.assertAlmostEqual(sum(l['numbers']['BP'] for l in report['lines'] if l['scope'] == 'RUNUP'), .8)
        self.assertEqual([l['category'] for l in report['lines']], ['АС', 'АС', 'ФП', 'ФП', 'ФП', 'ФП'])
        self.assertEqual(sum(l['scope'] == 'outside' for l in report['lines']), 4)

    def test_unresolved_never_inherits_or_matches_a_truncated_code(self):
        body = sample(); body['sheets']['Общая информация и затраты'][2][1]['BB'] = '_CI027216'
        report = prepare(body, self.registry)
        self.assertEqual(report['lines'][0]['scope'], 'unresolved')
        body['mappings'] = {'_CI027216': 'CI02721647'}
        self.assertEqual(prepare(body, self.registry)['lines'][0]['match'], 'manual')
        body['mappings']['_CI027216'] = 'CI999999999'
        with self.assertRaises(ValueError): prepare(body, self.registry)

    def test_invalid_rows_block_save_atomically(self):
        for change in [dict(BZ='99'), dict(BP='NaN'), dict(AG='5.2027'), dict(A='2'), dict(BA='X'), dict(AY='OC'), dict(C='2.02608171312123E15')]:
            body = sample();body['sheets']['Общая информация и затраты'][3][1].update(change)
            self.assertTrue(prepare(body, self.registry)['errors'], change)
            with self.assertRaises(ValueError): save_report(self.store, dict(body, base=self.base, revision=0), 'admin')
            self.assertEqual(read_report(self.store, self.base), dict(revision=0))

    def test_duplicate_and_conflicting_initiative_rejected(self):
        body = sample();body['sheets']['Общая информация и затраты'].append([9, copy.deepcopy(body['sheets']['Общая информация и затраты'][2][1])])
        self.assertTrue(prepare(body, self.registry)['errors'])
        body = sample();body['sheets']['Общая информация и затраты'][3][1]['L'] = 'Другой статус'
        self.assertTrue(prepare(body, self.registry)['errors'])

    def test_revision_idempotence_snapshot_isolation_and_audit(self):
        body = dict(sample(), base=self.base, revision=0)
        first = save_report(self.store, body, 'operator');self.assertEqual(first['revision'], 1)
        body['revision'] = 1
        self.assertEqual(save_report(self.store, body, 'operator')['revision'], 1)
        with self.store.db() as db:self.assertEqual(db.execute('SELECT COUNT(*) FROM initiative_events').fetchone()[0], 1)
        body['revision'] = 0
        with self.assertRaises(RuntimeError): save_report(self.store, body, 'operator')
        other = self.store.commit(self.raw, parse_data(self.raw), 'Next', '2026-11-04', self.base)
        self.assertEqual(read_report(self.store, other), dict(revision=0))
        with self.assertRaises(RuntimeError): save_report(self.store, body, 'operator')
        self.assertEqual(read_report(self.store, self.base)['revision'], 1)

    def test_changed_header_and_direct_mapping_override_rejected(self):
        body = sample();body['sheets']['Общая информация и затраты'][0][1]['BB'] = 'Другая колонка'
        with self.assertRaises(ValueError): prepare(body, self.registry)
        body = sample();body['mappings'] = {'232517': 'CI03197613'}
        self.assertTrue(prepare(body, self.registry)['errors'])

    def test_authenticated_api_preview_save_and_stale_revision(self):
        import base64
        import threading
        from urllib.error import HTTPError
        from urllib.request import Request, urlopen
        from server import make_server, password_hash
        folder = Path(self.tmp.name)
        data = folder / 'api.csv';data.write_bytes(self.raw)
        salt = 'ab' * 16
        users = folder / 'users.json'
        users.write_text(json.dumps({r: dict(role=r, salt=salt, hash=password_hash('test-password-only', salt)) for r in ['user', 'operator', 'admin']}))
        server = make_server('127.0.0.1', 0, users, data)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        def request(path, body=None, role='operator'):
            headers = {'Content-Type': 'application/json'}
            if role:headers['Authorization'] = 'Basic ' + base64.b64encode((role + ':test-password-only').encode()).decode()
            try:
                with urlopen(Request('http://127.0.0.1:' + str(server.server_port) + path, data=json.dumps(body).encode() if body is not None else None, headers=headers)) as response:
                    raw=response.read()
                    return response.status, json.loads(raw) if response.headers.get('Content-Type','').startswith('application/json') else raw
            except HTTPError as error:return error.code, json.loads(error.read())
        try:
            base = server.store.list()[0]['id']
            self.assertEqual(request('/api/initiatives/config', role=None)[0], 401)
            self.assertEqual(request('/api/initiatives/config', role='user')[0], 200)
            body = dict(sample(), base=base, revision=0)
            self.assertEqual(request('/api/initiatives/preview', body, role='user')[0], 403)
            status, preview = request('/api/initiatives/preview', body)
            self.assertEqual(status, 200);self.assertEqual(preview['errors'], [])
            self.assertEqual(request('/api/initiatives/save', body)[1]['revision'], 1)
            self.assertEqual(request('/api/initiatives/save', body)[0], 409)
            body['revision'] = 1
            self.assertEqual(request('/api/initiatives/save', body)[1]['revision'], 1)
            self.assertEqual(request('/api/initiatives/' + base, role='user')[1]['revision'], 1)
            body['sheets']['Общая информация и затраты'][3][1]['BP'] = '-2'
            self.assertEqual(request('/api/initiatives/save', body)[0], 400)
            self.assertEqual(request('/api/initiatives/' + base)[1]['revision'], 1)
            for filename in ['initiatives_ui.js', 'initiatives_core.js', 'initiative_import_worker.js']:
                self.assertEqual(request('/' + filename)[0], 200)
        finally:
            server.shutdown();server.server_close()


if __name__ == '__main__':
    unittest.main()
