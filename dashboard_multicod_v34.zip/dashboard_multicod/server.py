"""Dependency-free Linux dashboard server. Put behind an HTTPS reverse proxy."""
import argparse
import base64
import csv
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
import getpass
import hashlib
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import io
import json
import os
from pathlib import Path
import re
import secrets
import tempfile
import threading
import zipfile
from urllib.parse import unquote
from state_store import StateStore
from security import Security, ROLES
from importer import ImportJobs, FILE_LIMIT
from fincontrol_model import payload as fincontrol_payload

from prepare_data import FIELDS, LEGACY_FIELDS, V13_FIELDS, V15_FIELDS, V16_FIELDS
from registry import validate_registry_row, validate_registry_dataset
from transition import validate_transition
from ownership import OWNERSHIP_FIELDS, validate_ownership

ROOT = Path(__file__).resolve().parent
LOCK = threading.RLock()
LIMIT = 20 * 1024 * 1024


def parse_data(raw):
    reader = csv.DictReader(io.StringIO(raw.decode('utf-8-sig')), delimiter=';')
    if reader.fieldnames not in (FIELDS, LEGACY_FIELDS, V13_FIELDS, V15_FIELDS, V16_FIELDS):
        raise ValueError('Структура CSV не соответствует шаблону. Требуются UTF-8 и разделитель «;».')
    rows = list(reader)
    if not rows or len(rows) > 100000:
        raise ValueError('CSV пуст или содержит более 100 000 строк')
    for row in rows:
        for field in FIELDS:
            if field not in reader.fieldnames:
                row[field] = ''
        if 'base_source' not in reader.fieldnames and row.get('record_type')=='entity':
            row['base_source']='LEGACY_CATALOG'
        if row.get('rsm_presence') not in ('', '0', '1') or row.get('rsm_rows') and not re.fullmatch(r'\d{1,12}', row['rsm_rows']):
            raise ValueError('Неверный признак наличия КЭ в РСМ')
        if row.get('rsm_presence') in ('0','1') and (not row.get('rsm_source') or not row.get('rsm_rows') or (row['rsm_presence']=='0') != (int(row['rsm_rows'])==0)):
            raise ValueError('Признак РСМ не согласован с количеством строк и источником')
        if row.get('record_type')=='entity':
            validate_registry_row(row)
        validate_transition(row)
        validate_ownership(row)
        for field in ('fp_prom_total', 'fp_scope_total'):
            if row.get(field) and not re.fullmatch(r'\d{1,7}', row[field]):
                raise ValueError('Неверное количество ФП: ' + field)
        if row.get('parent_in_scope', '') not in ('', '0', '1'):
            raise ValueError('Неверный признак периметра родительской АС')
    ids, budget_keys = {}, set()
    for row in rows:
        if None in row or any(v is None for v in row.values()):
            raise ValueError('Неверное количество колонок')
        audit = row['record_type'] == 'budget_outside'
        if not audit and not re.fullmatch(r'CI\d+', row['id_ke']):
            raise ValueError('Неверный CI-ID')
        if row['record_type'] not in ('entity', 'budget', 'budget_outside'):
            raise ValueError('Неизвестный тип строки')
        if not audit and (row['category'] not in ('АС', 'ФП') or not row['criticality'] or not row['lifecycle']):
            raise ValueError('Объект вне согласованного периметра')
        try:
            datetime.strptime(row['snapshot'], '%Y-%m-%d')
        except ValueError:
            raise ValueError('Неверная дата снимка')
        if not row['name'] or not row['dit'] or not row['business_block']:
            raise ValueError('Не заполнены название или организационные поля')
        if row['in_as_list'] not in ['0', '1']:
            raise ValueError('Не задан признак списка АС')
        for field in ['budget_rub', 'cpu', 'ram_gb', 'disk_gb', 'pshe_change_main', 'pshe_run_main', 'pshe_change_prom', 'pshe_run_prom', 'pshe_change_standin', 'pshe_run_standin', 'pshe_vendor_standin']:
            if row[field] == '':
                continue
            try:
                value = Decimal(row[field])
                if not value.is_finite() or abs(value) > Decimal('1e18'):
                    raise InvalidOperation
                if field.startswith('pshe_') and value < 0:
                    raise InvalidOperation
            except InvalidOperation:
                raise ValueError('Некорректное число: ' + field)
        if row['record_type'] == 'entity':
            if row['id_ke'] in ids:
                raise ValueError('Повтор объекта: ' + row['id_ke'])
            if row['budget_rub'] or row['budget_consumption'] or row['stand'] or row['budget_source_id']:
                raise ValueError('Бюджет должен находиться в отдельной строке')
            ids[row['id_ke']] = row
        else:
            if not row['budget_source_id'] or row['budget_source_id'] in budget_keys:
                raise ValueError('Отсутствует или повторяется ключ бюджетной строки')
            budget_keys.add(row['budget_source_id'])
            if row['budget_rub'] == '' or not row['stand'] or not row['budget_consumption']:
                raise ValueError('Бюджетная строка не заполнена')
            if any(row[k] for k in FIELDS if k.startswith('pshe_')):
                raise ValueError('ПШЕ должны находиться только в строке объекта')
    if not ids:
        raise ValueError('В файле нет объектов')
    validate_registry_dataset(list(ids.values()))
    for row in rows:
        if row['record_type'] == 'budget':
            e = ids.get(row['id_ke'])
            if not e or any(row[k] != e[k] for k in ['name', 'category', 'parent_id', 'dit', 'business_block', 'criticality', 'lifecycle', 'snapshot', 'in_as_list']):
                raise ValueError('Бюджетная строка не соответствует объекту')
    from pshe_model import fill_rows_model
    return fill_rows_model(rows, ROOT / 'model_v4_3.json')


def password_hash(password, salt):
    return hashlib.pbkdf2_hmac('sha256', password.encode(), bytes.fromhex(salt), 300000).hex()


class Handler(BaseHTTPRequestHandler):
    def setup(self):
        super().setup()
        self.connection.settimeout(30)

    def reply(self, status, body, content_type='application/json; charset=utf-8'):
        if not isinstance(body, bytes):
            body = json.dumps(body, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(body)

    def user(self):
        try:
            scheme, value = self.headers.get('Authorization', '').split(' ', 1)
            if scheme != 'Basic':
                return None
            name, password = base64.b64decode(value, validate=True).decode().split(':', 1)
            u = self.server.security.account(name)
            if u and hmac.compare_digest(password_hash(password, u['salt']), u['hash']):
                return {'name': name, 'role': u['role']}
        except (ValueError, UnicodeError, OSError, KeyError):
            pass
        return None

    def initiatives_route(self):
        from initiatives import config, prepare, read_report, save_report
        user = self.user()
        if not user:
            return self.reply(401, {'error': 'Требуется вход'})
        try:
            if self.command == 'GET':
                if self.path == '/api/initiatives/config':
                    return self.reply(200, config())
                base = self.path.rsplit('/', 1)[-1]
                self.server.store.snapshot(base)
                return self.reply(200, read_report(self.server.store, base))
            if user['role'] not in ('admin', 'operator'):
                return self.reply(403, {'error': 'Загрузка инициатив доступна оператору и администратору'})
            size = int(self.headers.get('Content-Length', '0'))
            if not 0 < size <= LIMIT:
                return self.reply(413, {'error': 'Максимум 20 МБ'})
            body = json.loads(self.rfile.read(size))
            if not isinstance(body, dict):
                raise ValueError('Неверный запрос')
            latest = self.server.store.list()
            if not latest or body.get('base') != latest[0]['id']:
                raise RuntimeError('Срез изменился. Повторите проверку.')
            if self.path == '/api/initiatives/preview':
                registry = [r for r in parse_data(self.server.store.snapshot(body['base'])['csv']) if r['record_type'] == 'entity']
                return self.reply(200, prepare(body, registry))
            if self.path == '/api/initiatives/save':
                return self.reply(200, save_report(self.server.store, body, user['name']))
            return self.reply(404, {'error': 'Не найдено'})
        except RuntimeError as err:
            return self.reply(409, {'error': str(err)})
        except (ValueError, KeyError, TypeError) as err:
            return self.reply(400, {'error': str(err)})

    def do_GET(self):
        if self.path.startswith('/api/initiatives/'):
            return self.initiatives_route()
        if self.path.startswith(('/api/admin/', '/api/preferences')):
            return self.security_route()
        if self.path.startswith('/api/import/'):
            return self.import_route()
        if self.path in ('/', '/app.js', '/style.css', '/v2.js', '/model.js', '/charts.js', '/sections.js', '/excel.js', '/export.js', '/csv.js', '/state.js', '/workflows.js', '/enhancements.js', '/system.js', '/volume.js', '/no_kts.js', '/browser_import_ui.js', '/transition_ui.js', '/questionnaire_worker.js', '/registry_ui.js', '/file_read.js', '/overview.js', '/plans_bulk.js', '/plan_import_worker.js', '/initiatives_core.js', '/initiatives_ui.js', '/initiative_import_worker.js', '/enrichment_ui.js'):
            name = {'/': 'index.html', '/app.js': 'app.js', '/style.css': 'style.css', '/v2.js': 'v2.js', '/model.js': 'model.js', '/charts.js': 'charts.js', '/sections.js': 'sections.js', '/excel.js': 'excel.js', '/export.js': 'export.js', '/csv.js': 'csv.js', '/state.js': 'state.js', '/workflows.js': 'workflows.js', '/enhancements.js': 'enhancements.js', '/system.js': 'system.js', '/volume.js': 'volume.js', '/no_kts.js': 'no_kts.js', '/browser_import_ui.js': 'browser_import_ui.js', '/transition_ui.js': 'transition_ui.js', '/questionnaire_worker.js': 'questionnaire_worker.js', '/registry_ui.js': 'registry_ui.js', '/file_read.js': 'file_read.js', '/overview.js': 'overview.js', '/plans_bulk.js':'plans_bulk.js', '/plan_import_worker.js':'plan_import_worker.js', '/initiatives_core.js':'initiatives_core.js', '/initiatives_ui.js':'initiatives_ui.js', '/initiative_import_worker.js':'initiative_import_worker.js','/enrichment_ui.js':'enrichment_ui.js'}[self.path]
            mime = 'text/html' if self.path == '/' else 'text/css' if self.path == '/style.css' else 'application/javascript'
            return self.reply(200, (ROOT / 'web' / name).read_bytes(), mime + '; charset=utf-8')
        if self.path not in ('/api/data', '/api/fincontrol', '/api/me', '/api/csv', '/api/snapshots', '/api/planning', '/api/views') and not self.path.startswith(('/api/snapshots/', '/api/fincontrol/')):
            return self.reply(404, {'error': 'Не найдено'})
        user = self.user()
        if not user:
            return self.reply(401, {'error': 'Неверный логин или пароль'})
        if self.path == '/api/fincontrol' or self.path.startswith('/api/fincontrol/'):
            try:
                versions = self.server.store.list()
                key = self.path.rsplit('/', 1)[-1] if self.path.startswith('/api/fincontrol/') else (versions[0]['id'] if versions else None)
                raw = self.server.store.snapshot(key)['csv'] if key else self.server.data_path.read_bytes()
                baseline = json.loads((ROOT / 'data' / 'fincontrol.json').read_text())
                value = fincontrol_payload(baseline, parse_data(raw), self.server.data_path.parent / 'fincontrol_resources')
                value['snapshot_id'] = key
                return self.reply(200, value)
            except KeyError:
                return self.reply(404, {'error': 'Срез не найден'})
        if self.path == '/api/me':
            return self.reply(200, user)
        if self.path == '/api/snapshots':
            return self.reply(200, self.server.store.list())
        if self.path == '/api/planning':
            return self.reply(200, self.server.store.planning())
        if self.path == '/api/views':
            return self.reply(200, self.server.store.views(user['name']))
        if self.path.startswith('/api/snapshots/'):
            try:
                snap = self.server.store.snapshot(self.path.split('/')[-1])
                snap['rows'] = parse_data(snap.pop('csv'))
                return self.reply(200, snap)
            except KeyError:
                return self.reply(404, {'error': 'Версия не найдена'})
        with LOCK:
            versions = self.server.store.list()
            if not self.server.data_path.exists() and not versions:
                return self.reply(404, {'error': 'Загрузите первый CSV'})
            raw = self.server.store.snapshot(versions[0]['id'])['csv'] if versions else self.server.data_path.read_bytes()
            if self.path == '/api/csv':
                return self.reply(200, raw, 'text/csv; charset=utf-8')
            return self.reply(200, {'rows': parse_data(raw), 'updated_at': versions[0]['at'] if versions else datetime.fromtimestamp(self.server.data_path.stat().st_mtime, timezone.utc).isoformat(), 'snapshot_id': versions[0]['id'] if versions else ''})

    def do_POST(self):
        if self.path.startswith('/api/initiatives/'):
            return self.initiatives_route()
        if self.path == '/api/state/import':
            return self.state_import_route()
        if self.path.startswith(('/api/admin/', '/api/preferences')):
            return self.security_route()
        if self.path.startswith('/api/import/'):
            return self.import_route()
        if self.path not in ('/api/upload', '/api/planning', '/api/planning/batch', '/api/views'):
            return self.reply(404, {'error': 'Не найдено'})
        try:
            size = int(self.headers.get('Content-Length', '0'))
        except ValueError:
            return self.reply(400, {'error': 'Неверный размер файла'})
        if size <= 0 or size > LIMIT:
            return self.reply(413, {'error': 'Максимальный размер CSV — 20 МБ'})
        raw = self.rfile.read(size)
        user = self.user()
        if not user:
            return self.reply(401, {'error': 'Требуется вход'})
        if self.path == '/api/views':
            try:
                body = json.loads(raw)
                if not isinstance(body, dict):
                    raise ValueError('Неверный запрос')
                if body.get('action'):
                    self.server.store.update_view(user['name'], body.get('name'), body['action'], body.get('new_name'), body.get('page', 'overview'))
                else:
                    self.server.store.save_view(user['name'], body.get('name'), body.get('value'))
                return self.reply(200, {'message': 'Представление сохранено'})
            except (ValueError, TypeError) as err:
                return self.reply(400, {'error': str(err)})
        if user['role'] != 'admin' and not (user['role'] == 'operator' and self.path == '/api/upload'):
            return self.reply(403, {'error': 'Изменение данных доступно только админу; загрузка срезов — также оператору'})
        if self.path == '/api/planning/batch':
            try:
                body = json.loads(raw)
                if not isinstance(body, dict):
                    raise ValueError('Неверный запрос')
                return self.reply(200, self.server.store.save_plans_batch(body.get('items'), user['name'], body.get('base')))
            except RuntimeError as err:
                return self.reply(409, {'error': str(err)})
            except (ValueError, KeyError, TypeError) as err:
                return self.reply(400, {'error': str(err)})
        if self.path == '/api/planning':
            try:
                body = json.loads(raw)
                if not isinstance(body, dict):
                    raise ValueError('Неверный запрос')
                if 'base' in body:
                    result = self.server.store.save_plans_batch([dict(ci=body['ci'], value=body.get('value'), revision=body.get('revision',0))], user['name'], body['base'])
                    plan = result['plans'].get(body['ci']) or self.server.store.planning()['plans'].get(body['ci'],{})
                else:
                    plan = self.server.store.save_plan(body['ci'], body.get('value'), body.get('revision', 0), user['name'])
                return self.reply(200, plan)
            except RuntimeError as err:
                return self.reply(409, {'error': str(err)})
            except (ValueError, KeyError, TypeError) as err:
                return self.reply(400, {'error': str(err)})
        if self.headers.get('Content-Type', '').split(';')[0] != 'text/csv':
            return self.reply(415, {'error': 'Ожидается CSV'})
        try:
            rows = parse_data(raw)
            if any(r['record_type']=='entity' and r.get('base_source')!='RUNUP_QUESTIONNAIRE' for r in rows):
                raise ValueError('Для нового среза обязателен базовый опросник RUNUP. Старые CSV доступны через импорт истории.')
            output = io.StringIO(newline='')
            writer = csv.DictWriter(output, fieldnames=FIELDS, delimiter=';')
            writer.writeheader()
            writer.writerows(rows)
            raw = output.getvalue().encode('utf-8-sig')
        except (ValueError, UnicodeError, csv.Error) as err:
            return self.reply(400, {'error': str(err)})
        path = self.server.data_path
        path.parent.mkdir(parents=True, exist_ok=True)
        with LOCK:
            try:
                self.server.security.consume(self.headers.get('X-Backup-Id', ''), user['name'], self.headers.get('X-Base-Snapshot'))
                version = self.server.store.commit(raw, rows, unquote(self.headers.get('X-Source-Name', 'dashboard.csv')),
                                                 self.headers.get('X-Snapshot-Date') or max(r['snapshot'] for r in rows if r['record_type'] == 'entity'),
                                                 self.headers.get('X-Base-Snapshot'))
            except RuntimeError as err:
                return self.reply(409, {'error': str(err)})
            except ValueError as err:
                return self.reply(400, {'error': str(err)})
            mirror_raw = self.server.store.snapshot(self.server.store.list()[0]['id'])['csv']
            if path.exists():
                history = path.parent / 'history'
                history.mkdir(exist_ok=True)
                (history / (datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%f') + '.csv')).write_bytes(path.read_bytes())
            with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as temp:
                temp.write(mirror_raw)
                temp.flush()
                os.fsync(temp.fileno())
                tmp = temp.name
            os.replace(tmp, path)
            with (path.parent / 'uploads.jsonl').open('a') as log:
                log.write(json.dumps({'time': datetime.now(timezone.utc).isoformat(), 'user': user['name'], 'rows': len(rows), 'sha256': hashlib.sha256(raw).hexdigest()}) + '\n')
        return self.reply(200, {'message': 'Данные обновлены; версия сохранена', 'rows': len(rows), 'snapshot_id': version})

    def security_route(self):
        user = self.user()
        if not user:
            return self.reply(401, {'error': 'Требуется вход'})
        operator_backup = user['role'] == 'operator' and (self.path.startswith('/api/admin/backups/') or self.path == '/api/admin/rsm-evidence')
        if self.path != '/api/preferences' and user['role'] != 'admin' and not operator_backup:
            return self.reply(403, {'error': 'Доступно только админу'})
        try:
            security = self.server.security
            if self.command == 'GET':
                if self.path == '/api/preferences':
                    return self.reply(200, security.preferences(user['name']))
                if self.path == '/api/admin/users':
                    return self.reply(200, security.users())
                if self.path == '/api/admin/rsm-evidence':
                    versions=self.server.store.list()
                    known=''
                    if versions:
                        current=parse_data(self.server.store.snapshot(versions[0]['id'])['csv'])
                        known=' '.join({r.get('rsm_source','') for r in current if r['record_type']=='entity'})
                    candidates=[self.server.data_path.parent/'rsm_presence_cache.json']+list(self.server.import_jobs.root.glob('*/rsm_presence_cache.json'))
                    for path in candidates:
                        if path.exists():
                            evidence=json.loads(path.read_text())
                            signature=evidence.get('signature',[])
                            if len(signature)==2 and all(sha in known for name,sha in signature):
                                return self.reply(200,evidence)
                    return self.reply(200,None)
                if self.path.startswith('/api/admin/backups/file/'):
                    key = self.path.split('/')[-1]
                    security.receipt(key, user['name'])
                    return self.reply(200, (security.folder / (key + '.sqlite3')).read_bytes(), 'application/octet-stream')
            size = int(self.headers.get('Content-Length', 0))
            if self.command != 'POST' or not 0 < size <= 600000:
                raise ValueError('Неверный запрос')
            body = json.loads(self.rfile.read(size))
            if not isinstance(body, dict):
                raise ValueError('Неверный запрос')
            if self.path == '/api/preferences':
                return self.reply(200, security.preferences(user['name'], body))
            if self.path == '/api/admin/users':
                security.save_user(body, password_hash)
                return self.reply(200, security.users())
            if self.path == '/api/admin/backups/prepare':
                with LOCK:
                    return self.reply(200, security.prepare(user['name'], body.get('base', '')))
            if self.path == '/api/admin/backups/ack':
                security.acknowledge(body.get('id'), user['name'], body.get('sha256'))
                return self.reply(200, {'message': 'Копия на устройстве проверена'})
            return self.reply(404, {'error': 'Не найдено'})
        except RuntimeError as error:
            return self.reply(409, {'error': str(error)})
        except (ValueError, TypeError, KeyError, OSError) as error:
            return self.reply(400, {'error': str(error)})

    def import_route(self):
        user = self.user()
        if not user:
            return self.reply(401, {'error': 'Требуется вход'})
        if user['role'] not in ('admin', 'operator'):
            return self.reply(403, {'error': 'Загрузка Excel доступна оператору и админу'})
        parts = self.path.strip('/').split('/')
        if parts[:3] != ['api', 'import', 'jobs']:
            return self.reply(404, {'error': 'Не найдено'})
        jobs, owner = self.server.import_jobs, user['name']
        try:
            if self.command == 'GET':
                if len(parts) == 3:
                    return self.reply(200, jobs.list(owner))
                if len(parts) == 4:
                    return self.reply(200, jobs.get(parts[3], owner))
                if len(parts) == 5 and parts[4] == 'result':
                    return self.reply(200, jobs.result(parts[3], owner))
            size = int(self.headers.get('Content-Length', '0'))
            if self.command != 'POST' or not 0 < size <= FILE_LIMIT:
                raise ValueError('Неверный запрос или файл больше 300 МБ')
            if len(parts) == 6 and parts[4] == 'files':
                return self.reply(200, jobs.upload(parts[3], owner, parts[5], self.rfile, size,
                                                  unquote(self.headers.get('X-Source-Name', parts[5] + '.xlsx'))))
            if size > 100000:
                raise ValueError('Слишком большой служебный запрос')
            body = json.loads(self.rfile.read(size))
            if not isinstance(body, dict):
                raise ValueError('Неверный запрос')
            if len(parts) == 3:
                return self.reply(200, jobs.create(owner, body.get('date'), body.get('base', ''),body.get('mode','create')))
            if len(parts) == 5 and parts[4] == 'run':
                return self.reply(200, jobs.run(parts[3], owner))
            if len(parts) == 5 and parts[4] == 'commit':
                with LOCK:
                    self.server.security.consume(body.get('backup_id', ''), owner, body.get('base'))
                    return self.reply(200, jobs.commit(parts[3], owner, body.get('base')))
            return self.reply(404, {'error': 'Не найдено'})
        except PermissionError as error:
            return self.reply(403, {'error': str(error)})
        except RuntimeError as error:
            return self.reply(409, {'error': str(error)})
        except (ValueError, KeyError, TypeError, zipfile.BadZipFile) as error:
            return self.reply(400, {'error': str(error)})

    def state_import_route(self):
        user = self.user()
        if not user:
            return self.reply(401, {'error': 'Требуется вход'})
        if user['role'] != 'admin':
            return self.reply(403, {'error': 'Добавление срезов доступно только админу'})
        try:
            size = int(self.headers.get('Content-Length', 0))
            if not 0 < size <= 200 * 1024 * 1024:
                raise ValueError('Максимальный размер истории — 200 МБ')
            value = json.loads(self.rfile.read(size))
            with LOCK:
                self.server.security.consume(self.headers.get('X-Backup-Id', ''), user['name'])
                return self.reply(200, self.server.store.import_backup(value, user['name'], parse_data, FIELDS))
        except (ValueError, KeyError, TypeError, AttributeError) as error:
            return self.reply(400, {'error': str(error)})


def make_server(host, port, users, data):
    server = ThreadingHTTPServer((host, port), Handler)
    server.users_path, server.data_path = Path(users), Path(data)
    server.store = StateStore(server.data_path.parent / 'dashboard_state.sqlite3')
    server.security = Security(server.store, server.users_path)
    server.import_jobs = ImportJobs(server.data_path.parent / 'import_jobs', server.store, parse_data)
    if server.data_path.exists() and not server.store.list():
        raw = server.data_path.read_bytes()
        rows = parse_data(raw)
        server.store.commit(raw, rows, 'Исходные данные', max(r['snapshot'] for r in rows if r['record_type'] == 'entity'))
    return server


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--host', default='127.0.0.1')
    p.add_argument('--port', type=int, default=8080)
    p.add_argument('--users', type=Path, default=ROOT / 'private' / 'users.json')
    p.add_argument('--data', type=Path, default=ROOT / 'data' / 'dashboard.csv')
    p.add_argument('--add-user')
    p.add_argument('--role', choices=['user', 'operator', 'admin', 'viewer', 'uploader'], default='user')
    a = p.parse_args()
    if a.add_user:
        if ':' in a.add_user or not a.add_user.strip():
            p.error('Неверный логин')
        password = getpass.getpass('Пароль (не менее 12 символов): ')
        if len(password) < 12 or password != getpass.getpass('Повторите пароль: '):
            p.error('Пароли не совпадают или короче 12 символов')
        users = json.loads(a.users.read_text()) if a.users.exists() else {}
        salt = secrets.token_hex(16)
        users[a.add_user] = dict(role=ROLES[a.role], salt=salt, hash=password_hash(password, salt))
        a.users.parent.mkdir(parents=True, exist_ok=True)
        a.users.write_text(json.dumps(users))
        a.users.chmod(0o600)
        store = StateStore(a.data.parent / 'dashboard_state.sqlite3')
        Security(store, a.users).save_user(dict(name=a.add_user, password=password, role=ROLES[a.role]), password_hash)
    else:
        if not a.users.exists():
            p.error('Сначала создайте пользователей через --add-user')
        if a.data.exists():
            parse_data(a.data.read_bytes())
        print(f'МультиЦОД+ → http://{a.host}:{a.port}', flush=True)
        make_server(a.host, a.port, a.users, a.data).serve_forever()
