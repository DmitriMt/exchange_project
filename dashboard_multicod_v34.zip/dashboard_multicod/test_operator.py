import base64
import io
import json
from pathlib import Path
import tempfile
import threading
import time
from unittest.mock import patch
import unittest
from urllib.error import HTTPError
from urllib.request import Request, urlopen
import zipfile
from server import ROOT, make_server, password_hash
from importer import REQUIRED_ROLES

class OperatorTests(unittest.TestCase):
    def test_operator_routes_and_five_sources(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);data=root/'dashboard.csv';data.write_bytes((ROOT/'data/dashboard.csv').read_bytes())
            users=root/'users.json';salt='ab'*16
            users.write_text(json.dumps({r:dict(role=r,salt=salt,hash=password_hash('test-password-only',salt)) for r in ['user','operator','admin']}))
            server=make_server('127.0.0.1',0,users,data)
            threading.Thread(target=server.serve_forever,daemon=True).start()
            def req(path,body=None,role='operator',raw=None):
                h={'Authorization':'Basic '+base64.b64encode((role+':test-password-only').encode()).decode()}
                value=raw if raw is not None else json.dumps(body).encode() if body is not None else None
                h['Content-Type']='application/octet-stream' if raw is not None else 'application/json'
                try:
                    with urlopen(Request('http://127.0.0.1:'+str(server.server_port)+path,data=value,headers=h)) as r:
                        b=r.read();return r.status,json.loads(b) if r.headers.get('Content-Type','').startswith('application/json') else b
                except HTTPError as e:return e.code,json.loads(e.read())
            try:
                self.assertEqual(req('/api/me')[1]['role'],'operator')
                self.assertEqual(req('/api/import/jobs',role='user')[0],403)
                self.assertEqual(req('/api/admin/users')[0],403)
                self.assertEqual(req('/api/admin/users',{'name':'new','role':'admin','password':'test-password-only'})[0],403)
                self.assertEqual(req('/api/planning',{'ci':'CI123','value':{},'revision':0})[0],403)
                self.assertEqual(req('/api/preferences',{'filters':{'dit':'Mine'}})[0],200)
                self.assertEqual(REQUIRED_ROLES,{'rsm','questionnaire'})
                base=server.store.list()[0]['id']
                status,job=req('/api/import/jobs',{'date':'2026-11-04','base':base});self.assertEqual(status,200)
                route='/api/import/jobs/'+job['id'];stream=io.BytesIO()
                with zipfile.ZipFile(stream,'w') as book:book.writestr('xl/workbook.xml','<workbook/>')
                for role in REQUIRED_ROLES:self.assertEqual(req(route+'/files/'+role,raw=stream.getvalue())[0],200)
                self.assertEqual(set(req(route)[1]['files']),REQUIRED_ROLES)
                self.assertEqual(req(route+'/commit',{'base':base})[0],400)
                def prepare(folder, output, date, progress):
                    self.assertEqual(len(list(folder.glob('*.xlsx'))),2)
                    output.write_bytes(data.read_bytes().replace(b'2026-11-03',date.encode()))
                    return {'entities':1415}
                with patch('importer.prepare',prepare), patch('fincontrol_model.resource_evidence',return_value={'signature':[], 'resources':{}}):
                    self.assertEqual(req(route+'/run',{})[0],200)
                    for _ in range(100):
                        job=req(route)[1]
                        if job['status'] not in ('running','uploading'):break
                        time.sleep(.02)
                    self.assertEqual(job['status'],'ready',job)

                status,receipt=req('/api/admin/backups/prepare',{'base':base});self.assertEqual(status,200)
                self.assertEqual(req('/api/admin/backups/file/'+receipt['id'])[0],200)
                self.assertEqual(req('/api/admin/backups/file/'+receipt['id'],role='user')[0],403)
                self.assertEqual(req('/api/admin/backups/ack',{'id':receipt['id'],'sha256':receipt['sha256']})[0],200)
                self.assertEqual(req('/api/admin/rsm-evidence')[0],200)
                self.assertEqual(req(route+'/commit',{'base':base,'backup_id':receipt['id']})[0],200)
                self.assertEqual(len(server.store.list()),2)
                current=server.store.list()[0];count=len(server.store.list())
                status,extra=req('/api/import/jobs',{'base':current['id'],'mode':'supplement'});self.assertEqual(status,200)
                extra_route='/api/import/jobs/'+extra['id']
                self.assertEqual(req(extra_route+'/files/rsm',raw=stream.getvalue())[0],400)
                self.assertEqual(req(extra_route+'/files/wallet',raw=stream.getvalue())[0],200)
                def enrich(records,folder,progress):
                    result=[dict(r) for r in records];result[0]['pshe_vendor_standin']='17';return result
                with patch('supplement.enrich',enrich):
                    self.assertEqual(req(extra_route+'/run',{})[0],200)
                    for _ in range(100):
                        extra=req(extra_route)[1]
                        if extra['status']!='running':break
                        time.sleep(.02)
                    self.assertEqual(extra['status'],'ready',extra)
                status,receipt=req('/api/admin/backups/prepare',{'base':current['id']});self.assertEqual(status,200)
                self.assertEqual(req('/api/admin/backups/ack',{'id':receipt['id'],'sha256':receipt['sha256']})[0],200)
                self.assertEqual(req(extra_route+'/commit',{'base':current['id'],'backup_id':receipt['id']})[0],200)
                after=server.store.list()[0];self.assertEqual(after['id'],current['id']);self.assertEqual(after['date'],current['date']);self.assertEqual(after['at'],current['at']);self.assertEqual(len(server.store.list()),count)

                server.security.save_user(dict(name='new-operator',role='operator',password='test-password-only'),password_hash)
                self.assertEqual(server.security.account('new-operator')['role'],'operator')
            finally:server.shutdown();server.server_close()

if __name__=='__main__':unittest.main()
