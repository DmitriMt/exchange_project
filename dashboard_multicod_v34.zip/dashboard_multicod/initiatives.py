"""Lossless initiative report validation and transactional, snapshot-bound imports."""
import hashlib
import json
import math
import re
from datetime import datetime, timezone
from pathlib import Path

CONFIG = Path(__file__).parent / 'data' / 'initiative_config.json'


def config():
    return json.loads(CONFIG.read_text())


def text(v):
    return str(v if v is not None else '').strip()


def norm(v):
    return re.sub(r'\s+', ' ', text(v)).strip()


def prepare(body, registry, cfg=None):
    cfg = cfg or config()
    sheets = body.get('sheets')
    if not isinstance(sheets, dict):
        raise ValueError('Нет листов отчёта')
    source = sheets.get('Общая информация и затраты')
    if not isinstance(source, list) or not 3 <= len(source) <= 5002:
        raise ValueError('Ожидается лист Общая информация и затраты, до 5000 строк данных')
    for name, rows in sheets.items():
        if name not in ['Общая информация и затраты', 'Оценка', 'Эффекты'] or not isinstance(rows, list) or len(rows) > 5002:
            raise ValueError('Неверные листы отчёта')
        previous_line = 0
        for row in rows:
            if not isinstance(row, list) or len(row) != 2 or not isinstance(row[0], int) or not isinstance(row[1], dict):
                raise ValueError('Неверная строка отчёта')
            if row[0] <= previous_line:
                raise ValueError('Повторный или нарушенный номер строки')
            previous_line = row[0]
            if any(not re.fullmatch('[A-Z]{1,2}', k) or not isinstance(v, (str, int, float)) or len(text(v)) > 20000 for k, v in row[1].items()):
                raise ValueError('Неверное значение ячейки')
    if source[0][0] != 1 or source[1][0] != 2 or any(norm(source[0][1].get(k)) != norm(v) for k, v in cfg['headers'].items()) or any(norm(v) and k not in cfg['headers'] for _, row in source for k, v in row.items()):
        raise ValueError('Структура отчёта изменилась: заголовки не совпадают. Ничего не сохранено.')
    catalog = dict(cfg['catalog'])
    catalog.update({e['id_ke']: e for e in registry})
    scope = {e['id_ke'] for e in registry}
    mappings = body.get('mappings', {})
    if not isinstance(mappings, dict) or len(mappings) > 5000:
        raise ValueError('Неверное сопоставление')
    codes = {text(r.get('BB')) for _, r in source[2:] if text(r.get('BB'))}
    for code, ci in mappings.items():
        if code not in codes or not isinstance(ci, str) or ci not in catalog:
            raise ValueError('Сопоставление содержит неизвестный код или КЭ: ' + str(code))
    initiatives, lines, seen, errors = {}, [], set(), []
    for line, raw in source[2:]:
        if not any(text(v) for v in raw.values()):
            continue
        try:
            r = {k: text(v) for k, v in raw.items()}
            code = r.get('C', '')
            if not re.fullmatch('[0-9]{1,30}', code) or not r.get('D'):
                raise ValueError('Нужны текстовый код и название инициативы; научная запись кода не допускается')
            if r.get('A') != '0':
                raise ValueError('Поддерживается версия БП (0); другие версии нельзя смешивать')
            if not re.fullmatch('20[0-9]{2}', r.get('B', '')) or r.get('E', '') not in ['', '1', '2']:
                raise ValueError('Неверный год или тип инициативы')
            for k in ['AG', 'AH']:
                if not re.fullmatch('[1-4]\.20[0-9]{2}', r.get(k, '')):
                    raise ValueError('Срок инициативы должен иметь формат квартал.год')
            period = lambda v: (int(v.split('.')[1]), int(v.split('.')[0]))
            if period(r['AG']) > period(r['AH']):
                raise ValueError('Начало позже окончания инициативы')
            if r.get('BA'):
                raise ValueError('Строки с признаком удаления затрат не принимаются; загрузите полный актуальный отчёт')
            signature = json.dumps(sorted((k, v) for k, v in r.items() if v), ensure_ascii=False)
            if signature in seen:
                raise ValueError('Повторная строка затрат: возможное удвоение сумм')
            seen.add(signature)
            meta = dict(code=code, name=r['D'], year=r['B'], version=r['A'], status=r.get('L', ''),
                        kind={'': 'Change', '1': 'RUN', '2': 'ДЗО'}[r.get('E', '')],
                        block=r.get('P', ''), tribe=r.get('R', ''), product=r.get('V', ''),
                        start=r['AG'], end=r['AH'], inactive=r.get('AU', ''), result=r.get('AM', ''))
            if code in initiatives and initiatives[code] != meta:
                raise ValueError('Противоречивые реквизиты одной инициативы')
            initiatives[code] = meta
            expense = r.get('AY', '')
            if expense not in ['', 'IT', 'BS', 'DZ', 'OC']:
                raise ValueError('Неизвестный тип расходов')
            obj = r.get('BB', '')
            if expense and not obj:
                raise ValueError('В строке затрат отсутствует собственный код АС/ФП')
            def number(k):
                v = r.get(k, '')
                if not v:
                    return None
                try:
                    result = float(v.replace(',', '.'))
                except ValueError:
                    raise ValueError('Неверное число в ' + k)
                if not math.isfinite(result) or result < 0:
                    raise ValueError('Неверное число в ' + k)
                return result
            numeric = {k: number(k) for k in ['BL', 'BM', 'BN', 'BO', 'BP', 'BQ', 'BR', 'BS', 'BT', 'BY', 'BZ', 'CA', 'CB', 'CK', 'CL', 'CM', 'CN', 'CW', 'CX', 'CY', 'CZ']}
            if not expense and (obj or any(v is not None for v in numeric.values())):
                raise ValueError('Не указан тип расходов для строки затрат')
            for k in ['BH', 'BI', 'BJ', 'BK', 'BU', 'BV', 'BW', 'BX', 'CG', 'CH', 'CI', 'CJ', 'CS', 'CT', 'CU', 'CV']:
                number(k)
            for total, parts in [('BY', ['BZ', 'CA', 'CB']), ('CW', ['CX', 'CY', 'CZ']), ('CX', ['CK', 'CL', 'CM', 'CN'])]:
                if numeric[total] is not None and any(numeric[k] is not None for k in parts):
                    if abs(numeric[total] - sum(numeric[k] or 0 for k in parts)) > .05:
                        raise ValueError('Итог ' + total + ' не сходится с детализацией')
            if expense == 'OC' and any(numeric[k] not in [None, 0] for k in ['BL', 'BM', 'BN', 'BO', 'BP', 'BZ']):
                raise ValueError('Вендорская строка содержит численность/РОТ')
            if expense in ['IT', 'BS', 'DZ'] and any(numeric[k] not in [None, 0] for k in ['CK', 'CL', 'CM', 'CN', 'CX']):
                raise ValueError('Строка численности содержит вендорские расходы')
            ci = ('CI' + obj.zfill(8)) if re.fullmatch('[0-9]+', obj) else (obj if re.fullmatch('CI[0-9]{8,}', obj) else '')
            direct = ci if ci in catalog else ''
            if obj in mappings and direct and mappings[obj] != direct:
                raise ValueError('Ручное сопоставление противоречит существующему коду')
            ci = direct or mappings.get(obj, '')
            e = catalog.get(ci, {})
            lines.append(dict(line=line, initiative=code, object_code=obj, object_name=r.get('BC', ''), ci=ci,
                              category=e.get('category', ''), dit=e.get('dit', ''), expense=expense,
                              scope=('RUNUP' if ci in scope else 'outside' if ci else 'unresolved') if obj else 'none',
                              match='code' if direct else 'manual' if ci else '', numbers=numeric, raw=r))
        except ValueError as err:
            errors.append(dict(line=line, error=str(err)))
    for name, col in [('Оценка', 'B'), ('Эффекты', 'C')]:
        for line, r in sheets.get(name, []):
            if line > 2 and text(r.get(col)) not in initiatives:
                errors.append(dict(line=line, error=name + ': неизвестный код инициативы'))
    return dict(initiatives=initiatives, lines=lines, errors=errors,
                source=str(body.get('source', 'Отчёт инициатив'))[:250], mappings=mappings,
                sheets=sheets, catalog_source=cfg['catalog_source'])


def read_report(store, base):
    with store.db() as db:
        db.execute('CREATE TABLE IF NOT EXISTS initiative_reports(base TEXT PRIMARY KEY, data TEXT)')
        row = db.execute('SELECT data FROM initiative_reports WHERE base=?', (base,)).fetchone()
        return json.loads(row['data']) if row else dict(revision=0)


def save_report(store, body, user):
    with store.db() as db:
        db.execute('CREATE TABLE IF NOT EXISTS initiative_reports(base TEXT PRIMARY KEY, data TEXT)')
        db.execute('CREATE TABLE IF NOT EXISTS initiative_events(id INTEGER PRIMARY KEY, base TEXT, at TEXT, user TEXT, data TEXT)')
        db.execute('BEGIN IMMEDIATE')
        latest = db.execute('SELECT id,csv FROM snapshots ORDER BY date DESC,at DESC LIMIT 1').fetchone()
        base = body.get('base')
        if not latest or base != latest['id']:
            raise RuntimeError('Срез изменился. Повторите проверку отчёта.')
        import csv
        import io
        registry = [r for r in csv.DictReader(io.StringIO(bytes(latest['csv']).decode('utf-8-sig')), delimiter=';') if r['record_type'] == 'entity']
        report = prepare(body, registry)
        if report['errors']:
            raise ValueError('Ошибки отчёта: ' + '; '.join(str(e['line']) + ': ' + e['error'] for e in report['errors'][:5]))
        digest = hashlib.sha256(json.dumps([report['sheets'], report['mappings']], sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        old = db.execute('SELECT data FROM initiative_reports WHERE base=?', (base,)).fetchone()
        previous = json.loads(old['data']) if old else dict(revision=0)
        if type(body.get('revision')) is not int or body['revision'] != previous['revision']:
            raise RuntimeError('Инициативы изменил другой пользователь. Повторите проверку.')
        if previous.get('digest') == digest:
            return previous
        report.update(revision=previous['revision'] + 1, digest=digest, base=base, at=datetime.now(timezone.utc).isoformat(), user=user)
        db.execute('INSERT OR REPLACE INTO initiative_reports VALUES(?,?)', (base, json.dumps(report, ensure_ascii=False)))
        db.execute('INSERT INTO initiative_events(base,at,user,data) VALUES(?,?,?,?)', (base, report['at'], user, json.dumps(dict(before=previous, after=report), ensure_ascii=False)))
        return report
