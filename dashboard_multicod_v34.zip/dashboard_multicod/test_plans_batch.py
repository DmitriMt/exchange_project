import tempfile
from pathlib import Path
import unittest
from state_store import StateStore

class BatchPlansTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.store=StateStore(Path(self.tmp.name)/'state.sqlite3')
        keys=['budget_rub','cpu','ram_gb','disk_gb','pshe_change_standin','pshe_run_standin','pshe_vendor_standin']
        rows=[dict(record_type='entity',id_ke=ci,category=kind,**{k:'0'for k in keys})for ci,kind in [('CI1','АС'),('CI2','ФП')]]
        raw='record_type;id_ke;category\nentity;CI1;АС\nentity;CI2;ФП\n'.encode()
        self.base=self.store.commit(raw,rows,'Initial','2026-11-03','')
    def tearDown(self):self.tmp.cleanup()
    def item(self,ci,revision=0):return dict(ci=ci,revision=revision,value=dict(year='2026',quarter='4',target_date='2026-11-30',site='ЦОД',owner='Иван',status='Запланировано'))
    def test_as_and_fp_atomic_with_audit_and_idempotence(self):
        result=self.store.save_plans_batch([self.item('CI1'),self.item('CI2')],'admin',self.base)
        self.assertEqual(result['updated'],2);self.assertEqual(len(self.store.planning()['events']),2)
        result=self.store.save_plans_batch([self.item('CI1',1),self.item('CI2',1)],'admin',self.base)
        self.assertEqual(result['updated'],0);self.assertEqual(len(self.store.planning()['events']),2)
    def test_invalid_second_item_rolls_back_everything(self):
        for bad in [self.item('CI2',99),self.item('CI999'),self.item('CI1'),dict(ci='CI2',revision=0,value={'target_date':'2026-02-30'})]:
            with self.assertRaises((ValueError,RuntimeError)):self.store.save_plans_batch([self.item('CI1'),bad],'admin',self.base)
            self.assertEqual(self.store.planning()['plans'],{});self.assertEqual(self.store.planning()['events'],[])
    def test_stale_snapshot_and_invalid_revision_rejected(self):
        for items,base in [([self.item('CI1')],'old'),([self.item('CI1',True)],self.base),([],self.base)]:
            with self.assertRaises((ValueError,RuntimeError)):self.store.save_plans_batch(items,'admin',base)
        self.assertEqual(self.store.planning()['plans'],{})

if __name__=='__main__':unittest.main()
