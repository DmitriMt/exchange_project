// Run after build_local_html.py. Tests application state without network or browser storage.
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'../../outputs/dashboard-v34/МультиЦОД.html'),'utf8');
const script=html.match(/<script>\n([\s\S]*?)<\/script>/)[1],elements=new Map();
const el=()=>({value:'',checked:false,hidden:false,innerHTML:'',textContent:'',files:[],open:false,dataset:{},classList:{toggle(){}},querySelectorAll(){return [];},querySelector(){return null;},closest(){return null;},insertAdjacentHTML(){},remove(){},before(){},addEventListener(){},removeEventListener(){},after(){},append(){},click(){},focus(){},scrollIntoView(){},showModal(){this.open=true;},close(){this.open=false;}});
const document={getElementById(id){if(!elements.has(id))elements.set(id,el());return elements.get(id);},createElement:el,querySelector:s=>s.startsWith('.drill-panel')?null:el(),querySelectorAll:()=>[],body:{append(){}}};
const c={document,Intl,Date,TextDecoder,TextEncoder,Blob,structuredClone,setTimeout,clearTimeout,console,URL};
vm.createContext(c);vm.runInContext(script,c);


(async()=>{
 const read=e=>vm.runInContext(e,c);
 for(let i=0;i<60;i++){await new Promise(r=>setImmediate(r));if(read('stateReady'))break;}
 assert(read('stateReady'));
 const t=read('financeScope(filtered()).total');
 assert.equal(t.systems,1617);assert.equal(t.known,1466);assert.equal(t.missing,151);
 assert(Math.abs(t.fte-2045.0552644744891)<1e-8);
 assert(Math.abs(read('financeScope(filtered()).classes.reduce((s,r)=>s+r.fte,0)')-t.fte)<1e-8);
 read("page='overview';render()");assert(document.getElementById('content').innerHTML.includes('<strong>422</strong><small>АС</small>'));assert(document.getElementById('content').innerHTML.includes('<strong>993</strong><small>ФП</small>'));const overview=read('exportWorkbook()');
 const fte=overview[0].rows.find(r=>r[0]==='Потребность ПШЕ')[1];
 read("page='fincontrol';render()");const finance=read('exportWorkbook()');
 assert.equal(finance[0].rows.at(-1)[7],fte);
 assert.equal(finance[1].rows.length,1618);
 assert.equal(finance[1].rows.slice(1).filter(r=>r[9]==='Нет').length,151);
 // Every global filter applies identically to the overview and financial detail.
 document.getElementById('dit').value=read("entities.find(e=>e.category==='АС').dit");
 read("page='overview';render()");const scoped=read('exportWorkbook()[0].rows.find(r=>r[0]===\"Потребность ПШЕ\")[1]');
 read("page='fincontrol';render()");assert.equal(read('exportWorkbook()[0].rows.at(-1)[7]'),scoped);
 document.getElementById('dit').value='';document.getElementById('category').value='ФП';
 assert.equal(read('financeScope(filtered()).total.systems'),1121);assert.equal(read('financeScope(filtered()).total.known'),999);assert(Math.abs(read('financeScope(filtered()).total.fte')-767.6177424512563)<1e-8);
 assert.equal(read('operationalStats(filtered(),{},\"2026-11-05\").records.length'),993);
 document.getElementById('category').value='АС';
 assert.equal(read('financeScope(filtered()).total.systems'),436);
 assert.equal(read('financeScope(filtered()).total.known'),407);
 assert(Math.abs(read('financeScope(filtered()).total.fte')-1131.623801864576)<1e-8);
 c.scopeFixture=[{id_ke:'parent',category:'АС'},{id_ke:'child',category:'ФП',parent_id:'parent'}];
 const savedFinance=read('fincontrolData');c.fakeFinance={records:[{id_ke:'parent',fte:10,cpu_rsm:20,cpu_openshift:0,cpu_total:20}]};
 read('fincontrolData=fakeFinance');assert.equal(read('financeScope(scopeFixture).total.known'),1);assert.equal(read('financeScope(scopeFixture).total.missing'),1);assert.equal(read('financeScope(scopeFixture).total.fte'),10);c.savedFinance=savedFinance;read('fincontrolData=savedFinance');
 document.getElementById('category').value='';
 const records=['a','b','c','d','e','f','g'].map(id=>({id_ke:id,category:'АС',transition_status:id==='a'?'planned':'blank',transition_strategy:id==='a'?'A-A-A':''}));records.push({id_ke:'fp',category:'ФП',transition_status:'planned',transition_strategy:'A-P-P'});
 c.fixture=records;c.plans={a:{target_date:'2026-11-05',owner:'Иван',site:'ЦОД',status:'Подготовка'},b:{year:'2026',quarter:'3',status:'Подготовка'},c:{target_date:'2026-10-01',status:'Развёрнуто'},d:{year:'2026'},e:{year:'2027',quarter:'1',status:'Запланировано'},f:{notes:'Черновик'},g:{year:'2025',status:'Приостановлено'},fp:{year:'2026',quarter:'4',owner:'Ольга',site:'ЦОД',status:'Запланировано'}};
 const s=read('operationalStats(fixture,plans,\"2026-11-05\")');
 assert.equal(s.records.length,8);assert.equal(s.groups.prepared.length,2);assert.equal(s.groups.strategy.length,2);
 assert.equal(s.groups.quarter.length,3);assert.equal(s.groups.quarter.filter(r=>!r.done).length,2);
 assert.equal(s.groups.year.length,5);assert.equal(s.groups.done.length,1);
 assert.deepEqual(Array.from(s.groups.overdue,r=>r.entity.id_ke).sort(),['b','g']);
 assert.equal(s.groups.unscheduled.length,1);assert.equal(s.groups.unowned.length,6);
 assert.equal(read('operationalStats(fixture,plans,\"2027-01-01\").quarter'),1);
 assert.equal(read('operationalStats(fixture,plans,\"2027-01-01\").groups.overdue.length'),5);
 // Empty planning records must remain visible as missing data, without invented dates.
 assert.equal(read('operationalStats(entities,{},\"2026-11-05\").groups.unscheduled.length'),1415);
 assert.equal(read('operationalStats(entities,{},\"2026-11-05\").groups.prepared.length'),0);
 read("page='operations';operationView='unscheduled';render()");
 assert.equal(read('exportWorkbook()[0].rows.length'),1416);

 // A single operational register replaces the legacy plan/strategy screens.
 read("page='operations';operationView='all';planningStatus='';transitionFilter='';render()");
 const content=document.getElementById('content').innerHTML;
 assert(content.indexOf('Общий итог выбранного периметра')<content.indexOf('Планы и стратегии АС и ФП'));
 assert(content.indexOf('Итоги по ДИТ')<content.indexOf('Планы и стратегии АС и ФП'));
 assert(content.includes('data-edit-plan='));assert(content.includes('operationStrategy'));
 assert(!content.includes('transition-coverage'));
 const dit=read('ditOperationSummary(operationalRows().stats,operationalRows().records)');
 assert.equal(dit.total[1],422);assert.equal(dit.total[2],993);assert.equal(dit.total[3],1415);assert.equal(dit.total[4],1415);
 for(let i=1;i<dit.headers.length;i++)assert.equal(dit.total[i],dit.rows.reduce((s,r)=>s+r[i],0));
 assert.equal(read('exportWorkbook()[2].rows.at(-1)[3]'),1415);
 read("page='planning';render()");assert.equal(read('page'),'operations');
 read("page='transition';transitionFilter='planned';render()");assert.equal(read('page'),'operations');assert.equal(read('operationalRows().records.length'),0);
 read("page='pshe';render()");assert.equal(read('page'),'fincontrol');assert(!document.getElementById('content').innerHTML.includes('Сверка с полным'));
 const nav=html.match(/<nav[^>]*>([\s\S]*?)<\/nav>/)[1];
 for(const id of ['planning','transition','pshe'])assert(!nav.includes('data-page="'+id+'"'));
 assert(nav.includes('data-page="operations"'));
 const synthetic=read('operationalStats(fixture,plans,"2026-11-05")');c.syntheticStats=synthetic;
 const grouped=read('ditOperationSummary(syntheticStats,syntheticStats.groups.quarter)');
 assert.equal(grouped.total[3],8);assert.equal(grouped.total[4],3);assert.equal(grouped.total[5],8);assert.equal(grouped.total[6],2);assert.equal(grouped.total[7],2);assert.equal(grouped.total[8],3);assert.equal(grouped.total[9],5);
 console.log('PASS: CI reconciliation, identical overview/detail/export FTE, global filters, FP inclusion, missing calculations, equal AS/FP planning, quarter/year boundaries, completed and paused deadlines, honest missing plans.');
})().catch(e=>{console.error(e);process.exitCode=1;});
