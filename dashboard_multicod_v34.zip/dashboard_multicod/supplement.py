"""Optional enrichment keeps the snapshot identity and immutable RUNUP/RSM evidence."""
import csv, io, json, hashlib
from copy import deepcopy
from datetime import datetime, timezone
from prepare_data import FIELDS, xlsx_rows, optional_data
from ownership import enrich_ownership, OWNERSHIP_FIELDS, CATALOG_COLUMNS
from registry import annotate_registry

ALLOWED = set(OWNERSHIP_FIELDS+['business_block','catalog_presence','fp_registry_total','fp_registry_children_json','pshe_model_inputs','pshe_source_change','pshe_source_run','pshe_status','pshe_prom_status']+[k for k in FIELDS if k.startswith(('pshe_change_','pshe_run_','pshe_vendor_'))])

def encode(rows):
    out=io.StringIO(newline='');w=csv.DictWriter(out,fieldnames=FIELDS,delimiter=';');w.writeheader();w.writerows(rows);return out.getvalue().encode('utf-8-sig')

def guard(before, after):
    a={r['id_ke']:r for r in before if r['record_type']=='entity'};b={r['id_ke']:r for r in after if r['record_type']=='entity'}
    if a.keys()!=b.keys():raise ValueError('Обновление не может менять состав RUNUP')
    for ci in a:
        if any(a[ci].get(k,'')!=b[ci].get(k,'') for k in FIELDS if k not in ALLOWED):raise ValueError('Изменились базовые данные RUNUP/РСМ: '+ci)

def enrich(rows,folder,progress=print):
    entities={r['id_ke']:deepcopy(r) for r in rows if r['record_type']=='entity'};date=next(iter(entities.values()))['snapshot'];full={}
    cats=list(folder.glob('table_runup_DS_main_Katalog_IT-uslug_*.xlsx'))
    if len(cats)>1:raise ValueError('Нужен один каталог')
    for i,r in (xlsx_rows(cats[0]) if cats else []):
        if i==1:
            if r.get('A')!='ID КЭ' or r.get('BF')!='Владелец (Блок)' or r.get('BM')!='Код трайба/ГАК':raise ValueError('Не распознан каталог')
            continue
        if not r.get('A') or r['A'] in full:raise ValueError('Повторный или пустой КЭ каталога')
        full[r['A']]={k:r.get(k,'') for k in CATALOG_COLUMNS}
    if cats and not full:raise ValueError('Каталог пуст')
    if cats:
        overlay=dict(full)
        for ci,e in entities.items():
            c=full.get(ci,{})
            if c.get('G') and c['G']!={'АС':'Автоматизированные системы','ФП':'Функциональная подсистема'}[e['category']]:raise ValueError('Тип каталога не совпал с RUNUP: '+ci)
            e.update(business_block=c.get('BF') or '(не указан)',catalog_presence='1' if c else '0')
            overlay[ci]={**c,'A':ci,'B':e['name'],'G':{'АС':'Автоматизированные системы','ФП':'Функциональная подсистема'}[e['category']],'H':'('+e['parent_id']+')' if e['parent_id'] else '', 'S':e['criticality'],'M':e['lifecycle'],'V':e['dit']}
        enrich_ownership(entities,overlay);annotate_registry(entities)
    budgets,outside,_,_=optional_data(entities,folder,full,date,set(entities),progress)
    result=list(entities.values())+(budgets+outside if (folder/'Кошельки.xlsx').exists() else [deepcopy(r) for r in rows if r['record_type']!='entity'])
    # Refresh budget labels after ownership updates, without altering amounts.
    for r in result:
        if r['record_type']=='budget' and r['id_ke'] in entities:
            for k in ['name','category','parent_id','dit','business_block','criticality','lifecycle']:r[k]=entities[r['id_ke']][k]
    guard(rows,result);return result

def workbook_initiatives(folder,rows,mappings=None):
    path=folder/'Инициативы.xlsx'
    if not path.exists():return None
    from initiatives import prepare
    import zipfile
    sheets={}
    with zipfile.ZipFile(path) as z:xml=z.read('xl/workbook.xml').decode()
    for name in ['Общая информация и затраты','Оценка','Эффекты']:
        if name in xml:sheets[name]=[[i,r] for i,r in xlsx_rows(path,sheet=name)]
    codes={str(r.get('BB','')).strip() for i,r in sheets.get('Общая информация и затраты',[]) if i>2}
    kept={k:v for k,v in (mappings or {}).items() if k in codes}
    result=prepare(dict(sheets=sheets,mappings=kept,source=path.name),[r for r in rows if r['record_type']=='entity'])
    if result['errors']:raise ValueError('Инициативы: '+str(result['errors'][:5]))
    return result

def write_report(db,base,report,user,expected=None):
    if report is None:return
    db.execute('CREATE TABLE IF NOT EXISTS initiative_reports(base TEXT PRIMARY KEY,data TEXT)')
    db.execute('CREATE TABLE IF NOT EXISTS initiative_events(id INTEGER PRIMARY KEY,base TEXT,at TEXT,user TEXT,data TEXT)')
    row=db.execute('SELECT data FROM initiative_reports WHERE base=?',(base,)).fetchone();before=json.loads(row['data']) if row else {'revision':0}
    if expected is not None and before['revision']!=expected:raise RuntimeError('Инициативы изменились. Повторите проверку.')
    digest=hashlib.sha256(json.dumps([report['sheets'],report['mappings']],sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    if before.get('digest')==digest:return
    value={**report,'base':base,'revision':before['revision']+1,'digest':digest,'at':datetime.now(timezone.utc).isoformat(),'user':user}
    db.execute('INSERT OR REPLACE INTO initiative_reports VALUES(?,?)',(base,json.dumps(value,ensure_ascii=False)))
    db.execute('INSERT INTO initiative_events(base,at,user,data) VALUES(?,?,?,?)',(base,value['at'],user,json.dumps({'before':before,'after':value},ensure_ascii=False)))
