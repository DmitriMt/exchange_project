// Run after build_local_html.py. Tests application state without network or browser storage.
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'../../outputs/dashboard-v34/МультиЦОД.html'),'utf8');
const script=html.match(/<script>\n([\s\S]*?)<\/script>/)[1],elements=new Map();
const el=()=>({value:'',checked:false,hidden:false,innerHTML:'',textContent:'',files:[],open:false,dataset:{},classList:{toggle(){}},querySelectorAll(){return [];},querySelector(){return null;},closest(){return null;},insertAdjacentHTML(){},remove(){},before(){},addEventListener(){},removeEventListener(){},after(){},append(){},click(){},focus(){},scrollIntoView(){},showModal(){this.open=true;},close(){this.open=false;}});
const document={getElementById(id){if(!elements.has(id))elements.set(id,el());return elements.get(id);},createElement:el,querySelector:s=>s.startsWith('.drill-panel')?null:el(),querySelectorAll:()=>[],body:{append(){}}};
const c={document,Intl,Date,TextDecoder,TextEncoder,Blob,structuredClone,setTimeout,clearTimeout,console,URL};
vm.createContext(c);vm.runInContext(script,c);


(async()=>{
 const read=e=>vm.runInContext(e,c),get=id=>document.getElementById(id);
 for(let i=0;i<80;i++){await new Promise(r=>setImmediate(r));if(read('stateReady'))break;}
 await read('ensureInitiativeReport()');
 assert.equal(read('financeScope(filtered()).total.mui'),null);
 read("page='fincontrol';render()");assert(get('content').innerHTML.includes('ПШЕ в МУИ'));assert(!get('content').innerHTML.includes('CPU выбранных АС'));
 const originalFte=read('financeScope(filtered()).total.fte');
 c.body=read(`({sheets:{'Общая информация и затраты':[[1,structuredClone(INITIATIVE_CONFIG.headers)],[2,{}],...['232517','3197613','3421627','3457040','4596809','5306897'].map((obj,i)=>[i+3,{A:'0',B:'2027',C:'2026081713121230',D:'МультиЦОД+ Домклик',L:'Приостановлена',AG:'1.2027',AH:'4.2027',AY:'IT',BB:obj,BC:'Объект',BM:'0.1',BN:'0.2',BO:'0.25',BP:obj==='3197613'?'0.5':'0.3',BY:'100',BZ:'100'}])]},source:'Test.xlsx',mappings:{},base:liveVersion,revision:0})`);
 const fp=read("financeScope(filtered()).missing.find(r=>r.entity.category==='ФП').entity");
 const extra={...c.body.sheets['Общая информация и затраты'][2][1],BB:fp.id_ke,BC:fp.name,BP:'0.25',BM:'0.25'};
 c.body.sheets['Общая информация и затраты'].push([9,extra],[10,{...extra,BB:'IT2027',BC:'Без сопоставления',BP:'2',BM:'2'}]);
 await read('stateRepo.saveInitiatives(body)');read('initiativeContext=null');await read('ensureInitiativeReport()');read("page='fincontrol';render()");
 const f=read('financeScope(filtered())');assert(Math.abs(f.total.mui-1.05)<1e-8);assert.equal(f.total.fte,originalFte);
 assert(Math.abs(f.classes.reduce((s,r)=>s+(r.mui||0),0)-f.total.mui)<1e-8);
 assert.equal(f.mui.unresolved,2);assert(Math.abs(f.mui.full-f.total.mui-(f.mui.outside||0)-f.mui.unresolved)<1e-8);
 read("page='overview';render()");const overviewHtml=get('content').innerHTML;assert(overviewHtml.indexOf('АС и ФП в программе')<overviewHtml.indexOf('ПШЕ в МУИ'));assert(overviewHtml.indexOf('ПШЕ в МУИ')<overviewHtml.indexOf('Стоимость КТС'));assert.equal(read('exportWorkbook()[0].rows.find(r=>r[0]==="ПШЕ в МУИ")[1]'),f.total.mui);
 get('muiPeriod').value='BM';get('muiPeriod').onchange();assert(Math.abs(read('financeScope(filtered()).total.mui')-.45)<1e-8);read("page='fincontrol';muiPeriodKey='BP';render()");
 let sheets=read('exportWorkbook()');assert.equal(sheets[0].rows[0][8],'ПШЕ в МУИ');assert.equal(sheets[0].rows.at(-1)[8],f.total.mui);assert.equal(sheets[0].rows.at(-1)[7],originalFte);
 get('muiPeriod').value='BM';get('muiPeriod').onchange();assert(Math.abs(read('financeScope(filtered()).total.mui')-.45)<1e-8);
 assert.equal(read('financeScope(filtered()).mui.period.label'),'1 квартал 2027 · на 01.04.2027');
 get('category').value='ФП';assert.equal(read('financeScope(filtered()).total.mui'),.25);
 get('category').value='АС';assert(Math.abs(read('financeScope(filtered()).total.mui')-.2)<1e-8);
 get('category').value='';get('search').value=fp.id_ke;assert.equal(read('financeScope(filtered()).total.mui'),.25);
 get('search').value='';read("muiPeriodKey='BP'");c.body.revision=1;
 for(const row of c.body.sheets['Общая информация и затраты'].slice(2))row[1].BP='0';
 await read('stateRepo.saveInitiatives(body)');read('initiativeContext=null');await read('ensureInitiativeReport()');assert.strictEqual(read('financeScope(filtered()).total.mui'),0);
 read('viewVersion="other-snapshot"');assert.equal(read('financeScope(filtered()).total.mui'),null);
 console.log('PASS: MUI metric replaces CPU; summary/export tie-out; period selection; AS and FP filters; objects without model estimates; unmapped/outside separation; zero vs missing; snapshot isolation; resource-model FTE unchanged.');
})().catch(e=>{console.error(e);process.exitCode=1;});
