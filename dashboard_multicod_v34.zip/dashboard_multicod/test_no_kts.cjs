// Run after build_local_html.py. Tests application state without network or browser storage.
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'../../outputs/dashboard-v34/МультиЦОД.html'),'utf8');
const script=html.match(/<script>\n([\s\S]*?)<\/script>/)[1],elements=new Map();
const el=()=>({value:'',checked:false,hidden:false,innerHTML:'',textContent:'',files:[],open:false,dataset:{},classList:{toggle(){}},querySelectorAll(){return [];},querySelector(){return null;},closest(){return null;},insertAdjacentHTML(){},remove(){},before(){},addEventListener(){},removeEventListener(){},after(){},append(){},click(){},focus(){},scrollIntoView(){},showModal(){this.open=true;},close(){this.open=false;}});
const document={getElementById(id){if(!elements.has(id))elements.set(id,el());return elements.get(id);},createElement:el,querySelector:s=>s.startsWith('.drill-panel')?null:el(),querySelectorAll:()=>[],body:{append(){}}};
const c={document,Intl,Date,TextDecoder,TextEncoder,Blob,structuredClone,setTimeout,clearTimeout,console,URL};
vm.createContext(c);vm.runInContext(script,c);

(async()=>{
 const read=e=>vm.runInContext(e,c),get=id=>document.getElementById(id);
 for(let i=0;i<30;i++){await new Promise(r=>setImmediate(r));if(read('stateReady'))break;}
 assert(read('stateReady'));read("page='noKts';resetAllFilters();render()");
 assert(html.includes('data-page="noKts"'));assert(get('content').innerHTML.includes('ФП без КТС'));
 assert.equal(read("filtered().filter(e=>e.category==='ФП'&&e.rsm_presence==='0').length"),122);
 assert.equal(read("filtered().filter(e=>e.category==='ФП'&&e.rsm_presence==='1').length"),871);
 assert.equal(read('exportWorkbook()[0].rows.length'),123);
 if(process.env.MULTICOD_NO_KTS_XLSX)fs.writeFileSync(process.env.MULTICOD_NO_KTS_XLSX,Buffer.from(await read('makeXlsx(exportWorkbook())').arrayBuffer()));
 assert(read('exportWorkbook()[0].rows.slice(1).every(r=>r[16]===\'Нет в обеих РСМ\'&&r[17]===0)'));
 const before=read('JSON.stringify(exportWorkbook()[0].rows)');read('budgets=[];render()');assert.equal(read('JSON.stringify(exportWorkbook()[0].rows)'),before);
 read("globalThis.missingFp=entities.find(e=>e.category==='ФП'&&e.rsm_presence==='0')");await read('openVolumeObject(missingFp.id_ke)');assert(get('dialogBody').innerHTML!==undefined);
 read("missingFp.rsm_presence='';missingFp.rsm_rows='';missingFp.rsm_source='';render()");
 assert.equal(read('exportWorkbook()[0].rows.length'),122);assert.equal(read('exportWorkbook().find(s=>s.name===\'Не проверено\').rows.length'),2);
 assert(get('content').innerHTML.includes('не считаются ФП без КТС'));
 const fields=read("LOCAL_FIELDS.slice(0,LOCAL_FIELDS.indexOf('rsm_presence'))"),records=read('structuredClone(rows)');
 const q=v=>'"'+String(v??'').replace(/"/g,'""')+'"';c.oldCsv='\uFEFF'+[fields,...records.map(r=>fields.map(k=>r[k]))].map(r=>r.map(q).join(';')).join('\r\n');
 // Convert escaped markers in this test payload to actual CSV bytes.
 c.oldCsv=c.oldCsv.replace(/^\\uFEFF/,'\uFEFF').replace(/\\r\\n/g,'\r\n');
 const old=read('parseLocalCsv(oldCsv)');assert(old.every(r=>r.rsm_presence===''));assert(old.some(r=>r.owner_department));
 await read('makeXlsx(exportWorkbook())').arrayBuffer();
 assert(!html.includes('max-width:1800px'));assert(html.includes('main{max-width:none;min-width:0}'));
 console.log('PASS: 122 absent /871 present, RSM independent of budget, unknown separated, legacy v13 accepted, Excel and full-width styles.');
})().catch(e=>{console.error(e);process.exitCode=1;});
