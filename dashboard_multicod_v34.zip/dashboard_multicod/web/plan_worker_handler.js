self.onmessage=async({data})=>{try{
 const file=new File([data.bytes],data.name),book=await new BrowserXlsx(file).open();
 const xml=await book.xml('xl/workbook.xml'),date1904=/date1904\s*=\s*["'](?:1|true)["']/.test(xml),rows=[];
 for await(const [i,r]of book.rows('Планы')){if(i>5001)throw new Error('Не более 5000 строк');rows.push([i,Array.from({length:12},(_,n)=>r[String.fromCharCode(65+n)]||'')]);if(Object.entries(r).some(([k,v])=>!/^([A-L])$/.test(k)&&String(v).trim()))throw new Error('Лишние колонки в листе Планы');}
 let base='';if(/name=["']Параметры["']/.test(xml))for await(const [,r]of book.rows('Параметры'))if(r.A==='Срез')base=r.B||'';
 self.postMessage({rows,date1904,base});
}catch(e){self.postMessage({error:e.message||String(e)});}};
