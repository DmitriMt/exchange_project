'use strict';
// A self-contained HTML prepares Excel locally; hosted users retain the server import path.
Object.assign(sectionTitles,{update:'Экспортер Excel'});
let localExcelWorker=null,localExcelCancel=null,localExcelResult=null,localExcelGeneration=0;
const originalBrowserImportPage=importPage;
importPage=function(){
 if(!(stateRepo instanceof BrowserRepo))return originalBrowserImportPage();
 const result=localExcelResult?.profile===currentUser&&localExcelResult.mode===importMode()?localExcelResult:null;
 return `${importFormHtml(true)}${result?`<section class="panel"><h2>Срез подготовлен на ${esc(result.date)}</h2><p>${fmt(result.report.entities)} объектов · ${fmt(result.report.as_count)} АС · ${fmt(result.report.fp_count)} ФП · ${fmt(result.report.fp_without_rsm)} ФП без КТС</p><button id="reviewLocalExcel" class="primary">${result.mode==='supplement'?'Проверить дополнение':'Проверить и добавить срез'}</button><button id="downloadLocalExcelCsv">Скачать итоговый CSV</button></section>`:''}${storageMode.startsWith('Только память')?'<p class="quality-callout">Хранилище браузера недоступно: история останется только до закрытия вкладки. Скачайте итоговый CSV и резервную копию истории на устройство.</p>':''}`;
};
function stopLocalExcel(){localExcelGeneration++;localExcelCancel?.();localExcelCancel=null;if(localExcelWorker){localExcelWorker.terminate();localExcelWorker=null;}importBusy=false;}
async function runLocalExcel(event){
 event.preventDefault();if(!(stateRepo instanceof BrowserRepo)||!canEdit||importBusy)return;
 if(typeof Worker==='undefined'||(!BROWSER_JS_INFLATE_AVAILABLE&&typeof DecompressionStream==='undefined')||!globalThis.crypto?.subtle)throw new Error('Для встроенного экспортера нужен актуальный браузер с поддержкой Worker, DecompressionStream и SHA-256.');
 try{if(!BROWSER_JS_INFLATE_AVAILABLE)new DecompressionStream('deflate-raw');}catch{throw new Error('Браузер не поддерживает распаковку XLSX. Откройте HTML в актуальном Chrome или Edge.');}
 const mode=page==='enrichment'?'supplement':'create',date=mode==='supplement'?versions[0].date:$('excelDate').value,files=collectImportFiles();if(!date||mode==='create'&&requiredSourceRoles.some(k=>!files[k])||mode==='supplement'&&!Object.values(files).some(Boolean))throw new Error('Для нового среза нужны дата, RUNUP и РСМ; для дополнения выберите дополнительные файлы');if(Object.values(files).filter(Boolean).some(f=>f.size>300*1024*1024))throw new Error('Максимум 300 МБ на файл');
 const profile=currentUser,generation=++localExcelGeneration,repo=stateRepo;localExcelResult=null;importBusy=true;importProgressMode=mode;importProgress='Подготавливаем встроенный экспортер';render();
 const url=URL.createObjectURL(new Blob([BROWSER_IMPORT_WORKER],{type:'application/javascript'}));let ownedWorker=null,ownedCancel=null;
 try{
  const baseSnapshot=liveVersion?await repo.getSnapshot(liveVersion):null,initiativeRevision=liveVersion?(await repo.getInitiatives(liveVersion)).revision:0;const questionnaire=files.questionnaire?await snapshotLocalFile(files.questionnaire,importStatus):null;if(generation!==localExcelGeneration)throw new Error('Обработка отменена; данные не изменены');const safeFiles={...files};delete safeFiles.questionnaire;
  const result=await new Promise((resolve,reject)=>{
   const worker=new Worker(url);ownedWorker=worker;localExcelWorker=worker;ownedCancel=()=>reject(new Error('Обработка отменена; данные не изменены'));localExcelCancel=ownedCancel;
   worker.onmessage=({data})=>{if(generation!==localExcelGeneration)return;if(data.type==='progress')importStatus(data.message);else if(data.type==='done')resolve(data.value);else if(data.type==='error')reject(importReadError(data.message));};
   worker.onerror=event=>reject(new Error(event.message||'Не удалось запустить встроенный экспортер'));worker.postMessage({files:safeFiles,fileBuffers:questionnaire?{questionnaire}:{},date,mode,baseRows:baseSnapshot?.rows||[]},questionnaire?[questionnaire.bytes]:[]);
  });
  if(generation!==localExcelGeneration||profile!==currentUser||stateRepo!==repo)return;
  importStatus('Проверяем итоговый CSV');result.rows=parseLocalCsv(csvEncode(result.rows));
  if(files.initiatives){const sheets=await readInitiativeBook(files.initiatives),codes=new Set((sheets['Общая информация и затраты']||[]).filter(([i])=>i>2).map(([,r])=>String(r.BB||'').trim())),previous=mode==='supplement'?await repo.getInitiatives(baseSnapshot.id):{},mappings=Object.fromEntries(Object.entries(previous.mappings||{}).filter(([k])=>codes.has(k)));result.initiatives=prepareInitiatives({sheets,mappings,source:files.initiatives.name},result.rows.filter(r=>r.record_type==='entity'),await getInitiativeConfig());}if(result.initiatives?.errors.length)throw new Error('Исправьте ошибки инициатив: '+JSON.stringify(result.initiatives.errors.slice(0,5)));localExcelResult={...result,date,profile,mode,baseSnapshot,initiativeRevision};importProgress='Срез готов. Проверьте изменения или скачайте итоговый CSV.';
 }catch(error){if(generation===localExcelGeneration)importProgress=error.message;throw error;}
 finally{ownedWorker?.terminate();if(localExcelWorker===ownedWorker)localExcelWorker=null;if(localExcelCancel===ownedCancel)localExcelCancel=null;URL.revokeObjectURL(url);if(generation===localExcelGeneration){importBusy=false;if(['update','enrichment'].includes(page))render();}}
}
function localResult(){if(!localExcelResult||localExcelResult.profile!==currentUser||localExcelResult.mode!==importMode())throw new Error('Сначала подготовьте срез из Excel');return localExcelResult;}
function downloadLocalCsv(){const result=localResult();saveBlob(new Blob([csvEncode(result.rows)],{type:'text/csv;charset=utf-8'}),'МультиЦОД_'+result.date+'.csv');}
async function confirmHtmlBackup(repo){
 const value=await repo.backup(),blob=new Blob([JSON.stringify(value)],{type:'application/json'}),hash=await sha256(await blob.arrayBuffer());
 await new Promise((resolve,reject)=>{
  stateModal('Резервная копия перед добавлением среза',`<p>Сохраните текущую историю HTML на устройство и выберите сохранённый файл для проверки. До этого новый срез не добавляется.</p><button id="saveHtmlBeforeImport" class="primary">1. Скачать резервную копию истории</button><label>2. Выберите сохранённую копию<input id="checkHtmlBeforeImport" type="file" accept=".json"></label><p id="htmlBackupStatus" role="status"></p>`);
  const dialog=$('stateDialog'),closed=()=>reject(new Error('Добавление отменено: резервная копия не подтверждена'));dialog.addEventListener('close',closed,{once:true});
  $('saveHtmlBeforeImport').onclick=()=>saveBlob(blob,'МультиЦОД_история_перед_загрузкой_'+new Date().toISOString().replace(/[:.]/g,'-')+'.json');
  $('checkHtmlBeforeImport').onchange=async()=>{try{const file=$('checkHtmlBeforeImport').files[0];if(!file||file.size!==blob.size||await sha256(await file.arrayBuffer())!==hash)throw new Error('Выберите скачанную резервную копию: файл не совпадает');dialog.removeEventListener('close',closed);dialog.close();resolve();}catch(e){$('htmlBackupStatus').textContent=e.message;}};
 });
}
async function reviewLocalExcel(){
 const result=localResult(),repo=stateRepo,profile=currentUser,list=await repo.list(),base=list[0]?.id||'',previous=base?(await repo.getSnapshot(base)).rows:[];
 stateModal('Проверка Excel-среза на '+result.date,previewHtml(datasetDiff(previous,result.rows),'Изменения относительно актуального среза')+(result.report.transition?`<p>План перехода к 3 зонам доступности указан: ${fmt(result.report.transition.planned)} · пустой ответ: ${fmt(result.report.transition.blank)} · нет КЭ: ${fmt(result.report.transition.not_listed)}</p>`:'')+`<p>ФП без КТС: ${fmt(result.report.fp_without_rsm)} · дополнено моделью ПШЕ: ${fmt(result.report.model_added)}</p><details class="object-fold"><summary>Исходные файлы и контрольные суммы</summary>${table(['Источник','Файл','Размер, МБ','SHA-256'],Object.entries(result.manifest).map(([role,f])=>`<tr><td>${esc(sourceRoles[role])}</td><td>${esc(f.name)}</td><td class="num">${num(f.bytes/1024/1024,1)}</td><td class="rsm-source">${esc(f.sha256)}</td></tr>`).join(''))}</details><div class="dialog-actions"><button id="saveLocalPreparedCsv">Скачать итоговый CSV</button><button id="applyLocalPreparedCsv" class="primary">${result.mode==='supplement'?'Обновить дополнительные данные':'Добавить срез в историю HTML'}</button></div>`);
 $('saveLocalPreparedCsv').onclick=downloadLocalCsv;
 $('applyLocalPreparedCsv').onclick=async()=>{const b=$('applyLocalPreparedCsv');b.disabled=true;try{
  await confirmHtmlBackup(repo);if(profile!==currentUser||repo!==stateRepo||result!==localExcelResult)throw new Error('Профиль или подготовленный результат изменился. Повторите проверку.');
  if(result.mode==='supplement')await repo.updateOptional(result);else await repo.commit(result.rows,'Excel-срез '+result.date,result.date,base,result.initiatives);localExcelResult=null;await stateInit();page='history';render();message(result.mode==='supplement'?'Дополнительные данные обновлены в том же срезе.':'Срез из исходных Excel добавлен на '+result.date);
 }catch(error){stateError(error);}finally{b.disabled=false;}};
}
const browserImportRender=render;render=function(){browserImportRender();if(!['update','enrichment'].includes(page)||!(stateRepo instanceof BrowserRepo))return;if($('localExcelImportForm'))$('localExcelImportForm').onsubmit=e=>runLocalExcel(e).catch(stateError);if($('cancelLocalExcel'))$('cancelLocalExcel').onclick=()=>{stopLocalExcel();importProgress='Обработка отменена; данные не изменены';render();};if($('reviewLocalExcel'))$('reviewLocalExcel').onclick=()=>reviewLocalExcel().catch(stateError);if($('downloadLocalExcelCsv'))$('downloadLocalExcelCsv').onclick=()=>{try{downloadLocalCsv();}catch(e){stateError(e);}};};
const browserImportClear=clearUserPanels;clearUserPanels=function(){stopLocalExcel();localExcelResult=null;importProgress='';browserImportClear();};
const browserImportProfile=BrowserRepo.prototype.changeProfile;BrowserRepo.prototype.changeProfile=async function(name){stopLocalExcel();localExcelResult=null;importProgress='';return browserImportProfile.call(this,name);};
