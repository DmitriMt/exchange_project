'use strict';
let initiativeConfig=typeof INITIATIVE_CONFIG!=='undefined'?INITIATIVE_CONFIG:null,initiativeReport=null,initiativeContext=null,initiativeLoading=null,initiativeScope='all',initiativeSearch='',initiativeImportGeneration=0;
const initiativeScopeNames={RUNUP:'В RUNUP',outside:'Вне RUNUP',unresolved:'Не сопоставлен',none:'Без строки затрат'};
const stableInitiative=v=>JSON.stringify(v,(_,x)=>x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.keys(x).sort().map(k=>[k,x[k]])):x);
async function getInitiativeConfig(){if(!initiativeConfig)initiativeConfig=await api('/api/initiatives/config');return initiativeConfig;}
BrowserRepo.prototype.getInitiatives=async function(base){return (await this.settings()).initiativeReports?.[base]||{revision:0};};
ServerRepo.prototype.getInitiatives=async function(base){return api('/api/initiatives/'+encodeURIComponent(base));};
async function ensureInitiativeReport(){
 const context={repo:stateRepo,base:viewVersion,user:currentUser};
 if(!stateReady||!context.base)return;
 if(initiativeContext?.repo===context.repo&&initiativeContext.base===context.base&&initiativeContext.user===context.user)return initiativeLoading;
 initiativeContext=context;initiativeReport=null;
 initiativeLoading=context.repo.getInitiatives(context.base).then(report=>{if(initiativeContext===context)initiativeReport=report;}).catch(e=>{if(initiativeContext===context){initiativeReport={revision:0,error:e.message};}});
 return initiativeLoading;
}
function currentInitiativeReport(){return initiativeContext?.repo===stateRepo&&initiativeContext.base===viewVersion&&initiativeContext.user===currentUser?initiativeReport:null;}
function initiativeWriteGuard(){if(!stateReady||!canLoad||isHistorical())throw new Error('Загрузка инициатив доступна оператору и администратору на актуальном срезе');}
BrowserRepo.prototype.saveInitiatives=async function(body){
 const cfg=await getInitiativeConfig(),report=prepareInitiatives(body,entities,cfg);if(report.errors.length)throw new Error('Исправьте ошибки отчёта');
 const apply=s=>{
  const previous=s.initiativeReports?.[body.base]||{revision:0};if(previous.revision!==body.revision)throw new Error('Инициативы изменились. Повторите проверку.');
  if(stableInitiative([previous.sheets,previous.mappings])===stableInitiative([report.sheets,report.mappings]))return previous;
  const next={...report,base:body.base,revision:previous.revision+1,at:new Date().toISOString(),user:this.profile};
  s.initiativeReports=s.initiativeReports||{};s.initiativeReports[body.base]=next;s.initiativeEvents=s.initiativeEvents||[];s.initiativeEvents.push({base:body.base,at:next.at,user:this.profile,before:previous,after:next});return next;
 };
 if(!this.db){if((await this.list())[0]?.id!==body.base)throw new Error('Срез изменился. Повторите проверку.');return this.mutateSettings(apply);}
 return new Promise((resolve,reject)=>{let result;const tx=this.db.transaction(['settings','meta'],'readwrite'),store=tx.objectStore('settings'),request=tx.objectStore('meta').getAll();
  request.onsuccess=()=>{try{const latest=request.result.sort((a,b)=>b.date.localeCompare(a.date)||b.at.localeCompare(a.at))[0];if(latest?.id!==body.base)throw new Error('Срез изменился. Повторите проверку.');const get=store.get('workspace');get.onsuccess=()=>{try{const s=get.result||{plans:{},events:[],views:[]};result=apply(s);store.put(s,'workspace');}catch(e){tx.abort();reject(e);}};}catch(e){tx.abort();reject(e);}};
  tx.oncomplete=()=>resolve(result);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||new Error('Загрузка отменена'));
 });
};
ServerRepo.prototype.saveInitiatives=async function(body){return api('/api/initiatives/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});};
const initiativeRestore=BrowserRepo.prototype.restore;
BrowserRepo.prototype.restore=async function(value){
 const incoming=value.workspace?.initiativeReports||{},cfg=await getInitiativeConfig(),current=await this.settings();
 for(const [base,r]of Object.entries(incoming)){
  const snapshot=value.snapshots?.find(s=>s.id===base)||await this.get('snapshots',base);if(!snapshot)throw new Error('Нет среза для инициатив');
  const check=prepareInitiatives(r,parseLocalCsv(snapshot.csv).filter(e=>e.record_type==='entity'),cfg);if(check.errors.length||r.base!==base||!Number.isInteger(r.revision)||r.revision<1)throw new Error('Неверная история инициатив');
  if(current.initiativeReports?.[base]&&stableInitiative([current.initiativeReports[base].sheets,current.initiativeReports[base].mappings])!==stableInitiative([r.sheets,r.mappings]))throw new Error('Конфликт инициатив в истории. Сохраните отчёт отдельно и загрузите через предпросмотр.');
 }
 await initiativeRestore.call(this,value);
 await this.mutateSettings(s=>{s.initiativeReports={...incoming,...s.initiativeReports};s.initiativeEvents=[...(s.initiativeEvents||[]),...(value.workspace?.initiativeEvents||[]).filter(e=>!s.initiativeEvents?.some(x=>x.base===e.base&&x.at===e.at))];});
 initiativeContext=null;
};
async function readInitiativeBook(file,mapping=false){
 if(!file||! /\.xlsx$/i.test(file.name)||file.size>10*1024*1024)throw new Error('Выберите XLSX до 10 МБ');
 const data=await snapshotLocalFile(file);data.mapping=mapping;let worker;
 const local=typeof INITIATIVE_IMPORT_WORKER!=='undefined',url=local?URL.createObjectURL(new Blob([INITIATIVE_IMPORT_WORKER],{type:'text/javascript'})):'/initiative_import_worker.js';
 try{return await new Promise((resolve,reject)=>{const timer=setTimeout(()=>{worker?.terminate();reject(new Error('Чтение заняло слишком много времени'));},60000);worker=new Worker(url);worker.onmessage=({data})=>{clearTimeout(timer);data.error?reject(new Error(data.error)):resolve(data.sheets);};worker.onerror=e=>{clearTimeout(timer);reject(new Error(e.message||'Ошибка чтения XLSX'));};worker.postMessage(data,[data.bytes]);});}
 finally{worker?.terminate();if(local)URL.revokeObjectURL(url);}
}
function initiativeMappingSheets(report){
 const objects=new Map((report?.lines||[]).filter(r=>r.object_code).map(r=>[r.object_code,r]));
 const normalize=v=>String(v||'').toLowerCase().replace(/\(прочее\)/g,'').replace(/[^a-zа-яё0-9]/g,''),names=new Map();
 for(const e of Object.values({...initiativeConfig?.catalog,...Object.fromEntries(entities.map(e=>[e.id_ke,e]))})){const key=normalize(e.name);if(!key)continue;if(!names.has(key))names.set(key,[]);names.get(key).push(e.id_ke+' · '+e.category);}
 return [{name:'Сопоставление',rows:[['Код АС/ФП в отчёте','КЭ АС/ФП','Наименование в отчёте','Кандидаты по названию — требуют проверки'],...[...objects.values()].map(r=>[r.object_code,r.ci,r.object_name,r.ci?'':(names.get(normalize(r.object_name))||[]).join(' / ')])]},{name:'Инструкция',rows:[['Правило','Описание'],['Заполнение','Для несопоставленных кодов укажите собственный КЭ АС или ФП из каталога. Загрузите файл вместе с исходным отчётом. Пустой КЭ сохраняет объект как несопоставленный.'],['Кандидаты','Совпадения названий в колонке D — только подсказка. Проверьте объект и перенесите его собственный КЭ в колонку B. Автоматически по названию ничего не привязывается.'],['Запрет','Не указывайте родительскую АС вместо ФП. Автоматические совпадения по существующему коду переопределять нельзя.'],['Каталог',initiativeConfig?.catalog_source||'']]}];
}
function parseInitiativeMappings(sheets){
 const rows=sheets.Сопоставление;if(!rows?.length||rows[0][1].A!=='Код АС/ФП в отчёте'||rows[0][1].B!=='КЭ АС/ФП')throw new Error('Используйте шаблон сопоставления');
 const result={},seen=new Set();for(const [line,r]of rows.slice(1)){const code=String(r.A||'').trim(),ci=String(r.B||'').trim();if(!code&&!ci)continue;if(!code||seen.has(code))throw new Error('Пустой или повторный код в сопоставлении, строка '+line);seen.add(code);if(ci)result[code]=ci;}return result;
}
function initiativeSummaryHtml(lines){
 const t=initiativeTotals(lines),ciScope=scope=>new Set(lines.filter(r=>r.scope===scope).map(r=>r.ci||r.object_code)).size;
 return `<p><strong>Инициатив: ${fmt(t.initiatives)} · АС и ФП / кодов: ${fmt(t.objects)}</strong></p><p>В RUNUP: ${fmt(ciScope('RUNUP'))} · вне RUNUP: ${fmt(ciScope('outside'))} · не сопоставлено: ${fmt(ciScope('unresolved'))}</p>${table(['ПШЕ Q1 2027','ПШЕ Q2 2027','ПШЕ Q3 2027','ПШЕ Q4 2027','РОТ 2027, ₽','Вендоры 2027, ₽'],`<tr>${['BM','BN','BO','BP','BZ','CX'].map(k=>`<td class="num">${t[k]===null?'Нет данных':num(t[k],2)}</td>`).join('')}</tr>`)}`;
}
function initiativeLinesHtml(lines){return table(['Строка','Код инициативы','Код АС/ФП','КЭ','Тип','Наименование','Периметр','Сопоставление','Расходы','ПШЕ Q4 2027','РОТ 2027, ₽','Вендоры 2027, ₽'],lines.map(r=>`<tr><td>${r.line}</td><td><button class="table-link" data-initiative="${esc(r.initiative)}">${esc(r.initiative)}</button></td><td>${esc(r.object_code)}</td><td>${esc(r.ci||'—')}</td><td>${esc(r.category||'—')}</td><td>${esc(r.object_name)}</td><td>${esc(initiativeScopeNames[r.scope])}</td><td>${r.match==='code'?'По коду':r.match==='manual'?'Подтверждено вручную':'—'}</td><td>${esc(r.expense)}</td>${['BP','BZ','CX'].map(k=>`<td class="num">${r.numbers[k]===null?'—':num(r.numbers[k],2)}</td>`).join('')}</tr>`).join(''));}
async function openInitiativeImport(){
 initiativeWriteGuard();const generation=++initiativeImportGeneration;await getInitiativeConfig();await ensureInitiativeReport();if(generation!==initiativeImportGeneration)return;
 stateModal('Загрузка инициатив',`<p>Выберите полный отчёт инициатив версии БП (0). Новый отчёт заменит предыдущий отчёт этого среза после проверки; исходные АС, ФП и планы сохраняются.</p><label>Отчёт инициатив<input id="initiativeFile" type="file" accept=".xlsx"></label><label>Сопоставление нестандартных кодов — необязательно<input id="initiativeMappingFile" type="file" accept=".xlsx"></label><button id="checkInitiativeFile" class="primary">Проверить отчёт</button><p id="initiativeImportMessage" role="status"></p>`);
 $('checkInitiativeFile').onclick=async()=>{
  const b=$('checkInitiativeFile');b.disabled=true;
  try{
   initiativeWriteGuard();const repo=stateRepo,user=currentUser,base=liveVersion;const previous=await repo.getInitiatives(base),file=$('initiativeFile').files[0],mappingFile=$('initiativeMappingFile').files[0];
   const sheets=await readInitiativeBook(file),mappings=mappingFile?parseInitiativeMappings(await readInitiativeBook(mappingFile,true)):{};
   const body={sheets,mappings,source:file.name,base,revision:previous.revision};
   let preview=prepareInitiatives(body,entities,initiativeConfig);
   if(repo instanceof ServerRepo)preview=await api('/api/initiatives/preview',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
   if(generation!==initiativeImportGeneration||repo!==stateRepo||user!==currentUser||base!==liveVersion||isHistorical())throw new Error('Состояние изменилось. Повторите проверку.');
   showInitiativePreview(preview,body,{repo,user,base,generation},previous);
  }catch(e){$('initiativeImportMessage').textContent=e.message;b.disabled=false;}
 };
}
function showInitiativePreview(preview,body,context,previous){
 const before=Object.keys(previous.initiatives||{}),after=Object.keys(preview.initiatives),removed=before.filter(c=>!after.includes(c));
 const unresolved=new Map(preview.lines.filter(r=>r.scope==='unresolved').map(r=>[r.object_code,r]));
 stateModal('Проверка инициатив',`<p>Будет заменён отчёт версии ${previous.revision}. Было инициатив: ${before.length}; станет: ${after.length}; исчезнет из отчёта: ${removed.length}.</p>${removed.length?`<details><summary>Инициативы, отсутствующие в новом отчёте</summary><p>${removed.map(esc).join(', ')}</p></details>`:''}${initiativeSummaryHtml(preview.lines)}<p>ПШЕ на квартальные даты не суммируются между кварталами и не добавляются к расчётной потребности «Итог 2045». Даты инициатив не заменяют планы развёртывания.</p>${preview.errors.length?'<p class="error">Сохранение заблокировано. Исправьте ошибки:</p>'+table(['Строка','Ошибка'],preview.errors.map(e=>`<tr><td>${e.line}</td><td>${esc(e.error)}</td></tr>`).join('')):''}${unresolved.size?`<p class="quality-callout">Не сопоставлено кодов: ${unresolved.size}. Эти строки и суммы сохранятся в инициативе, но не будут приписаны АС/ФП. Скачайте сопоставление, заполните собственные КЭ и повторите загрузку с обоими файлами.</p>`:''}<button id="initiativeMappingTemplate">Скачать сопоставление Excel</button><button id="initiativeCheckExport">Скачать результаты проверки</button><button id="initiativeChooseAgain">Выбрать другой файл</button>${preview.errors.length?'':'<button id="initiativeSave" class="primary">Сохранить отчёт целиком</button>'}<p id="initiativeSaveMessage" role="status"></p>${initiativeLinesHtml(preview.lines)}`);
 $('initiativeMappingTemplate').onclick=()=>saveBlob(makeXlsx(initiativeMappingSheets(preview)),'Сопоставление_инициатив.xlsx');
 $('initiativeCheckExport').onclick=()=>saveBlob(makeXlsx(initiativeExportSheets(preview)),'Проверка_инициатив.xlsx');
 $('initiativeChooseAgain').onclick=()=>openInitiativeImport().catch(stateError);
 if(!preview.errors.length)$('initiativeSave').onclick=async()=>{
  const b=$('initiativeSave');b.disabled=true;try{initiativeWriteGuard();if(context.generation!==initiativeImportGeneration||context.repo!==stateRepo||context.user!==currentUser||context.base!==liveVersion)throw new Error('Повторите проверку');
   const saved=await context.repo.saveInitiatives(body);initiativeReport=saved;initiativeContext={repo:stateRepo,base:viewVersion,user:currentUser};workspace=await stateRepo.settings();$('stateDialog').close();page='initiatives';render();message('Инициативы сохранены. Версия '+saved.revision+'. Повторные строки не добавлены.');
  }catch(e){$('initiativeSaveMessage').textContent=e.message;b.disabled=false;}
 };
 document.querySelectorAll('[data-initiative]').forEach(b=>b.onclick=()=>openInitiativeCard(b.dataset.initiative,preview));
}
function initiativeVisibleLines(report){
 const ids=new Set(filtered().map(e=>e.id_ke));return (report.lines||[]).filter(r=>(initiativeScope==='all'||initiativeScope==='selected'&&ids.has(r.ci)||initiativeScope===r.scope)&&(!initiativeSearch||(r.initiative+' '+report.initiatives[r.initiative].name+' '+r.object_code+' '+r.ci+' '+r.object_name).toLowerCase().includes(initiativeSearch.toLowerCase())));
}
function initiativesPage(){
 const r=currentInitiativeReport();
 return `<section class="panel"><div class="section-title"><h2>Инициативы АС и ФП</h2><button id="refreshInitiatives">Обновить инициативы</button><button id="importInitiativesPage" class="primary" ${canLoad&&!isHistorical()?'':'disabled'}>Загрузить отчёт инициатив</button></div>${!r?'<p>Загружаем отчёт…</p>':r.error?`<p class="error">${esc(r.error)}</p><button id="retryInitiatives">Повторить загрузку</button>`:!r.revision?'<p>Для этого среза отчёт инициатив ещё не загружен. Загрузите исходный Excel через кнопку выше.</p>':`<p>${esc(r.source)} · версия ${r.revision} · ${esc(new Date(r.at).toLocaleString('ru-RU'))}</p><div class="operation-controls"><label>Периметр<select id="initiativeScope">${Object.entries({all:'Отчёт целиком',selected:'Текущий RUNUP с фильтрами',outside:'Вне RUNUP',unresolved:'Не сопоставлены'}).map(([k,v])=>`<option value="${k}" ${initiativeScope===k?'selected':''}>${v}</option>`).join('')}</select></label><label>Поиск инициативы или объекта<input id="initiativeSearch" value="${esc(initiativeSearch)}" placeholder="Код инициативы, КЭ или название"></label></div><p class="note">${initiativeScope==='selected'?'Применены общие фильтры объектов.':'Показан периметр отчёта; общие фильтры объектов не применяются.'} Срок инициативы не подтверждает дату развёртывания. Все статусы сохранены из источника.</p>${initiativeSummaryHtml(initiativeVisibleLines(r))}<button id="exportInitiatives">Скачать инициативы Excel</button><button id="exportInitiativeMapping">Скачать сопоставление</button>${initiativeLinesHtml(initiativeVisibleLines(r))}`}</section>`;
}
function openInitiativeCard(code,report=currentInitiativeReport()){
 const meta=report?.initiatives?.[code];if(!meta)return;const lines=report.lines.filter(r=>r.initiative===code);
 const score=(report.sheets.Оценка||[]).find(([line,r])=>line>2&&String(r.B)===code)?.[1];
 stateModal('Инициатива '+code,`<h3>${esc(meta.name)}</h3><p>Статус: <strong>${esc(meta.status)}</strong> · ${esc(meta.start)} — ${esc(meta.end)} · ${esc(meta.kind)} · ${esc(meta.year)}</p><p>${esc(meta.tribe)} · ${esc(meta.product)}</p><p>Ключевой результат: ${esc(meta.result||'Не указан')}</p>${score?`<p>Оценка: ${esc(score.N||'Нет данных')} из 10</p>`:''}<h3>Инициатива целиком</h3>${initiativeSummaryHtml(lines)}<h3>Часть в текущем RUNUP</h3>${initiativeSummaryHtml(lines.filter(r=>r.scope==='RUNUP'))}${initiativeLinesHtml(lines)}`);
}
function initiativeExportSheets(report=currentInitiativeReport(),selected=false){
 if(!report?.lines)return [{name:'Инициативы',rows:[['Отчёт не загружен']]}];
 const lines=selected?initiativeVisibleLines(report):report.lines,codes=new Set(lines.map(r=>r.initiative)),t=initiativeTotals(lines);
 const sheets=[{name:'Итоги инициатив',rows:[['Показатель','Значение'],['Инициатив',t.initiatives],['АС и ФП / кодов',t.objects],...['BM','BN','BO','BP','BZ','CX'].map((k,i)=>[['ПШЕ Q1 2027','ПШЕ Q2 2027','ПШЕ Q3 2027','ПШЕ Q4 2027','РОТ 2027, ₽','Вендоры 2027, ₽'][i],t[k]]),['Периметр',selected?initiativeScope:'Отчёт целиком'],['Версия',report.revision||'Предпросмотр'],['Источник',report.source]]},
 {name:'Инициативы',rows:[['Код','Название','Статус','Год','Тип','Трайб','Продукт','Начало','Окончание','Ключевой результат'],...Object.values(report.initiatives).filter(r=>codes.has(r.code)).map(r=>[r.code,r.name,r.status,r.year,r.kind,r.tribe,r.product,r.start,r.end,r.result])]},
 {name:'Затраты и связи',rows:[['Строка','Код инициативы','Код АС/ФП','КЭ','Тип','Название','ДИТ','Периметр','Способ связи','Тип расходов',...initiativeNumeric],...lines.map(r=>[r.line,r.initiative,r.object_code,r.ci,r.category,r.object_name,r.dit,initiativeScopeNames[r.scope],r.match,r.expense,...initiativeNumeric.map(k=>r.numbers[k])])]},...initiativeMappingSheets(report),
 {name:'Ошибки проверки',rows:[['Строка','Ошибка'],...(report.errors||[]).map(e=>[e.line,e.error])]}];
 return sheets;
}
Object.assign(sectionTitles,{initiatives:'Инициативы'});
const initiativeRender=render;
render=function(){
 initiativeRender();
 const ready=currentInitiativeReport();if(stateReady&&viewVersion&&!ready&&(!initiativeContext||initiativeContext.repo!==stateRepo||initiativeContext.base!==viewVersion||initiativeContext.user!==currentUser))ensureInitiativeReport().then(()=>{if(['initiatives','operations','fincontrol','overview'].includes(page))render();});
 if(['fincontrol','overview'].includes(page)&&$('muiPeriod'))$('muiPeriod').onchange=()=>{muiPeriodKey=$('muiPeriod').value;render();};
 const header=$('loadInitiativesHeader');if(header){header.hidden=!canLoad;header.disabled=isHistorical();header.onclick=()=>openInitiativeImport().catch(stateError);}
 if(page==='update'&&!document.getElementById('importInitiativesUpdate')){$('content').insertAdjacentHTML('afterbegin','<section class="panel"><h2>Отчёт инициатив</h2><p>Загрузка инициатив с сопоставлением собственных КЭ АС и ФП, проверкой строк затрат и предпросмотром.</p><button id="importInitiativesUpdate">Загрузить отчёт инициатив</button></section>');const b=$('importInitiativesUpdate');if(b){b.disabled=!canLoad||isHistorical();b.onclick=()=>openInitiativeImport().catch(stateError);}}
 if(page==='initiatives'){
  if($('refreshInitiatives'))$('refreshInitiatives').onclick=()=>{initiativeContext=null;render();};
  $('importInitiativesPage').onclick=()=>openInitiativeImport().catch(stateError);
  if($('initiativeScope'))$('initiativeScope').onchange=()=>{initiativeScope=$('initiativeScope').value;render();};
  if($('initiativeSearch'))$('initiativeSearch').onchange=()=>{initiativeSearch=$('initiativeSearch').value;render();};
  if($('exportInitiatives'))$('exportInitiatives').onclick=()=>saveBlob(makeXlsx(initiativeExportSheets(currentInitiativeReport(),true)),'Инициативы.xlsx');
  if($('exportInitiativeMapping'))$('exportInitiativeMapping').onclick=()=>saveBlob(makeXlsx(initiativeMappingSheets(currentInitiativeReport())),'Сопоставление_инициатив.xlsx');
  if($('retryInitiatives'))$('retryInitiatives').onclick=()=>{initiativeContext=null;render();};
 }
 document.querySelectorAll('[data-initiative]').forEach(b=>b.onclick=()=>openInitiativeCard(b.dataset.initiative));
};
const initiativeOperations=operationsPage;
operationsPage=function(){const report=currentInitiativeReport(),ids=new Set(filtered().map(e=>e.id_ke)),linked=(report?.lines||[]).filter(r=>ids.has(r.ci)),objects=new Map(linked.map(r=>[r.ci,r]));return initiativeOperations()+(report?.revision?`<section class="panel"><h2>Связь с инициативами</h2><p>Инициатив: ${fmt(new Set(linked.map(r=>r.initiative)).size)} · АС: ${fmt([...objects.values()].filter(r=>r.category==='АС').length)} · ФП: ${fmt([...objects.values()].filter(r=>r.category==='ФП').length)}</p><p>Связь с инициативой не означает готовность плана или завершение развёртывания.</p><button data-section="initiatives">Открыть инициативы</button></section>`:'');};
const initiativeObjectCard=showObjectCard;
showObjectCard=async function(ci){await ensureInitiativeReport();await initiativeObjectCard(ci);const r=currentInitiativeReport(),codes=new Set((r?.lines||[]).filter(x=>x.ci===ci).map(x=>x.initiative));$('dialogBody').insertAdjacentHTML('beforeend',`<section class="panel"><h3>Инициативы АС / ФП</h3>${!r?.revision?'<p>Отчёт инициатив для этого среза не загружен.</p>':!codes.size?'<p>Связанных инициатив в загруженном отчёте нет.</p>':[...codes].map(code=>`<p><button class="table-link" data-initiative="${esc(code)}">${esc(code)} · ${esc(r.initiatives[code].name)}</button> · ${esc(r.initiatives[code].status)}</p>`).join('')}</section>`);document.querySelectorAll('[data-initiative]').forEach(b=>b.onclick=()=>openInitiativeCard(b.dataset.initiative));};
const initiativeExport=exportWorkbook;
exportWorkbook=function(detail=false){return page==='initiatives'?initiativeExportSheets(currentInitiativeReport(),true):initiativeExport(detail);};

const initiativeCsvDownload=$('download').onclick;
$('download').onclick=()=>{if(page!=='initiatives')return initiativeCsvDownload();const sheet=initiativeExportSheets(currentInitiativeReport(),true).find(s=>s.name==='Затраты и связи');if(!sheet)return message('Отчёт инициатив ещё не загружен',true);const quote=v=>'"'+String(v??'').replace(/"/g,'""')+'"';saveBlob(new Blob(['\uFEFF'+sheet.rows.map(r=>r.map(quote).join(';')).join('\r\n')],{type:'text/csv;charset=utf-8'}),'Инициативы.csv');};

// Staffing from MUI is a dated stock, separate from the resource model's FTE.
let muiPeriodKey='BP';
const muiPeriods=[{key:'BH',year:2025,label:'На 01.01.2026'},...Array.from({length:16},(_,i)=>({key:String.fromCharCode(66)+String.fromCharCode(73+i),year:2026+Math.floor(i/4),label:`${i%4+1} квартал ${2026+Math.floor(i/4)} · на 01.${String((i%4+1)%4*3+1).padStart(2,'0')}.${2026+Math.floor(i/4)+(i%4===3?1:0)}`}))];
function muiLineValue(line,key){
 if(!['IT','BS','DZ'].includes(line.expense))return null;
 if(Object.hasOwn(line.numbers||{},key))return line.numbers[key];
 const raw=String(line.raw?.[key]??'').trim();if(!raw)return null;const n=Number(raw.replace(',','.'));return Number.isFinite(n)&&n>=0?n:null;
}
function financeMui(records){
 const report=currentInitiativeReport(),loaded=Boolean(report?.revision),source=loaded?report.lines:[];
 const available=muiPeriods.filter(p=>source.some(r=>muiLineValue(r,p.key)!==null));
 const years=loaded?Object.values(report.initiatives).map(r=>Number(r.year)).filter(Number.isFinite):[];
 if(available.length&&!available.some(p=>p.key===muiPeriodKey))muiPeriodKey=(available.filter(p=>p.year===Math.max(...years)).at(-1)||available.at(-1)).key;
 const period=muiPeriods.find(p=>p.key===muiPeriodKey)||muiPeriods.find(p=>p.key==='BP'),byCi=new Map(),ids=new Set(records.map(r=>r.entity.id_ke));
 const totalOf=values=>values.length?values.reduce((a,b)=>a+b,0):null,all=[],outside=[],unresolved=[];let missing=0;
 for(const line of source){const value=muiLineValue(line,period.key);if(value===null){if(ids.has(line.ci)&&['IT','BS','DZ'].includes(line.expense))missing++;continue;}all.push(value);
  if(!line.ci){unresolved.push(value);continue;}if(!ids.has(line.ci)){outside.push(value);continue;}byCi.set(line.ci,(byCi.get(line.ci)||0)+value);
 }
 return {report,loaded,period,available:available.length?available:[period],byCi,total:totalOf([...byCi.values()]),full:totalOf(all),outside:totalOf(outside),unresolved:totalOf(unresolved),missing};
}
function financeMuiMetric(f){
 const m=f.mui,caption=m.report?.error?'Не удалось загрузить отчёт инициатив':!m.report?'Загружаем отчёт инициатив…':!m.loaded?'Загрузите отчёт через «Действия → Загрузить инициативы»':`По сопоставленным АС и ФП в выборке · ${esc(m.period.label)}`;
 const selector=m.loaded?`<label>Период МУИ <select id="muiPeriod">${m.available.map(p=>`<option value="${p.key}" ${p.key===m.period.key?'selected':''}>${esc(p.label)}</option>`).join('')}</select></label>`:'';
 return metric('ПШЕ в МУИ',m.total===null?'Нет данных':fmt(m.total,2),caption+selector);
}
function financeMuiCaption(f){
 const m=f.mui;if(!m.loaded)return '<p class="note">ПШЕ в МУИ — численность из загруженного отчёта инициатив. Пока данных для этого среза нет.</p>';
 const show=v=>v===null?'нет данных':fmt(v,2);
 return `<p class="note">ПШЕ в МУИ: ${esc(m.period.label)} · отчёт ${esc(m.report.source)}. В отчёте целиком: ${show(m.full)}; вне выбранных АС и ФП: ${show(m.outside)}; без сопоставления: ${show(m.unresolved)}. Кварталы не складываются.${m.missing?' В выборке есть строки без численности за этот период; показана сумма заполненных значений.':''}</p>`;
}
