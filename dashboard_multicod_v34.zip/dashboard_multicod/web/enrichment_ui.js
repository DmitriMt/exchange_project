'use strict';
Object.assign(sectionTitles,{enrichment:'Дополнение текущего среза'});
function attachOptionalInitiatives(settings,base,report,expected){
 const previous=settings.initiativeReports?.[base]||{revision:0};if(expected!==undefined&&previous.revision!==expected)throw new Error('Инициативы изменились. Повторите подготовку.');
 if(stableInitiative([previous.sheets,previous.mappings])===stableInitiative([report.sheets,report.mappings]))return;
 const value={...report,base,revision:previous.revision+1,user:currentUser,at:new Date().toISOString()};settings.initiativeReports=settings.initiativeReports||{};settings.initiativeReports[base]=value;settings.initiativeEvents=settings.initiativeEvents||[];settings.initiativeEvents.push({base,at:value.at,user:currentUser,before:previous,after:value});
}
function guardOptionalRows(before,after){
 const allowed=new Set([...volumeOwnershipFieldsSafe(),...['business_block','catalog_presence','fp_registry_total','fp_registry_children_json','pshe_model_inputs','pshe_source_change','pshe_source_run','pshe_status','pshe_prom_status'],...LOCAL_FIELDS_SAFE().filter(k=>/^pshe_(change|run|vendor)_/.test(k))]);
 const index=rs=>new Map(rs.filter(r=>r.record_type==='entity').map(r=>[r.id_ke,r])),a=index(before),b=index(after);
 if(a.size!==b.size||[...a.keys()].some(ci=>!b.has(ci)||LOCAL_FIELDS_SAFE().some(k=>!allowed.has(k)&&(a.get(ci)[k]||'')!==(b.get(ci)[k]||''))))throw new Error('Дополнение не может менять состав RUNUP, дату или данные РСМ');
}
function volumeOwnershipFieldsSafe(){return ['owner_department','owner_department_code','owner_tribe','owner_tribe_code','parent_name','parent_business_block','parent_owner_department','parent_owner_tribe','parent_owner_tribe_code','parent_criticality','parent_lifecycle','parent_in_scope','fp_prom_total','fp_scope_total','parent_fp_prom_total','parent_fp_scope_total','fp_children_json'];}
BrowserRepo.prototype.updateOptional=async function(result){
 if(!canLoad||isHistorical())throw new Error('Нужен актуальный срез и право загрузки');const base=result.baseSnapshot?.id,raw=csvEncode(result.rows);guardOptionalRows(result.baseSnapshot.rows,result.rows);
 const apply=(snap,meta,settings)=>{
  if(!snap||snap.csv!==result.baseSnapshot.csv)throw new Error('Данные среза изменились. Повторите подготовку.');
  if(result.initiatives)attachOptionalInitiatives(settings,base,result.initiatives,result.initiativeRevision);
  settings.enrichmentEvents=settings.enrichmentEvents||[];if(snap.csv!==raw)settings.enrichmentEvents.push({base,at:new Date().toISOString(),user:currentUser,before:snap.csv,after:raw,sources:result.manifest});
  snap.csv=raw;snap.stats=datasetStats(result.rows);meta.stats=snap.stats;return [snap,meta,settings];
 };
 if(!this.db){if((await this.list())[0]?.id!==base)throw new Error('Срез изменился');const values=apply(await this.get('snapshots',base),await this.get('meta',base),await this.settings());await this.batch([['snapshots',base,values[0]],['meta',base,values[1]],['settings','workspace',values[2]]]);return base;}
 return new Promise((resolve,reject)=>{const tx=this.db.transaction(['snapshots','meta','settings'],'readwrite'),meta=tx.objectStore('meta'),snaps=tx.objectStore('snapshots'),settings=tx.objectStore('settings');let snapshot,stored;const fail=e=>{tx.abort();reject(e);};const list=meta.getAll();list.onsuccess=()=>{try{const latest=list.result.sort((a,b)=>b.date.localeCompare(a.date)||b.at.localeCompare(a.at))[0];if(latest?.id!==base)throw new Error('Срез изменился');const get=snaps.get(base);get.onsuccess=()=>{snapshot=get.result;const req=settings.get('workspace');req.onsuccess=()=>{try{stored=req.result||{plans:{},events:[],views:[]};const values=apply(snapshot,latest,stored);snaps.put(values[0],base);meta.put(values[1],base);settings.put(values[2],'workspace');}catch(e){fail(e);}};};}catch(e){fail(e);}};tx.oncomplete=()=>resolve(base);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||new Error('Запись отменена'));});
};
const enrichmentRender=render;render=function(){
 enrichmentRender();bindSharedImportFields();cleanDataSettingsPanels();document.querySelectorAll('nav [data-page="enrichment"]').forEach(b=>b.hidden=!canLoad);if(page!=='enrichment')return;
 if(!canLoad||isHistorical()){$('content').innerHTML=`<section class="panel"><h2>Дополнение текущего среза</h2><p>Нужен актуальный срез и роль оператора или администратора.</p>${canLoad&&isHistorical()?'<button id="enrichmentBackToLive">Открыть актуальный срез</button>':''}</section>`;if(canLoad&&isHistorical())$('enrichmentBackToLive').onclick=()=>selectVersion(liveVersion).catch(stateError);return;}
 if($('excelImportForm'))$('excelImportForm').onsubmit=e=>submitImport(e).catch(stateError);
 document.querySelectorAll('[data-import-review]').forEach(b=>b.onclick=()=>reviewImport(b.dataset.importReview).catch(stateError));
 if($('refreshImports'))$('refreshImports').onclick=()=>refreshImports().then(render).catch(stateError);
};

const dataSettingsPages=['update','enrichment','history','quality'];
const settingsFiltered=filtered;
filtered=function(){return dataSettingsPages.includes(page)?entities:settingsFiltered();};
function cleanDataSettingsPanels(){
 const management=dataSettingsPages.includes(page);
 const active=$('activeFilters');if(active)active.hidden=management;
 const drawer=document.querySelector('.filter-drawer');if(drawer)drawer.hidden=management;
 if($('baseRegistryBanner'))$('baseRegistryBanner').hidden=management;
 if(management&&$('savedBar'))$('savedBar').hidden=true;
 if(['update','enrichment'].includes(page)&&$('versionBar'))$('versionBar').hidden=true;
}
function bindSharedImportFields(){
 if(!['update','enrichment'].includes(page))return;
 const draft=importDraft();
 if(page==='update'&&$('excelDate'))$('excelDate').onchange=()=>{importDraftDate=$('excelDate').value;};
 for(const [role]of currentSourceRoles()){
  const input=$('source_'+role);if(!input)continue;
  const update=()=>{const name=$('selected_source_'+role);if(name)name.textContent=draft[role]?.name||'';document.querySelectorAll('[data-clear-source="'+role+'"]').forEach(b=>b.hidden=!draft[role]);};
  input.onchange=()=>{draft[role]=input.files?.[0]||null;update();};
  document.querySelectorAll('[data-clear-source="'+role+'"]').forEach(b=>b.onclick=e=>{e.preventDefault();draft[role]=null;input.value='';input.required=page==='update'&&requiredSourceRoles.includes(role);update();});
 }
}
