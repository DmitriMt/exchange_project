'use strict';
const planImportHeaders=['КЭ','Тип','Наименование','Год','Квартал','Целевая дата','Площадка','Ответственный','Статус','Комментарий','Версия плана','Действие'];
let bulkPlanPreview=null,bulkPlanGeneration=0;
function planWriteGuard(){if(!stateReady||!canEdit||isHistorical())throw new Error('Изменять планы можно на актуальном срезе с правами администратора.');}
async function refreshPlanState(){const repo=stateRepo,user=currentUser;const fresh=await repo.settings();if(repo!==stateRepo||user!==currentUser)throw new Error('Пользователь изменился. Повторите действие.');workspace=fresh;render();}
async function savePlanAndRefresh(ci,value){
 planWriteGuard();const repo=stateRepo,user=currentUser,base=liveVersion,revision=workspace.plans[ci]?.revision||0;
 const saved=await repo.savePlan(ci,value,revision);
 if(repo!==stateRepo||user!==currentUser||base!==liveVersion)throw new Error('Состояние изменилось после сохранения. Откройте актуальный срез.');
 await refreshPlanState();return saved;
}
function planSaveMessage(ci){const p=activePlans()[ci]||{},period=planPeriod(p);return `План сохранён${period.year?': '+period.year+(period.quarter?' · '+period.quarter+' кв.':''):''}. Обзор, оперативные показатели и итоги по ДИТ обновлены.`;}
function stagePlanBatch(items,s,user,allowed){
 if(!Array.isArray(items)||!items.length||items.length>5000)throw new Error('Нужно от 1 до 5000 планов');
 const seen=new Set(),staged=[];
 for(const item of items){
  if(!allowed.has(item.ci)||seen.has(item.ci))throw new Error('Неизвестный или повторный КЭ: '+item.ci);seen.add(item.ci);
  if(!Number.isSafeInteger(item.revision)||item.revision<0)throw new Error('Неверная версия плана: '+item.ci);
  const before=s.plans[item.ci]||{},value=cleanPlan(item.value);
  if((before.revision||0)!==item.revision)throw new Error('План изменён: '+item.ci+'. Повторите проверку.');
  if(JSON.stringify(value)===JSON.stringify(cleanPlan(before)))continue;
  staged.push({ci:item.ci,before,after:{...value,revision:item.revision+1,at:new Date().toISOString(),user}});
 }
 for(const change of staged){s.plans[change.ci]=change.after;s.events.unshift({id:stateId(),...change,at:change.after.at,user});}
 return {updated:staged.length,plans:Object.fromEntries(staged.map(r=>[r.ci,r.after]))};
}
BrowserRepo.prototype.savePlansBatch=async function(items,base){
 const allowed=new Set(entities.map(e=>e.id_ke)),user=this.profile;
 if(!this.db){const list=await this.list();if(list[0]?.id!==base)throw new Error('Срез изменился. Повторите проверку.');return this.mutateSettings(s=>stagePlanBatch(items,s,user,allowed));}
 return new Promise((resolve,reject)=>{
  let result;const tx=this.db.transaction(['settings','meta'],'readwrite'),settings=tx.objectStore('settings'),meta=tx.objectStore('meta');
  const request=meta.getAll();request.onsuccess=()=>{
   try{const latest=request.result.sort((a,b)=>b.date.localeCompare(a.date)||b.at.localeCompare(a.at))[0];if(latest?.id!==base)throw new Error('Срез изменился. Повторите проверку.');
    const get=settings.get('workspace');get.onsuccess=()=>{try{const s=get.result||{plans:{},events:[],views:[]};result=stagePlanBatch(items,s,user,allowed);settings.put(s,'workspace');}catch(e){tx.abort();reject(e);}};
   }catch(e){tx.abort();reject(e);}
  };tx.oncomplete=()=>resolve(result);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||new Error('Загрузка отменена'));
 });
};
ServerRepo.prototype.savePlansBatch=async function(items,base){return api('/api/planning/batch',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({items,base})});};
function planTemplateSheets(es=filtered()){
 const plans=activePlans();return [{name:'Планы',widths:[18,10,55,12,12,18,25,30,25,45,16,18],rows:[planImportHeaders,...programmeObjects(es).map(e=>{const p=plans[e.id_ke]||{};return [e.id_ke,e.category,e.name,...planKeys.map(k=>p[k]||''),p.revision||0,'Обновить'];})]},
 {name:'Инструкция',widths:[28,105],rows:[['Поле / правило','Как заполнить'],['Порядок','Заполните лист Планы и загрузите его через Массовую загрузку планов. Перед сохранением проверьте предпросмотр.'],['КЭ','Уникальный собственный КЭ АС или ФП. Тип и наименование — справочные поля.'],['Даты','ГГГГ-ММ-ДД, ДД.ММ.ГГГГ или дата Excel. Год и квартал должны совпадать с датой.'],['Действие','Обновить — записать заполненную строку целиком; пустые поля очистятся. Пропустить — не менять. Очистить — удалить значения плана с записью в журнал.'],['Пустая строка','Строки без полей плана автоматически пропускаются, если действие не Очистить.'],['Версия плана','Не изменяйте: предотвращает перезапись плана другого пользователя. Для нового плана — 0.'],['Статусы',planStatuses.join(' / ')],['Готовность','План внесён — заполнено любое поле. Полностью подготовлен — есть срок, площадка, ответственный и статус.'],['Стратегия перехода к 3 зонам доступности','Обновляется отдельно из опросника. Файл планов её не меняет.']]},
 {name:'Параметры',rows:[['Параметр','Значение'],['Срез',viewVersion],['Дата экспорта',moscowToday()],['Объектов',es.length]]}];
}
function downloadPlanTemplate(){saveBlob(makeXlsx(planTemplateSheets()),'Шаблон_массовой_загрузки_планов.xlsx');}
function parsePlansCsv(text){
 const rows=[];let row=[],cell='',quoted=false;
 for(let i=0;i<text.length;i++){const c=text[i];if(c==='"'){if(quoted&&text[i+1]==='"'){cell+='"';i++;}else quoted=!quoted;}else if(!quoted&&(c===';'||c==='\n'||c==='\r')){row.push(cell);cell='';if(c!==';'){rows.push(row);row=[];if(c==='\r'&&text[i+1]==='\n')i++;}}else cell+=c;}
 if(quoted)throw new Error('Незакрытая кавычка CSV');if(cell||row.length){row.push(cell);rows.push(row);}return rows.map((r,i)=>[i+1,r]);
}
function planImportDate(value,date1904=false){
 const text=String(value??'').trim();if(!text)return '';
 if(/^\d{4}-\d{2}-\d{2}$/.test(text))return text;
 const ru=text.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);if(ru)return `${ru[3]}-${ru[2]}-${ru[1]}`;
 if(/^\d+(\.0+)?$/.test(text)){const serial=Number(text);if(serial<0||serial>80000)throw new Error('Неверная дата Excel');return new Date(Date.UTC(date1904?1904:1899,date1904?0:11,date1904?1:30)+serial*86400000).toISOString().slice(0,10);}
 throw new Error('Дата: используйте ГГГГ-ММ-ДД или дату Excel');
}
function validatePlanImport(fileRows,registry,plans,date1904=false){
 const rows=fileRows.filter(([,r])=>r.some(v=>String(v??'').trim()));if(!rows.length)throw new Error('Файл пуст');
 const header=rows.shift()[1].map(v=>String(v??'').replace(/^\uFEFF/,'').trim());
 if(header.length!==planImportHeaders.length||header.some((v,i)=>v!==planImportHeaders[i]))throw new Error('Колонки не совпадают с шаблоном. Скачайте актуальный шаблон планов.');
 if(rows.length>5000)throw new Error('Не более 5000 строк за одну загрузку');
 const index=new Map(registry.map(e=>[e.id_ke,e])),seen=new Set(),items=[],errors=[],skipped=[];
 for(const [line,cells]of rows){
  try{
   if(cells.length>planImportHeaders.length)throw new Error('Лишние колонки');
   const values=Array.from({length:planImportHeaders.length},(_,i)=>String(cells[i]??'').trim()),ci=values[0],action=values[11]||'Обновить';
   if(!['Обновить','Пропустить','Очистить'].includes(action))throw new Error('Действие: Обновить / Пропустить / Очистить');
   if(!/^CI\d+$/.test(ci)||!index.has(ci))throw new Error('КЭ отсутствует в актуальном реестре');
   if(seen.has(ci))throw new Error('КЭ повторяется в файле');seen.add(ci);
   const entity=index.get(ci);if(values[1]&&entity.category!==values[1])throw new Error('Тип не совпадает с реестром');
   if(action==='Пропустить'||action==='Обновить'&&values.slice(3,10).every(v=>!v)){skipped.push({line,ci});continue;}
   if(!/^\d+$/.test(values[10])||!Number.isSafeInteger(Number(values[10])))throw new Error('Неверная версия плана');
   const before=plans[ci]||{},revision=Number(values[10]);if(revision!==(before.revision||0))throw new Error('Версия плана устарела: скачайте новый шаблон');
   const raw=Object.fromEntries(planKeys.map((k,i)=>[k,action==='Очистить'?'':values[i+3]]));raw.target_date=planImportDate(raw.target_date,date1904);
   const value=cleanPlan(raw);if(JSON.stringify(value)===JSON.stringify(cleanPlan(before))){skipped.push({line,ci});continue;}
   items.push({ci,value,revision,line,name:entity.name,category:entity.category,before:cleanPlan(before)});
  }catch(error){errors.push({line,ci:String(cells[0]??''),error:error.message});}
 }
 return {items,errors,skipped,total:rows.length};
}
async function readPlanFile(file){
 if(!file||file.size>10*1024*1024)throw new Error('Выберите XLSX или CSV до 10 МБ');
 const data=await snapshotLocalFile(file);
 if(/\.csv$/i.test(file.name))return {rows:parsePlansCsv(new TextDecoder('utf-8',{fatal:true}).decode(data.bytes)),date1904:false};
 if(!/\.xlsx$/i.test(file.name))throw new Error('Нужен XLSX или CSV');
 const local=typeof PLAN_IMPORT_WORKER!=='undefined',url=local?URL.createObjectURL(new Blob([PLAN_IMPORT_WORKER],{type:'application/javascript'})):'/plan_import_worker.js';
 let worker;
 try{return await new Promise((resolve,reject)=>{worker=new Worker(url);worker.onmessage=({data})=>data.error?reject(new Error(data.error)):resolve(data);worker.onerror=e=>reject(new Error(e.message||'Не удалось прочитать планы'));worker.postMessage(data,[data.bytes]);});}
 finally{worker?.terminate();if(local)URL.revokeObjectURL(url);}
}
function openBulkPlanImport(){
 planWriteGuard();const generation=++bulkPlanGeneration;bulkPlanPreview=null;
 stateModal('Массовая загрузка планов',`<p>Скачайте шаблон для выбранных АС и ФП, заполните планы и выберите файл. Изменения сохранятся после проверки всей партии.</p><button id="downloadBulkPlanTemplate">Скачать шаблон Excel</button><label>Файл планов<input id="bulkPlanFile" type="file" accept=".xlsx,.csv"></label><button id="checkBulkPlans" class="primary">Проверить файл</button><p id="bulkPlanMessage" role="status"></p>`);
 $('downloadBulkPlanTemplate').onclick=downloadPlanTemplate;
 $('checkBulkPlans').onclick=async()=>{
  const button=$('checkBulkPlans');button.disabled=true;
  const context={repo:stateRepo,user:currentUser,base:liveVersion};
  try{
   await refreshPlanState();const source=await readPlanFile($('bulkPlanFile').files[0]);
   if(generation!==bulkPlanGeneration||context.repo!==stateRepo||context.user!==currentUser||context.base!==liveVersion||!document.getElementById('bulkPlanFile'))throw new Error('Состояние изменилось. Повторите проверку.');
   if(source.base&&source.base!==viewVersion)throw new Error('Шаблон относится к другому срезу. Скачайте новый шаблон.');
   const preview=validatePlanImport(source.rows,entities,workspace.plans,source.date1904);bulkPlanPreview={...context,...preview};
   const changes=preview.items.map(r=>`<tr><td>${esc(r.ci)}</td><td>${esc(r.category)}</td><td>${esc(r.name)}</td><td>${esc(planKeys.map(k=>r.before[k]).filter(Boolean).join(' · ')||'Пустой план')}</td><td>${esc(planKeys.map(k=>r.value[k]).filter(Boolean).join(' · ')||'Очистить план')}</td></tr>`).join('');
   stateModal('Проверка массовой загрузки',`<p>Строк: ${fmt(preview.total)} · изменений: ${fmt(preview.items.length)} · пропущено: ${fmt(preview.skipped.length)} · ошибок: ${fmt(preview.errors.length)}</p>${preview.errors.length?'<p class="error">Ошибки нужно исправить. До этого ничего не сохраняется.</p>'+table(['Строка','КЭ','Ошибка'],preview.errors.map(e=>`<tr><td>${e.line}</td><td>${esc(e.ci)}</td><td>${esc(e.error)}</td></tr>`).join('')):''}${preview.items.length?table(['КЭ','Тип','Наименование','Было','Станет'],changes):'<p>Изменений нет.</p>'}<button id="chooseBulkPlanFile">Выбрать другой файл</button>${!preview.errors.length&&preview.items.length?'<button id="commitBulkPlans" class="primary">Сохранить все планы</button>':''}<p id="bulkCommitMessage" role="status"></p>`);
   $('chooseBulkPlanFile').onclick=openBulkPlanImport;
   if($('commitBulkPlans')&&!preview.errors.length&&preview.items.length)$('commitBulkPlans').onclick=async()=>{
    const b=$('commitBulkPlans');b.disabled=true;
    try{planWriteGuard();const p=bulkPlanPreview;if(!p||p.repo!==stateRepo||p.user!==currentUser||p.base!==liveVersion)throw new Error('Повторите проверку файла.');
     const result=await p.repo.savePlansBatch(p.items.map(({ci,value,revision})=>({ci,value,revision})),p.base);await refreshPlanState();bulkPlanPreview=null;$('stateDialog').close();message(`Сохранено планов: ${fmt(result.updated)}. Обзор, оперативные показатели и итоги ДИТ обновлены.`);
    }catch(e){$('bulkCommitMessage').textContent=e.message;b.disabled=false;}
   };
  }catch(e){if($('bulkPlanMessage'))$('bulkPlanMessage').textContent=e.message;button.disabled=false;}
 };
}
const planBulkOperations=operationsPage;
operationsPage=function(){return `<div class="plan-import-tools"><button id="refreshPlans">Обновить планы</button><button id="downloadPlansTemplate">Шаблон планов Excel</button><button id="bulkPlansImport" class="primary" ${canEdit&&!isHistorical()?'':'disabled'}>Массовая загрузка планов</button></div>`+planBulkOperations();};
const planBulkRender=render;
render=function(){planBulkRender();if(page==='operations'){
 if($('refreshPlans'))$('refreshPlans').onclick=()=>refreshPlanState().then(()=>message('Планы и показатели обновлены.')).catch(stateError);
 if($('downloadPlansTemplate'))$('downloadPlansTemplate').onclick=downloadPlanTemplate;
 if($('bulkPlansImport'))$('bulkPlansImport').onclick=()=>{try{openBulkPlanImport();}catch(e){stateError(e);}};
}};
