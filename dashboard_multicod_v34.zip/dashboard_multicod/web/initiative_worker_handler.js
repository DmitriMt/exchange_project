self.onmessage=async({data})=>{try{
 const book=await new BrowserXlsx(new File([data.bytes],data.name)).open(),sheets={};
 const xml=await book.xml('xl/workbook.xml');
 const names=[...xml.matchAll(/<(?:\w+:)?sheet\b([^>]*?)\/?\s*>/g)].map(m=>bxAttrs(m[1]).name);
 for(const name of (data.mapping?['Сопоставление']:['Общая информация и затраты','Оценка','Эффекты'])){
  if(!names.includes(name)){if(name==='Общая информация и затраты'||data.mapping)throw new Error('Нет листа '+name);continue;}
  sheets[name]=[];for await(const row of book.rows(name)){
   if(sheets[name].length>=5002||row[0]>5002)throw new Error('Не более 5000 строк данных на листе');
   sheets[name].push(row);
  }
 }
 self.postMessage({sheets});
}catch(e){self.postMessage({error:e.message||String(e)});}};
