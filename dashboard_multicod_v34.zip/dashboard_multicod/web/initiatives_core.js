'use strict';
const initiativeNumeric=['BL','BM','BN','BO','BP','BQ','BR','BS','BT','BY','BZ','CA','CB','CK','CL','CM','CN','CW','CX','CY','CZ'];
function prepareInitiatives(body,registry,cfg){
 const norm=v=>String(v??'').trim().replace(/\s+/g,' '),source=body.sheets?.['Общая информация и затраты'];
 if(!Array.isArray(source)||source.length<3||source.length>5002)throw new Error('Ожидается лист Общая информация и затраты, до 5000 строк данных');
 for(const [name,rows]of Object.entries(body.sheets)){
  if(!['Общая информация и затраты','Оценка','Эффекты'].includes(name)||!Array.isArray(rows)||rows.length>5002)throw new Error('Неверные листы отчёта');
  let previousLine=0;for(const row of rows){if(!Array.isArray(row)||row.length!==2||!Number.isInteger(row[0])||!row[1]||Array.isArray(row[1])||Object.entries(row[1]).some(([k,v])=>! /^[A-Z]{1,2}$/.test(k)||!['string','number'].includes(typeof v)||String(v).length>20000))throw new Error('Неверная строка отчёта');if(row[0]<=previousLine)throw new Error('Повторный или нарушенный номер строки');previousLine=row[0];}
 }
 if(source[0][0]!==1||source[1][0]!==2||Object.entries(cfg.headers).some(([k,v])=>norm(source[0][1][k])!==norm(v))||source.some(([,r])=>Object.entries(r).some(([k,v])=>norm(v)&&!Object.hasOwn(cfg.headers,k))))throw new Error('Структура отчёта изменилась: заголовки не совпадают. Ничего не сохранено.');
 const catalog={...cfg.catalog,...Object.fromEntries(registry.map(e=>[e.id_ke,e]))},scope=new Set(registry.map(e=>e.id_ke)),mappings=body.mappings||{},codes=new Set(source.slice(2).map(([,r])=>String(r.BB??'').trim()).filter(Boolean));
 if(!mappings||Array.isArray(mappings)||Object.keys(mappings).length>5000)throw new Error('Неверное сопоставление');
 for(const [code,ci]of Object.entries(mappings))if(!codes.has(code)||!Object.hasOwn(catalog,ci))throw new Error('Сопоставление содержит неизвестный код или КЭ: '+code);
 const initiatives={},lines=[],errors=[],seen=new Set();
 for(const [line,raw]of source.slice(2)){
  if(!Object.values(raw).some(v=>String(v??'').trim()))continue;
  try{
   const r=Object.fromEntries(Object.entries(raw).map(([k,v])=>[k,String(v??'').trim()])),code=r.C;
   if(!/^[0-9]{1,30}$/.test(code||'')||!r.D)throw new Error('Нужны текстовый код и название инициативы; научная запись кода не допускается');
   if(r.A!=='0')throw new Error('Поддерживается версия БП (0); другие версии нельзя смешивать');
   if(!/^20[0-9]{2}$/.test(r.B||'')||!['','1','2'].includes(r.E||''))throw new Error('Неверный год или тип инициативы');
   for(const k of ['AG','AH'])if(!/^[1-4]\.20[0-9]{2}$/.test(r[k]||''))throw new Error('Срок инициативы должен иметь формат квартал.год');
   const period=v=>Number(v.split('.')[1])*4+Number(v.split('.')[0]);if(period(r.AG)>period(r.AH))throw new Error('Начало позже окончания инициативы');
   if(r.BA)throw new Error('Строки с признаком удаления затрат не принимаются; загрузите полный актуальный отчёт');
   const signature=JSON.stringify(Object.entries(r).filter(([,v])=>v).sort(([a],[b])=>a.localeCompare(b)));
   if(seen.has(signature))throw new Error('Повторная строка затрат: возможное удвоение сумм');seen.add(signature);
   const meta={code,name:r.D,year:r.B,version:r.A,status:r.L||'',kind:({'':'Change','1':'RUN','2':'ДЗО'})[r.E||''],block:r.P||'',tribe:r.R||'',product:r.V||'',start:r.AG,end:r.AH,inactive:r.AU||'',result:r.AM||''};
   if(Object.hasOwn(initiatives,code)&&JSON.stringify(initiatives[code])!==JSON.stringify(meta))throw new Error('Противоречивые реквизиты одной инициативы');initiatives[code]=meta;
   const expense=r.AY||'',obj=r.BB||'';if(!['','IT','BS','DZ','OC'].includes(expense))throw new Error('Неизвестный тип расходов');
   if(expense&&!obj)throw new Error('В строке затрат отсутствует собственный код АС/ФП');
   const number=k=>{const v=r[k];if(!v)return null;const n=Number(v.replace(',','.'));if(!Number.isFinite(n)||n<0)throw new Error('Неверное число в '+k);return n;};
   const numbers=Object.fromEntries(initiativeNumeric.map(k=>[k,number(k)]));
   if(!expense&&(obj||Object.values(numbers).some(v=>v!==null)))throw new Error('Не указан тип расходов для строки затрат');
   for(const k of ['BH','BI','BJ','BK','BU','BV','BW','BX','CG','CH','CI','CJ','CS','CT','CU','CV'])number(k);
   for(const [total,parts]of [['BY',['BZ','CA','CB']],['CW',['CX','CY','CZ']],['CX',['CK','CL','CM','CN']]])if(numbers[total]!==null&&parts.some(k=>numbers[k]!==null)&&Math.abs(numbers[total]-parts.reduce((s,k)=>s+(numbers[k]||0),0))>.05)throw new Error('Итог '+total+' не сходится с детализацией');
   if(expense==='OC'&&['BL','BM','BN','BO','BP','BZ'].some(k=>numbers[k]!==null&&numbers[k]!==0))throw new Error('Вендорская строка содержит численность/РОТ');
   if(['IT','BS','DZ'].includes(expense)&&['CK','CL','CM','CN','CX'].some(k=>numbers[k]!==null&&numbers[k]!==0))throw new Error('Строка численности содержит вендорские расходы');
   let ci=/^[0-9]+$/.test(obj)?'CI'+obj.padStart(8,'0'):/^CI[0-9]{8,}$/.test(obj)?obj:'';const direct=Object.hasOwn(catalog,ci)?ci:'';
   if(Object.hasOwn(mappings,obj)&&direct&&mappings[obj]!==direct)throw new Error('Ручное сопоставление противоречит существующему коду');
   ci=direct||(Object.hasOwn(mappings,obj)?mappings[obj]:'');const e=catalog[ci]||{};
   lines.push({line,initiative:code,object_code:obj,object_name:r.BC||'',ci,category:e.category||'',dit:e.dit||'',expense,scope:obj?(scope.has(ci)?'RUNUP':ci?'outside':'unresolved'):'none',match:direct?'code':ci?'manual':'',numbers,raw:r});
  }catch(e){errors.push({line,error:e.message});}
 }
 for(const [name,col]of [['Оценка','B'],['Эффекты','C']])for(const [line,r]of body.sheets[name]||[])if(line>2&&!Object.hasOwn(initiatives,String(r[col]??'').trim()))errors.push({line,error:name+': неизвестный код инициативы'});
 return {initiatives,lines,errors,source:String(body.source||'Отчёт инициатив').slice(0,250),mappings,sheets:body.sheets,catalog_source:cfg.catalog_source};
}
function initiativeTotals(lines){
 const result={initiatives:new Set(lines.map(r=>r.initiative)).size,objects:new Set(lines.filter(r=>r.object_code).map(r=>r.ci||'unresolved:'+r.object_code)).size};
 for(const k of initiativeNumeric){const values=lines.map(r=>r.numbers[k]).filter(v=>v!==null);result[k]=values.length?values.reduce((a,b)=>a+b,0):null;}
 return result;
}
