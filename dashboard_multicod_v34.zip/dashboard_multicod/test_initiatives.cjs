// Run after build_local_html.py. Tests application state without network or browser storage.
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'../../outputs/dashboard-v34/МультиЦОД.html'),'utf8');
const script=html.match(/<script>\n([\s\S]*?)<\/script>/)[1],elements=new Map();
const el=()=>({value:'',checked:false,hidden:false,innerHTML:'',textContent:'',files:[],open:false,dataset:{},classList:{toggle(){}},querySelectorAll(){return [];},querySelector(){return null;},closest(){return null;},insertAdjacentHTML(){},remove(){},before(){},addEventListener(){},removeEventListener(){},after(){},append(){},click(){},focus(){},scrollIntoView(){},showModal(){this.open=true;},close(){this.open=false;}});
const document={getElementById(id){if(!elements.has(id))elements.set(id,el());return elements.get(id);},createElement:el,querySelector:s=>s.startsWith('.drill-panel')?null:el(),querySelectorAll:()=>[],body:{append(){}}};
const c={document,Intl,Date,TextDecoder,TextEncoder,Blob,structuredClone,setTimeout,clearTimeout,console,URL};
vm.createContext(c);vm.runInContext(script,c);


(async()=>{
 const read=e=>vm.runInContext(e,c);
 for(let i=0;i<80;i++){await new Promise(r=>setImmediate(r));if(read('stateReady'))break;}
 await read('ensureInitiativeReport()');
 c.body=read(`({sheets:{'Общая информация и затраты':[[1,structuredClone(INITIATIVE_CONFIG.headers)],[2,{}],...['232517','3197613','3421627','3457040','4596809','5306897'].map((obj,i)=>[i+3,{A:'0',B:'2027',C:'2026081713121230',D:'МультиЦОД+ Домклик',L:'Приостановлена',AG:'1.2027',AH:'4.2027',AY:'IT',BB:obj,BC:'Объект',BL:obj==='3197613'?'0.5':'0.3',BM:obj==='3197613'?'0.5':'0.3',BN:obj==='3197613'?'0.5':'0.3',BO:obj==='3197613'?'0.5':'0.3',BP:obj==='3197613'?'0.5':'0.3',BY:'100',BZ:'100'}])]},source:'Test.xlsx',mappings:{},base:liveVersion,revision:0})`);
 const first=await read('stateRepo.saveInitiatives(body)');assert.equal(first.revision,1);assert.equal(first.errors.length,0);c.body.revision=1;
 assert.equal((await read('stateRepo.saveInitiatives(body)')).revision,1);
 read('initiativeContext=null');await read('ensureInitiativeReport()');read("page='initiatives';render()");
 assert(document.getElementById('content').innerHTML.includes('Инициативы АС и ФП'));
 read("openInitiativeCard('2026081713121230')");
 assert.equal(read('initiativeTotals(currentInitiativeReport().lines).BP'),2);
 assert.equal(read('initiativeTotals(currentInitiativeReport().lines.filter(r=>r.scope==="RUNUP")).BP'),.8);
 assert.equal(read('currentInitiativeReport().lines.filter(r=>r.scope==="outside").length'),4);
 c.invalid=structuredClone(c.body);c.invalid.sheets['Общая информация и затраты'][2][1].BP='NaN';
 await assert.rejects(read('stateRepo.saveInitiatives(invalid)'));assert.equal((await read('stateRepo.getInitiatives(liveVersion)')).revision,1);
 const blob=read('makeXlsx(initiativeMappingSheets(currentInitiativeReport()))'),bytes=await blob.arrayBuffer();let result;
 const wc={Blob,File,TextDecoder,TextEncoder,Uint8Array,Uint32Array,DataView,BigInt,DecompressionStream,console,self:{postMessage(value){result=value}}};
 vm.createContext(wc);vm.runInContext(read('INITIATIVE_IMPORT_WORKER'),wc);await wc.self.onmessage({data:{bytes,name:'Сопоставление.xlsx',mapping:true}});assert(!result.error,result.error);
 c.mappingSheets=result.sheets;assert.equal(Object.keys(read('parseInitiativeMappings(mappingSheets)')).length,6);
 c.backup=await read('stateRepo.backup()');read('otherRepo=new BrowserRepo(null)');await read('otherRepo.restore(backup)');assert.equal((await read('otherRepo.getInitiatives(liveVersion)')).lines.length,6);
 const files=read('initiativeExportSheets(currentInitiativeReport())');await read('makeXlsx(initiativeExportSheets(currentInitiativeReport()))').arrayBuffer();assert(files.every(s=>s.name.length<=31));
 read('viewVersion="missing"');assert.equal(read('currentInitiativeReport()'),null);
 console.log('PASS: own AS/FP mapping; full initiative and RUNUP subtotals; idempotence; failed batch atomicity; snapshot isolation; real XLSX mapping template and exports; backup restore.');
})().catch(e=>{console.error(e);process.exitCode=1;});
