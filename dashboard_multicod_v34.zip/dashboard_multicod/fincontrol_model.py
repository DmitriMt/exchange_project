"""Snapshot-bound completion of the Итог 2045 CPU model, strictly RUNUP ∩ RSM."""
import copy
from decimal import Decimal, InvalidOperation
import hashlib
import json
import math
from pathlib import Path
import posixpath
import re
import zipfile
import xml.etree.ElementTree as ET
from rsm_presence import nodes, NS, FILES, SINGLE, rsm_files


def saved_rows(path, sheet=1, columns=None):
    """Stream selected saved cells; do not calculate or change a workbook."""
    with zipfile.ZipFile(path) as book:
        target = f'xl/worksheets/sheet{sheet}.xml'
        if isinstance(sheet, str):
            wb = ET.fromstring(book.read('xl/workbook.xml'))
            selected = next(s for s in wb.find(NS+'sheets') if s.get('name').strip() == sheet.strip())
            rid = selected.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
            rel = ET.fromstring(book.read('xl/_rels/workbook.xml.rels'))
            target = next(r.get('Target') for r in rel if r.get('Id') == rid)
            target = target.lstrip('/') if target.startswith('/') else posixpath.normpath('xl/'+target)
        strings = []
        if 'xl/sharedStrings.xml' in book.namelist():
            for el in nodes(book.open('xl/sharedStrings.xml'), NS+'si'):
                strings.append(''.join(t.text or '' for t in el.iter(NS+'t')))
        for el in nodes(book.open(target), NS+'row'):
            row = {}
            for cell in el:
                col = re.sub(r'\d', '', cell.get('r', ''))
                if columns and col not in columns:
                    continue
                v = cell.find(NS+'v')
                value = strings[int(v.text)] if v is not None and cell.get('t') == 's' else v.text if v is not None else ''.join(t.text or '' for t in cell.iter(NS+'t'))
                row[col] = value or ''
            yield int(el.get('r')), row


def decimal(value):
    result = Decimal(str(value))
    if not result.is_finite() or result < 0:
        raise ValueError('Недопустимое значение CPU/коэффициента')
    return result


def production(env):
    return str(env).strip().lower() == 'пром (промышленная среда)'


def model_reference(source):
    coef = None
    for i, row in saved_rows(source, 'Нормализация B2C', {'A'}):
        if i == 6:
            coef = str(decimal(row['A']))
            break
    if not coef or decimal(coef) == 0:
        raise ValueError('Не найден положительный коэффициент Итог 2045')
    openshift = {}
    for i, row in saved_rows(source, 'ОШ', {'B','J','V'}):
        if i == 1:
            if row.get('J') != 'КЭ АС' or row.get('V') != 'Количество ядер':
                raise ValueError('Не распознаны поля OpenShift')
            continue
        if production(row.get('B')) and re.fullmatch(r'CI\d+', row.get('J','')):
            key = row['J']
            openshift[key] = openshift.get(key, Decimal(0)) + decimal(row.get('V') or 0)
    digest = hashlib.sha256(Path(source).read_bytes()).hexdigest()
    return dict(name='Итог 2045 · CPU', coefficient=coef, intercept='0',
                formula='ПШЕ = (CPU РСМ ПРОМ + CPU OpenShift ПРОМ) × coefficient',
                coefficient_source='Нормализация B2C!A6', formula_source='Весь банк на коэф-ах B2C!I3',
                source_sha256=digest, source_file=Path(source).name,
                openshift={k:str(v) for k,v in openshift.items()})


def signature_key(signature):
    return hashlib.sha256(json.dumps(signature, sort_keys=True).encode()).hexdigest()


def resource_evidence(folder, destination, progress=print):
    """Complete scan: own AS keys in D, own FP keys in L; production CPU in AK."""
    signature, resources = [], {'АС':{}, 'ФП':{}}
    for path in rsm_files(folder):
        name = path.name
        digest = hashlib.sha256()
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(1024*1024), b''):
                digest.update(block)
        signature.append([name,digest.hexdigest()])
        progress('CPU модели Итог 2045: '+name)
        for i,row in saved_rows(path,1,{'D','L','N','AK'}):
            if i == 1:
                if row.get('D')!='АС КЭ' or row.get('L')!='ФП КЭ' or row.get('AK')!='кол-во Ядер':
                    raise ValueError('Не распознана структура CPU РСМ')
                continue
            for category,col in [('АС','D'),('ФП','L')]:
                ci=row.get(col,'').strip()
                if not re.fullmatch(r'CI\d+',ci):
                    continue
                item=resources[category].setdefault(ci,dict(rows=0,prom_rows=0,cpu='0',invalid_cpu=False))
                item['rows']+=1
                if production(row.get('N')):
                    item['prom_rows']+=1
                    try:
                        item['cpu']=str(decimal(item['cpu'])+decimal(row.get('AK') or 0))
                    except (ValueError,InvalidOperation):
                        item['invalid_cpu']=True
    result=dict(schema_version=1,signature=signature,resources=resources,
                rule='АС D; ФП L; N=ПРОМ (промышленная среда); CPU=SUM(AK)')
    target=Path(destination)/ (signature_key(signature)+'.json')
    target.parent.mkdir(parents=True,exist_ok=True)
    tmp=target.with_suffix('.tmp');tmp.write_text(json.dumps(result,ensure_ascii=False));tmp.replace(target)
    return result


def evidence_for(rows, directory):
    entities=[r for r in rows if r.get('record_type')=='entity' and r.get('base_source')=='RUNUP_QUESTIONNAIRE']
    if not entities:
        return None
    # The evidence must belong to both RSM files recorded in this particular snapshot.
    wanted={}
    names=[SINGLE] if any(SINGLE+'=' in e.get('rsm_source','') for e in entities) else FILES
    for name in names:
        matches={m for e in entities for m in re.findall(re.escape(name)+r'=([0-9a-f]{64})', e.get('rsm_source',''))}
        if len(matches)!=1:
            return None
        wanted[name]=matches.pop()
    signature=[[name,wanted[name]] for name in names]
    path=Path(directory)/(signature_key(signature)+'.json')
    if not path.exists():
        return None
    value=json.loads(path.read_text())
    return value if value.get('signature')==signature else None


def complete_fincontrol(baseline, rows, evidence):
    """Preserve all original estimates. Never extrapolate outside proven RUNUP ∩ RSM."""
    result=copy.deepcopy(baseline)
    original=result['records'];ids={r['id_ke'] for r in original}
    if len(ids)!=len(original):
        raise ValueError('Дубли КЭ в исходном расчёте')
    model=baseline.get('model');added=[];skipped=[];seen=set()
    for e in rows:
        if e.get('record_type')!='entity':
            continue
        ci=e['id_ke']
        if ci in seen:
            raise ValueError('Дубли КЭ в RUNUP')
        seen.add(ci)
        if ci in ids:
            continue
        reason=None
        resource=(evidence or {}).get('resources',{}).get(e.get('category'),{}).get(ci)
        signature=(evidence or {}).get('signature',[])
        proof=bool((len(signature)==2 and {pair[0] for pair in signature}==set(FILES) or len(signature)==1 and signature[0][0]==SINGLE) and all(re.fullmatch(r'[0-9a-f]{64}',sha) and name+'='+sha in e.get('rsm_source','') for name,sha in signature))
        if e.get('base_source')!='RUNUP_QUESTIONNAIRE' or e.get('category')not in ['АС','ФП']:
            reason='not_runup'
        elif e.get('rsm_presence')!='1':
            reason='not_in_rsm'
        elif evidence is None:
            reason='rsm_evidence_unavailable'
        elif not resource or resource['rows']<=0:
            reason='not_in_rsm'
        elif not proof:
            reason='rsm_evidence_mismatch'
        elif not model:
            reason='no_model'
        elif resource.get('invalid_cpu'):
            reason='invalid_cpu'
        if reason:
            skipped.append(dict(id_ke=ci,category=e.get('category'),reason=reason));continue
        cpu_rsm=decimal(resource['cpu']);cpu_osh=decimal(model.get('openshift',{}).get(ci,'0'))
        cpu=cpu_rsm+cpu_osh
        fte=decimal(model['coefficient'])*cpu
        record=dict(id_ke=ci,name=e['name'],category=e['category'],criticality=e['criticality'],
                    business_block=e['business_block'],dit=e['dit'],cpu_rsm=float(cpu_rsm),
                    cpu_openshift=float(cpu_osh),cpu_total=float(cpu),fte=float(fte),
                    estimate_origin='calculated_runup_rsm',method=model['formula'],
                    coefficient=model['coefficient'],rsm_signature=signature,
                    rsm_rows=resource['rows'],prom_rows=resource['prom_rows'],
                    zero_reason='Нет CPU ПРОМ в проверенных источниках' if cpu==0 else '')
        added.append(record)
    result['baseline_total']=copy.deepcopy(baseline['total'])
    result['records']=original+added
    result['total']=dict(systems=len(result['records']),share=1,
        **{key:math.fsum(r[key] for r in result['records'])for key in ['fte','cpu_rsm','cpu_openshift','cpu_total']})
    result['classes']=[]
    for c in sorted({r['criticality']for r in result['records']}):
        records=[r for r in result['records']if r['criticality']==c]
        result['classes'].append(dict(criticality=c,systems=len(records),
            **{key:math.fsum(r[key]for r in records)for key in ['fte','cpu_rsm','cpu_openshift','cpu_total']},
            share=math.fsum(r['fte']for r in records)/result['total']['fte']if result['total']['fte']else 0))
    result['completion']=dict(added_count=len(added),added_fte=math.fsum(r['fte']for r in added),
                              added=added,skipped=skipped,rule='Новая оценка только по собственному КЭ в RUNUP и подтверждённой РСМ')
    # The full imported model remains the baseline, including objects outside RUNUP.
    return result


def payload(baseline, rows, directory):
    return complete_fincontrol(baseline,rows,evidence_for(rows,directory))
