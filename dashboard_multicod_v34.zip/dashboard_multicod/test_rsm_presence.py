import csv
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile
from xml.sax.saxutils import escape
from rsm_presence import FILES, annotate_rsm, scan
from prepare_data import FIELDS, V13_FIELDS
from server import parse_data


def book(path, values, bad=False):
    rows=[{'D':'АС КЭ','L':'Неверно' if bad else 'ФП КЭ'}, *values]
    xml='<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'+''.join('<row r="'+str(i)+'">'+''.join('<c r="'+col+str(i)+'" t="inlineStr"><is><t>'+escape(text)+'</t></is></c>' for col,text in row.items())+'</row>' for i,row in enumerate(rows,1))+'</sheetData></worksheet>'
    with zipfile.ZipFile(path,'w') as z:z.writestr('xl/worksheets/sheet1.xml',xml)

class RsmTests(unittest.TestCase):
    def test_exact_fp_presence_both_files_no_parent_inheritance_and_all_stands(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            book(root/FILES[0],[{'D':'CI10','L':'CI11','N':'ТЕСТ','W':'выведен'},{'D':'CI10','L':'CI11'},{'D':'CI10','L':''},{'D':'CI12','L':' CI13 '}])
            book(root/FILES[1],[{'D':'CI10','L':'CI14'}])
            es={ci:dict(id_ke=ci,category=cat) for ci,cat in [('CI10','АС'),('CI11','ФП'),('CI12','ФП'),('CI13','ФП'),('CI14','ФП'),('CI15','ФП')]}
            cache=root/'presence.json'
            annotate_rsm(es,root,cache,lambda _:None)
            self.assertEqual(es['CI11']['rsm_rows'],'2')
            self.assertEqual(es['CI14']['rsm_presence'],'1')
            self.assertEqual(es['CI13']['rsm_presence'],'1')
            self.assertEqual(es['CI12']['rsm_presence'],'0') # present only as AS; not FP evidence
            self.assertEqual(es['CI15']['rsm_presence'],'0')
            self.assertIn('SHA-256',es['CI15']['rsm_source'])
            with patch('rsm_presence.scan',side_effect=AssertionError('cache was not used')):
                annotate_rsm(es,root,cache,lambda _:None)
            book(root/FILES[1],[{'D':'CI10','L':'CI15'}])
            annotate_rsm(es,root,cache,lambda _:None)
            self.assertEqual(es['CI15']['rsm_presence'],'1')
            self.assertEqual(es['CI14']['rsm_presence'],'0')
            with patch.dict('sys.modules',{'lxml':None}):
                self.assertEqual(scan(root/FILES[1])['ФП'],{'CI15':1})

    def test_missing_or_bad_rsm_does_not_produce_false_absence(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);es={'CI11':dict(id_ke='CI11',category='ФП')}
            book(root/FILES[0],[])
            with self.assertRaises(ValueError):annotate_rsm(es,root,root/'cache',lambda _:None)
            self.assertNotIn('rsm_presence',es['CI11'])
            book(root/FILES[1],[],bad=True)
            with self.assertRaises(ValueError):annotate_rsm(es,root,root/'cache',lambda _:None)
            self.assertNotIn('rsm_presence',es['CI11'])

    def test_v13_csv_remains_unknown_and_inconsistent_status_rejected(self):
        rows=parse_data((Path(__file__).parent/'data/dashboard.csv').read_bytes())
        def encode(fields):
            out=io.StringIO();w=csv.DictWriter(out,fields,delimiter=';',extrasaction='ignore');w.writeheader();w.writerows(rows);return out.getvalue().encode('utf-8-sig')
        older=parse_data(encode(V13_FIELDS))
        self.assertTrue(all(r['rsm_presence']=='' for r in older))
        self.assertTrue(any(r['owner_department'] for r in older))
        fp=next(r for r in rows if r['record_type']=='entity' and r['category']=='ФП')
        fp.update(rsm_presence='0',rsm_rows='2')
        with self.assertRaises(ValueError):parse_data(encode(FIELDS))

if __name__=='__main__':unittest.main()
