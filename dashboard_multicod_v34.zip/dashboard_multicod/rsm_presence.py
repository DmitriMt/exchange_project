"""Exact catalog CI presence in both RSM files, independent of wallet and PSHE."""
import collections
import hashlib
import json
from pathlib import Path
import re
import zipfile

RSM_FIELDS = ['rsm_presence', 'rsm_rows', 'rsm_source']
FILES = ['РСМ ДЭШ_1.xlsx', 'РСМ ДЭШ_2.xlsx']
SINGLE = 'РСМ ДЭШ.xlsx'
def rsm_files(folder):
    folder=Path(folder)
    if (folder/SINGLE).exists():
        if any((folder/n).exists() for n in FILES): raise ValueError('Нельзя смешивать единую и разделённые выгрузки РСМ')
        return [folder/SINGLE]
    paths=[folder/n for n in FILES]
    if not all(p.exists() for p in paths): raise ValueError('Нужна единая выгрузка РСМ')
    return paths
NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'


def nodes(stream, tag):
    try:
        from lxml import etree as ET
    except ImportError:
        from xml.etree import ElementTree as ET
        stack = []
        for event, el in ET.iterparse(stream, events=('start', 'end')):
            if event == 'start':
                stack.append(el)
            else:
                if el.tag == tag:
                    yield el
                    el.clear()
                    if len(stack) > 1:
                        stack[-2].remove(el)
                stack.pop()
    else:
        for _, el in ET.iterparse(stream, events=('end',), tag=tag, resolve_entities=False, no_network=True):
            yield el
            el.clear()
            while el.getprevious() is not None:
                del el.getparent()[0]


def scan(path):
    counts = {'АС': collections.Counter(), 'ФП': collections.Counter()}
    with zipfile.ZipFile(path) as book:
        strings = []
        if 'xl/sharedStrings.xml' in book.namelist():
            with book.open('xl/sharedStrings.xml') as stream:
                for el in nodes(stream, NS+'si'):
                    strings.append(''.join(t.text or '' for t in el.iter(NS+'t')))
        def value(cell):
            if cell.get('t') == 'inlineStr':
                return ''.join(t.text or '' for t in cell.iter(NS+'t'))
            v = cell.find(NS+'v')
            if v is None:
                return ''
            if cell.get('t') == 'e':
                raise ValueError(path.name+': ошибка Excel в КЭ')
            return strings[int(v.text)] if cell.get('t') == 's' else v.text or ''
        header = False
        with book.open('xl/worksheets/sheet1.xml') as stream:
            for el in nodes(stream, NS+'row'):
                row = {re.sub(r'\d', '', c.get('r', '')): value(c).strip() for c in el if re.sub(r'\d', '', c.get('r', '')) in ('D', 'L')}
                if el.get('r') == '1':
                    if row.get('D') != 'АС КЭ' or row.get('L') != 'ФП КЭ':
                        raise ValueError(path.name+': не распознаны поля D «АС КЭ» / L «ФП КЭ»')
                    header = True
                    continue
                if not header:
                    raise ValueError(path.name+': отсутствует заголовок РСМ')
                for category, col in [('АС', 'D'), ('ФП', 'L')]:
                    ci = row.get(col, '')
                    if re.fullmatch(r'CI\d+', ci):
                        counts[category][ci] += 1
        if not header:
            raise ValueError(path.name+': пустой РСМ')
    return {k: dict(v) for k,v in counts.items()}


def annotate_rsm(entities, folder, cache_path, progress=print):
    paths = rsm_files(folder)
    names = [p.name for p in paths]
    signature = []
    for path in paths:
        digest = hashlib.sha256()
        with path.open('rb') as stream:
            for chunk in iter(lambda: stream.read(1024*1024), b''):
                digest.update(chunk)
        signature.append([path.name, digest.hexdigest()])
    cache = Path(cache_path)
    stored = json.loads(cache.read_text()) if cache.exists() else None
    if stored and stored.get('version') == 1 and stored.get('signature') == signature:
        results = stored['results']
        progress('Наличие КТС: используем проверенные результаты обеих РСМ')
    else:
        results = {}
        for path in paths:
            progress('Проверяем наличие КЭ в РСМ: '+path.name)
            results[path.name] = scan(path)
        cache.parent.mkdir(parents=True, exist_ok=True)
        cache.write_text(json.dumps(dict(version=1, signature=signature, results=results), ensure_ascii=False))
    for e in entities.values():
        category, ci = e['category'], e['id_ke']
        count = sum(results[name][category].get(ci, 0) for name in names)
        column = 'L «ФП КЭ»' if category == 'ФП' else 'D «АС КЭ»'
        e.update(rsm_presence='1' if count else '0', rsm_rows=str(count),
                 rsm_source=' + '.join(names)+' · лист 1 · '+column+' · все строки и стенды · SHA-256: '+'; '.join(name+'='+sha for name,sha in signature))
