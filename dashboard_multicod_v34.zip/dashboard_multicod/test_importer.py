import csv
import io
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch
import zipfile

from importer import ImportJobs, ROLES, REQUIRED_ROLES
from prepare_data import FIELDS
from server import ROOT, parse_data
from state_store import StateStore


class ImportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = (ROOT / 'data/dashboard.csv').read_bytes()
        stream = io.BytesIO()
        with zipfile.ZipFile(stream, 'w') as book:
            book.writestr('xl/workbook.xml', '<workbook/>')
        cls.xlsx = stream.getvalue()

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = StateStore(Path(self.temp.name) / 'state.sqlite3')
        self.base = self.store.commit(self.raw, parse_data(self.raw), 'Initial', '2026-11-02', '')
        self.jobs = ImportJobs(Path(self.temp.name) / 'jobs', self.store, parse_data)
        self.job = self.jobs.create('operator', '2026-11-03', self.base)

    def tearDown(self):
        self.temp.cleanup()

    def upload_all(self):
        for role in REQUIRED_ROLES:
            self.jobs.upload(self.job['id'], 'operator', role, io.BytesIO(self.xlsx), len(self.xlsx), role + '.xlsx')

    def fake_prepare(self, folder, output, date, progress):
        self.assertEqual(date, '2026-11-03')
        self.assertEqual(len(list(folder.glob('*.xlsx'))), 2)
        rows = parse_data(self.raw)
        for row in rows:
            row['snapshot'] = date
        with output.open('w', encoding='utf-8-sig', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=FIELDS, delimiter=';')
            writer.writeheader()
            writer.writerows(rows)
        return {'entities': 1415}

    def wait_done(self):
        for _ in range(200):
            job = self.jobs.get(self.job['id'], 'operator')
            if job['status'] != 'running':
                return job
            time.sleep(.01)
        self.fail('Processing did not finish')

    def test_ownership_missing_sources_and_invalid_xlsx(self):
        with self.assertRaises(PermissionError):
            self.jobs.get(self.job['id'], 'another')
        with self.assertRaises(ValueError):
            self.jobs.run(self.job['id'], 'operator')
        with self.assertRaises(zipfile.BadZipFile):
            self.jobs.upload(self.job['id'], 'operator', 'catalog', io.BytesIO(b'bad'), 3, 'bad.xlsx')
        self.assertEqual(self.jobs.get(self.job['id'], 'operator')['files'], {})
        self.assertEqual(len(self.store.list()), 1)

    def test_prepare_then_commit_is_explicit_idempotent_and_keeps_history(self):
        self.upload_all()
        with patch('importer.prepare', side_effect=self.fake_prepare), patch('fincontrol_model.resource_evidence', return_value={'signature':[], 'resources':{}}):
            self.jobs.run(self.job['id'], 'operator')
            self.assertEqual(self.wait_done()['status'], 'ready')
        self.assertEqual(len(self.store.list()), 1)
        rows = self.jobs.result(self.job['id'], 'operator')['rows']
        self.assertTrue(all(r['snapshot'] == '2026-11-03' for r in rows))
        with self.assertRaises(RuntimeError):
            self.jobs.commit(self.job['id'], 'operator', 'stale')
        saved = self.jobs.commit(self.job['id'], 'operator', self.base)
        self.jobs.commit(self.job['id'], 'operator', self.base)
        self.assertEqual(len(self.store.list()), 2)
        self.assertEqual(self.store.list()[0]['id'], saved['snapshot_id'])
        self.assertEqual(self.store.snapshot(self.base)['csv'], self.raw)

    def test_bad_source_does_not_change_live_snapshot(self):
        self.upload_all()
        with patch('importer.prepare', side_effect=ValueError('Bad headers')):
            self.jobs.run(self.job['id'], 'operator')
            job = self.wait_done()
        self.assertEqual(job['status'], 'failed')
        self.assertIn('Bad headers', job['message'])
        self.assertEqual(self.store.list()[0]['id'], self.base)


if __name__ == '__main__':
    unittest.main()
