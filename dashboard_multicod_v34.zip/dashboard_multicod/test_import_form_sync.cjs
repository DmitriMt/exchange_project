// Run after build_local_html.py. Tests application state without network or browser storage.
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'../../outputs/dashboard-v34/МультиЦОД.html'),'utf8');
const script=html.match(/<script>\n([\s\S]*?)<\/script>/)[1],elements=new Map();
const el=()=>({value:'',checked:false,hidden:false,innerHTML:'',textContent:'',files:[],open:false,dataset:{},classList:{toggle(){}},querySelectorAll(){return [];},querySelector(){return null;},closest(){return null;},insertAdjacentHTML(){},remove(){},before(){},addEventListener(){},removeEventListener(){},after(){},append(){},click(){},focus(){},scrollIntoView(){},showModal(){this.open=true;},close(){this.open=false;}});
const document={getElementById(id){if(!elements.has(id))elements.set(id,el());return elements.get(id);},createElement:el,querySelector:s=>s.startsWith('.drill-panel')?null:el(),querySelectorAll:()=>[],body:{append(){}}};
const c={document,Intl,Date,TextDecoder,TextEncoder,Blob,structuredClone,setTimeout,clearTimeout,console,URL};
vm.createContext(c);vm.runInContext(script,c);


(async()=>{
 const read=e=>vm.runInContext(e,c),get=id=>document.getElementById(id);
 for(let i=0;i<80;i++){await new Promise(r=>setImmediate(r));if(read('stateReady'))break;}
 read("page='update';render()");
 const create=read('importPage()');assert(create.includes('localExcelImportForm'));assert.equal((create.match(/type="file"/g)||[]).length,6);
 c.chosen=new File(['data'],'catalog-selected.xlsx');get('source_catalog').files=[c.chosen];get('source_catalog').onchange();get('excelDate').value='2027-01-31';get('excelDate').onchange();
 get('source_catalog').files=[];
 read("page='enrichment';render()");const supplement=read('importPage()');assert.equal((supplement.match(/type="file"/g)||[]).length,4);assert(supplement.includes('catalog-selected.xlsx'));assert(!supplement.includes('source_rsm'));assert(!supplement.includes('source_questionnaire'));assert(!supplement.includes('id="excelDate"'));assert(supplement.includes('optional-sources" open'));assert.equal(read('collectImportFiles().catalog.name'),'catalog-selected.xlsx');
 read("page='update';render()");assert(read('importPage()').includes('2027-01-31'));assert.equal(read('collectImportFiles().catalog.name'),'catalog-selected.xlsx');
 get('category').value='АС';read("page='overview';render()");const count=read('filtered().length');assert.equal(count,422);
 for(const section of ['update','enrichment','history','quality']){read('page='+JSON.stringify(section)+';render()');assert.equal(get('activeFilters').hidden,true);assert.equal(get('savedBar').hidden,true);assert.equal(read('filtered().length'),1415);assert.equal(get('category').value,'АС');}
 read("page='overview';render()");assert.equal(get('activeFilters').hidden,false);assert.equal(read('filtered().length'),count);
 read("localExcelResult={profile:currentUser,mode:'create',date:'2031-01-01',report:{entities:1,as_count:1,fp_count:0,fp_without_rsm:0}};page='enrichment'");assert(!read('importPage()').includes('Срез подготовлен на'));read("page='update'");assert(read('importPage()').includes('Срез подготовлен на'));read("page='enrichment'");assert.throws(()=>read('localResult()'));
 read("stateRepo=new ServerRepo();importJobs=[{id:'create-job',mode:'create',date:'2026-11-06',created_at:'2026-11-06T00:00:00Z',status:'ready',message:'CREATE-MESSAGE'},{id:'supplement-job',mode:'supplement',date:'2026-11-06',created_at:'2026-11-06T00:00:00Z',status:'ready',message:'SUPPLEMENT-MESSAGE'}]");
 assert(read('importPage()').includes('SUPPLEMENT-MESSAGE'));assert(!read('importPage()').includes('CREATE-MESSAGE'));read("page='update'");assert(read('importPage()').includes('CREATE-MESSAGE'));assert(!read('importPage()').includes('SUPPLEMENT-MESSAGE'));
 console.log('PASS: same optional file fields in both modes; retained selections/date; mode-specific prepared results and server jobs; data-settings panels hidden; analytical filters preserved.');
})().catch(e=>{console.error(e);process.exitCode=1;});
