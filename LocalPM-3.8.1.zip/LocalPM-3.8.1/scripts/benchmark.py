#!/usr/bin/env python3
"""Isolated LAN API smoke/load profile; never connects to an existing database."""
import argparse
import concurrent.futures
import hashlib
import json
import secrets
import sys
import tempfile
import threading
import time
import urllib.request
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from localpm import core
from localpm.application import Application,password_hash
from localpm.http_server import Server

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--users',type=int,default=200);parser.add_argument('--tasks',type=int,default=5000);parser.add_argument('--parallel',type=int,default=16);parser.add_argument('--output');args=parser.parse_args()
    if not 1<=args.users<=500 or not 1<=args.tasks<=5000 or not 1<=args.parallel<=32:parser.error('users 1–500, tasks 1–5000, parallel 1–32')
    with tempfile.TemporaryDirectory(prefix='localpm-benchmark-') as tmp:
        app=Application(tmp,dev=True,client_origins=['http://127.0.0.1:9099']);server=None;thread=None
        try:
            shared_hash=password_hash(secrets.token_urlsafe(24));users=[];tokens=[]
            for i in range(args.users):
                user={'id':'bench-user-'+str(i),'username':'bench'+str(i),'name':'Employee '+str(i),'hash':shared_hash,'admin':i==0,'active':1,'capacity':8};app.repo.create_user(user);users.append(user);token=secrets.token_hex(32);tokens.append(token);app.sessions[token]={'userId':user['id'],'csrf':secrets.token_hex(24),'expires':time.time()+3600,'kind':'desktop','origin':'http://127.0.0.1:9099'}
            start=time.perf_counter();p=core.calculate({'id':'benchmark-project','name':'Isolated load profile','calendar_id':'5day','start_date':core.today(),'tasks':[{'id':'bench-task-'+str(i),'name':'Task '+str(i),'duration_days':1,'assignee_id':users[i%len(users)]['id'],'owner':users[i%len(users)]['name']} for i in range(args.tasks)],'dependencies':[{'id':'bench-link-'+str(i),'pred_id':'bench-task-'+str(i),'succ_id':'bench-task-'+str(i+1),'type':'FS'} for i in range(args.tasks-1)]},strict=True);planning_ms=(time.perf_counter()-start)*1000
            app.repo.save({'project':p,'version':1,'acl':{u['id']:'manager' if i==0 else 'viewer' for i,u in enumerate(users)},'comments':[],'updates':[],'attachments':[],'notifications':[],'audit':[],'operations':[]},0)
            server=Server(('127.0.0.1',0),app,Path(__file__).resolve().parent.parent/'web');thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();base='http://127.0.0.1:'+str(server.server_port)
            def request(i):
                start=time.perf_counter();request=urllib.request.Request(base+'/api/projects/benchmark-project',headers={'Authorization':'Bearer '+tokens[i],'Origin':'http://127.0.0.1:9099','X-LocalPM-Client':'desktop-v1'})
                with urllib.request.urlopen(request,timeout=45) as response:data=json.loads(response.read())
                if len(data['project']['tasks'])!=args.tasks or len(data['project']['dependencies'])!=args.tasks-1:raise ValueError('Incomplete response')
                return (time.perf_counter()-start)*1000
            started=time.perf_counter()
            with concurrent.futures.ThreadPoolExecutor(max_workers=args.parallel) as executor:latencies=list(executor.map(request,range(args.users)))
            latencies.sort();report={'users':args.users,'tasksPerProject':args.tasks,'dependencies':args.tasks-1,'parallelRequests':args.parallel,'successfulRequests':len(latencies),'planningMs':round(planning_ms,1),'totalSeconds':round(time.perf_counter()-started,2),'medianMs':round(latencies[len(latencies)//2],1),'p95Ms':round(latencies[min(len(latencies)-1,int(len(latencies)*.95))],1),'maxMs':round(latencies[-1],1),'scope':'one synthetic project, loopback HTTP, isolated temporary database; not a production capacity guarantee'}
            if args.output:Path(args.output).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
            print(json.dumps(report,ensure_ascii=False,indent=2))
        finally:
            if server:server.shutdown();server.server_close()
            if thread:thread.join(timeout=5)
            app.close()

if __name__=='__main__':main()
