/* One bounded board surface owns both axes; the document and column headers stay put. */
var boardViewport3=null;
function boardViewportKey3(){return JSON.stringify([connectionMode,signedInUser?.id||'',boardState3.project,boardState3.assignee,boardState3.search,productPrefs4.boardLanes||''])}
function captureBoardView3(){if(!boardViewport3||!document.contains(boardViewport3.grid))return null;return {key:boardViewport3.key,top:boardViewport3.grid.scrollTop,left:boardViewport3.grid.scrollLeft}}
function disposeBoardViewport3(){if(boardViewport3){boardViewport3.dispose();boardViewport3=null}}
function boardEdgeScroll3(position,start,end){var edge=Math.min(40,(end-start)/4);if(position<start||position>end||edge<=0)return 0;if(position<start+edge)return -Math.ceil(18*(start+edge-position)/edge);if(position>end-edge)return Math.ceil(18*(position-end+edge)/edge);return 0}
function installBoardViewport3(view){
 var root=el('app'),active=state.screen==='kanban';
 root?.classList.toggle('kanban-viewport',active);document.documentElement.classList.toggle('kanban-viewport',active);
 if(!active){disposeBoardViewport3();if(root)root.style.removeProperty('--board-viewport-height');return}
 var board=root.querySelector('.kanban-screen'),grid=board?.querySelector('.kanban-columns');if(!board||!grid)return;
 disposeBoardViewport3();if(window.scrollX||window.scrollY)window.scrollTo(0,0);
 grid.tabIndex=0;grid.setAttribute('role','region');grid.setAttribute('aria-label','Рабочая область канбана');
 var disposed=false,resizeFrame=0,dragFrame=0,pointer=null,observer=null,visual=window.visualViewport;
 function refresh(){if(disposed||!document.contains(board))return;var height=Math.max(1,Math.floor(visual?.height||window.innerHeight));if(root.style.getPropertyValue('--board-viewport-height')!==height+'px')root.style.setProperty('--board-viewport-height',height+'px');board.style.removeProperty('height')}
 function resized(){if(disposed||resizeFrame)return;resizeFrame=requestAnimationFrame(function(){resizeFrame=0;refresh()})}
 function stopDrag(){pointer=null;if(dragFrame){cancelAnimationFrame(dragFrame);dragFrame=0}}
 function dragTick(){dragFrame=0;if(disposed||!pointer||!boardDrag3||!document.contains(grid))return;var r=grid.getBoundingClientRect(),dx=boardEdgeScroll3(pointer.x,r.left,r.left+grid.clientWidth),dy=boardEdgeScroll3(pointer.y,r.top,r.top+grid.clientHeight),left=grid.scrollLeft,top=grid.scrollTop;grid.scrollLeft+=dx;grid.scrollTop+=dy;if((grid.scrollLeft!==left||grid.scrollTop!==top)&&pointer)dragFrame=requestAnimationFrame(dragTick)}
 function dragOver(e){if(!boardDrag3)return;pointer={x:e.clientX,y:e.clientY};if(!dragFrame)dragFrame=requestAnimationFrame(dragTick)}
 function dragLeave(e){if(!grid.contains(e.relatedTarget))stopDrag()}
 window.addEventListener('resize',resized);visual?.addEventListener('resize',resized);
 grid.addEventListener('dragover',dragOver);grid.addEventListener('dragleave',dragLeave);grid.addEventListener('drop',stopDrag);document.addEventListener('dragend',stopDrag);window.addEventListener('blur',stopDrag);
 if(typeof ResizeObserver==='function'){observer=new ResizeObserver(resized);Array.from(root.children).filter(function(e){return e!==board}).concat(Array.from(board.children).filter(function(e){return e!==grid})).forEach(function(e){observer.observe(e)})}
 boardViewport3={grid:grid,key:boardViewportKey3(),refresh:refresh,dispose:function(){disposed=true;stopDrag();if(resizeFrame)cancelAnimationFrame(resizeFrame);observer?.disconnect();window.removeEventListener('resize',resized);visual?.removeEventListener('resize',resized);grid.removeEventListener('dragover',dragOver);grid.removeEventListener('dragleave',dragLeave);grid.removeEventListener('drop',stopDrag);document.removeEventListener('dragend',stopDrag);window.removeEventListener('blur',stopDrag)}};
 refresh();if(view&&view.key===boardViewport3.key){grid.scrollTop=Math.max(0,Math.min(view.top,grid.scrollHeight-grid.clientHeight));grid.scrollLeft=Math.max(0,Math.min(view.left,grid.scrollWidth-grid.clientWidth))}
}
