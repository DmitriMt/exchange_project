/* Disk is authoritative. This queue never persists workspace contents in browser storage. */
(function(root,factory){var api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.LocalPMFileBooks=api})(typeof globalThis!=='undefined'?globalThis:this,function(){
 'use strict';
 function copy(x){return JSON.parse(JSON.stringify(x))}
 function Book(adapter,workspace,client,fingerprint,onChange){this.adapter=adapter;this.workspace=copy(workspace);this.client=copy(client||{values:{},kv:{}});this.fingerprint=fingerprint;this.generation=0;this.saved=0;this.running=null;this.error=null;this.onChange=onChange||function(){}}
 Book.prototype.touch=function(){this.generation++;this.error=null;this.onChange(this);return this.generation};
 Book.prototype.dirty=function(){return this.saved<this.generation};
 Book.prototype.flush=function(){var self=this;if(self.running)return self.running.then(function(){return self.dirty()?self.flush():true});self.running=(async function(){while(self.dirty()){var generation=self.generation,body=Object.assign({},self.workspace);body.localpm_device_state=self.client;var text=JSON.stringify(body,null,2);var result=await self.adapter.write(text,self.fingerprint);self.fingerprint=result;self.saved=generation;self.error=null;self.onChange(self)}return true})().catch(function(e){self.error=e;self.onChange(self);throw e}).finally(function(){self.running=null});return self.running};
 return {Book:Book};
});
