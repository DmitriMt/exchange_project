/* Restore a personal FSAA link without overwriting a newer browser draft or external file. */
async function fileStateHash3(data){var d=Core.workspace(data);return sha256(JSON.stringify({projects:d.projects,settings:d.settings||{}}))}
async function rememberFileLink3(handle,data,fingerprint){try{var link={};link.fingerprint=fingerprint;link.snapshotHash=await fileStateHash3(data);link.name=handle.name||DB_FILE_NAME;return await putLocal('file-link-v3',link)}catch(e){return false}}
async function idbPutHandle(handle){if(!idbDB)return false;try{var tx=idbDB.transaction('kv','readwrite');tx.objectStore('kv').put(handle,'fileHandle');await idbTxDone(tx);await rememberFileLink3(handle,serializeWorkspace(),fileFingerprint);return true}catch(e){return false}}
async function idbClearHandle(){if(!idbDB)return false;try{var tx=idbDB.transaction('kv','readwrite');tx.objectStore('kv').delete('fileHandle');tx.objectStore('kv').delete('file-link-v3');await idbTxDone(tx);return true}catch(e){return false}}
async function restorePersonalFile3(handle,request){
 if(connectionMode!=='local'||state.localTabReadOnly)return false;
 state.pendingHandle=handle;state.pendingName=handle.name||DB_FILE_NAME;
 var permission=await handle.queryPermission({mode:'readwrite'});
 if(permission!=='granted'&&request)permission=await handle.requestPermission({mode:'readwrite'});
 if(permission!=='granted'){state.notice='Для восстановления файла «'+state.pendingName+'» разрешите доступ в разделе «Файлы и копии».';return false}
 var raw=await(await handle.getFile()).text(),report=LocalPMLegacy.migrate(importedJson3(raw)),data=report.workspace;
 data.projects=data.projects.map(function(p){return LocalPMProduct.validate(p)});
 var fingerprint=await sha256(raw),link=await getLocal('file-link-v3'),localHash=await fileStateHash3(serializeWorkspace()),pending=!!link&&localHash!==link.snapshotHash,external=!!link&&fingerprint!==link.fingerprint;
 if(pending&&external||!link&&state.projects.length&&localHash!==await fileStateHash3(data)){
  state.notice='Файл и локальная копия требуют сравнения. Автоматическая запись остановлена; выберите версию в разделе «Файлы и копии».';
  if(request)showWorkspaceImport3(data);
  return false;
 }
 if(!pending){applyWorkspace(data,'replace',false);await persistLocal()}
 fileHandle=handle;fileFingerprint=fingerprint;state.fileName=handle.name||DB_FILE_NAME;state.fileConnected=true;state.dbMode='file';state.pendingHandle=null;state.pendingName='';state.fileDirty=pending;
 if(!pending)await rememberFileLink3(handle,serializeWorkspace(),fingerprint);
 state.notice=pending?'Доступ к файлу восстановлен. Неотправленные локальные изменения сохранены и ожидают записи.':'Доступ к личному файлу восстановлен.';
 updateDbChip();return true;
}
async function restoreFileHandle(){if(connectionMode!=='local'||state.localTabReadOnly||state.localRecoveryError||!window.showOpenFilePicker)return false;try{var handle=await idbGetHandle();return handle?await restorePersonalFile3(handle,false):false}catch(e){state.notice='Файл не восстановлен: '+e.message+'. Локальная копия сохранена.';return false}}
async function allowPending(){if(!state.pendingHandle)return;try{if(await restorePersonalFile3(state.pendingHandle,true)){closeModal();render()}}catch(e){inform3('Файл не подключён: '+e.message)}}
