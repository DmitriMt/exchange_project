/* Built-in regression and stress checks remain available in both standalone editions. */
function createStressProject3(){var p=createProjectObject('Стресс-тест: 1000 задач','2026-11-02','Отдельный синтетический проект для проверки; текущие проекты не заменяются.');p.calendar_id='5day';p.tasks=[];p.dependencies=[];for(var i=0;i<1000;i++){var t={};t.id='stress-task-'+i;t.name='Проверочная задача '+(i+1);t.duration_days=1;t.sort_order=i;t.parent_id=null;p.tasks.push(t);if(i){var d={};d.id='stress-link-'+i;d.pred_id='stress-task-'+(i-1);d.succ_id=t.id;d.type='FS';d.lag_workdays=0;p.dependencies.push(d)}}return Core.calculate(p,{strict:true})}
function showStressTest3(){try{var started=Date.now(),p=createStressProject3();window.__stressProject3=p;showModal('Стресс-тест: 1000 задач','<p>Расчёт выполнен: <b>'+p.tasks.length+' задач</b>, <b>'+p.dependencies.length+' связей</b>.</p><p>Время расчёта: '+(Date.now()-started)+' мс. Ошибок CPM нет. Это проверка расчётного ядра; для проверки отрисовки добавьте отдельный локальный проект.</p>',modalButton3('Закрыть','closeModal()')+(connectionMode==='local'&&!state.localTabReadOnly?modalButton3('Добавить отдельный проект','installStressProject3()',true):''))}catch(e){inform3('Стресс-тест не выполнен: '+e.message)}}
function installStressProject3(){if(connectionMode!=='local'||state.localTabReadOnly)return inform3('Проверочный проект добавляется в доступное для записи локальное пространство.');var p=window.__stressProject3;if(!p)return;try{p=Core.copyProject(p);p.name='Стресс-тест: 1000 задач';pushHistory();state.projects.push(p);storeProject(p);window.__stressProject3=null;closeModal();openProject(p.id)}catch(e){inform3(e.message)}}
function installLeadRequirements3(){
 var baseTests=runTests;
 runTests=function(){baseTests();var R=window.__testReport||[];try{
  var p=Core.calculate({id:'selfcheck-wbs',name:'WBS',start_date:'2026-10-05',calendar_id:'5day',tasks:[{id:'s',name:'Этап'},{id:'a',name:'А',parent_id:'s',sort_order:0},{id:'b',name:'Б',parent_id:'s',sort_order:1},{id:'c',name:'В',sort_order:1}],dependencies:[]});
  assert(Core.tree(p).flat.map(function(t){return t.external_number}).join(';')==='1;1.1;1.2;2','Иерархические номера задач',R);
  var links=Core.predecessors(p,'c','1.1НС+2д; 1.2НН');assert(links.length===2&&links[0].lag_workdays===2&&links[1].type==='SS','Связи по номерам с точками',R);
  var cycle=false;try{Core.predecessors(p,'a','1.1НС')}catch(e){cycle=true}assert(cycle,'Предшественники: самоссылка отклоняется',R);
  var stress=createStressProject3();assert(stress.tasks.length===1000&&stress.dependencies.length===999&&!stress.cpmError,'Стресс-тест 1000 задач и 999 связей',R);
  var defs=getColumnDefs(p),num=defs.find(function(d){return d.key==='num'}),preds=defs.find(function(d){return d.key==='preds'});assert(num.w===78&&preds.w===170,'Базовые ширины номера и предшественников',R);
 }catch(e){assert(false,'Дополнительная регрессия: '+e.message,R)}
 window.__testReport=R;var ok=R.filter(function(r){return r.ok}).length;showModal('Самотестирование: '+ok+'/'+R.length,'<div class="form-field full"><div style="max-height:340px;overflow:auto">'+R.map(function(r){return '<div>'+(r.ok?'✅':'❌')+' '+esc(r.name)+'</div>'}).join('')+'</div></div>',modalButton3('Печать протокола (PDF)','printProtocol()')+modalButton3('Закрыть','closeModal()',true));
 };
 App.runTests=runTests;App.showStressTest3=showStressTest3;App.installStressProject3=installStressProject3;
}
