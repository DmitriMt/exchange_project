/* Layout in CSS pixels: no dependency on monitor resolution or devicePixelRatio. */
(function(root,factory){var api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.LocalPMLayout=api})(typeof globalThis!=='undefined'?globalThis:this,function(){
 function gantt(width,view,definitions){width=Math.max(320,Number(width)||1280);view=view||{};var saved=Number(view.leftWidth)||760,fixed=view.leftPanelMode==='fixed'||saved!==760,min=Math.min(760,width*.65),max=Math.max(280,width-320),left=Math.max(280,Math.min(max,fixed?saved:Math.max(min,Math.round(width*.46)))),defs=definitions.map(function(d){return Object.assign({},d)}),sum=defs.reduce(function(n,d){return n+d.w},0),name=defs.find(function(d){return d.key==='name'});if(name&&sum<left){name.w+=left-sum;sum=left}return {leftWidth:Math.round(left),columns:defs,tableWidth:sum}}
 return {gantt:gantt};
});
