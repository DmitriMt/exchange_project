/* SHA-256 must be identical on HTTPS, plain HTTP and file://. */
(function(root,factory){var api=factory(root);if(typeof module==='object'&&module.exports)module.exports=api;else root.LocalPMChecksum=api})(typeof globalThis!=='undefined'?globalThis:this,function(root){
  'use strict';
  var K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  function utf8(text){
    if(root.TextEncoder)return new root.TextEncoder().encode(text);
    var bytes=[];
    for(var i=0;i<text.length;i++){
      var c=text.charCodeAt(i);
      if(c>=0xd800&&c<=0xdbff){var next=text.charCodeAt(i+1);if(next>=0xdc00&&next<=0xdfff){c=0x10000+((c-0xd800)<<10)+(next-0xdc00);i++}else c=0xfffd}
      else if(c>=0xdc00&&c<=0xdfff)c=0xfffd;
      if(c<0x80)bytes.push(c);
      else if(c<0x800)bytes.push(0xc0|(c>>>6),0x80|(c&63));
      else if(c<0x10000)bytes.push(0xe0|(c>>>12),0x80|((c>>>6)&63),0x80|(c&63));
      else bytes.push(0xf0|(c>>>18),0x80|((c>>>12)&63),0x80|((c>>>6)&63),0x80|(c&63));
    }
    return new Uint8Array(bytes);
  }
  function hex(words){return words.map(function(w){return (w>>>0).toString(16).padStart(8,'0')}).join('')}
  function rotr(x,n){return (x>>>n)|(x<<(32-n))}
  function fallback(bytes){
    var length=bytes.length,size=Math.ceil((length+9)/64)*64,data=new Uint8Array(size),view=new DataView(data.buffer);
    data.set(bytes);data[length]=0x80;
    view.setUint32(size-8,Math.floor(length/0x20000000));view.setUint32(size-4,(length*8)>>>0);
    var h=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19],w=new Int32Array(64);
    for(var offset=0;offset<size;offset+=64){
      for(var i=0;i<16;i++)w[i]=view.getInt32(offset+i*4);
      for(i=16;i<64;i++){var x=w[i-15],y=w[i-2];w[i]=((rotr(x,7)^rotr(x,18)^(x>>>3))+w[i-16]+(rotr(y,17)^rotr(y,19)^(y>>>10))+w[i-7])|0}
      var a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],j=h[7];
      for(i=0;i<64;i++){
        var t1=(j+(rotr(e,6)^rotr(e,11)^rotr(e,25))+((e&f)^(~e&g))+K[i]+w[i])|0;
        var t2=((rotr(a,2)^rotr(a,13)^rotr(a,22))+((a&b)^(a&c)^(b&c)))|0;
        j=g;g=f;f=e;e=(d+t1)|0;d=c;c=b;b=a;a=(t1+t2)|0;
      }
      var round=[a,b,c,d,e,f,g,j];for(i=0;i<8;i++)h[i]=(h[i]+round[i])|0;
    }
    return hex(h);
  }
  async function sha256(text){
    var bytes=utf8(String(text));
    if(root.crypto&&root.crypto.subtle){try{var result=await root.crypto.subtle.digest('SHA-256',bytes);return Array.from(new Uint8Array(result),function(b){return b.toString(16).padStart(2,'0')}).join('')}catch(e){/* Some browser policies disable digest even when exposed. */}}
    return fallback(bytes);
  }
  return {sha256:sha256};
});
