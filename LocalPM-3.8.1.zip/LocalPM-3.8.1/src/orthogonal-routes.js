/* Shortest rectilinear paths between right/left ports, avoiding the two endpoint bars. */
(function(root,factory){var api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.LocalPMRoutes=api})(typeof globalThis!=='undefined'?globalThis:this,function(){
 'use strict';
 function inside(p,r){return p.x>r.left+.001&&p.x<r.right-.001&&p.y>r.top+.001&&p.y<r.bottom-.001}
 function blocked(a,b,rects){return rects.some(function(r){if(a.y===b.y)return a.y>r.top+.001&&a.y<r.bottom-.001&&Math.max(a.x,b.x)>r.left+.001&&Math.min(a.x,b.x)<r.right-.001;return a.x>r.left+.001&&a.x<r.right-.001&&Math.max(a.y,b.y)>r.top+.001&&Math.min(a.y,b.y)<r.bottom-.001})}
 function compact(points){var out=[];points.forEach(function(p){if(out.length&&out[out.length-1].x===p.x&&out[out.length-1].y===p.y)return;while(out.length>1){var a=out[out.length-2],b=out[out.length-1];if((a.x===b.x&&b.x===p.x)||(a.y===b.y&&b.y===p.y))out.pop();else break}out.push(p)});return out}
 function route(source,target,pad){pad=pad||8;var start={x:source.right,y:(source.top+source.bottom)/2},end={x:target.left,y:(target.top+target.bottom)/2},a={x:start.x+pad,y:start.y},b={x:end.x-pad,y:end.y};var rects=[source,target].map(function(r){return {left:r.left-pad,right:r.right+pad,top:r.top-pad,bottom:r.bottom+pad}});
  if(a.x<=b.x){var simple=[a,{x:b.x,y:a.y},b];if(!blocked(simple[0],simple[1],rects)&&!blocked(simple[1],simple[2],rects))return compact([start].concat(simple,[end]))}
  var xs=Array.from(new Set([a.x,b.x].concat(rects.flatMap(function(r){return [r.left,r.right]})))).sort(function(x,y){return x-y}),ys=Array.from(new Set([a.y,b.y].concat(rects.flatMap(function(r){return [r.top,r.bottom]})))).sort(function(x,y){return x-y}),nodes=[],by=new Map();
  ys.forEach(function(y,iy){xs.forEach(function(x,ix){var p={x:x,y:y,ix:ix,iy:iy};if(!rects.some(function(r){return inside(p,r)})){p.id=nodes.length;nodes.push(p);by.set(ix+','+iy,p)}})});
  var first=by.get(xs.indexOf(a.x)+','+ys.indexOf(a.y)),last=by.get(xs.indexOf(b.x)+','+ys.indexOf(b.y));if(!first||!last)return [];
  var distances=new Map(),previous=new Map(),queue=[{node:first,dir:0,length:0,bends:0,key:first.id+':0'}],best=null;distances.set(queue[0].key,[0,0]);
  while(queue.length){queue.sort(function(x,y){return x.length-y.length||x.bends-y.bends});var current=queue.shift(),known=distances.get(current.key);if(current.length!==known[0]||current.bends!==known[1])continue;if(current.node===last){best=current;break}
   [[1,0],[-1,0],[0,1],[0,-1]].forEach(function(delta){var next=by.get((current.node.ix+delta[0])+','+(current.node.iy+delta[1]));if(!next||blocked(current.node,next,rects))return;var dir=delta[0]?0:1,length=current.length+Math.abs(next.x-current.node.x)+Math.abs(next.y-current.node.y),bends=current.bends+(dir!==current.dir?1:0),key=next.id+':'+dir,old=distances.get(key);if(!old||length<old[0]||length===old[0]&&bends<old[1]){distances.set(key,[length,bends]);previous.set(key,current);queue.push({node:next,dir:dir,length:length,bends:bends,key:key})}})
  }
  if(!best)return [];var points=[];for(var step=best;step;step=previous.get(step.key))points.push({x:step.node.x,y:step.node.y});points.reverse();return compact([start].concat(points,[end]));
 }
 return {route:route,blocked:blocked};
});
