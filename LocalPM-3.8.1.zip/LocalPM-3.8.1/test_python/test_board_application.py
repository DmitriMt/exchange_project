"""Board workflow checks against the real application/SQLite without opening a socket."""
import copy
import datetime as dt
import secrets
import tempfile
import unittest
from localpm.application import Application,COOKIE
from localpm.storage import APIError
from test_core import sample

class DirectClient:
    def __init__(self,app): self.app=app; self.cookie=''; self.csrf=''
    def call(self,method,path,data=None,expected=200):
        headers={'Host':'127.0.0.1','Cookie':self.cookie,'X-LocalPM-CSRF':self.csrf}
        try: status,payload,extra=self.app.handle(method,path,headers,data or {})
        except APIError as e: status,payload,extra=e.status,{'error':str(e)},{}
        except ValueError as e: status,payload,extra=422,{'error':str(e)},{}
        if status!=expected: raise AssertionError(f'{method} {path}: {status} != {expected}: {payload}')
        if extra.get('Set-Cookie'): self.cookie=extra['Set-Cookie'].split(';')[0]
        if isinstance(payload,dict) and 'csrf' in payload: self.csrf=payload['csrf']
        return payload

class BoardApplicationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.app=Application(self.tmp.name); self.addCleanup(self.tmp.cleanup); self.addCleanup(self.app.close)
        self.manager=DirectClient(self.app); password=secrets.token_urlsafe(24)
        self.manager.call('POST','/api/setup',{'code':self.app.bootstrap_code,'username':'manager','name':'Руководитель','password':password},201)
        self.manager.call('POST','/api/login',{'username':'manager','password':password})
        self.doc=self.manager.call('POST','/api/projects',{'project':sample()},201)
    def worker(self,role='contributor'):
        password=secrets.token_urlsafe(24); name='user'+secrets.token_hex(4)
        user=self.manager.call('POST','/api/users',{'username':name,'name':'Сотрудник','password':password},201)
        self.doc=self.manager.call('POST','/api/projects/project-test/members',{'userId':user['id'],'role':role})
        client=DirectClient(self.app); client.call('POST','/api/login',{'username':name,'password':password})
        return user,client
    def put(self,doc,change):
        p=copy.deepcopy(doc['project']); change(p)
        return self.manager.call('PUT','/api/projects/project-test',{'project':p,'expectedVersion':doc['version'],'operationId':secrets.token_hex(10)})
    def fact(self,status='В работе'):
        return {'actual_start':dt.date.today().isoformat(),'actual_finish':'','percent_complete':25,'remaining_days':2,'status':status,'blocker':'Проверка'}
    def propose(self,client,data=None,expected=201,operation=None):
        return client.call('POST','/api/projects/project-test/updates',{'taskId':'a','actual':data or self.fact(),'operationId':operation or secrets.token_hex(10)},expected)
    def review(self,doc,expected=200):
        return self.manager.call('POST','/api/projects/project-test/updates/'+doc['updates'][-1]['id']+'/review',{'decision':'accepted'},expected)
    def test_employee_own_card_changes_after_manager_accepts(self):
        user,client=self.worker(); self.propose(client,expected=403)
        self.doc=self.put(self.doc,lambda p:p['tasks'][0].update(assignee_id=user['id']))
        submitted=self.propose(client,self.fact('Заблокировано')); self.assertEqual(submitted['project']['tasks'][0]['percent_complete'],0)
        accepted=self.review(submitted); self.assertEqual(accepted['project']['tasks'][0]['status'],'Заблокировано'); self.assertEqual(accepted['project']['tasks'][0]['percent_complete'],25)
        self.assertTrue(client.call('GET','/api/projects/project-test')['notifications'])
    def test_viewer_cannot_move_card_and_other_projects_remain_private(self):
        user,client=self.worker('viewer'); self.propose(client,expected=403)
        second=sample(); second['id']='private-project'; self.manager.call('POST','/api/projects',{'project':second},201)
        self.assertEqual(len(client.call('GET','/api/projects')),1); client.call('GET','/api/projects/private-project',expected=403)
    def test_completion_requires_dates_hundred_percent_and_zero_remaining(self):
        bad=self.fact('Завершено'); bad.update(percent_complete=100); self.propose(self.manager,bad,expected=422)
        complete=self.fact('Завершено'); complete.update(actual_finish=dt.date.today().isoformat(),percent_complete=100,remaining_days=0)
        submitted=self.propose(self.manager,complete); accepted=self.review(submitted)
        self.assertEqual(accepted['project']['tasks'][0]['status'],'Завершено'); self.assertEqual(accepted['project']['tasks'][0]['remaining_days'],0)
    def test_status_only_changes_invalidate_stale_proposals(self):
        submitted=self.propose(self.manager,self.fact('На приёмке'))
        self.put(submitted,lambda p:p['tasks'][0].update(status='Заблокировано'))
        self.review(submitted,expected=409)
    def test_same_operation_retry_does_not_duplicate_proposal(self):
        operation=secrets.token_hex(10); first=self.propose(self.manager,operation=operation)
        second=self.propose(self.manager,expected=200,operation=operation)
        self.assertEqual(first['version'],second['version']); self.assertEqual(len(second['updates']),1)
    def test_reopen_completed_task_recalculates_forecast(self):
        data=self.fact('Завершено'); data.update(actual_finish=dt.date.today().isoformat(),percent_complete=100,remaining_days=0)
        self.review(self.propose(self.manager,data))
        reopened=self.fact('В работе'); accepted=self.review(self.propose(self.manager,reopened))
        task=accepted['project']['tasks'][0]; self.assertEqual(task['status'],'В работе'); self.assertEqual(task['actual_finish'],''); self.assertEqual(task['remaining_days'],2)


class BoardSettingsTests(unittest.TestCase):
    setUp=BoardApplicationTests.setUp
    worker=BoardApplicationTests.worker
    fact=BoardApplicationTests.fact
    propose=BoardApplicationTests.propose
    review=BoardApplicationTests.review
    def config(self): return self.manager.call('GET','/api/kanban')
    def update_config(self,config,version,expected=200): return self.manager.call('PUT','/api/kanban',{'config':config,'expectedVersion':version},expected)
    def test_only_admin_edits_global_columns_and_all_users_read_them(self):
        user,client=self.worker('manager'); current=self.config(); cfg=copy.deepcopy(current['config']); cfg['columns'][0]['name']='Очередь'
        client.call('PUT','/api/kanban',{'config':cfg,'expectedVersion':current['version']},403)
        saved=self.update_config(cfg,current['version']); self.assertEqual(saved['version'],1); self.assertEqual(client.call('GET','/api/kanban')['config']['columns'][0]['name'],'Очередь')
    def test_count_reorder_rename_and_stale_admin_change(self):
        current=self.config(); cfg=copy.deepcopy(current['config']); cfg['columns'].insert(1,{'id':'external','name':'Внешняя проверка','kind':'review'}); cfg['columns'].reverse()
        saved=self.update_config(cfg,0); self.assertEqual(len(saved['config']['columns']),6)
        self.update_config(current['config'],0,409); self.assertEqual(self.config(),saved)
    def test_invalid_config_is_atomic(self):
        current=self.config(); bad=copy.deepcopy(current['config']); bad['columns'][1]['name']=bad['columns'][0]['name']; self.update_config(bad,0,422); self.assertEqual(self.config(),current)
        bad=copy.deepcopy(current['config']); bad['columns']=[c for c in bad['columns'] if c['kind']!='done']; self.update_config(bad,0,422); self.assertEqual(self.config(),current)
    def test_removal_requires_redirect_and_preserves_task_facts(self):
        before=self.manager.call('GET','/api/projects/project-test'); current=self.config(); cfg=copy.deepcopy(current['config']); cfg['columns']=[c for c in cfg['columns'] if c['id']!='blocked']; self.update_config(cfg,0,422)
        cfg['redirects']={'blocked':'work'}; saved=self.update_config(cfg,0); self.assertEqual(saved['config']['redirects']['blocked'],'work'); self.assertEqual(self.manager.call('GET','/api/projects/project-test'),before)
    def test_columns_persist_and_are_in_backup_restore(self):
        from localpm.storage import Repository
        current=self.config(); cfg=copy.deepcopy(current['config']); cfg['columns'][0]['name']='Входящие'; saved=self.update_config(cfg,0)
        backup=self.manager.call('POST','/api/backup'); self.assertEqual(backup['content']['kanban'],saved)
        with tempfile.TemporaryDirectory() as target:
            repo=Repository(target)
            try: repo.restore(backup); self.assertEqual(repo.board_setting(),saved)
            finally: repo.close()
        self.app.close(); reopened=Application(self.tmp.name)
        try: self.assertEqual(reopened.repo.board_setting(),saved)
        finally: reopened.close()
    def test_shared_folder_configuration_persists_under_owner_lock(self):
        from localpm.storage import Repository
        from localpm.kanban import defaults
        from pathlib import Path
        with tempfile.TemporaryDirectory() as target:
            root=Path(target); repo=Repository(root/'db',root/'share')
            try: saved=repo.save_board_setting(defaults(),0); self.assertEqual(repo.board_setting(),saved)
            finally: repo.close()
            repo=Repository(root/'db',root/'share')
            try: self.assertEqual(repo.board_setting(),saved)
            finally: repo.close()
    def test_custom_column_id_round_trips_through_proposal_approval(self):
        current=self.config(); cfg=copy.deepcopy(current['config']); cfg['columns'].append({'id':'external','name':'Внешняя проверка','kind':'review'}); self.update_config(cfg,0)
        data=self.fact('На приёмке'); data['kanban_column_id']='external'; accepted=self.review(self.propose(self.manager,data)); self.assertEqual(accepted['project']['tasks'][0]['kanban_column_id'],'external')
    def test_removed_column_rejects_new_and_pending_transitions(self):
        current=self.config(); cfg=copy.deepcopy(current['config']); cfg['columns'].append({'id':'external','name':'Внешняя проверка','kind':'review'}); self.update_config(cfg,0)
        data=self.fact('На приёмке'); data['kanban_column_id']='external'; pending=self.propose(self.manager,data)
        cfg['columns']=[c for c in cfg['columns'] if c['id']!='external']; cfg['redirects']={'external':'work'}; self.update_config(cfg,1)
        self.propose(self.manager,data,409); self.review(pending,409)
    def test_done_column_requires_completed_actual_and_worker_cannot_spoof_it(self):
        data=self.fact(); data['kanban_column_id']='done'; self.propose(self.manager,data,422)
        data['kanban_column_id']='missing'; self.propose(self.manager,data,409)
        self.manager.call('POST','/api/projects/project-test/updates',{'taskId':'a','actual':[1]},422)

if __name__=='__main__': unittest.main()
