import hashlib
import hmac
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch,MagicMock
import test_board_application as board_tests
from localpm.maintenance import integration_config,deliver_webhook,deliver_mail,Maintenance
from localpm.storage import Repository,APIError,json_text

class IntegrationTests(unittest.TestCase):
    def test_integration_config_is_disabled_by_default_and_rejects_weak_secrets(self):
        self.assertFalse(integration_config(None)['enabled'])
        with tempfile.TemporaryDirectory() as root:
            file=Path(root)/'config.json';file.write_text(json.dumps({'enabled':True,'webhooks':[{'url':'http://internal.test/hook','secret':'short'}]}))
            with self.assertRaises(ValueError):integration_config(file)
    def test_webhook_signature_covers_the_exact_utf8_payload_and_redirects_are_not_followed(self):
        event={'id':'p:2','event':'project.changed','project':{'id':'p','name':'Проект'},'version':2};config={'url':'https://internal.test/hook','secret':'x'*32}
        response=MagicMock();response.__enter__.return_value.status=204;opener=MagicMock();opener.open.return_value=response
        with patch('urllib.request.build_opener',return_value=opener):deliver_webhook(config,event)
        request=opener.open.call_args.args[0];self.assertEqual(request.data,json_text(event,sort_keys=True).encode());expected=hmac.new(config['secret'].encode(),request.data,hashlib.sha256).hexdigest();self.assertEqual(request.get_header('X-localpm-signature'),'sha256='+expected)
        self.assertEqual(request.get_header('X-localpm-event-id'),'p:2')
    def test_email_uses_tls_and_a_stable_message_id_without_real_delivery(self):
        event={'id':'p:2','project':{'name':'Проект'},'version':2,'at':'2026-10-27'};config={'enabled':True,'host':'smtp.internal.test','from':'localpm@example.test','recipients':['qa@example.test'],'username':'test','password':'test-only-value'}
        with patch('smtplib.SMTP') as smtp:
            deliver_mail(config,event);server=smtp.return_value.__enter__.return_value;server.starttls.assert_called_once();message=server.send_message.call_args.args[0];self.assertIn(hashlib.sha256(b'p:2').hexdigest(),message['Message-ID'])

class DeliveryTests(unittest.TestCase):
    setUp=board_tests.BoardApplicationTests.setUp
    def test_successful_destinations_are_not_resent_after_another_destination_fails(self):
        config={'enabled':True,'webhooks':[{'url':'https://one.test','secret':'a'*32},{'url':'https://two.test','secret':'b'*32}],'mail':{}}
        maintenance=Maintenance(self.app,config);self.app.repo.enqueue_event(self.doc);calls=[]
        def send(target,event):
            calls.append(target['url'])
            if target['url']=='https://two.test' and calls.count(target['url'])==1:raise OSError('peer error containing a private secret')
        with patch('localpm.maintenance.deliver_webhook',side_effect=send):
            maintenance.deliveries();self.assertEqual(self.app.repo.delivery_status().get('pending'),1);self.app.repo.db.execute('UPDATE deliveries SET next_at=0');maintenance.deliveries();maintenance.deliveries()
        self.assertEqual(calls.count('https://one.test'),1);self.assertEqual(calls.count('https://two.test'),2);self.assertEqual(self.app.repo.delivery_status().get('sent'),1)
        self.assertNotIn('private secret',str([dict(r) for r in self.app.repo.db.execute('SELECT * FROM deliveries')]))
    def test_backup_contains_pending_delivery_and_restores_it(self):
        self.app.repo.event_sink_enabled=True;self.app.repo.enqueue_event(self.doc);backup=self.app.repo.backup()
        with tempfile.TemporaryDirectory() as root:
            repo=Repository(root)
            try:repo.restore(backup);self.assertEqual(repo.delivery_status().get('pending'),1)
            finally:repo.close()
    def test_future_database_schema_is_never_silently_downgraded(self):
        with tempfile.TemporaryDirectory() as root:
            repo=Repository(root);repo.db.execute('PRAGMA user_version=99');repo.close()
            with self.assertRaises(APIError):Repository(root)

if __name__=='__main__':unittest.main()
