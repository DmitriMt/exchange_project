"""Real HTTP coverage for standalone clients, CORS and memory-only bearer sessions."""
import http.client
import json
import secrets
import tempfile
import threading
import unittest
from pathlib import Path
from localpm.application import Application
from localpm.http_server import Server
from test_core import sample
ROOT=Path(__file__).resolve().parents[1]
class StandaloneAPITests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.app=Application(self.tmp.name,client_origins=['null','http://127.0.0.1:9099'])
        self.server=Server(('127.0.0.1',0),self.app,ROOT/'web'); self.thread=threading.Thread(target=self.server.serve_forever,kwargs={'poll_interval':.01},daemon=True); self.thread.start()
        self.password=secrets.token_urlsafe(24); self.request('POST','/api/setup',{'code':self.app.bootstrap_code,'username':'client-test','name':'Client test','password':self.password},expected=201)
    def tearDown(self): self.server.shutdown(); self.server.server_close(); self.thread.join(); self.app.close(); self.tmp.cleanup()
    def request(self,method,path,data=None,headers=None,expected=200):
        connection=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=20); h={'Content-Type':'application/json',**(headers or {})}
        connection.request(method,path,None if data is None else json.dumps(data),h); r=connection.getresponse(); raw=r.read(); response_headers=dict(r.getheaders()); out=json.loads(raw) if raw and 'application/json' in r.getheader('Content-Type','') else raw; status=r.status; connection.close(); self.assertEqual(status,expected,(path,status,out)); return out,response_headers
    def client_headers(self,origin='null',session=None):
        h={'Origin':origin,'X-LocalPM-Client':'desktop-v1'}
        if session: h.update(Authorization='Bearer '+session['sessionToken'],**{'X-LocalPM-CSRF':session['csrf']})
        return h
    def login(self,origin='null'):
        session,h=self.request('POST','/api/client/login',{'username':'client-test','password':self.password},self.client_headers(origin)); self.assertNotIn('Set-Cookie',h); return session
    def test_null_origin_enabled_explicitly_without_cookie_credentials(self):
        out,h=self.request('GET','/api/status',headers=self.client_headers()); self.assertEqual(out['clientApiVersion'],1); self.assertEqual(h['Access-Control-Allow-Origin'],'null'); self.assertNotIn('Access-Control-Allow-Credentials',h)
        self.app.client_origins.clear(); self.request('GET','/api/status',headers=self.client_headers(),expected=403)
    def test_preflight_exact_origin_methods_headers_and_private_network(self):
        _,h=self.request('OPTIONS','/api/projects',headers={'Origin':'null','Access-Control-Request-Method':'PUT','Access-Control-Request-Headers':'authorization,content-type,x-localpm-client,x-localpm-csrf','Access-Control-Request-Private-Network':'true'},expected=204)
        self.assertEqual(h['Access-Control-Allow-Origin'],'null'); self.assertEqual(h['Access-Control-Allow-Private-Network'],'true'); self.assertNotIn('Access-Control-Allow-Credentials',h)
        self.request('OPTIONS','/api/projects',headers={'Origin':'https://untrusted.example','Access-Control-Request-Method':'GET','Access-Control-Request-Headers':'x-localpm-client'},expected=403)
        self.request('OPTIONS','/api/projects',headers={'Origin':'null','Access-Control-Request-Method':'TRACE','Access-Control-Request-Headers':'x-localpm-client'},expected=403)
        self.request('OPTIONS','/api/projects',headers={'Origin':'null','Access-Control-Request-Method':'POST','Access-Control-Request-Headers':'x-localpm-client,x-unknown'},expected=403)
    def test_login_crud_versions_and_logout_with_bearer(self):
        session=self.login(); h=self.client_headers(session=session); doc,_=self.request('POST','/api/projects',{'project':sample()},h,201)
        projects,_=self.request('GET','/api/projects',headers=h); self.assertEqual(len(projects),1)
        p=doc['project']; p['name']='Edited from standalone'; saved,_=self.request('PUT','/api/projects/project-test',{'project':p,'expectedVersion':doc['version'],'operationId':secrets.token_hex(12)},h); self.assertEqual(saved['project']['name'],p['name'])
        self.request('PUT','/api/projects/project-test',{'project':p,'expectedVersion':doc['version'],'operationId':secrets.token_hex(12)},h,409)
        _,headers=self.request('POST','/api/logout',{},h); self.assertNotIn('Set-Cookie',headers); self.request('GET','/api/projects',headers=h,expected=401)
    def test_cookie_cannot_authenticate_a_file_client_and_bearer_cannot_authenticate_web_session(self):
        web,headers=self.request('POST','/api/login',{'username':'client-test','password':self.password}); cookie=headers['Set-Cookie'].split(';')[0]
        self.request('GET','/api/projects',headers={**self.client_headers(),'Cookie':cookie},expected=401)
        session=self.login(); self.request('GET','/api/projects',headers={'Authorization':'Bearer '+session['sessionToken']},expected=401)
        self.request('GET','/api/projects',headers={'Cookie':'localpm_py_session='+session['sessionToken']},expected=401)
    def test_bearer_is_bound_to_client_origin_and_writes_require_csrf(self):
        session=self.login(); self.request('GET','/api/projects',headers=self.client_headers('http://127.0.0.1:9099',session),expected=401)
        self.request('GET','/api/projects',headers=self.client_headers('https://untrusted.example',session),expected=403)
        h=self.client_headers(session=session); h['X-LocalPM-CSRF']=''; self.request('POST','/api/projects',{'project':sample()},h,403)
    def test_untrusted_origins_cannot_login_and_cookie_login_setup_are_not_exposed(self):
        self.request('POST','/api/client/login',{'username':'client-test','password':self.password},self.client_headers('https://untrusted.example'),403)
        self.request('POST','/api/login',{'username':'client-test','password':self.password},self.client_headers(),403)
        self.request('POST','/api/setup',{},self.client_headers(),403)
    def test_wrong_password_and_error_responses_include_allowed_cors(self):
        out,h=self.request('POST','/api/client/login',{'username':'client-test','password':secrets.token_urlsafe(24)},self.client_headers(),401); self.assertEqual(h['Access-Control-Allow-Origin'],'null'); self.assertNotIn('sessionToken',out)
    def test_regular_web_login_is_compatible_and_client_html_is_self_contained(self):
        session,h=self.request('POST','/api/login',{'username':'client-test','password':self.password}); cookie=h['Set-Cookie'].split(';')[0]
        self.request('GET','/api/projects',headers={'Cookie':cookie}); page,h=self.request('GET','/client.html'); self.assertIn(b'LOCALPM_CLIENT=true',page); self.assertNotIn(b'<script src=',page)

class ClientConfigurationTests(unittest.TestCase):
    def test_invalid_origin_does_not_create_or_lock_storage(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            with self.assertRaises(ValueError): Application(root/'db',root/'share',client_origins=['*'])
            self.assertFalse((root/'db').exists()); self.assertFalse((root/'share').exists())
    def test_client_origin_normalization(self):
        from localpm.client_access import origin_value
        self.assertEqual(origin_value('http://LOCALHOST:80/'),'http://localhost')
        self.assertEqual(origin_value('https://example.test:443'),'https://example.test')
        for value in ['http://example.test:bad','https://user:secret@example.test','file:///tmp/client','https://example.test/path']:
            with self.assertRaises(ValueError): origin_value(value)
