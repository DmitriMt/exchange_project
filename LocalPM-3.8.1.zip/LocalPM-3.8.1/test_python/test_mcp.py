"""MCP protocol, least privilege, durable plan patches and real stdio/API integration."""
import copy
import io
import json
import os
import secrets
import stat
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from localpm import core
from localpm_mcp.client import APIClient,ClientError,load_session,save_session,server_url
from localpm_mcp.protocol import Protocol,run,MODERN,MAX_MESSAGE
from localpm_mcp.tools import CATALOG,Tools,InvalidArguments,validate
import test_api as api_tests
ROOT=api_tests.ROOT

META={'io.modelcontextprotocol/protocolVersion':MODERN,'io.modelcontextprotocol/clientCapabilities':{}}
def request(method,params=None,id=1):return {'jsonrpc':'2.0','id':id,'method':method,'params':params or {}}
def modern(method,params=None,id=1):return request(method,{**(params or {}),'_meta':META},id)
class FakeTools:
    def __init__(self):self.calls=[]
    def catalog(self):return []
    def call(self,name,args):self.calls.append((name,args));return {'ok':True}

class ProtocolTests(unittest.TestCase):
    def setUp(self):self.tools=FakeTools();self.protocol=Protocol(self.tools)
    def test_modern_discovery_and_calls_without_initialize(self):
        out=self.protocol.dispatch(modern('server/discover'))['result'];self.assertEqual(out['resultType'],'complete');self.assertIn(MODERN,out['supportedVersions']);self.assertIn('tools',out['capabilities'])
        out=self.protocol.dispatch(modern('tools/call',{'name':'test','arguments':{}}))['result'];self.assertFalse(out['isError']);self.assertIn('io.modelcontextprotocol/serverInfo',out['_meta'])
    def test_legacy_handshake_and_initialization_notification(self):
        self.assertEqual(self.protocol.dispatch(request('tools/list'))['error']['code'],-32600)
        init=self.protocol.dispatch(request('initialize',{'protocolVersion':'2025-11-25','clientInfo':{'name':'test','version':'1'},'capabilities':{}}))
        self.assertEqual(init['result']['protocolVersion'],'2025-11-25');self.assertNotIn('resultType',init['result'])
        self.protocol.dispatch({'jsonrpc':'2.0','method':'notifications/initialized'})
        self.assertEqual(self.protocol.dispatch(request('tools/list'))['result'],{'tools':[]})
    def test_protocol_negotiation_missing_metadata_and_unknown_methods(self):
        value=modern('tools/list');value['params']['_meta']={**META,'io.modelcontextprotocol/protocolVersion':'2999-01-01'}
        out=self.protocol.dispatch(value);self.assertEqual(out['error']['code'],-32022);self.assertIn('supported',out['error']['data'])
        self.assertEqual(self.protocol.dispatch(request('server/discover'))['error']['code'],-32602)
        self.assertEqual(self.protocol.dispatch(modern('not/a/method'))['error']['code'],-32601)
    def test_notifications_never_execute_mutations_and_ids_are_strict(self):
        self.assertIsNone(self.protocol.dispatch({'jsonrpc':'2.0','method':'tools/call','params':{'name':'danger'}}));self.assertEqual(self.tools.calls,[])
        for id in [None,True,1.5,'x'*257]:self.assertEqual(self.protocol.dispatch(modern('ping',id=id))['error']['code'],-32600)
        self.assertEqual(self.protocol.dispatch([])['error']['code'],-32600)
    def test_invalid_json_recovers_and_eof_exits_without_non_protocol_output(self):
        source=io.BytesIO(b'broken\n'+json.dumps(modern('ping')).encode()+b'\n');out=io.StringIO()
        self.assertEqual(run(self.protocol,source,out),0);lines=[json.loads(x) for x in out.getvalue().splitlines()]
        self.assertEqual(lines[0]['error']['code'],-32700);self.assertEqual(lines[1]['result']['resultType'],'complete')
    def test_oversized_message_exits_and_resource_uri_cannot_escape(self):
        out=io.StringIO();self.assertEqual(run(self.protocol,io.BytesIO(b'x'*(MAX_MESSAGE+1)),out),1)
        self.assertEqual(self.protocol.dispatch(modern('resources/read',{'uri':'localpm://projects/../api/users'}))['error']['code'],-32602)
        self.assertEqual(self.tools.calls,[])
    def test_catalog_schemas_match_the_runtime_validator(self):
        self.assertEqual(len({t['name'] for t in CATALOG}),14)
        for t in CATALOG:self.assertEqual(t['inputSchema']['type'],'object');self.assertFalse(t['inputSchema']['additionalProperties'])
        self.assertRaises(InvalidArguments,validate,{'project_id':'../secret'},CATALOG[2]['inputSchema'])
        self.assertRaises(InvalidArguments,validate,{'project_id':'ok','limit':True},next(t for t in CATALOG if t['name']=='localpm_list_tasks')['inputSchema'])
    def test_urls_require_tls_off_loopback_and_never_embed_credentials(self):
        for url in ['file:///tmp/db','https://u:p@example.com','https://example.com/api','https://example.com?token=x','http://example.com']:
            self.assertRaises(ClientError,server_url,url)
        self.assertEqual(server_url('https://EXAMPLE.com:443/'),'https://example.com')
        self.assertEqual(server_url('http://127.0.0.1:8787'),'http://127.0.0.1:8787')
    def test_session_file_permissions_symlink_and_cross_server_binding(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'session.json';value={'server_url':'https://one.example','token':secrets.token_hex(32),'csrf':secrets.token_hex(24)}
            save_session(p,value);self.assertEqual(load_session(p),value)
            if os.name!='nt':
                self.assertEqual(stat.S_IMODE(p.stat().st_mode),0o600);p.chmod(0o644);self.assertRaises(ClientError,load_session,p);p.chmod(0o600)
                symlink=Path(tmp)/'link';symlink.symlink_to(p);self.assertRaises(ClientError,load_session,symlink)
            self.assertRaises(ClientError,APIClient,'https://two.example',value)

    def test_redirect_never_makes_a_second_credential_bearing_request(self):
        import threading
        from http.server import BaseHTTPRequestHandler,HTTPServer
        seen=[]
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                seen.append(self.path)
                if self.path=='/api/projects':
                    self.send_response(302);self.send_header('Location','/api/secret');self.send_header('Content-Length','0');self.end_headers()
                else:
                    self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(b'{}')
            def log_message(self,*args):pass
        with HTTPServer(('127.0.0.1',0),Handler) as server:
            thread=threading.Thread(target=server.serve_forever,kwargs={'poll_interval':.01});thread.start()
            try:
                api=APIClient('http://127.0.0.1:'+str(server.server_port));api.token=secrets.token_hex(32)
                with self.assertRaises(ClientError) as ctx:api.request('GET','/api/projects')
                self.assertEqual(ctx.exception.status,302);self.assertEqual(seen,['/api/projects'])
            finally:server.shutdown();thread.join()
    def test_large_resource_response_is_bounded_at_the_stdio_boundary(self):
        self.tools.call=lambda *args:{'data':'x'*(MAX_MESSAGE+100)}
        source=io.BytesIO((json.dumps(modern('resources/read',{'uri':'localpm://projects/example'}))+'\n').encode());out=io.StringIO()
        run(self.protocol,source,out);self.assertLess(len(out.getvalue()),MAX_MESSAGE)
        self.assertEqual(json.loads(out.getvalue())['error']['code'],-32603)

class MCPIntegrationTests(unittest.TestCase):
    setUpBase=api_tests.APITests.setUp
    tearDown=api_tests.APITests.tearDown
    project=api_tests.APITests.project
    worker=api_tests.APITests.worker
    put=api_tests.APITests.put
    def setUp(self):
        self.setUpBase();self.doc=self.project();self.api=self.api_for(self.admin_name,self.password);self.tools=Tools(self.api,True)
    def api_for(self,name,password):
        api=APIClient('http://127.0.0.1:'+str(self.server.server_port));api.login(name,password);return api
    def call(self,name,args):return self.tools.call(name,args)
    def patch(self,version=None,operation=None,changes=None,links=None):
        return {'project_id':'project-test','expected_version':version or self.doc['version'],'operation_id':operation or core.uid(),
                'changes':changes if changes is not None else [{'task_id':'a','fields':{'name':'Changed by agent'}}],
                'dependency_changes':links or []}
    def read(self):return self.manager.call('GET','/api/projects/project-test')
    def agent_user(self,role):
        name='agent'+secrets.token_hex(4);password=secrets.token_urlsafe(24)
        user=self.manager.call('POST','/api/users',{'username':name,'password':password,'name':'MCP test'},201)
        self.doc=self.manager.call('POST','/api/projects/project-test/members',{'userId':user['id'],'role':role})
        return user,Tools(self.api_for(name,password),True)
    def test_read_tools_filters_pagination_members_and_resources(self):
        self.assertEqual(self.call('localpm_list_projects',{'limit':1})['total'],1)
        result=self.call('localpm_list_tasks',{'project_id':'project-test','limit':1});self.assertEqual(result['next_offset'],1)
        self.assertEqual(self.call('localpm_list_tasks',{'project_id':'project-test','query':'not found'})['total'],0)
        self.assertEqual(self.call('localpm_get_task',{'project_id':'project-test','task_id':'a'})['base_actual']['percent_complete'],0)
        self.assertEqual(len(self.call('localpm_list_dependencies',{'project_id':'project-test'})['items']),1)
        self.assertEqual(len(self.call('localpm_get_board',{'project_id':'project-test'})['board']['columns']),5)
        self.assertEqual(len(self.call('localpm_list_members',{'project_id':'project-test'})['members']),1)
        self.assertEqual(self.call('localpm_list_comments',{'project_id':'project-test'})['total'],0)
        serialized=json.dumps(self.call('localpm_connection_info',{}));self.assertNotIn(self.api.token,serialized);self.assertNotIn(self.api.csrf,serialized)
        self.assertIn('contents',Protocol(self.tools).dispatch(modern('resources/read',{'uri':'localpm://projects/project-test/tasks/a'}))['result'])
    def test_read_only_and_allowlist_restrict_calls_even_with_admin_credentials(self):
        ro=Tools(self.api);self.assertNotIn('localpm_apply_plan',[t['name'] for t in ro.catalog()]);self.assertRaises(InvalidArguments,ro.call,'localpm_apply_plan',self.patch())
        limited=Tools(self.api,True,['other-project']);self.assertEqual(limited.call('localpm_list_projects',{})['total'],0)
        self.assertRaises(ClientError,limited.call,'localpm_get_project',{'project_id':'project-test'})
        self.assertRaises(ClientError,limited.call,'localpm_apply_plan',self.patch())
        self.assertEqual(self.read()['version'],self.doc['version'])
    def test_preview_calculates_weekends_without_persisting_then_apply_matches(self):
        args=self.patch(changes=[{'task_id':'a','fields':{'duration_days':2,'schedule_calendar':'all_days','constraint_snet':'2026-10-24'}}])
        preview_args={k:v for k,v in args.items() if k!='operation_id'}
        preview=self.call('localpm_preview_plan',preview_args);self.assertTrue(preview['dryRun']);self.assertEqual(self.read()['version'],self.doc['version'])
        result=self.call('localpm_apply_plan',args);self.assertEqual(result['version'],self.doc['version']+1)
        task=self.read()['project']['tasks'][0];self.assertEqual(task['start_date'],'2026-10-24');self.assertEqual(task['finish_date'],'2026-10-25')
        self.assertEqual(preview['finish'],self.read()['project']['finish_date'])
    def test_stale_invalid_and_cyclic_patches_are_atomic(self):
        changed=self.put(self.manager,self.doc,lambda p:p['tasks'][0].update(note='Other user'))
        with self.assertRaises(ClientError) as ctx:self.call('localpm_apply_plan',self.patch())
        self.assertEqual(ctx.exception.status,409);self.assertEqual(ctx.exception.current_version,changed['version'])
        bad=self.patch(version=changed['version'],changes=[{'task_id':'a','fields':{'name':'Should not save'}},{'task_id':'missing','fields':{'name':'Missing'}}])
        self.assertRaises(ClientError,self.call,'localpm_apply_plan',bad)
        cyclic=self.patch(version=changed['version'],changes=[],links=[{'id':'ba','pred_id':'b','succ_id':'a','type':'FS'}])
        self.assertRaises(ClientError,self.call,'localpm_apply_plan',cyclic);self.assertEqual(self.read()['version'],changed['version']);self.assertNotEqual(self.read()['project']['tasks'][0]['name'],'Should not save')
    def test_plan_replay_survives_unrelated_edits_and_service_restart(self):
        args=self.patch();first=self.call('localpm_apply_plan',args);doc=self.read();doc=self.put(self.manager,doc,lambda p:p['tasks'][1].update(note='Later change'))
        replay=self.call('localpm_apply_plan',args);self.assertTrue(replay['replayed']);self.assertEqual(replay['version'],doc['version']);self.assertEqual(replay['receipt']['version'],first['version'])
        self.assertEqual(self.read()['project']['tasks'][1]['note'],'Later change')
        # Durable receipts are in SQLite, not MCP process memory.
        from localpm.application import Application
        self.app.close();self.app=Application(Path(self.tmp.name)/'data');self.server.app=self.app
        self.manager.call('POST','/api/login',{'username':self.admin_name,'password':self.password});self.api=self.api_for(self.admin_name,self.password);self.tools=Tools(self.api,True)
        self.assertTrue(self.call('localpm_apply_plan',args)['replayed'])
        args['changes'][0]['fields']['name']='Different payload';self.assertRaises(ClientError,self.call,'localpm_apply_plan',args)
    def test_editor_plan_submission_and_retry_keep_approval_pending(self):
        self.doc=self.put(self.manager,self.doc,lambda p:p.update(require_plan_approval=True))
        user,editor=self.agent_user('editor');args=self.patch();out=editor.call('localpm_apply_plan',args)
        self.assertTrue(out['approval_pending']);self.assertIsNotNone(out['plan_submission']);self.assertNotEqual(self.read()['project']['tasks'][0]['name'],'Changed by agent')
        replay=editor.call('localpm_apply_plan',args);self.assertTrue(replay['approval_pending']);self.assertEqual(replay['plan_submission'],out['plan_submission'])
        self.assertEqual(len(self.read()['changeRequests']),1)
    def test_contributor_and_viewer_cannot_change_the_plan(self):
        for role in ['contributor','viewer']:
            _,tools=self.agent_user(role);before=self.read()['version']
            with self.assertRaises(ClientError) as ctx:tools.call('localpm_apply_plan',self.patch(version=before))
            self.assertEqual(ctx.exception.status,403);self.assertEqual(self.read()['version'],before)
    def test_creation_preserves_existing_ids_and_forbids_actual_or_permission_fields(self):
        args=self.patch(changes=[{'task_id':'agent-created','create':True,'fields':{'name':'New task','parent_id':'a','duration_days':1}}])
        out=self.call('localpm_apply_plan',args);self.assertEqual(len(self.read()['project']['tasks']),3)
        for fields in [{'percent_complete':100},{'acl':{}},{'id':'other'},{'status':'Завершено'}]:
            args=self.patch(version=out['version'],changes=[{'task_id':'b','fields':fields}]);self.assertRaises(InvalidArguments,self.call,'localpm_apply_plan',args)
        self.assertEqual(self.read()['version'],out['version'])
    def test_durable_comments_and_actual_proposals_do_not_duplicate(self):
        args={'project_id':'project-test','task_id':'a','operation_id':core.uid(),'text':'Test comment'}
        self.call('localpm_add_comment',args);self.call('localpm_add_comment',args);self.assertEqual(len(self.read()['comments']),1)
        task=self.call('localpm_get_task',{'project_id':'project-test','task_id':'a'})
        actual={'actual_start':core.today(),'actual_finish':'','percent_complete':20,'remaining_days':2,'status':'В работе'}
        args={'project_id':'project-test','task_id':'a','operation_id':core.uid(),'base_actual':task['base_actual'],'actual':actual}
        out=self.call('localpm_submit_actual',args);self.call('localpm_submit_actual',args)
        self.assertEqual(len(self.read()['updates']),1);self.assertTrue(out['approval_pending']);self.assertEqual(self.read()['project']['tasks'][0]['percent_complete'],0)
        args['operation_id']=core.uid();args['base_actual']['percent_complete']=80;self.assertRaises(ClientError,self.call,'localpm_submit_actual',args)
    def test_stdio_subprocess_exchanges_real_mcp_messages_without_leaking_secrets(self):
        path=Path(self.tmp.name)/'mcp-session.json';save_session(path,{'server_url':self.api.url,'token':self.api.token,'csrf':self.api.csrf})
        messages=[request('initialize',{'protocolVersion':'2025-11-25','clientInfo':{'name':'integration','version':'1'},'capabilities':{}}),
                  {'jsonrpc':'2.0','method':'notifications/initialized'},request('tools/list',id=2),
                  request('tools/call',{'name':'localpm_list_projects','arguments':{}},id=3)]
        proc=subprocess.run([sys.executable,str(ROOT/'mcp_server.py'),'serve','--server-url',self.api.url,'--session-file',str(path)],
                            input='\n'.join(json.dumps(x) for x in messages)+'\n',text=True,capture_output=True,timeout=20,cwd=ROOT)
        self.assertEqual(proc.returncode,0,proc.stderr);self.assertEqual(proc.stderr,'');lines=[json.loads(x) for x in proc.stdout.splitlines()]
        self.assertEqual(len(lines),3);self.assertEqual(lines[-1]['result']['structuredContent']['total'],1)
        self.assertNotIn(self.api.token,proc.stdout+proc.stderr);self.assertNotIn(self.api.csrf,proc.stdout+proc.stderr)
    def test_expired_session_disabled_account_and_redirect_are_rejected(self):
        self.app.sessions[self.api.token]['expires']=0
        with self.assertRaises(ClientError) as ctx:self.call('localpm_list_projects',{})
        self.assertEqual(ctx.exception.status,401)

    def test_plan_dependency_removal_and_custom_fields_keep_calendar_rules(self):
        args=self.patch(changes=[{'task_id':'a','fields':{'note':'Details','custom1':'Value','schedule_calendar':'all_days'}}],links=[{'id':'ab','remove':True}])
        self.call('localpm_apply_plan',args);doc=self.read();self.assertEqual(doc['project']['dependencies'],[])
        self.assertEqual(doc['project']['tasks'][0]['custom1'],'Value');self.assertEqual(doc['project']['tasks'][0]['schedule_calendar'],'all_days')

    def test_work_log_retry_and_scope_revocation_are_enforced(self):
        args={'project_id':'project-test','task_id':'a','operation_id':core.uid(),'hours':2,'date':core.today(),'reason':'MCP test work'}
        self.call('localpm_log_work',args);self.call('localpm_log_work',args)
        self.assertEqual(len(self.read()['project']['tasks'][0]['work_logs']),1)
        user,viewer=self.agent_user('viewer');self.assertEqual(viewer.call('localpm_get_project',{'project_id':'project-test'})['role'],'viewer')
        self.manager.call('DELETE','/api/projects/project-test/members/'+user['id'])
        with self.assertRaises(ClientError) as ctx:viewer.call('localpm_get_project',{'project_id':'project-test'})
        self.assertEqual(ctx.exception.status,403)

    def test_disabled_account_and_backend_plan_field_injection_are_rejected(self):
        user,viewer=self.agent_user('viewer')
        self.manager.call('PATCH','/api/users/'+user['id'],{'active':False})
        with self.assertRaises(ClientError) as ctx:viewer.call('localpm_list_projects',{})
        self.assertEqual(ctx.exception.status,401)
        before=self.read()['version']
        self.manager.call('POST','/api/projects/project-test/task-changes',{'expectedVersion':before,'operationId':core.uid(),'changes':[{'task_id':'a','fields':{'acl':{user['id']:'manager'}}}]},422)
        self.assertEqual(self.read()['version'],before)

    def test_login_config_check_and_logout_helpers_do_not_store_passwords(self):
        p=Path(self.tmp.name)/'helper-session.json';base=[sys.executable,str(ROOT/'mcp_server.py')]
        common=['--server-url',self.api.url,'--session-file',str(p)]
        env=dict(os.environ,LOCALPM_MCP_PASSWORD=self.password)
        login=subprocess.run(base+['login',*common,'--username',self.admin_name],text=True,capture_output=True,env=env,timeout=20,cwd=ROOT)
        self.assertEqual(login.returncode,0,login.stderr);self.assertNotIn(self.password,p.read_text());self.assertNotIn(self.password,login.stdout+login.stderr)
        check=subprocess.run(base+['check',*common],text=True,capture_output=True,timeout=20,cwd=ROOT)
        self.assertEqual(check.returncode,0,check.stderr);self.assertTrue(json.loads(check.stdout)['read_only'])
        config=subprocess.run(base+['config',*common,'--project','project-test'],text=True,capture_output=True,timeout=20,cwd=ROOT)
        value=json.loads(config.stdout);self.assertNotIn('env',value['mcpServers']['localpm']);self.assertIn('--project',value['mcpServers']['localpm']['args'])
        token=load_session(p)['token'];self.assertNotIn(token,config.stdout+check.stdout)
        logout=subprocess.run(base+['logout',*common],text=True,capture_output=True,timeout=20,cwd=ROOT)
        self.assertEqual(logout.returncode,0,logout.stderr);self.assertFalse(p.exists());self.assertNotIn(token,self.app.sessions)

    def test_parallel_plan_patches_cannot_overwrite_each_other(self):
        from concurrent.futures import ThreadPoolExecutor
        first=self.patch();second=self.patch(changes=[{'task_id':'b','fields':{'name':'Concurrent edit'}}])
        def call(args):
            try:return self.call('localpm_apply_plan',args)['version']
            except ClientError as e:return e.status
        with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(call,[first,second]))
        self.assertEqual(sorted(results),[self.doc['version']+1,409]);self.assertEqual(self.read()['version'],self.doc['version']+1)

    def test_modern_stdio_can_preview_apply_and_replay_an_authorized_plan(self):
        path=Path(self.tmp.name)/'mcp-session.json';save_session(path,{'server_url':self.api.url,'token':self.api.token,'csrf':self.api.csrf})
        args=self.patch();preview={k:v for k,v in args.items() if k!='operation_id'}
        messages=[modern('server/discover',id=1),modern('tools/call',{'name':'localpm_preview_plan','arguments':preview},id=2),
                  modern('tools/call',{'name':'localpm_apply_plan','arguments':args},id=3),
                  modern('tools/call',{'name':'localpm_apply_plan','arguments':args},id=4)]
        proc=subprocess.run([sys.executable,str(ROOT/'mcp_server.py'),'serve','--server-url',self.api.url,'--session-file',str(path),'--allow-writes'],
                            input='\n'.join(json.dumps(x) for x in messages)+'\n',text=True,capture_output=True,timeout=20,cwd=ROOT)
        self.assertEqual(proc.returncode,0,proc.stderr);out=[json.loads(x) for x in proc.stdout.splitlines()]
        self.assertTrue(out[1]['result']['structuredContent']['dryRun']);self.assertFalse(out[2]['result']['isError'])
        self.assertTrue(out[3]['result']['structuredContent']['replayed']);self.assertEqual(self.read()['version'],self.doc['version']+1)

    def test_old_agent_api_blocks_new_plan_tools_before_mutation(self):
        with patch.object(self.api,'status',return_value={'agentApiVersion':0}):
            self.assertRaises(ClientError,self.call,'localpm_apply_plan',self.patch())
        self.assertEqual(self.read()['version'],self.doc['version'])
