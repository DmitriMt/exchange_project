"""Private loopback file broker: user-selected JSON, CAS and atomic persistence."""
import concurrent.futures
import hashlib
import http.client
import json
import secrets
import tempfile
import threading
import unittest
from pathlib import Path
from client import ClientServer
from localpm.device_files import DeviceFiles,DeviceError

class FileBrokerTests(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.folder=Path(self.tmp.name);self.files=DeviceFiles();self.path=self.folder/'Задачник.json';self.doc={'format':'localpm','schemaVersion':3,'projects':[]}
    def tearDown(self):self.tmp.cleanup()
    def grant(self,create=False):return self.files.call('grant',{'path':str(self.path),'create':create})
    def test_create_open_and_unicode_path_are_real_device_files(self):
        ref=self.grant(True);self.assertFalse(ref['exists']);text=json.dumps(self.doc,ensure_ascii=False)
        saved=self.files.call('write',{'id':ref['id'],'text':text,'expected':None});self.assertEqual(self.path.read_text(),text)
        self.assertEqual(self.files.call('read',{'id':ref['id']})['fingerprint'],saved['fingerprint']);self.assertEqual(saved['path'],str(self.path.resolve()))
        self.assertFalse(list(self.folder.glob('*.tmp')));self.assertFalse(list(self.folder.glob('*.localpm-lock')))
    def test_foreign_json_and_relative_paths_never_receive_a_grant(self):
        self.path.write_text('{"password":"not-a-workbook"}')
        for b in [{'path':str(self.path)},{'path':'relative.json'},{'path':str(self.folder/'not.txt'),'create':True}]:
            with self.assertRaises(DeviceError):self.files.call('grant',b)
        self.assertEqual(self.files.grants,{})
        with self.assertRaises(DeviceError):self.files.call('read',{'id':'unknown'})
    def test_external_modification_or_held_lock_prevents_overwrite(self):
        self.path.write_text(json.dumps(self.doc));ref=self.grant();self.path.write_text(json.dumps({**self.doc,'label':'external'}));original=self.path.read_bytes()
        with self.assertRaises(DeviceError) as ctx:self.files.call('write',{'id':ref['id'],'text':json.dumps(self.doc),'expected':ref['fingerprint']})
        self.assertEqual(ctx.exception.status,409);self.assertEqual(self.path.read_bytes(),original)
        lock=self.path.with_name(self.path.name+'.localpm-lock');lock.write_text('other process')
        with self.assertRaises(DeviceError):self.files.call('write',{'id':ref['id'],'text':json.dumps(self.doc),'expected':ref['fingerprint']})
        self.assertEqual(lock.read_text(),'other process')
    def test_two_writes_with_the_same_fingerprint_have_one_winner(self):
        self.path.write_text(json.dumps(self.doc));ref=self.grant()
        def save(n):
            try:self.files.call('write',{'id':ref['id'],'text':json.dumps({**self.doc,'label':n}),'expected':ref['fingerprint']});return 200
            except DeviceError as e:return e.status
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:self.assertEqual(sorted(pool.map(save,[1,2])),[200,409])
    def test_invalid_external_file_does_not_leave_a_stale_owned_lock(self):
        self.path.write_text(json.dumps(self.doc));ref=self.grant();self.path.write_text('broken')
        with self.assertRaises(DeviceError):self.files.call('write',{'id':ref['id'],'text':json.dumps(self.doc),'expected':ref['fingerprint']})
        self.assertFalse(list(self.folder.glob('*.localpm-lock')));self.assertEqual(self.path.read_text(),'broken')
    def test_bom_json_is_read_and_compared_without_losing_its_fingerprint(self):
        raw=b'\xef\xbb\xbf'+json.dumps(self.doc).encode();self.path.write_bytes(raw);ref=self.grant()
        self.assertEqual(ref['fingerprint'],hashlib.sha256(raw).hexdigest());self.files.call('write',{'id':ref['id'],'text':json.dumps(self.doc),'expected':ref['fingerprint']})
    def test_browse_lists_folders_and_json_only(self):
        (self.folder/'subfolder').mkdir();self.path.write_text(json.dumps(self.doc));(self.folder/'secret.txt').write_text('hidden')
        result=self.files.call('browse',{'path':str(self.folder)})
        self.assertEqual([e['name'] for e in result['entries']],['subfolder','Задачник.json'])

class FileBrokerHTTPTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.server=ClientServer(('127.0.0.1',0));self.thread=threading.Thread(target=self.server.serve_forever,kwargs={'poll_interval':.01});self.thread.start()
        self.host='127.0.0.1:'+str(self.server.server_port)
    def tearDown(self):self.server.shutdown();self.server.server_close();self.thread.join();self.tmp.cleanup()
    def call(self,method,path,body=None,headers=None):
        c=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=10);data=json.dumps(body or {}) if method=='POST' else None
        h={'Host':self.host,'Origin':'http://'+self.host,'X-LocalPM-Device':self.server.device.token,'Content-Type':'application/json',**(headers or {})};c.request(method,path,data,h);r=c.getresponse();data=r.read();status=r.status;c.close();return status,data
    def test_launcher_exposes_only_own_origin_with_a_private_capability(self):
        status,html=self.call('GET','/');self.assertEqual(status,200);self.assertIn(self.server.device.token.encode(),html)
        for headers in [{'X-LocalPM-Device':''},{'X-LocalPM-Device':'é'},{'Origin':'https://evil.example'},{'Host':'evil.example'}]:
            status,data=self.call('POST','/api/device-files/browse',{'path':self.tmp.name},headers);self.assertEqual(status,403);self.assertNotIn(self.tmp.name.encode(),data)
        self.assertEqual(self.call('GET','/api/device-files/read')[0],404)
        self.assertEqual(self.call('GET','/../../etc/passwd')[0],404)
    def test_http_file_can_be_saved_and_reopened_after_a_fresh_grant(self):
        path=str(Path(self.tmp.name)/'book.json');status,raw=self.call('POST','/api/device-files/grant',{'path':path,'create':True});self.assertEqual(status,200);ref=json.loads(raw)
        doc={'format':'localpm','projects':[]};self.assertEqual(self.call('POST','/api/device-files/write',{'id':ref['id'],'text':json.dumps(doc),'expected':None})[0],200)
        status,raw=self.call('POST','/api/device-files/grant',{'path':path});self.assertEqual(status,200);self.assertEqual(json.loads(json.loads(raw)['text']),doc)
