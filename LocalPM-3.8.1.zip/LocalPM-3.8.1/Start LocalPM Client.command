#!/bin/sh
cd "$(dirname "$0")" || exit 1
python3 client.py --port 9099
