@echo off
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 server.py --client-origin null --client-origin http://127.0.0.1:9099 %*
) else (
  python server.py --client-origin null --client-origin http://127.0.0.1:9099 %*
)
pause
