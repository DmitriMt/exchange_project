#!/bin/sh
cd "$(dirname "$0")" || exit 1
if ! command -v python3 >/dev/null 2>&1; then
  echo "Install Python 3.11 or newer to run LocalPM."
  read -r localpm_close
  exit 1
fi
python3 server.py --client-origin null --client-origin http://127.0.0.1:9099 "$@"
read -r localpm_close
