'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),crypto=require('node:crypto');
const code=fs.readFileSync(require('node:path').join(__dirname,'../src/checksum.js'),'utf8');
function checksum(context){vm.createContext(context);vm.runInContext(code,context);return context.LocalPMChecksum}
const expected=text=>crypto.createHash('sha256').update(text).digest('hex');
const inputs=['','abc','Привет, мир!','Задача 👩‍💻\r\nСтрока\n\u0000','\ud800','\udc00','\ud800X\udc00','a'.repeat(55),'a'.repeat(56),'a'.repeat(63),'a'.repeat(64),'a'.repeat(65),'я'.repeat(10000),'a'.repeat(1000000)];
for(const [mode,context] of [
  ['WebCrypto',{crypto:crypto.webcrypto,TextEncoder}],
  ['plain HTTP without WebCrypto',{TextEncoder}],
  ['without WebCrypto or TextEncoder',{}],
  ['browser policy rejects digest',{TextEncoder,crypto:{subtle:{digest:async()=>{throw Error('disabled')}}}}]
])test('SHA-256 matches independent implementation: '+mode,async()=>{const api=checksum(context);for(const text of inputs)assert.equal(await api.sha256(text),expected(text),'UTF-16 length '+text.length)});
test('fallback handles reproducible arbitrary Unicode and block boundaries',async()=>{const api=checksum({});let seed=12345;for(let length=0;length<260;length++){let text='';for(let i=0;i<length;i++){seed=(Math.imul(seed,1664525)+1013904223)>>>0;text+=String.fromCharCode(seed>>>16)}assert.equal(await api.sha256(text),expected(text))}});
