#!/usr/bin/env python3
"""Loopback standalone launcher with an authenticated local JSON-file chooser/broker."""
import argparse
import hmac
import json
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
from localpm.device_files import DeviceFiles,DeviceError,MAX_FILE
ROOT=Path(__file__).resolve().parent
class ClientServer(ThreadingHTTPServer):
    daemon_threads=True
    def __init__(self,address,files=True):self.device=DeviceFiles() if files else None;super().__init__(address,ClientHandler)
class ClientHandler(BaseHTTPRequestHandler):
    def setup(self):super().setup();self.connection.settimeout(15)
    def respond(self,status,payload,content='application/json; charset=utf-8'):
        raw=payload if isinstance(payload,bytes) else json.dumps(payload,ensure_ascii=False,allow_nan=False).encode()
        self.send_response(status)
        for k,v in {'Content-Type':content,'Content-Length':str(len(raw)),'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Content-Security-Policy':"frame-ancestors 'none'",'Connection':'close'}.items():self.send_header(k,v)
        self.end_headers();self.close_connection=True;self.wfile.write(raw)
    def valid_host(self):return self.headers.get('Host') in ['127.0.0.1:'+str(self.server.server_port),'localhost:'+str(self.server.server_port)]
    def do_GET(self):
        if not self.valid_host():return self.respond(403,{'error':'Адрес не разрешён.'})
        if self.path.split('?',1)[0] not in ['/','/index.html','/client.html']:return self.respond(404,{'error':'Не найдено.'})
        html=(ROOT/'LocalPM-client.html').read_text(encoding='utf-8');device=getattr(self.server,'device',None)
        if device:
            marker='<script>window.LOCALPM_CLIENT=true;';assert marker in html
            html=html.replace(marker,marker+'window.LOCALPM_DEVICE8='+json.dumps({'token':device.token})+';',1)
        return self.respond(200,html.encode('utf-8'),'text/html; charset=utf-8')
    def do_POST(self):
        device=getattr(self.server,'device',None)
        if (not device or not self.valid_host() or self.headers.get('Origin')!='http://'+self.headers.get('Host','') or
            self.headers.get('Sec-Fetch-Site')=='cross-site' or not hmac.compare_digest(self.headers.get('X-LocalPM-Device','').encode('utf-8'),device.token.encode('ascii'))):
            return self.respond(403,{'error':'Доступ к локальным файлам не разрешён.'})
        path=urlsplit(self.path).path
        if path not in ['/api/device-files/browse','/api/device-files/grant','/api/device-files/read','/api/device-files/write'] or self.path!=path:return self.respond(404,{'error':'Не найдено.'})
        try:
            if self.headers.get('Transfer-Encoding') or not self.headers.get('Content-Type','').startswith('application/json'):raise DeviceError(415,'Ожидается JSON.')
            try:length=int(self.headers.get('Content-Length','-1'))
            except ValueError:raise DeviceError(400,'Некорректная длина.')
            if not 0<=length<=MAX_FILE+1024*1024:raise DeviceError(413,'Слишком большой запрос.')
            raw=self.rfile.read(length)
            if len(raw)!=length:raise DeviceError(400,'Неполный запрос.')
            body=json.loads(raw,parse_constant=lambda _:(_ for _ in ()).throw(ValueError()))
            if not isinstance(body,dict):raise DeviceError(422,'Ожидается объект.')
            return self.respond(200,device.call(path.rsplit('/',1)[1],body))
        except DeviceError as e:return self.respond(e.status,{'error':str(e)})
        except (ValueError,UnicodeError,RecursionError):return self.respond(422,{'error':'Некорректный JSON или текст файла.'})
        except OSError:return self.respond(403,{'error':'Файл недоступен. Проверьте путь и разрешения операционной системы.'})
    def log_message(self,*args):pass

def main():
    parser=argparse.ArgumentParser(description='LocalPM local client and JSON files (loopback only)');parser.add_argument('--port',type=int,default=9099);parser.add_argument('--no-device-files',action='store_true',help='Serve HTML only, without local file access');args=parser.parse_args()
    if not 1<=args.port<=65535:parser.error('Invalid port.')
    if not (ROOT/'LocalPM-client.html').is_file():parser.error('Build the client first: python3 build.py')
    with ClientServer(('127.0.0.1',args.port),not args.no_device_files) as server:
        print(f'LocalPM client: http://127.0.0.1:{args.port}',flush=True)
        print('Файлы JSON выбираются в приложении. Общая серверная база не запускается.',flush=True)
        try:server.serve_forever()
        except KeyboardInterrupt:pass
if __name__=='__main__':main()
