@echo off
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 client.py --port 9099
) else (
  python client.py --port 9099
)
pause
