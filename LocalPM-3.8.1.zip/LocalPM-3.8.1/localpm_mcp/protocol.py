"""MCP JSON-RPC over newline-delimited stdio, with legacy and modern lifecycles."""
from __future__ import annotations
import json
import re
from . import __version__
from .client import ClientError
from .tools import GUIDE,InvalidArguments

MODERN='2026-07-28'
LEGACY=('2025-11-25','2025-06-18','2025-03-26')
VERSIONS=(MODERN,*LEGACY)
MAX_MESSAGE=1024*1024
INFO={'name':'localpm','title':'LocalPM projects and tasks','version':__version__}
CAPABILITIES={'tools':{'listChanged':False},'resources':{'subscribe':False,'listChanged':False}}
RESOURCE={'uri':'localpm://guide','name':'localpm_guide','title':'LocalPM agent guide','mimeType':'text/plain'}

class RPCError(Exception):
    def __init__(self,code,message,data=None):super().__init__(message);self.code=code;self.data=data

def error(id,code,message,data=None):
    return {'jsonrpc':'2.0','id':id,'error':{'code':code,'message':message,**({'data':data} if data is not None else {})}}

class Protocol:
    def __init__(self,tools):self.tools=tools;self.version=None;self.initialized=False
    def dispatch(self,message):
        id=message.get('id') if isinstance(message,dict) else None
        try:
            if not isinstance(message,dict) or message.get('jsonrpc')!='2.0' or not isinstance(message.get('method'),str):
                raise RPCError(-32600,'Invalid JSON-RPC request')
            if 'id' not in message:
                if message['method']=='notifications/initialized' and self.version:self.initialized=True
                return None  # A notification can never invoke a tool or mutate data.
            if type(id) not in [int,str] or isinstance(id,str) and len(id)>256:
                id=None
                raise RPCError(-32600,'Request id must be an integer or a string of at most 256 characters')
            params=message.get('params',{})
            if not isinstance(params,dict):raise RPCError(-32602,'params must be an object')
            method=message['method'];meta=params.get('_meta',{})
            if not isinstance(meta,dict):raise RPCError(-32602,'_meta must be an object')
            modern='io.modelcontextprotocol/protocolVersion' in meta or method=='server/discover'
            if modern:
                version=meta.get('io.modelcontextprotocol/protocolVersion')
                if not isinstance(version,str) or not 1<=len(version)<=200:raise RPCError(-32602,'Required per-request protocol metadata is missing or invalid')
                if version!=MODERN:raise RPCError(-32022,'Unsupported protocol version',{'supported':list(VERSIONS),'requested':version})
                if not isinstance(meta.get('io.modelcontextprotocol/clientCapabilities'),dict):raise RPCError(-32602,'Required clientCapabilities metadata is missing')
            elif method=='initialize':
                if self.version:raise RPCError(-32600,'Already initialized')
                if not isinstance(params.get('protocolVersion'),str) or not isinstance(params.get('capabilities'),dict) or not isinstance(params.get('clientInfo'),dict):
                    raise RPCError(-32602,'Invalid initialize parameters')
                if any(not isinstance(params['clientInfo'].get(k),str) or not params['clientInfo'][k] or len(params['clientInfo'][k])>200 for k in ['name','version']):raise RPCError(-32602,'Invalid clientInfo')
                self.version=params['protocolVersion'] if params['protocolVersion'] in LEGACY else LEGACY[0]
                return {'jsonrpc':'2.0','id':id,'result':{'protocolVersion':self.version,'capabilities':CAPABILITIES,'serverInfo':INFO,'instructions':GUIDE}}
            elif method!='ping' and not self.initialized:raise RPCError(-32600,'Initialize and send notifications/initialized first, or use modern per-request metadata')
            result=self.method(method,{k:v for k,v in params.items() if k!='_meta'},modern)
            if modern:
                result={**result,'resultType':'complete','_meta':{'io.modelcontextprotocol/serverInfo':INFO}}
                if method in ['server/discover','tools/list','resources/list','resources/templates/list']:result.update(ttlMs=0,cacheScope='private')
            return {'jsonrpc':'2.0','id':id,'result':result}
        except RPCError as e:return error(id,e.code,str(e),e.data)
        except InvalidArguments as e:return error(id,-32602,str(e))
        except Exception:return error(id,-32603,'Internal MCP error')
    def method(self,method,params,modern):
        if method=='ping':return {}
        if method=='server/discover' and modern:return {'supportedVersions':list(VERSIONS),'capabilities':CAPABILITIES,'instructions':GUIDE}
        if method=='tools/list':
            if set(params)-{'cursor'} or params.get('cursor'):raise InvalidArguments('Invalid tools cursor')
            return {'tools':self.tools.catalog()}
        if method=='tools/call':
            if set(params)-{'name','arguments'} or not isinstance(params.get('name'),str):raise InvalidArguments('Invalid tools/call parameters')
            try:
                data=self.tools.call(params['name'],params.get('arguments',{}))
                serialized=json.dumps(data,ensure_ascii=False,allow_nan=False,separators=(',',':'))
                if len(serialized.encode('utf-8'))>MAX_MESSAGE//2:raise ClientError('Результат слишком большой. Используйте меньшую страницу или более узкий фильтр.')
                return {'content':[{'type':'text','text':serialized}],'structuredContent':data,'isError':False}
            except ClientError as e:
                data={'error':str(e),'http_status':e.status,**({'current_version':e.current_version} if e.current_version is not None else {})}
                return {'content':[{'type':'text','text':json.dumps(data,ensure_ascii=False)}],'structuredContent':data,'isError':True}
        if method in ['resources/list','resources/templates/list']:
            if set(params)-{'cursor'} or params.get('cursor'):raise InvalidArguments('Invalid resource cursor')
            if method=='resources/list':return {'resources':[RESOURCE]}
            return {'resourceTemplates':[{'uriTemplate':'localpm://projects/{project_id}','name':'localpm_project','mimeType':'application/json'},
                                         {'uriTemplate':'localpm://projects/{project_id}/tasks/{task_id}','name':'localpm_task','mimeType':'application/json'}]}
        if method=='resources/read':
            if set(params)!={'uri'} or not isinstance(params['uri'],str):raise InvalidArguments('uri is required')
            uri=params['uri']
            if uri==RESOURCE['uri']:return {'contents':[{**RESOURCE,'text':GUIDE}]}
            match=re.fullmatch(r'localpm://projects/([A-Za-z0-9][A-Za-z0-9_.:-]{0,127})(?:/tasks/([A-Za-z0-9][A-Za-z0-9_.:-]{0,127}))?',uri)
            if not match:raise InvalidArguments('Unknown LocalPM resource URI')
            try:
                args={'project_id':match[1]}
                if match[2]:args['task_id']=match[2]
                data=self.tools.call('localpm_get_task' if match[2] else 'localpm_get_project',args)
                return {'contents':[{'uri':uri,'mimeType':'application/json','text':json.dumps(data,ensure_ascii=False,allow_nan=False)}]}
            except ClientError as e:raise RPCError(-32602,str(e),{'http_status':e.status}) from None
        raise RPCError(-32601,'Method not found')

def run(protocol,input_stream,output_stream):
    while True:
        raw=input_stream.readline(MAX_MESSAGE+1)
        if not raw:return 0
        if len(raw)>MAX_MESSAGE:
            output_stream.write(json.dumps(error(None,-32600,'MCP message exceeds 1 MiB'))+'\n');output_stream.flush();return 1
        if not raw.strip():continue
        try:
            value=json.loads(raw,parse_constant=lambda _:(_ for _ in ()).throw(ValueError()))
            result=protocol.dispatch(value)
        except (ValueError,UnicodeError,RecursionError):result=error(None,-32700,'Parse error')
        if result is not None:
            serialized=json.dumps(result,ensure_ascii=False,allow_nan=False,separators=(',',':'))
            if len(serialized.encode('utf-8'))>MAX_MESSAGE:
                serialized=json.dumps(error(result.get('id'),-32603,'Result too large; use task pagination or a narrower query'))
            output_stream.write(serialized+'\n');output_stream.flush()
