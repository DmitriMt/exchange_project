"""LocalPM MCP stdio adapter; standard library only."""
__version__='1.0.0'
