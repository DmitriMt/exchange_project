#!/usr/bin/env python3
"""LocalPM MCP adapter entry point. Use login once, then configure a stdio client."""
from __future__ import annotations
import argparse
import getpass
import json
import os
import sys
from pathlib import Path
from localpm_mcp.client import APIClient,ClientError,load_session,save_session
from localpm_mcp.protocol import Protocol,run
from localpm_mcp.tools import ID,InvalidArguments,Tools,validate

DEFAULT_SESSION=str(Path.home()/'.localpm'/'mcp-session.json')
def parser():
    root=argparse.ArgumentParser(description='LocalPM MCP adapter (stdio, Python 3.11+, no external packages)')
    subs=root.add_subparsers(dest='mode',required=True)
    for name in ['login','serve','check','config','logout']:
        sub=subs.add_parser(name);sub.add_argument('--server-url',required=True,help='LocalPM server origin, for example https://localpm.company.internal')
        sub.add_argument('--session-file',default=DEFAULT_SESSION,help='Private session file; passwords are never stored')
        sub.add_argument('--ca-file',help='Optional corporate CA PEM file; certificate verification remains enabled')
        sub.add_argument('--allow-http',action='store_true',help='Explicitly allow LAN HTTP for development')
        sub.add_argument('--timeout',type=int,default=15,help='API timeout in seconds, 1–60')
        if name=='login':sub.add_argument('--username',help='Ask interactively when omitted')
        if name in ['serve','check','config']:
            sub.add_argument('--allow-writes',action='store_true',help='Expose write tools; server roles still apply')
            sub.add_argument('--project',action='append',default=[],help='Restrict MCP to this project ID; repeat for several')
    return root

def main(argv=None):
    args=parser().parse_args(argv)
    if sys.version_info<(3,11):raise SystemExit('Нужен Python 3.11 или новее.')
    try:
        if not 1<=args.timeout<=60:raise ClientError('Тайм-аут должен быть от 1 до 60 секунд.')
        for id in getattr(args,'project',[]):validate(id,ID)
        session_path=str(Path(args.session_file).expanduser().resolve())
        # Validate the original path too: resolve must never silently permit a secret symlink.
        if Path(args.session_file).expanduser().is_symlink():raise ClientError('Символическая ссылка на файл сессии не разрешена.')
        if args.mode=='config':
            from localpm_mcp.client import server_url
            url=server_url(args.server_url,args.allow_http)
            command=[str(Path(__file__).resolve()),'serve','--server-url',url,'--session-file',session_path]
            if args.allow_http:command.append('--allow-http')
            if args.ca_file:command.extend(['--ca-file',str(Path(args.ca_file).expanduser().resolve())])
            if args.allow_writes:command.append('--allow-writes')
            for id in args.project:command.extend(['--project',id])
            command.extend(['--timeout',str(args.timeout)])
            print(json.dumps({'mcpServers':{'localpm':{'command':sys.executable,'args':command}}},ensure_ascii=False,indent=2));return 0
        session=None if args.mode=='login' else load_session(session_path)
        api=APIClient(args.server_url,session,args.allow_http,args.ca_file,args.timeout)
        if args.mode=='login':
            username=args.username or input('Логин LocalPM: ').strip()
            password=os.environ.get('LOCALPM_MCP_PASSWORD') or getpass.getpass('Пароль LocalPM: ')
            try:value=api.login(username,password)
            finally:password=''
            try:save_session(session_path,value)
            except Exception:
                try:api.request('POST','/api/logout',{})
                except ClientError:pass
                raise
            print('Сессия сохранена: '+session_path+'\nПароль не сохранён. Проверьте доступ командой check.');return 0
        if args.mode=='logout':
            api.request('POST','/api/logout',{});Path(session_path).unlink();print('Сессия отозвана и локальный файл удалён.');return 0
        tools=Tools(api,args.allow_writes,args.project)
        if args.mode=='check':
            result=tools.call('localpm_connection_info',{})
            if args.allow_writes:tools.agent_api()
            print(json.dumps(result,ensure_ascii=False,indent=2));return 0
        sys.stdin.reconfigure(encoding='utf-8');sys.stdout.reconfigure(encoding='utf-8')
        return run(Protocol(tools),sys.stdin.buffer,sys.stdout)
    except (ClientError,InvalidArguments) as e:
        print('LocalPM MCP: '+str(e),file=sys.stderr);return 1
    except (OSError,ValueError):
        print('LocalPM MCP: файл или конфигурация недоступны. Проверьте пути и права доступа.',file=sys.stderr);return 1
    except (KeyboardInterrupt,BrokenPipeError):return 0

if __name__=='__main__':raise SystemExit(main())
