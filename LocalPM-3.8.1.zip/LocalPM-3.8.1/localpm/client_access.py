"""Explicit cross-origin access for standalone clients; no ambient cookie credentials."""
from urllib.parse import urlsplit
MARKER='desktop-v1'
HEADERS={'content-type','authorization','x-localpm-csrf','x-localpm-client'}
METHODS={'GET','HEAD','POST','PUT','PATCH','DELETE'}
def origin_value(value):
    if value=='null': return value
    if not isinstance(value,str): raise ValueError('Некорректный адрес клиента.')
    u=urlsplit(value)
    if u.scheme not in ['http','https'] or not u.hostname or u.username or u.password or u.query or u.fragment or u.path not in ['', '/']: raise ValueError('Укажите origin клиента: http(s)://адрес:порт либо null для HTML-файла.')
    port=u.port
    host=u.hostname.lower()
    host='['+host+']' if ':' in host else host.encode('idna').decode('ascii')
    suffix=':'+str(port) if port is not None and port!=({'http':80,'https':443}[u.scheme]) else ''
    return u.scheme+'://'+host+suffix
def is_client(headers): return headers.get('X-LocalPM-Client')==MARKER
