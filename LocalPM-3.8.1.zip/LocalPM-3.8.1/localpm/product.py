"""Product rules enforced at the API boundary, independent of browser validation."""
from __future__ import annotations
from . import core,kanban

def fields(project):
    definitions=project.get('field_definitions',[])
    if not isinstance(definitions,list) or len(definitions)>30: raise ValueError('Не более 30 пользовательских полей.')
    ids=set()
    for f in definitions:
        if not isinstance(f,dict): raise ValueError('Некорректное поле.')
        id=core.valid_id(f.get('id'))
        if id in ids or f.get('type') not in ['text','select','number','date','user','url','boolean'] or not isinstance(f.get('name'),str) or not 1<=len(f['name'].strip())<=100: raise ValueError('Проверьте пользовательское поле.')
        ids.add(id)
        for key,allowed in [('task_types',['task','bug','request','milestone']),('required_kinds',kanban.KINDS)]:
            if key in f and (not isinstance(f[key],list) or any(x not in allowed for x in f[key])): raise ValueError('Некорректное условие обязательности поля.')
        if f['type']=='select':
            options=f.get('options')
            if not isinstance(options,list) or not 1<=len(options)<=100 or any(not isinstance(x,str) or not x.strip() or len(x)>200 for x in options) or len(set(options))!=len(options): raise ValueError('Проверьте варианты списка.')
    return definitions

def field_values(project,task,required=False,kind='work'):
    values=task.get('field_values',{})
    if not isinstance(values,dict): raise ValueError('Некорректные значения полей.')
    for f in fields(project):
        value=values.get(f['id'])
        if value is None or value=='':
            if required and f.get('required') and (not f.get('task_types') or task.get('task_type','task') in f['task_types']) and (not f.get('required_kinds') or kind in f['required_kinds']): raise ValueError('Заполните поле «'+f['name']+'».')
            continue
        type=f['type']
        if type=='number': core.number(value,f['name'],-1e12,1e12)
        elif type=='boolean' and not isinstance(value,bool): raise ValueError('Ожидается флажок.')
        elif type=='date' and not core.date(value): raise ValueError('Некорректная дата поля.')
        elif type=='user': core.valid_id(value)
        elif type=='select' and value not in f['options']: raise ValueError('Нет такого значения в списке.')
        elif type=='url':
            from urllib.parse import urlsplit
            if not isinstance(value,str) or len(value)>2000 or urlsplit(value).scheme not in ['http','https'] or not urlsplit(value).hostname: raise ValueError('Укажите HTTP/HTTPS-ссылку.')
        elif type=='text' and (not isinstance(value,str) or len(value)>4000): raise ValueError('Некорректный текст поля.')

def config(project,global_config=None): return kanban.validate(project.get('workflow',{}).get('columns') or global_config or kanban.defaults())

def column(task,cfg):
    columns=cfg['columns'];id=task.get('kanban_column_id');id=cfg.get('redirects',{}).get(id,id);complete=bool(task.get('actual_finish')) or task.get('percent_complete',0)>=100
    found=next((c for c in columns if c['id']==id and (not complete or c['kind']=='done')),None)
    if found:return found
    status=str(task.get('status') or '').strip().lower().replace('ё','е')
    found=next((c for c in columns if c['name'].strip().lower().replace('ё','е')==status and (not complete or c['kind']=='done')),None)
    if found:return found
    aliases={'todo':0,'to do':0,'open':0,'backlog':0,'не начато':0,'новая':0,'in progress':1,'в работе':1,'blocked':2,'заблокировано':2,'на паузе':2,'приостановлено':2,'review':3,'in review':3,'на приемке':3,'done':4,'closed':4,'завершено':4,'выполнено':4}
    kind=kanban.KINDS[4 if complete else aliases.get(status,1 if task.get('percent_complete',0)>0 or task.get('actual_start') else 0)];redirect=cfg.get('redirects',{}).get(kind)
    found=next((c for c in columns if c['id']==redirect and (not complete or c['kind']=='done')),None)
    return found or next((c for c in columns if c['kind']==kind),next((c for c in columns if c['kind']!='done'),columns[0]))

def validate(project,global_config=None):
    fields(project); workflow=project.get('workflow',{})
    if not isinstance(workflow,dict) or workflow.get('approval','all') not in ['all','contributors','none']: raise ValueError('Некорректный процесс проекта.')
    cfg=config(project,global_config); ids={c['id'] for c in cfg['columns']}; transitions=workflow.get('transitions',[])
    if not isinstance(transitions,list) or len(transitions)>400: raise ValueError('Некорректные переходы.')
    for rule in transitions:
        if not isinstance(rule,dict) or rule.get('from') not in ids or rule.get('to') not in ids or not isinstance(rule.get('required',[]),list): raise ValueError('Некорректный переход.')
        if any(k not in ['owner','blocker','actual_start','actual_finish','comment']+[f['id'] for f in fields(project)] for k in rule.get('required',[])): raise ValueError('Неизвестное обязательное поле перехода.')
    if project.get('shared_views'):
        if not isinstance(project['shared_views'],list) or len(project['shared_views'])>100: raise ValueError('Не более 100 представлений.')
        for view in project['shared_views']:
            core.valid_id(view.get('id'))
            if not isinstance(view.get('name'),str) or len(view['name'])>100: raise ValueError('Некорректное представление.')
    wip=workflow.get('wip',{})
    if not isinstance(wip,dict) or len(wip)>20: raise ValueError('Некорректные лимиты работы.')
    for id,rule in wip.items():
        if id not in ids or not isinstance(rule,dict) or rule.get('mode') not in ['warn','block'] or type(rule.get('limit')) is not int or not 0<=rule['limit']<=5000: raise ValueError('Проверьте лимит колонки.')
    for task in project.get('tasks',[]):
        if task.get('task_type') and task['task_type'] not in ['task','bug','request','milestone']: raise ValueError('Неизвестный тип задачи.')
        field_values(project,task)
        for key,max in [('priority',4),('spent_hours',1e7)]:
            if key in task: core.number(task[key],key,0,max)
        if not isinstance(task.get('watchers',[]),list) or len(task.get('watchers',[]))>200: raise ValueError('Некорректные наблюдатели.')
        for user in task.get('watchers',[]): core.valid_id(user)
        if not isinstance(task.get('tags',[]),list) or len(task.get('tags',[]))>30 or any(not isinstance(t,str) or len(t)>80 for t in task.get('tags',[])): raise ValueError('Некорректные метки.')
    recurrences=project.get('recurrences',[])
    if not isinstance(recurrences,list) or len(recurrences)>100: raise ValueError('Не более 100 правил повторения.')
    for r in recurrences:
        core.valid_id(r.get('id'))
        if r.get('unit') not in ['day','week','month'] or type(r.get('interval')) is not int or not 1<=r['interval']<=365 or not core.date(r.get('start')) or r.get('until') and not core.date(r['until']) or not isinstance(r.get('template'),dict) or not isinstance(r['template'].get('tasks'),list) or not r['template']['tasks'] or type(r.get('cursor',0)) is not int or not 0<=r.get('cursor',0)<=20000: raise ValueError('Некорректное правило повторения.')
    return project

def check_transition(project,task,actual,comment='',global_config=None):
    cfg=config(project,global_config); before=column(task,cfg); target=actual.get('kanban_column_id')
    if target:
        after=next((c for c in cfg['columns'] if c['id']==target),None)
        if not after: raise ValueError('Колонка больше не существует.')
    else: after=column({**task,**actual,'kanban_column_id':None},cfg)
    if (after['kind']=='done')!=(bool(actual.get('actual_finish')) or actual.get('percent_complete')==100): raise ValueError('Для завершения нужны даты, 100% и нулевой остаток.')
    rules=project.get('workflow',{}).get('transitions',[]); rule=next((r for r in rules if r['from']==before['id'] and r['to']==after['id']),None)
    if before['id']!=after['id'] and rules and rule is None: raise ValueError('Такой переход запрещён процессом проекта.')
    merged={**task,**actual,'comment':comment}
    for key in (rule or {}).get('required',[]):
        if not merged.get(key,merged.get('field_values',{}).get(key)): raise ValueError('Для перехода необходимо поле: '+key)
    field_values(project,merged,required=after['kind']!='todo',kind=after['kind'])
    limit=project.get('workflow',{}).get('wip',{}).get(after['id'],{})
    if before['id']!=after['id'] and limit.get('mode')=='block' and limit.get('limit'):
        parents={t.get('parent_id') for t in project['tasks']}; count=sum(1 for t in project['tasks'] if t['id'] not in parents and column(t,cfg)['id']==after['id'])
        if count>=limit['limit']: raise ValueError('Достигнут лимит задач в колонке.')
    return after

def needs_approval(project,role):
    policy=project.get('workflow',{}).get('approval','all')
    return policy=='all' or policy=='contributors' and role=='contributor'

def availability(value):
    if not isinstance(value,dict) or len(value)>1000: raise ValueError('Некорректные календари.')
    for key,c in value.items():
        if not isinstance(key,str) or len(key)>200 or not isinstance(c,dict) or not isinstance(c.get('hours'),list) or len(c['hours'])!=7 or not isinstance(c.get('absences',[]),list) or len(c.get('absences',[]))>200: raise ValueError('Проверьте календарь сотрудника.')
        for h in c['hours']: core.number(h,'Часов в дне',0,24)
        for a in c.get('absences',[]):
            if not core.date(a.get('from')) or not core.date(a.get('to')) or a['to']<a['from']: raise ValueError('Проверьте период отсутствия.')
    return value
