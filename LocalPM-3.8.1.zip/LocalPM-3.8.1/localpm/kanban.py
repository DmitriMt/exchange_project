"""Administrator-managed workspace board configuration."""
from . import core
KINDS=['todo','work','blocked','review','done']
NAMES=['Не начато','В работе','Заблокировано','На приёмке','Завершено']
def defaults(): return {'columns':[{'id':kind,'name':name,'kind':kind} for kind,name in zip(KINDS,NAMES)],'redirects':{}}
def validate(value):
    if not isinstance(value,dict) or not isinstance(value.get('columns'),list) or not 2<=len(value['columns'])<=20: raise ValueError('На доске должно быть от 2 до 20 колонок.')
    ids=set(); names=set(); columns=[]
    for c in value['columns']:
        if not isinstance(c,dict): raise ValueError('Некорректная колонка.')
        id=core.valid_id(c.get('id')); name=c.get('name'); kind=c.get('kind')
        if not isinstance(name,str) or not 1<=len(name.strip())<=80 or name.strip().lower().replace('ё','е') in names or id in ids: raise ValueError('Названия и ID колонок должны быть уникальны.')
        if kind not in KINDS: raise ValueError('Некорректный тип колонки.')
        ids.add(id); names.add(name.strip().lower().replace('ё','е')); columns.append({'id':id,'name':name.strip(),'kind':kind})
    if not any(c['kind']=='done' for c in columns) or not any(c['kind']!='done' for c in columns): raise ValueError('Нужны рабочая колонка и колонка завершения.')
    redirects=value.get('redirects',{})
    if not isinstance(redirects,dict) or len(redirects)>500: raise ValueError('Некорректные перенаправления колонок.')
    for id,target in redirects.items():
        core.valid_id(id)
        if id in ids or not isinstance(target,str) or target not in ids: raise ValueError('Некорректное перенаправление удалённой колонки.')
    return {'columns':columns,'redirects':core.clone(redirects)}
