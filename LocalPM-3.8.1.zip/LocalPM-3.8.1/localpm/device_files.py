"""Loopback-only JSON file broker for the standalone client, never mounted on the team server."""
from __future__ import annotations
import hashlib
import json
import os
import secrets
import threading
from pathlib import Path

MAX_FILE=64*1024*1024
class DeviceError(Exception):
    def __init__(self,status,message):super().__init__(message);self.status=status

def check_document(raw):
    try:value=json.loads(raw.lstrip('\ufeff') if isinstance(raw,str) else raw,parse_constant=lambda _:(_ for _ in ()).throw(ValueError()))
    except (ValueError,UnicodeError,RecursionError):raise DeviceError(422,'Файл не содержит корректный JSON.') from None
    if not isinstance(value,dict) or value.get('format')!='localpm' or not isinstance(value.get('projects'),list) or len(value['projects'])>200:
        raise DeviceError(422,'Это не JSON-файл задачника LocalPM.')
    return value

def digest(raw):return hashlib.sha256(raw).hexdigest()
class DeviceFiles:
    def __init__(self):self.token=secrets.token_hex(32);self.grants={};self.lock=threading.RLock()
    def file_path(self,value):
        if not isinstance(value,str) or not value.strip() or len(value)>4096 or '\0' in value:raise DeviceError(422,'Укажите полный путь к JSON-файлу.')
        path=Path(value).expanduser()
        if not path.is_absolute():raise DeviceError(422,'Нужен полный путь к файлу.')
        path=path.resolve()
        if path.suffix.lower()!='.json':raise DeviceError(422,'Задачник сохраняется в файл .json.')
        if not path.parent.is_dir():raise DeviceError(422,'Выбранная папка не существует.')
        return path
    def path_for(self,id):
        if not isinstance(id,str) or id not in self.grants:raise DeviceError(404,'Файл не подключён в этом запуске.')
        return self.grants[id]
    def read(self,path):
        if not path.exists():return {'text':None,'fingerprint':None,'exists':False,'path':str(path),'name':path.name}
        if not path.is_file() or path.stat().st_size>MAX_FILE:raise DeviceError(413,'Файл недоступен или превышает 64 МиБ.')
        if path.resolve()!=path or path.is_symlink():raise DeviceError(409,'Путь файла изменился. Откройте его заново.')
        raw=path.read_bytes()
        if len(raw)>MAX_FILE:raise DeviceError(413,'Файл превышает 64 МиБ.')
        text=raw.decode('utf-8');check_document(text)
        return {'text':text,'fingerprint':digest(raw),'exists':True,'path':str(path),'name':path.name}
    def call(self,action,body):
        with self.lock:
            if action=='browse':
                value=body.get('path') or str(Path.home());path=Path(value).expanduser()
                if not path.is_absolute() or not path.is_dir():raise DeviceError(422,'Папка не найдена.')
                path=path.resolve();entries=[]
                for entry in path.iterdir():
                    if entry.name.startswith('.'):continue
                    try:
                        if entry.is_dir() or entry.is_file() and entry.suffix.lower()=='.json':entries.append({'name':entry.name,'directory':entry.is_dir(),'path':str(entry)})
                    except OSError:continue
                entries.sort(key=lambda e:(not e['directory'],e['name'].casefold()))
                return {'path':str(path),'parent':str(path.parent),'entries':entries[:500],'truncated':len(entries)>500}
            if action=='grant':
                path=self.file_path(body.get('path'));create=body.get('create',False)
                if type(create) is not bool:raise DeviceError(422,'Некорректный режим открытия.')
                if not create and not path.is_file():raise DeviceError(404,'JSON-файл не найден.')
                info=self.read(path)
                if len(self.grants)>=128 and path not in self.grants.values():raise DeviceError(422,'Лимит подключённых файлов: 128.')
                id=next((k for k,v in self.grants.items() if v==path),None) or secrets.token_hex(24);self.grants[id]=path
                return {'id':id,**info}
            path=self.path_for(body.get('id'))
            if action=='read':return self.read(path)
            if action!='write':raise DeviceError(404,'Действие не найдено.')
            text=body.get('text');expected=body.get('expected')
            if not isinstance(text,str) or len(text.encode('utf-8'))>MAX_FILE:raise DeviceError(413,'Пакет превышает 64 МиБ.')
            check_document(text)
            if expected is not None and (not isinstance(expected,str) or len(expected)!=64):raise DeviceError(422,'Некорректная контрольная сумма.')
            lock=path.with_name(path.name+'.localpm-lock');temp=path.with_name(path.name+'.'+secrets.token_hex(12)+'.tmp');fd=None;acquired=False
            try:
                try:fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
                except FileExistsError:raise DeviceError(409,'Файл занят другим процессом. Запись не выполнена.') from None
                os.close(fd);fd=None;acquired=True
                current=self.read(path)
                if current['fingerprint']!=expected:raise DeviceError(409,'Файл изменён другим окном или программой. Сравните версии или сохраните отдельную копию.')
                raw=text.encode('utf-8');fd=os.open(temp,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
                with os.fdopen(fd,'wb') as stream:fd=None;stream.write(raw);stream.flush();os.fsync(stream.fileno())
                os.replace(temp,path)
                return {'fingerprint':digest(raw),'path':str(path),'name':path.name,'bytes':len(raw)}
            finally:
                if fd is not None:os.close(fd)
                if temp.exists():temp.unlink()
                # A lock belonging to another process must never be removed.
                if acquired and lock.exists():lock.unlink()
