"""LocalPM Python backend."""
__version__ = '3.8.0-dev'
