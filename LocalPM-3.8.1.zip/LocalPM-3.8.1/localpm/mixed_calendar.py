"""Task-specific all-day calendars; calendar dates form the shared dependency axis."""
import datetime as dt
import math
from bisect import bisect_left,bisect_right
from . import core

def calculate_mixed(p,layout):
    by,children,flat,leaves,inc,out,order=layout
    pc=core.calendar(p);ordinal=lambda s:dt.date.fromisoformat(s).toordinal();iso=lambda n:dt.date.fromordinal(n).isoformat()
    calendars={t['id']:core.task_calendar(p,t) for t in leaves}
    def allowed(day,cal): return ordinal(cal.ensure(iso(day)))
    def floor_index(cal,day):
        value=bisect_right(cal.days,iso(day))-1
        if value<0: core.fail('Обратный расчёт выходит за диапазон календаря 2000–2100.')
        return value
    def finish(start,duration,cal): return ordinal(cal.from_index(cal.serial(iso(start))+max(duration-1,0)))
    def start_for_end(end,duration,cal): return ordinal(cal.from_index(floor_index(cal,end)-max(duration-1,0)))
    def boundary(anchor,link):
        base=anchor+(1 if link['type']=='FS' else 0)
        if not link['lag_workdays']: return base
        at=bisect_left(pc.days,iso(base))+math.ceil(link['lag_workdays'])
        return ordinal(core.MIN)-1 if at<0 else ordinal(core.MAX)+1 if at>=len(pc.days) else ordinal(pc.from_index(at))
    def required(source,link,duration,cal):
        bound=boundary(source['EF'] if link['type'][0]=='F' else source['ES'],link)
        return allowed(bound,cal) if link['type'][1]=='S' else start_for_end(allowed(bound,cal),duration,cal)
    def latest(source,link,endpoint,cap,cal):
        lo,hi,best=0,floor_index(cal,cap),-1
        while lo<=hi:
            mid=(lo+hi)//2;start=ordinal(cal.from_index(mid));anchor=finish(start,source['dur'],cal) if link['type'][0]=='F' else start
            if boundary(anchor,link)<=endpoint: best=mid;lo=mid+1
            else: hi=mid-1
        if best<0: core.fail('Обратный расчёт выходит за диапазон календаря 2000–2100.')
        return ordinal(cal.from_index(best))
    base=ordinal(p['start_date']);calc={}
    for t in leaves:
        cal=calendars[t['id']];start=allowed(ordinal(t['start_date']) if t['is_manual'] else max(base,ordinal(t['constraint_snet']) if t.get('constraint_snet') else base),cal)
        duration=0 if t['is_milestone'] else t['duration_days'] or 1;end=allowed(ordinal(t['finish_date']),cal) if t['is_manual'] else finish(start,duration,cal)
        if end<start: core.fail('Окончание раньше начала.')
        if t['is_manual'] and not t['is_milestone']: duration=cal.serial(iso(end))-cal.serial(iso(start))+1
        calc[t['id']]={'ES':start,'EF':end,'dur':duration,'manual':t['is_manual'],'reason':'Ограничение начала' if t.get('constraint_snet') else 'Начало проекта'}
    for id in order:
        t,c,cal=by[id],calc[id],calendars[id]
        for link in inc[id]:
            candidate=required(calc[link['pred_id']],link,c['dur'],cal)
            if candidate>c['ES']:
                if c['manual']: p['scheduleWarnings'].append('«'+t['name']+'»: ручная дата нарушает связь от «'+by[link['pred_id']]['name']+'», начало не ранее '+iso(candidate)+'.')
                else: c['ES']=candidate;c['reason']='Связь '+link['type']+' от «'+by[link['pred_id']]['name']+'»'
        if not c['manual']: c['EF']=finish(c['ES'],c['dur'],cal)
    end=max([base]+[c['EF'] for c in calc.values()])
    for id in reversed(order):
        c,cal=calc[id],calendars[id];c['LS']=c['ES'] if c['manual'] else start_for_end(end,c['dur'],cal)
        if not c['manual']:
            for link in out[id]:
                sc,tc=calc[link['succ_id']],calendars[link['succ_id']];endpoint=sc['LS'] if link['type'][1]=='S' else finish(sc['LS'],sc['dur'],tc)
                c['LS']=min(c['LS'],latest(c,link,endpoint,c['LS'],cal))
    forecasts={};asof=ordinal(p['status_date'])
    for id in order:
        t,c,cal=by[id],calc[id],calendars[id]
        start=allowed(ordinal(t['actual_start']),cal) if t.get('actual_start') else c['ES'] if t['is_manual'] else allowed(max(base,asof,ordinal(t['constraint_snet']) if t.get('constraint_snet') else base),cal)
        remaining=t.get('remaining_days');remaining=remaining if remaining is not None else max(0 if t['is_milestone'] else 1,math.ceil(c['dur']*(1-t['percent_complete']/100)))
        if t.get('actual_finish'): start=allowed(ordinal(t['actual_start']),cal);end_forecast=allowed(ordinal(t['actual_finish']),cal)
        elif t.get('actual_start'): end_forecast=finish(allowed(max(start,asof),cal),remaining,cal)
        else:
            for link in inc[id]: start=max(start,required(forecasts[link['pred_id']],link,0 if t['is_milestone'] else remaining,cal))
            end_forecast=finish(start,remaining,cal)
        forecasts[id]={'ES':start,'EF':end_forecast}
        free=floor_index(cal,end)-cal.serial(iso(c['EF']))
        if out[id]:
            values=[]
            for link in out[id]:
                sc=calc[link['succ_id']];endpoint=sc['ES'] if link['type'][1]=='S' else sc['EF']
                values.append(cal.serial(iso(latest(c,link,endpoint,start_for_end(end,c['dur'],cal),cal)))-cal.serial(iso(c['ES'])))
            free=min(values)
        t.update(start_date=iso(c['ES']),finish_date=iso(c['EF']),duration_days=c['dur'],total_float=cal.serial(iso(c['LS']))-cal.serial(iso(c['ES'])),free_float=free,critical=cal.serial(iso(c['LS']))-cal.serial(iso(c['ES']))<=0,schedule_reason=c['reason'],forecast_start=iso(start),forecast_finish=iso(end_forecast))
        if t.get('deadline') and t['forecast_finish']>t['deadline']: p['scheduleWarnings'].append('«'+t['name']+'»: прогноз позже целевого срока '+t['deadline']+'.')
    for row in reversed(flat):
        t=by[row['id']];ch=children[t['id']]
        if not ch: continue
        manual=(t['start_date'],t['finish_date']) if t['is_manual'] else None
        t.update(start_date=min(c['start_date'] for c in ch),finish_date=max(c['finish_date'] for c in ch),forecast_start=min(c.get('forecast_start',c['start_date']) for c in ch),forecast_finish=max(c.get('forecast_finish',c['finish_date']) for c in ch),percent_complete=core.progress(ch),critical=any(c['critical'] for c in ch),is_milestone=False)
        t['duration_days']=pc.serial(t['finish_date'])-pc.serial(t['start_date'])+1
        if manual:
            t['start_date'],t['finish_date']=manual;t['duration_days']=pc.serial(t['finish_date'])-pc.serial(t['start_date'])+1;end=max(end,ordinal(t['finish_date']))
            if any(c['start_date']<t['start_date'] or c['finish_date']>t['finish_date'] for c in ch): p['scheduleWarnings'].append('Работы выходят за ручные даты этапа «'+t['name']+'».')
    p.update(finish_date=iso(end),forecast_finish=max((t['forecast_finish'] for t in leaves),default=p['start_date']),percent_complete=core.progress(leaves));return p
