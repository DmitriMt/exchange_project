"""Explicitly configured integration delivery and verified scheduled backups."""
from __future__ import annotations
import datetime as dt
import hashlib
import hmac
import json
import smtplib
import ssl
import tempfile
import threading
import time
import urllib.error
import urllib.request
from email.message import EmailMessage
from pathlib import Path
from . import core,product
from .storage import Repository,atomic_write,json_text

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs): return None

def integration_config(path):
    if not path: return {'enabled':False,'webhooks':[],'mail':{}}
    value=json.loads(Path(path).read_text(encoding='utf-8'))
    if not isinstance(value,dict): raise ValueError('Некорректная конфигурация интеграций.')
    if not value.get('enabled'): return {'enabled':False,'webhooks':[],'mail':{}}
    from urllib.parse import urlsplit
    for webhook in value.get('webhooks',[]):
        url=urlsplit(webhook.get('url',''))
        if url.scheme not in (['https','http'] if webhook.get('allow_http') is True else ['https']) or not url.hostname or url.username or url.password or url.fragment or len(webhook.get('secret',''))<20: raise ValueError('Webhook требует HTTPS и секрет длиной от 20 символов; HTTP включается отдельно.')
    mail=value.get('mail',{})
    if mail.get('enabled'):
        if not mail.get('host') or mail.get('tls','starttls') not in ['ssl','starttls','none'] or any('\r' in str(x) or '\n' in str(x) for x in [mail.get('from',''),*mail.get('recipients',[])]): raise ValueError('Некорректные настройки почты.')
    return value

def deliver_webhook(config,event):
    body=json_text(event,sort_keys=True).encode('utf-8'); signature=hmac.new(config['secret'].encode(),body,hashlib.sha256).hexdigest()
    request=urllib.request.Request(config['url'],data=body,headers={'Content-Type':'application/json','X-LocalPM-Event-ID':event['id'],'X-LocalPM-Signature':'sha256='+signature},method='POST')
    with urllib.request.build_opener(NoRedirect()).open(request,timeout=5) as response:
        if not 200<=response.status<300: raise OSError('Webhook не подтвердил доставку.')

def deliver_mail(config,event):
    if not config.get('enabled') or not config.get('recipients'): return
    message=EmailMessage();message['From']=config['from'];message['To']=', '.join(config['recipients']);message['Subject']='LocalPM: '+event['project']['name'];message['Message-ID']='<'+hashlib.sha256(event['id'].encode()).hexdigest()+'@localpm>'
    message.set_content('Обновлён проект «'+event['project']['name']+'».\nВерсия: '+str(event['version'])+'\nДата: '+event['at']+'\nID события: '+event['id'])
    tls=config.get('tls','starttls'); cls=smtplib.SMTP_SSL if tls=='ssl' else smtplib.SMTP
    kwargs={'timeout':8}
    if tls=='ssl': kwargs['context']=ssl.create_default_context()
    with cls(config['host'],int(config.get('port',465 if tls=='ssl' else 587)),**kwargs) as server:
        if tls=='starttls': server.starttls(context=ssl.create_default_context())
        if config.get('username'): server.login(config['username'],config.get('password',''))
        server.send_message(message)

def occurrence(rule,index):
    start=dt.date.fromisoformat(rule['start']); amount=index*rule['interval']
    if rule['unit']=='month':
        import calendar
        month=start.year*12+start.month-1+amount; year=month//12; month=month%12+1
        return dt.date(year,month,min(start.day,calendar.monthrange(year,month)[1])).isoformat()
    return (start+dt.timedelta(days=amount*(7 if rule['unit']=='week' else 1))).isoformat()

def repeat_project(project,today):
    p=core.clone(project); added=0; existing={(t.get('source_recurrence'),t.get('occurrence')) for t in p['tasks'] if t.get('source_recurrence')}; cal=core.calendar(p)
    for rule in p.get('recurrences',[]):
        if rule.get('paused'): continue
        for i in range(rule.get('cursor',0),20000):
            date=occurrence(rule,i)
            if date>today or rule.get('until') and date>rule['until']: break
            rule['cursor']=i+1
            if (rule['id'],date) in existing: continue
            template=core.clone(rule['template']); tc=core.calendar(template); start=tc.ensure(cal.ensure(date)); shift=tc.serial(start)-tc.serial(template['start_date']); day_shift=(dt.date.fromisoformat(start)-dt.date.fromisoformat(template['start_date'])).days; mapping={t['id']:f"repeat-{rule['id']}-{date.replace('-','')}-{n}" for n,t in enumerate(template['tasks'])}
            for t in template['tasks']:
                t['id']=mapping[t['id']];t['project_id']=p['id'];t['parent_id']=mapping.get(t.get('parent_id'));t['sort_order']=len(p['tasks']);t['source_recurrence']=rule['id'];t['occurrence']=date
                for key in ['start_date','finish_date','constraint_snet','deadline']:
                    if t.get(key): t[key]=(dt.date.fromisoformat(t[key])+dt.timedelta(days=day_shift)).isoformat() if t.get('schedule_calendar')=='all_days' else tc.from_index(tc.serial(t[key])+shift)
                for key in ['actual_start','actual_finish','remaining_days','spent_hours','work_logs','blocker','kanban_column_id']: t.pop(key,None)
                t['percent_complete']=0;t['status']='Не начато';p['tasks'].append(t)
            for n,d in enumerate(template.get('dependencies',[])):
                d.update(id=f"repeat-link-{rule['id']}-{date.replace('-','')}-{n}",project_id=p['id'],pred_id=mapping[d['pred_id']],succ_id=mapping[d['succ_id']]);p['dependencies'].append(d)
            added+=len(template['tasks']);existing.add((rule['id'],date))
            if len(p['tasks'])>5000 or added>1000: raise ValueError('Повторение создаёт слишком много задач.')
    return (core.calculate(product.validate(p),strict=True),added) if added else (p,0)

class Maintenance:
    def __init__(self,app,config=None,backup_hours=24,retain=30):
        self.app=app;self.config=config or {'enabled':False};self.backup_hours=backup_hours;self.retain=retain;self.stop_event=threading.Event();self.last_schedule=0;self.last_backup_attempt=0;self.thread=None
        app.repo.event_sink_enabled=bool(self.config.get('enabled'));app.integration_public={'enabled':bool(self.config.get('enabled')),'webhooks':len(self.config.get('webhooks',[])),'mail':bool(self.config.get('mail',{}).get('enabled'))};app.maintenance_status=app.repo.setting('maintenance',{})['value'] or {}
    def backup(self):
        with self.app.lock:
            backup=self.app.repo.backup();folder=self.app.repo.data_dir/'backups';file=folder/('auto-'+core.now().replace(':','-')+'.json');atomic_write(file,backup)
        with tempfile.TemporaryDirectory(prefix='localpm-restore-check-') as tmp:
            repo=Repository(tmp)
            try:
                repo.restore(backup)
                if repo.count_users()!=len(backup['content']['users']) or len(repo.list())!=len(backup['content']['projects']): raise ValueError('Восстановленная копия не совпадает с исходной.')
            finally: repo.close()
        with self.app.lock:
            self.app.last_backup=backup['content']['createdAt'];self.app.maintenance_status.update(lastBackup=self.app.last_backup,lastVerified=core.now(),error=None)
            current=self.app.repo.setting('maintenance',{});self.app.repo.save_setting('maintenance',self.app.maintenance_status,current['version'])
        for old in sorted(folder.glob('auto-*.json'),reverse=True)[self.retain:]: old.unlink()
    def schedules(self):
        with self.app.lock:
            for doc in self.app.repo.list():
                p=doc['project']
                if p.get('archived'): continue
                if p.get('recurrences'):
                    result,added=repeat_project(p,core.today())
                    if added:
                        self.app.validate_assignments(result,doc['acl']);doc=self.app.mutate(doc,{'id':'scheduler','name':'Расписание'},'Созданы повторяющиеся задачи',lambda d:d.update(project=result));p=doc['project']
                today=core.today();key='report-snapshots:'+p['id'];saved=self.app.repo.setting(key,[]);snapshots=saved['value'] or []
                if not snapshots or snapshots[-1].get('at','')[:10]!=today:
                    snapshots.append({'at':core.now(),'planned':p.get('finish_date'),'forecast':p.get('forecast_finish'),'progress':p.get('percent_complete'),'user':'Расписание'})
                    self.app.repo.save_setting(key,snapshots[-200:],saved['version'])

    def deliveries(self):
        if not self.config.get('enabled'): return
        with self.app.lock: rows=[dict(r) for r in self.app.repo.db.execute("SELECT * FROM deliveries WHERE status='pending' AND next_at<=? ORDER BY next_at LIMIT 10",(time.time(),))]
        for row in rows:
            if self.stop_event.is_set(): return
            event=json.loads(row['event']);attempts=row['attempts']+1
            try:
                # Each destination has its own durable receipt; retries do not resend successes.
                for i,webhook in enumerate(self.config.get('webhooks',[])):
                    if self.stop_event.is_set(): return
                    key='delivery:'+row['id']+':webhook:'+str(i)
                    with self.app.lock: done=self.app.repo.setting(key,None)
                    if not done['version']:
                        deliver_webhook(webhook,event)
                        with self.app.lock: self.app.repo.save_setting(key,{'at':core.now()},0)
                if self.stop_event.is_set(): return
                key='delivery:'+row['id']+':mail'
                with self.app.lock: done=self.app.repo.setting(key,None)
                if not done['version']:
                    deliver_mail(self.config.get('mail',{}),event)
                    with self.app.lock: self.app.repo.save_setting(key,{'at':core.now()},0)
                with self.app.lock:self.app.repo.db.execute("UPDATE deliveries SET status='sent',attempts=?,error=NULL WHERE id=?",(attempts,row['id']))
            except Exception:
                # Never persist SMTP credentials, URL query strings or exception text from peers.
                with self.app.lock:self.app.repo.db.execute('UPDATE deliveries SET status=?,attempts=?,next_at=?,error=? WHERE id=?',('failed' if attempts>=12 else 'pending',attempts,time.time()+min(3600,2**attempts*15),'Доставка не подтверждена. Проверьте настройки интеграции.',row['id']))
    def tick(self):
        try:
            if time.time()-self.last_schedule>=60:self.schedules();self.last_schedule=time.time()
            with self.app.lock: saved=self.app.repo.setting('maintenance',{}).get('value') or {}
            last=saved.get('lastBackup');due=not last or (dt.datetime.now(dt.timezone.utc)-dt.datetime.fromisoformat(last.replace('Z','+00:00'))).total_seconds()>=self.backup_hours*3600
            if self.backup_hours and self.app.repo.count_users() and due and time.time()-self.last_backup_attempt>=900:
                self.last_backup_attempt=time.time();self.backup()
            self.deliveries()
        except Exception:self.app.maintenance_status['error']='Ошибка фонового обслуживания. Проверьте хранилище и журнал сервиса.'
    def start(self):
        self.thread=threading.Thread(target=self.run,name='localpm-maintenance',daemon=True);self.thread.start()
    def run(self):
        while not self.stop_event.is_set():self.tick();self.stop_event.wait(15)
    def close(self):
        self.stop_event.set()
        if self.thread:self.thread.join(timeout=45)
