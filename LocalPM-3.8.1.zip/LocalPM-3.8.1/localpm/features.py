"""Team configuration, durable action receipts and administrative diagnostics."""
from __future__ import annotations
import datetime as dt
import hashlib
import re
import time
from . import core,product
from .storage import APIError,json_text

def route(app,method,path,headers,b,user,token,session,secure=False):
    extra={}
    if path=='/api/preferences':
        key='preferences:'+user['id']
        if method=='GET': return 200,app.repo.setting(key,{}),extra
        if method=='PUT':
            value=b.get('value')
            if not isinstance(value,dict) or len(json_text(value))>200000: raise APIError(422,'Некорректные личные настройки.')
            return 200,app.repo.save_setting(key,value,b.get('expectedVersion')),extra
    if path=='/api/organization':
        if method=='GET': return 200,app.repo.setting('organization',{'groups':[],'availability':{},'templates':[],'emails':{}}),extra
        if method=='PUT':
            if not user['admin']: raise APIError(403,'Требуется администратор.')
            value=b.get('value')
            if not isinstance(value,dict) or len(json_text(value))>2*1024*1024: raise APIError(422,'Некорректные настройки команды.')
            product.availability(value.get('availability',{})); groups=value.get('groups',[]); users={u['id'] for u in app.repo.users()}
            if not isinstance(groups,list) or len(groups)>100: raise APIError(422,'Не более 100 групп.')
            ids=set()
            for group in groups:
                id=core.valid_id(group.get('id'))
                if id in ids or not isinstance(group.get('name'),str) or not 1<=len(group['name'].strip())<=100 or not isinstance(group.get('members'),list) or any(id not in users for id in group['members']): raise APIError(422,'Некорректная группа.')
                ids.add(id)
            emails=value.get('emails',{})
            if not isinstance(emails,dict) or any(id not in users or not isinstance(email,str) or len(email)>254 or not re.fullmatch(r'[^\s@<>\r\n]+@[^\s@<>\r\n]+',email) for id,email in emails.items()): raise APIError(422,'Проверьте почтовые адреса.')
            templates=value.get('templates',[])
            if not isinstance(templates,list) or len(templates)>50: raise APIError(422,'Не более 50 шаблонов.')
            for t in templates: product.validate(core.calculate(t['project'],strict=True))
            return 200,app.repo.save_setting('organization',value,b.get('expectedVersion')),extra
    if path=='/api/sessions' and method=='GET':
        if not user['admin']: raise APIError(403,'Требуется администратор.')
        return 200,[{'id':hashlib.sha256(id.encode()).hexdigest()[:24],'userId':s['userId'],'kind':s.get('kind'),'expires':s['expires'],'current':id==token} for id,s in app.sessions.items() if s['expires']>time.time()],extra
    if path=='/api/sessions/revoke' and method=='POST':
        if not user['admin']: raise APIError(403,'Требуется администратор.')
        for id in list(app.sessions):
            if hashlib.sha256(id.encode()).hexdigest()[:24]==b.get('id'): app.sessions.pop(id)
        return 200,{'ok':True},extra
    if path=='/api/diagnostics' and method=='GET':
        if not user['admin']: raise APIError(403,'Требуется администратор.')
        app.repo.assert_owner(); docs=app.repo.list()
        return 200,{'database':app.repo.db.execute('PRAGMA quick_check').fetchone()[0],'schemaVersion':app.repo.db.execute('PRAGMA user_version').fetchone()[0],'sharedFolder':'ok' if app.repo.shared_dir else 'not-configured','projects':len(docs),'tasks':sum(len(d['project']['tasks']) for d in docs),'pendingApprovals':sum(sum(r['status']=='pending' for r in d.get('updates',[])+d.get('changeRequests',[])) for d in docs),'sessions':sum(s['expires']>time.time() for s in app.sessions.values()),'deliveries':app.repo.delivery_status(),'backup':getattr(app,'maintenance_status',{}),'integrations':getattr(app,'integration_public',{'enabled':False}),'recentActivity':[{'project':d['project']['name'],**item} for d in docs for item in d.get('audit',[])[-5:]][-100:]},extra
    if path=='/api/projects/index' and method=='GET':
        from .application import role
        return 200,[{'id':d['project']['id'],'name':d['project']['name'],'version':d['version'],'role':role(d,user),'tasks':len(d['project']['tasks']),'forecast':d['project'].get('forecast_finish'),'archived':d['project'].get('archived',False)} for d in app.repo.list() if role(d,user)],extra
    match=re.fullmatch(r'/api/projects/([A-Za-z0-9_.:-]+)/(actions|task-changes|worklog|watch|group-members|snapshot|report-snapshots|task-page/\d+)',path)
    if not match: return None
    id,tail=match[1],match[2]; doc=app.document(id,user)
    from .application import role,response_doc,notify
    r=role(doc,user)
    if tail=='task-changes' and method=='POST':
        from .task_changes import submit
        return submit(app,doc,user,headers,b,secure)
    if tail.startswith('task-page/') and method=='GET':
        start=int(tail.split('/')[-1])*250
        core.renumber(doc['project'])
        return 200,{'projectId':id,'version':doc['version'],'total':len(doc['project']['tasks']),'offset':start,'tasks':doc['project']['tasks'][start:start+250]},extra
    if tail=='actions' and method=='POST':
        operation=core.valid_id(b.get('operationId')); kind=b.get('kind'); data=b.get('data'); mapping={'actual':'updates','comment':'comments','attachment':'attachments','watch':'watch','worklog':'worklog'}
        if kind not in mapping or not isinstance(data,dict): raise APIError(422,'Неизвестное действие.')
        if r=='viewer': raise APIError(403,'Доступ только для чтения.')
        fingerprint=hashlib.sha256(json_text({'user':user['id'],'kind':kind,'data':data},sort_keys=True).encode()).hexdigest()
        receipts=doc.get('action_receipts',{}); previous=receipts.get(operation)
        if previous:
            if previous['hash']!=fingerprint: raise APIError(409,'ID действия использован с другими данными.')
            return 200,{**response_doc(doc,user),'actionReceipt':previous},extra
        if len(receipts)>=20000: raise APIError(422,'Заполнен журнал повторов проекта. Администратор должен архивировать проект; повторная отправка старых действий остаётся защищена.')
        if kind=='actual':
            task=next((t for t in doc['project']['tasks'] if t['id']==data.get('taskId')),None)
            if not task: raise APIError(404,'Задача не найдена.')
            if r=='contributor' and task.get('assignee_id')!=user['id']: raise APIError(403,'Можно обновлять только свои задачи.')
            from .application import actual_snapshot
            if data.get('baseActual')!=actual_snapshot(task): raise APIError(409,'Факт изменился с момента создания действия. Сравните изменения.')
        app.action_context={'id':operation,'hash':fingerprint,'kind':kind,'user':user['id'],'at':core.now()}
        try:
            status,payload,extra=app._handle('POST','/api/projects/'+id+'/'+mapping[kind],headers,{**data,'operationId':operation},'127.0.0.1',secure)
            saved=app.repo.load(id); receipt=saved.get('action_receipts',{}).get(operation)
            if not receipt: raise APIError(503,'Не удалось подтвердить действие. Повторите отправку с тем же ID.')
            return status,{**payload,'actionReceipt':receipt},extra
        finally: app.action_context=None
    if tail=='group-members' and method=='POST':
        if r!='manager': raise APIError(403,'Требуется руководитель.')
        group=next((g for g in app.repo.setting('organization',{}).get('value',{}).get('groups',[]) if g['id']==b.get('groupId')),None)
        if not group or b.get('role') not in ['manager','editor','contributor','viewer']: raise APIError(422,'Проверьте группу и роль.')
        def change(d):
            for member in group['members']:
                u=app.repo.user(member)
                if u and u['active']: d['acl'][member]=b['role']
            if not any(x=='manager' for x in d['acl'].values()): raise APIError(422,'В проекте должен остаться руководитель.')
        return 200,response_doc(app.mutate(doc,user,'Добавлена группа участников',change),user),extra
    if tail=='report-snapshots' and method=='GET': return 200,app.repo.setting('report-snapshots:'+id,[])['value'],extra
    if tail=='snapshot' and method=='POST':
        if r!='manager': raise APIError(403,'Требуется руководитель.')
        key='report-snapshots:'+id;old=app.repo.setting(key,[])
        snapshot={'at':core.now(),'planned':doc['project'].get('finish_date'),'forecast':doc['project'].get('forecast_finish'),'progress':doc['project'].get('percent_complete'),'user':user['name']}
        app.repo.save_setting(key,((old['value'] or [])+[snapshot])[-200:],old['version'])
        return 200,response_doc(doc,user),extra
    if tail in ['watch','worklog'] and method=='POST':
        task=next((t for t in doc['project']['tasks'] if t['id']==b.get('taskId')),None)
        if not task: raise APIError(404,'Задача не найдена.')
        if r=='viewer' or tail=='worklog' and r=='contributor' and task.get('assignee_id')!=user['id']: raise APIError(403,'Недостаточно прав.')
        if tail=='watch':
            def change(d):
                t=next(t for t in d['project']['tasks'] if t['id']==task['id']); watchers=t.get('watchers',[])
                t['watchers']=list(set(watchers+[user['id']])) if b.get('watching') is True else [x for x in watchers if x!=user['id']]
        else:
            if any(t.get('parent_id')==task['id'] for t in doc['project']['tasks']): raise APIError(422,'Трудозатраты вносятся по конечной задаче.')
            hours=core.number(b.get('hours'),'Трудозатраты',0.01,24); date=core.date(b.get('date')); reason=b.get('reason','')
            if not date or date>core.today() or not isinstance(reason,str) or not reason.strip() or len(reason)>2000: raise APIError(422,'Укажите дату и причину/описание работы.')
            def change(d):
                t=next(t for t in d['project']['tasks'] if t['id']==task['id']); logs=t.setdefault('work_logs',[])
                if len(logs)>=5000: raise APIError(422,'Лимит записей времени задачи.')
                logs.append({'id':b.get('operationId') or core.uid(),'user_id':user['id'],'user':user['name'],'hours':hours,'date':date,'reason':reason});t['spent_hours']=sum(x['hours'] for x in logs)
        return 200,response_doc(app.mutate(doc,user,'Обновлены наблюдатели' if tail=='watch' else 'Учтено время',change),user),extra
    return None
