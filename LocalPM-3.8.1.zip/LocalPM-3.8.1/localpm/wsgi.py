"""WSGI entry point for a managed single-worker, threaded production service."""
from __future__ import annotations
import atexit
import json
import os
import threading
from http import HTTPStatus
from email.message import Message
from pathlib import Path
from urllib.parse import urlsplit
from .application import Application
from .http_server import STATIC,CSP,MAX_BODY
from .storage import APIError,json_text
from .maintenance import Maintenance,integration_config
from . import client_access

_state=None;_lock=threading.Lock()
def runtime():
    global _state
    with _lock:
        if _state is not None:return _state
        origin=os.environ.get('LOCALPM_PUBLIC_ORIGIN','')
        if not origin.startswith('https://') or urlsplit(origin).path not in ['', '/'] or urlsplit(origin).username or urlsplit(origin).password: raise ValueError('Set LOCALPM_PUBLIC_ORIGIN to an HTTPS origin.')
        app=Application(os.environ['LOCALPM_DATA_DIR'],shared_dir=os.environ.get('LOCALPM_SHARED_DIR') or None,public_origin=origin.rstrip('/'),allowed_host=urlsplit(origin).netloc,client_origins=[x.strip() for x in os.environ.get('LOCALPM_CLIENT_ORIGINS','').split(',') if x.strip()])
        setup=os.environ.get('LOCALPM_SETUP_CODE_FILE')
        if setup and not app.repo.count_users():
            from .storage import atomic_write
            atomic_write(setup,app.bootstrap_code+'\n')
        maintenance=Maintenance(app,integration_config(os.environ.get('LOCALPM_INTEGRATION_CONFIG')),float(os.environ.get('LOCALPM_BACKUP_HOURS','24')),int(os.environ.get('LOCALPM_BACKUP_RETAIN','30')));maintenance.start()
        def close():maintenance.close();app.close()
        atexit.register(close);_state=(app,maintenance);return _state

def application(environ,start_response):
    headers=Message()
    for key,value in environ.items():
        if key.startswith('HTTP_'): headers[key[5:].replace('_','-')]=value
    headers['Host']=environ.get('HTTP_HOST','');path=environ.get('PATH_INFO','/');method=environ.get('REQUEST_METHOD','GET');extra={};status=500;payload={'error':'Сервис временно недоступен.'}
    try:
        app,_=runtime();app.check_origin('GET' if method=='OPTIONS' else method,headers,True)
        if path.startswith('/api/'):
            if method=='OPTIONS':
                requested={x.strip().lower() for x in headers.get('Access-Control-Request-Headers','').split(',') if x.strip()}
                if not app.client_origin_allowed(headers,True) or headers.get('Access-Control-Request-Method') not in client_access.METHODS or 'x-localpm-client' not in requested or not requested<=client_access.HEADERS:raise APIError(403,'Клиент не разрешён.')
                status,payload=204,b'';extra={'Access-Control-Allow-Methods':', '.join(sorted(client_access.METHODS)),'Access-Control-Allow-Headers':', '.join(sorted(client_access.HEADERS)),'Access-Control-Max-Age':'300'}
                if headers.get('Access-Control-Request-Private-Network')=='true':extra['Access-Control-Allow-Private-Network']='true'
            else:
                body={}
                if method not in ['GET','HEAD']:
                    if not environ.get('CONTENT_TYPE','').startswith('application/json'):raise APIError(415,'Ожидается JSON.')
                    try:length=int(environ.get('CONTENT_LENGTH','-1'))
                    except ValueError:raise APIError(400,'Некорректная длина.')
                    if length<0:raise APIError(411,'Требуется длина запроса.')
                    if length>MAX_BODY:raise APIError(413,'Слишком большой запрос.')
                    raw=environ['wsgi.input'].read(length)
                    if len(raw)!=length:raise APIError(400,'Неполный запрос.')
                    body=json.loads(raw,parse_constant=lambda v:(_ for _ in ()).throw(ValueError('Non-finite JSON')))
                    if not isinstance(body,dict):raise APIError(422,'Ожидается объект.')
                status,payload,extra=app.handle(method,path,headers,body,environ.get('REMOTE_ADDR',''),True)
        else:
            if method not in ['GET','HEAD']:raise APIError(405,'Метод не разрешён.')
            if path not in STATIC:raise APIError(404,'Файл не найден.')
            file=Path(__file__).resolve().parent.parent/'web'/STATIC[path];payload=file.read_bytes();status=200;extra={'Content-Type':{'.html':'text/html','.js':'text/javascript','.css':'text/css'}[file.suffix]+'; charset=utf-8'}
    except APIError as e:status,payload=e.status,{'error':str(e),**e.extra}
    except (ValueError,TypeError,KeyError):status,payload=422,{'error':'Некорректный запрос или конфигурация.'}
    except Exception:
        import logging
        logging.exception('WSGI request failed')
    data=payload if isinstance(payload,bytes) else json_text(payload).encode('utf-8');result={'Content-Type':'application/json; charset=utf-8','Content-Length':str(len(data)),'Content-Security-Policy':CSP,'X-Content-Type-Options':'nosniff','Cache-Control':'no-store','Referrer-Policy':'same-origin',**extra}
    if path.startswith('/api/') and 'app' in locals() and app.client_origin_allowed(headers,True) and (client_access.is_client(headers) or method=='OPTIONS'):result.update({'Access-Control-Allow-Origin':headers['Origin'],'Vary':'Origin'})
    start_response(str(status)+' '+HTTPStatus(status).phrase,list(result.items()));return [b'' if method=='HEAD' else data]
