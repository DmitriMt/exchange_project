"""Excel-to-snapshot pipeline used by the web wizard and command-line exporter."""
import argparse
from datetime import datetime
import hashlib
import os
import json
from pathlib import Path
import shutil
import threading
import uuid
import zipfile

from prepare_data import prepare

ROLES = {'catalog': 'table_runup_DS_main_Katalog_IT-uslug_{date}_000000.xlsx',
         'wallet': 'Кошельки.xlsx', 'pshe': 'Калькулятор_ПШЕ.xlsx',
         'rsm1': 'РСМ ДЭШ_1.xlsx', 'rsm2': 'РСМ ДЭШ_2.xlsx', 'questionnaire':'Опросник перехода.xlsx'}
REQUIRED_ROLES = set(ROLES) - {'pshe'}
FILE_LIMIT = 300 * 1024 * 1024


class ImportJobs:
    def __init__(self, root, store, validator):
        self.root, self.store, self.validator = Path(root), store, validator
        self.root.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        for file in self.root.glob('*/job.json'):
            job = json.loads(file.read_text())
            if job['status'] == 'running':
                job.update(status='failed', message='Обработка прервана перезапуском. Запустите повторно.')
                file.write_text(json.dumps(job, ensure_ascii=False))

    def _path(self, key):
        if not isinstance(key, str) or len(key) != 32 or any(c not in '0123456789abcdef' for c in key):
            raise ValueError('Неверный идентификатор обработки')
        return self.root / key

    def _write(self, job):
        folder = self._path(job['id'])
        tmp = folder / 'job.tmp'
        tmp.write_text(json.dumps(job, ensure_ascii=False))
        tmp.replace(folder / 'job.json')

    def get(self, key, owner):
        with self.lock:
            path = self._path(key) / 'job.json'
            if not path.exists():
                raise ValueError('Обработка не найдена')
            job = json.loads(path.read_text())
            if job['owner'] != owner:
                raise PermissionError('Эта обработка принадлежит другому пользователю')
            return job

    def list(self, owner):
        with self.lock:
            jobs = [json.loads(p.read_text()) for p in self.root.glob('*/job.json')]
        return sorted((j for j in jobs if j['owner'] == owner), key=lambda j: j['created_at'], reverse=True)

    def create(self, owner, date, base):
        datetime.strptime(date, '%Y-%m-%d')
        key = uuid.uuid4().hex
        folder = self._path(key)
        (folder / 'sources').mkdir(parents=True)
        job = dict(id=key, owner=owner, date=date, base=base, files={}, status='uploading',
                   message='Выберите исходные Excel-файлы', created_at=datetime.now().astimezone().isoformat())
        with self.lock:
            self._write(job)
        return job

    def upload(self, key, owner, role, stream, size, name):
        if role not in ROLES or not 0 < size <= FILE_LIMIT:
            raise ValueError('Неизвестный источник или файл больше 300 МБ')
        with self.lock:
            job = self.get(key, owner)
            if job['status'] != 'uploading':
                raise ValueError('Набор файлов уже передан на обработку')
        folder = self._path(key)
        filename = ROLES[role].format(date=job['date'].replace('-', ''))
        target = folder / 'sources' / filename
        tmp = folder / (role + '.upload-' + uuid.uuid4().hex)
        digest = hashlib.sha256()
        try:
            with tmp.open('wb') as output:
                remaining = size
                while remaining:
                    block = stream.read(min(1024 * 1024, remaining))
                    if not block:
                        raise ValueError('Файл передан не полностью')
                    output.write(block)
                    digest.update(block)
                    remaining -= len(block)
            with zipfile.ZipFile(tmp) as book:
                if 'xl/workbook.xml' not in book.namelist() or sum(i.file_size for i in book.infolist()) > 8 * 1024**3:
                    raise ValueError('Неверный XLSX или слишком большой объём распаковки')
            with self.lock:
                job = self.get(key, owner)
                if job['status'] != 'uploading':
                    raise ValueError('Обработка уже начата')
                tmp.replace(target)
                job['files'][role] = dict(name=str(name)[:250], bytes=size, sha256=digest.hexdigest())
                self._write(job)
            return job
        finally:
            tmp.unlink(missing_ok=True)

    def run(self, key, owner):
        with self.lock:
            job = self.get(key, owner)
            if job['status'] not in ('uploading', 'failed'):
                raise ValueError('Обработка уже выполняется или завершена')
            missing = REQUIRED_ROLES - job['files'].keys()
            if missing:
                raise ValueError('Не загружены источники: ' + ', '.join(sorted(missing)))
            job.update(status='running', message='Проверяем исходные файлы')
            self._write(job)
        threading.Thread(target=self._work, args=(key, owner), daemon=True).start()
        return job

    def _work(self, key, owner):
        def progress(text):
            with self.lock:
                j = self.get(key, owner)
                j['message'] = str(text)
                self._write(j)
        try:
            job = self.get(key, owner)
            folder = self._path(key)
            report = prepare(folder / 'sources', folder / 'snapshot.csv', job['date'], progress)
            records = self.validator((folder / 'snapshot.csv').read_bytes())
            from fincontrol_model import resource_evidence, complete_fincontrol
            evidence = resource_evidence(folder / 'sources', self.root.parent / 'fincontrol_resources', progress)
            baseline = json.loads((Path(__file__).resolve().parent / 'data' / 'fincontrol.json').read_text())
            completed = complete_fincontrol(baseline, records, evidence)
            report['fincontrol_completion'] = completed['completion']
            with self.lock:
                job = self.get(key, owner)
                job.update(status='ready', message='Срез подготовлен. Проверьте изменения и сохраните.', report=report)
                self._write(job)
        except Exception as error:
            with self.lock:
                job = self.get(key, owner)
                job.update(status='failed', message=str(error) or type(error).__name__)
                self._write(job)

    def result(self, key, owner):
        job = self.get(key, owner)
        if job['status'] not in ('ready', 'committed'):
            raise ValueError('Срез ещё не подготовлен')
        return dict(rows=self.validator((self._path(key) / 'snapshot.csv').read_bytes()), job=job)

    def commit(self, key, owner, base=None):
        with self.lock:
            job = self.get(key, owner)
            if job['status'] == 'committed':
                return job
            data = self.result(key, owner)
            raw = (self._path(key) / 'snapshot.csv').read_bytes()
            version = self.store.commit(raw, data['rows'], 'Excel-срез ' + job['date'], job['date'], base if base is not None else job['base'])
            job.update(status='committed', message='Новый срез добавлен в историю', snapshot_id=version)
            self._write(job)
            return job


def main():
    parser = argparse.ArgumentParser(description='Создать новый срез из исходных Excel и добавить его в историю')
    parser.add_argument('source', type=Path)
    parser.add_argument('--date', required=True)
    parser.add_argument('--data-dir', type=Path, default=Path(__file__).resolve().parent / 'data')
    parser.add_argument('--preview-only', action='store_true')
    parser.add_argument('--admin-backup-dir', type=Path, help='Папка на устройстве админа или подключённом диске')
    args = parser.parse_args()
    from server import parse_data
    from state_store import StateStore
    args.data_dir.mkdir(parents=True, exist_ok=True)
    store = StateStore(args.data_dir / 'dashboard_state.sqlite3')
    current = args.data_dir / 'dashboard.csv'
    if not store.list() and current.exists():
        rows = parse_data(current.read_bytes())
        store.commit(current.read_bytes(), rows, 'Исходные данные', max(r['snapshot'] for r in rows if r['record_type'] == 'entity'))
    base = store.list()[0]['id'] if store.list() else ''
    output = args.data_dir / ('snapshot_' + args.date + '.csv')
    report = prepare(args.source, output, args.date)
    raw = output.read_bytes()
    rows = parse_data(raw)
    from fincontrol_model import resource_evidence, complete_fincontrol
    evidence = resource_evidence(args.source, args.data_dir / 'fincontrol_resources')
    baseline = json.loads((Path(__file__).resolve().parent / 'data' / 'fincontrol.json').read_text())
    report['fincontrol_completion'] = complete_fincontrol(baseline, rows, evidence)['completion']
    if not args.preview_only:
        if not args.admin_backup_dir:
            parser.error('Для сохранения требуется --admin-backup-dir: папка на устройстве админа')
        from security import Security
        import hashlib
        security = Security(store, args.data_dir / 'no-legacy-users.json')
        receipt = security.prepare('CLI', base)
        args.admin_backup_dir.mkdir(parents=True, exist_ok=True)
        source = security.folder / receipt['filename']
        destination = args.admin_backup_dir / receipt['filename']
        if destination.resolve().parent == security.folder.resolve():
            parser.error('Копия админа должна находиться отдельно от серверных копий')
        destination.write_bytes(source.read_bytes())
        destination.chmod(0o600)
        with destination.open('rb') as backup_file:
            os.fsync(backup_file.fileno())
        digest = hashlib.sha256(destination.read_bytes()).hexdigest()
        security.acknowledge(receipt['id'], 'CLI', digest)
        security.consume(receipt['id'], 'CLI', base)
        key = store.commit(raw, rows, 'Excel-срез ' + args.date, args.date, base)
        current.write_bytes(store.snapshot(store.list()[0]['id'])['csv'])
        print('Срез добавлен в историю:', key)
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
