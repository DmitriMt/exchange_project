#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ ! -s private/users.json ]; then
  echo 'Создайте пароль пользователя operator для первого входа.'
  python3 -B server.py --add-user operator --role admin
fi
echo 'Откройте http://127.0.0.1:8080/ и раздел «Обновление из Excel».'
python3 -B server.py --host 127.0.0.1 --port 8080
