"""Portable inference for the supplied v4.3 model; no training or external API."""
import math
import re
import unicodedata
import json


def norm(value):
    return re.sub(r'\s+', ' ', unicodedata.normalize('NFC', str(value or '')).lower().replace('ё', 'е')).strip()


def semantic(numeric, kind):
    n = dict(numeric)
    products, unknown = n.get('n_products'), n.get('tech_unknown_products')
    known = products - unknown if products is not None and unknown is not None else None
    weight, complex_count = n.get('tech_weight_sum'), n.get('tech_complex_products')
    mean = weight / known if weight is not None and known is not None and known > 0 else None
    share = complex_count / known if complex_count is not None and known is not None and known > 0 else None
    mods, subs, fps, servers = [n.get(k) for k in ['catalog_prod_modules', 'catalog_prod_submodules', 'catalog_prod_fp', 'n_servers']]
    total = mods + subs if mods is not None and subs is not None else None
    density = total / servers if total is not None and servers is not None and servers > 0 else None
    n.update(tech_mean_weight=mean, tech_complex_share=share, struct_total_modules=total,
             struct_modules_per_server=density,
             struct_modules_per_fp=total / max(fps, 1) if total is not None and fps is not None else None,
             interaction_servers_tech=math.log1p(servers) * mean if servers is not None and mean is not None else None,
             interaction_structure_tech=math.log1p(total) * mean if total is not None and mean is not None else None,
             as_tech_mean_weight=mean if kind == 'АС' else 0., as_struct_density=density if kind == 'АС' else 0.)
    for name, column, threshold in [('servers_over_10', 'n_servers', 10), ('servers_over_100', 'n_servers', 100),
                                     ('servers_over_1000', 'n_servers', 1000), ('modules_over_10', 'struct_total_modules', 10), ('modules_over_100', 'struct_total_modules', 100)]:
        value = n.get(column)
        n[name] = max((1 + value) / (1 + threshold) - 1, 0) if value is not None else None
    return n


def vector(record, feat, spec):
    n, values, missing = semantic(feat.get('numeric', {}), record['type']), [], []
    for name in spec['numeric']:
        value = n.get(name)
        values.append(math.log1p(value) if value is not None else None)
        missing.append(float(value is None))
    values += missing
    values += [float(p in feat.get('products', [])) for p in spec['products']]
    values += [float(record['type'] == 'АС')]
    values += [float(record.get('criticality', '') == c) for c in spec['classes']]
    values += [float(norm(record.get(k)) == v) for k, choices in spec.get('categories', {}).items() for v in choices]
    return [((v if v is not None else spec['median'][i]) - spec['mean'][i]) / spec['scale'][i] for i, v in enumerate(values)]


def predict(record, feat, head):
    n = feat.get('numeric', {})
    eligible = (record['type'] in head['matched_types'] and
                ((n.get('resource_present') and sum(n.get(k) is not None for k in ['n_servers', 'n_dbs', 'n_environments']) >= 2)
                 or (head['configuration'].get('allow_partial') and sum(n.get(k) is not None for k in ['catalog_prod_fp', 'catalog_prod_modules', 'catalog_prod_submodules']) >= 2)))
    if not eligible:
        return head['baseline'][record['type']], 'Средняя по типу · v4.3'
    def linear(spec, beta):
        return beta[0] + math.fsum(x * b for x, b in zip(vector(record, feat, spec), beta[1:]))
    probability = 1 / (1 + math.exp(-max(-30, min(30, linear(head['probability_vectorizer'], head['logistic'])))))
    amount = math.exp(max(-30, min(30, linear(head['amount_vectorizer'], head['positive']))))
    amount *= head.get('typed_smearing', {}).get(record['type'], head['smearing']) * head.get('amount_scale', 1)
    return probability * amount, 'Ресурсная модель · v4.3'


def fill_rows_model(rows, model_path):
    model = None
    for r in rows:
        if r['record_type'] != 'entity' or all(r[k] != '' for k in ['pshe_change_main', 'pshe_run_main', 'pshe_change_prom', 'pshe_run_prom', 'pshe_change_standin', 'pshe_run_standin', 'pshe_vendor_standin']):
            continue
        if model is None:
            model = json.loads(model_path.read_text())
        inputs = json.loads(r['pshe_model_inputs']) if r['pshe_model_inputs'] else {}
        if not isinstance(inputs, dict):
            raise ValueError('Неверные входы модели ПШЕ')
        record = dict(type=r['category'], criticality=r['criticality'], block=r['dit'])
        for variant, suffix in [('both', 'main'), ('prom', 'prom')]:
            feature = inputs.get(variant, {})
            if not isinstance(feature, dict) or not isinstance(feature.get('numeric', {}), dict):
                raise ValueError('Неверные признаки ПШЕ')
            for value in feature.get('numeric', {}).values():
                if value is not None and (not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0):
                    raise ValueError('Некорректное число в признаках ПШЕ')
            methods = []
            for target, label in [('own', 'change'), ('run', 'run')]:
                field = f'pshe_{label}_{suffix}'
                if r[field] != '':
                    continue
                amount, method = (0., 'Нет ПРОМ-ресурсов · подтверждено РСМ') if variant == 'prom' and inputs.get('prom_absent') else predict(record, feature, model['models'][target])
                r[field] = format(amount, '.15g')
                methods.append(method)
                if suffix == 'main':
                    r['pshe_source_change' if label == 'change' else 'pshe_source_run'] = method
            if methods:
                r['pshe_status' if suffix == 'main' else 'pshe_prom_status'] = ' / '.join(sorted(set(methods)))
        for target, label in [('own', 'change'), ('run', 'run'), ('vendor', 'vendor')]:
            field = f'pshe_{label}_standin'
            if r[field] == '':
                amount, _ = predict(record, inputs.get('both', {}), model['models'][target])
                r[field] = format(amount, '.15g')
    return rows
