"""Accounts, private preferences and verified pre-load database backups."""
from contextlib import closing
import hashlib
import json
import os
import re
import secrets
import sqlite3
import time
from pathlib import Path

ROLES = {'viewer': 'user', 'uploader': 'admin', 'user': 'user', 'admin': 'admin', 'operator': 'operator'}

class Security:
    def __init__(self, store, legacy):
        self.store = store
        self.folder = store.path.parent / 'backups'
        self.folder.mkdir(exist_ok=True, mode=0o700)
        with store.db() as db:
            db.executescript('''CREATE TABLE IF NOT EXISTS accounts(name TEXT PRIMARY KEY, role TEXT, salt TEXT, hash TEXT, active INTEGER);
            CREATE TABLE IF NOT EXISTS preferences(user TEXT PRIMARY KEY, data TEXT);
            CREATE TABLE IF NOT EXISTS backup_receipts(id TEXT PRIMARY KEY, owner TEXT, base TEXT, sha TEXT, bytes INTEGER, created REAL, acknowledged INTEGER, used INTEGER);''')
            if Path(legacy).exists():
                for name, u in json.loads(Path(legacy).read_text()).items():
                    db.execute('INSERT OR IGNORE INTO accounts VALUES(?,?,?,?,1)', (name, ROLES[u['role']], u['salt'], u['hash']))
        store.path.chmod(0o600)

    def account(self, name):
        with self.store.db() as db:
            r = db.execute('SELECT * FROM accounts WHERE name=? AND active=1', (name,)).fetchone()
            return dict(r) if r else None

    def users(self):
        with self.store.db() as db:
            return [dict(r) for r in db.execute('SELECT name,role,active FROM accounts ORDER BY name')]

    def save_user(self, body, hasher):
        name = str(body.get('name', '')).strip()
        role = body.get('role', 'user')
        if not re.fullmatch(r'[^\s:\x00-\x1f]{1,80}', name) or role not in ('user', 'operator', 'admin'):
            raise ValueError('Укажите логин без пробелов и роль пользователя или админа')
        active = 1 if body.get('active', True) else 0
        password = body.get('password', '')
        with self.store.db() as db:
            db.execute('BEGIN IMMEDIATE')
            old = db.execute('SELECT * FROM accounts WHERE name=?', (name,)).fetchone()
            if old and old['role'] == 'admin' and old['active'] and (role != 'admin' or not active):
                if db.execute("SELECT count(*) FROM accounts WHERE role='admin' AND active=1").fetchone()[0] <= 1:
                    raise ValueError('Нельзя отключить последнего админа')
            if not old or password:
                if not isinstance(password, str) or len(password) < 12 or len(password) > 1000:
                    raise ValueError('Пароль должен содержать от 12 до 1000 символов')
                salt = secrets.token_hex(16)
                digest = hasher(password, salt)
            else:
                salt, digest = old['salt'], old['hash']
            db.execute('INSERT OR REPLACE INTO accounts VALUES(?,?,?,?,?)', (name, role, salt, digest, active))

    def preferences(self, user, value=None):
        with self.store.db() as db:
            if value is not None:
                if not isinstance(value, dict) or len(json.dumps(value)) > 500000:
                    raise ValueError('Слишком большой набор настроек')
                db.execute('INSERT OR REPLACE INTO preferences VALUES(?,?)', (user, json.dumps(value)))
            r = db.execute('SELECT data FROM preferences WHERE user=?', (user,)).fetchone()
            return json.loads(r['data']) if r else {}

    def prepare(self, owner, base):
        current = self.store.list()
        if base != (current[0]['id'] if current else ''):
            raise RuntimeError('Данные изменились. Повторите проверку загрузки.')
        key = time.strftime('%Y%m%dT%H%M%S') + '-' + secrets.token_hex(12)
        path = self.folder / (key + '.sqlite3')
        with closing(sqlite3.connect(str(path))) as target, self.store.db() as source:
            source.backup(target)
        path.chmod(0o600)
        with path.open('rb') as handle:
            os.fsync(handle.fileno())
        raw = path.read_bytes()
        sha = hashlib.sha256(raw).hexdigest()
        with self.store.db() as db:
            db.execute('INSERT INTO backup_receipts VALUES(?,?,?,?,?,?,0,0)', (key, owner, base, sha, len(raw), time.time()))
        return dict(id=key, sha256=sha, bytes=len(raw), filename=path.name)

    def receipt(self, key, owner):
        with self.store.db() as db:
            r = db.execute('SELECT * FROM backup_receipts WHERE id=? AND owner=?', (key, owner)).fetchone()
        if not r or time.time() - r['created'] > 1800 or r['used']:
            raise ValueError('Резервная копия устарела. Создайте новую.')
        return dict(r)

    def acknowledge(self, key, owner, sha):
        receipt = self.receipt(key, owner)
        if sha != receipt['sha']:
            raise ValueError('Копия на устройстве не совпадает с серверной')
        with self.store.db() as db:
            db.execute('UPDATE backup_receipts SET acknowledged=1 WHERE id=?', (key,))

    def consume(self, key, owner, base=None):
        r = self.receipt(key, owner)
        current = self.store.list()
        latest = current[0]['id'] if current else ''
        if not r['acknowledged'] or r['base'] != latest or (base is not None and base != latest):
            raise ValueError('Перед загрузкой нужны свежая серверная копия и подтверждённая копия на устройстве админа')
        path = self.folder / (key + '.sqlite3')
        if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest() != r['sha']:
            raise ValueError('Серверная копия недоступна или повреждена')
        with self.store.db() as db:
            db.execute('UPDATE backup_receipts SET used=1 WHERE id=?', (key,))
