"""The questionnaire RUNUP is the sole authoritative system registry."""
import json
from transition import apply_questionnaire
from ownership import enrich_ownership

REGISTRY_FIELDS = ['base_source','catalog_presence','fp_registry_total','fp_registry_children_json']
BASE_SOURCE = 'RUNUP_QUESTIONNAIRE'
CATEGORIES = {'Автоматизированные системы':'АС','Функциональная подсистема':'ФП'}
CLASSES = {'Mission Critical+':'MC+','Mission Critical':'MC','Business Critical':'BC'}


def registry_entities(questionnaire, catalog, date):
    entities = {}
    overlay = {ci:dict(row) for ci,row in catalog.items()}
    for ci, rec in questionnaire['records'].items():
        category=CATEGORIES.get(rec['category'])
        if not category or not rec.get('name'):
            raise ValueError('Опросник RUNUP: заполните название и категорию АС/ФП для '+ci)
        parent=rec.get('parent_id','')
        e=dict(record_type='entity',id_ke=ci,name=rec['name'],category=category,parent_id=parent,
               criticality=CLASSES.get(rec.get('criticality'),rec.get('criticality') or '(не указана)'),
               lifecycle='ПРОМ' if rec.get('lifecycle')=='Промышленная эксплуатация' else rec.get('lifecycle') or '(не указан)',
               dit=rec.get('dit') or '(не указан)',business_block=catalog.get(ci,{}).get('BF') or '(не указан)',snapshot=date,
               pshe_status='Нет данных',base_source=BASE_SOURCE,catalog_presence='1' if ci in catalog else '0')
        entities[ci]=e
        overlay[ci]={**catalog.get(ci,{}), 'A':ci,'B':rec['name'],'G':rec['category'],'H':('('+parent+')') if parent else '',
                     'S':rec.get('criticality',''),'M':rec.get('lifecycle',''),'V':rec.get('dit','')}
    enrich_ownership(entities,overlay)
    annotate_registry(entities)
    apply_questionnaire(list(entities.values()),questionnaire)
    return entities


def annotate_registry(entities):
    children={}
    for e in entities.values():
        if e['category']=='ФП' and e.get('parent_id') in entities and entities[e['parent_id']]['category']=='АС':
            children.setdefault(e['parent_id'],[]).append({k:e.get(k,'') for k in ['id_ke','name','category','parent_id','criticality','lifecycle','business_block','owner_department','owner_department_code','owner_tribe','owner_tribe_code']})
    for e in entities.values():
        if e['category']=='ФП':
            p=entities.get(e.get('parent_id'))
            if p:
                e.update(parent_name=p['name'],parent_business_block=p['business_block'],parent_owner_department=p.get('owner_department',''),parent_owner_tribe=p.get('owner_tribe',''),parent_owner_tribe_code=p.get('owner_tribe_code',''),parent_criticality=p['criticality'],parent_lifecycle=p['lifecycle'],parent_in_scope='1')
            else:
                e['parent_in_scope']='0' if e.get('parent_name') else ''
        e['fp_registry_total']=str(len(children.get(e['id_ke'],[]))) if e['category']=='АС' else ''
        e['fp_registry_children_json']=json.dumps(children.get(e['id_ke'],[]),ensure_ascii=False,separators=(',',':')) if e['category']=='АС' else ''


def validate_registry_row(row):
    if row['record_type']!='entity':
        return
    if row.get('base_source')=='LEGACY_CATALOG':
        return
    if row.get('base_source')!=BASE_SOURCE or row.get('transition_status') not in ('planned','blank'):
        raise ValueError('Состав систем должен определяться опросником RUNUP')
    if row.get('catalog_presence','') not in ('','0','1'):
        raise ValueError('Неверный признак насыщения каталогом')
    if row['category']=='АС':
        try:
            children=json.loads(row.get('fp_registry_children_json') or 'null')
            if not isinstance(children,list) or str(len(children))!=row.get('fp_registry_total'):
                raise ValueError()
            seen=set()
            for child in children:
                if child.get('category')!='ФП' or child.get('parent_id')!=row['id_ke'] or child.get('id_ke') in seen:
                    raise ValueError()
                seen.add(child['id_ke'])
        except (ValueError,TypeError,AttributeError):
            raise ValueError('Неверный состав ФП базового реестра: '+row['id_ke'])


def validate_registry_dataset(entities):
    modern=[r for r in entities if r.get('base_source')==BASE_SOURCE]
    if not modern:
        return
    if len(modern)!=len(entities) or len({r['transition_sha256'] for r in modern})!=1 or len({r['transition_row'] for r in modern})!=len(modern):
        raise ValueError('Новый реестр должен целиком происходить из одного опросника RUNUP')
    children={}
    for r in modern:
        if r['category']=='ФП':
            children.setdefault(r.get('parent_id'),set()).add(r['id_ke'])
    for r in modern:
        if r['category']=='АС' and {c['id_ke'] for c in json.loads(r['fp_registry_children_json'])}!=children.get(r['id_ke'],set()):
            raise ValueError('Состав АС должен включать только ФП базового опросника RUNUP: '+r['id_ke'])
