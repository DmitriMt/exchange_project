"""Prepare missing PSHE model inputs from the supplied RSM and reference data."""
import collections
import json
from pathlib import Path
import re
import zipfile

from pshe_model import norm, predict

ROOT = Path(__file__).resolve().parent


def complete_pshe(entities, folder, cache_path=None, progress=print):
    model = json.loads((ROOT / 'model_v4_3.json').read_text())
    targets = {k: e for k, e in entities.items() if any(not e.get(field) for field in ('pshe_change_main','pshe_run_main','pshe_change_prom','pshe_run_prom','pshe_change_standin','pshe_run_standin','pshe_vendor_standin'))}
    if not targets:
        return
    def empty():
        return dict(rows=0, servers=set(), dbs=set(), envs=set(), products=set())
    both = collections.defaultdict(empty)
    prom = collections.defaultdict(empty)
    files = [folder / 'РСМ ДЭШ_1.xlsx', folder / 'РСМ ДЭШ_2.xlsx']
    signature = dict(files=[(p.name, p.stat().st_size, p.stat().st_mtime_ns) for p in files], targets=sorted(targets))
    cache = cache_path or ROOT / 'data' / 'model_inputs_cache.json'
    cache.parent.mkdir(parents=True, exist_ok=True)
    stored = json.loads(cache.read_text()) if cache.exists() else None
    if stored and stored['signature'] == json.loads(json.dumps(signature)):
        inputs = stored['inputs']
    else:
        try:
            from lxml import etree as ET
            def nodes(stream, tag):
                yield from ET.iterparse(stream, events=('end',), tag=tag, resolve_entities=False, no_network=True)
        except ImportError:
            from xml.etree import ElementTree as ET
            def nodes(stream, tag):
                iterator = ET.iterparse(stream, events=('start', 'end'))
                _, root = next(iterator)
                stack = [root]
                for event, element in iterator:
                    if event == 'start':
                        stack.append(element)
                    else:
                        if element.tag == tag:
                            yield event, element
                            element.clear()
                            if len(stack) > 1:
                                stack[-2].remove(element)
                        stack.pop()
        ns = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
        for path in files:
            progress('Ресурсы для ПШЕ: ' + path.name)
            with zipfile.ZipFile(path) as book:
                strings = []
                with book.open('xl/sharedStrings.xml') as stream:
                    for _, el in nodes(stream, ns + 'si'):
                        strings.append(''.join(t.text or '' for t in el.iter(ns + 't')))
                        el.clear()
                        while hasattr(el, 'getprevious') and el.getprevious() is not None:
                            del el.getparent()[0]
                def value(cell):
                    v = cell.find(ns + 'v')
                    return strings[int(v.text)] if v is not None and cell.get('t') == 's' else v.text if v is not None else ''
                with book.open('xl/worksheets/sheet1.xml') as stream:
                    for _, el in nodes(stream, ns + 'row'):
                        r = {re.sub(r'\d', '', c.get('r')): value(c) for c in el if re.sub(r'\d', '', c.get('r')) in ['D', 'L', 'N', 'O', 'P', 'T', 'W']}
                        if el.get('r') == '1' and (r.get('D') != 'АС КЭ' or r.get('L') != 'ФП КЭ' or r.get('N') != 'Стенд Тип'):
                            raise ValueError(path.name + ': структура РСМ не распознана')
                        fp = r.get('L', '')
                        key = fp if fp.startswith('CI') else r.get('D', '')
                        env = norm(r.get('N'))
                        is_prod = env.startswith('пром') and 'stand' not in env and 'si' not in env and 'резерв' not in env
                        is_standin = 'stand' in env or 'пром-si' in env
                        if key in targets and (is_prod or is_standin) and norm(r.get('W')) not in ['выведен', 'выведена', 'decommissioned', 'retired']:
                            for acc in [both[key]] + ([prom[key]] if is_prod else []):
                                acc['rows'] += 1
                                acc['envs'].add(env)
                                if r.get('T', '').startswith('CI'):
                                    acc['servers'].add(r['T'])
                                if r.get('P', '').startswith('CI'):
                                    acc['dbs'].add((env, r['P']))
                                if r.get('O') and r['O'] != '-':
                                    acc['products'].add(norm(r['O']))
                        el.clear()
                        while hasattr(el, 'getprevious') and el.getprevious() is not None:
                            del el.getparent()[0]
        weights = json.loads((ROOT / 'model_weights.json').read_text())
        structure = json.loads((ROOT / 'model_structure.json').read_text())
        inputs = {}
        for ci, entity in targets.items():
            variants = {}
            for key, acc in [('both', both[ci]), ('prom', prom[ci])]:
                ps = sorted(acc['products'])
                vals = [weights[p] for p in ps if p in weights]
                n = dict(resource_present=int(bool(acc['rows'])))
                if acc['rows']:
                    n.update(n_servers=len(acc['servers']), n_dbs=len(acc['dbs']), n_environments=len(acc['envs']), n_products=len(ps))
                n.update(tech_weight_sum=sum(vals) if vals else None, tech_weight_max=max(vals) if vals else None,
                         tech_complex_products=sum(v >= 2 for v in vals) if vals else None,
                         tech_unknown_products=len(set(ps) - weights.keys()) if ps else None,
                         tech_mapping_coverage=len(set(ps) & weights.keys()) / len(ps) if ps else None)
                n.update(structure.get(ci, {k: None for k in ['catalog_prod_fp', 'catalog_prod_modules', 'catalog_prod_submodules']}))
                variants[key] = dict(numeric=n, products=ps)
            variants['prom_absent'] = bool(both[ci]['rows'] and not prom[ci]['rows'])
            inputs[ci] = variants
        cache.write_text(json.dumps(dict(signature=signature, inputs=inputs), ensure_ascii=False))
    for ci, e in targets.items():
        record = dict(type=e['category'], criticality=e['criticality'], block=e['dit'])
        for variant, suffix in [('both', 'main'), ('prom', 'prom')]:
            methods = []
            for target, label in [('own', 'change'), ('run', 'run')]:
                if variant == 'prom' and inputs[ci]['prom_absent']:
                    amount, method = 0., 'Нет ПРОМ-ресурсов · подтверждено РСМ'
                else:
                    amount, method = predict(record, inputs[ci][variant], model['models'][target])
                field = f'pshe_{label}_{suffix}'
                if not e.get(field):
                    e[field] = format(amount, '.15g')
                methods.append(method)
            e['pshe_status' if suffix == 'main' else 'pshe_prom_status'] = ' / '.join(sorted(set(methods)))
        e['pshe_source_change'] = e['pshe_source_run'] = e['pshe_status']
        e['pshe_model_inputs'] = json.dumps(inputs[ci], ensure_ascii=False, separators=(',', ':'))
        for target, label in [('own', 'change'), ('run', 'run'), ('vendor', 'vendor')]:
            amount, _ = predict(record, inputs[ci]['both'], model['models'][target])
            if not e.get(f'pshe_{label}_standin'):
                e[f'pshe_{label}_standin'] = format(amount, '.15g')
    progress('ПШЕ дополнены для ' + str(len(targets)) + ' объектов')
