import csv
import io
import json
from pathlib import Path
import unittest
import tempfile
from state_store import StateStore
from ownership import enrich_ownership, validate_ownership
from prepare_data import FIELDS, LEGACY_FIELDS
from server import parse_data

ROOT = Path(__file__).resolve().parent

class OwnershipTests(unittest.TestCase):
    def catalog(self):
        def row(ci, fp=False, parent='', criticality='Mission Critical', block='Блок А', tribe='Т1', life='Промышленная эксплуатация'):
            return dict(A=ci, B='Объект '+ci, G='Функциональная подсистема' if fp else 'Автоматизированные системы', H=parent, M=life, S=criticality, BF=block, BG='Подразделение '+block, BJ='Код '+block, BK='Трайб '+tribe, BM=tribe)
        values=[row('CI100'),row('CI101',True,'АС (CI100)',criticality='Business Critical'),row('CI102',True,'АС (CI100)',block='Блок Б'),row('CI103',True,'АС (CI100)',tribe='Т2'),row('CI104',True,'АС (CI100)',criticality='Business Operational'),row('CI105',True,'АС (CI100)',life='Тест'),row('CI200',criticality='Business Operational',block='Блок Б'),row('CI106',True,'АС (CI200)'),row('CI107',True,'АС (CI999)')]
        return {r['A']:r for r in values}

    def test_full_composition_cross_owner_and_parent_outside_perimeter(self):
        catalog=self.catalog()
        entities={ci:dict(record_type='entity',id_ke=ci,name=r['B'],category='ФП' if r['G']=='Функциональная подсистема' else 'АС',criticality='BC' if ci=='CI101' else 'MC') for ci,r in catalog.items() if ci not in ('CI104','CI105','CI200')}
        enrich_ownership(entities,catalog)
        parent=entities['CI100']
        self.assertEqual(parent['fp_prom_total'],'4')
        self.assertEqual(parent['fp_scope_total'],'3')
        children=json.loads(parent['fp_children_json'])
        self.assertEqual({c['id_ke'] for c in children},{'CI101','CI102','CI103','CI104'})
        self.assertEqual(entities['CI102']['owner_department'],'Подразделение Блок Б')
        self.assertEqual(entities['CI102']['parent_business_block'],'Блок А')
        self.assertEqual(entities['CI103']['owner_tribe_code'],'Т2')
        self.assertEqual(entities['CI103']['parent_owner_tribe_code'],'Т1')
        self.assertEqual(entities['CI101']['criticality'],'BC')
        self.assertEqual(entities['CI106']['parent_in_scope'],'0')
        self.assertEqual(entities['CI106']['parent_name'],'Объект CI200')
        self.assertEqual(entities['CI106']['parent_fp_prom_total'],'1')
        self.assertEqual(entities['CI107']['parent_id'],'CI999')
        self.assertEqual(entities['CI107']['parent_name'],'')
        for e in entities.values():validate_ownership(e)
        with self.assertRaises(ValueError):validate_ownership(dict(parent,fp_prom_total='3'))
        with self.assertRaises(ValueError):validate_ownership(dict(parent,fp_scope_total='5'))

    def test_legacy_csv_keeps_unknown_history_and_bad_composition_rejected(self):
        rows=parse_data((ROOT/'data/dashboard.csv').read_bytes())
        def encode(records,fields):
            out=io.StringIO();writer=csv.DictWriter(out,fieldnames=fields,delimiter=';',extrasaction='ignore');writer.writeheader();writer.writerows(records);return out.getvalue().encode('utf-8-sig')
        legacy_raw=encode(rows,LEGACY_FIELDS)
        with tempfile.TemporaryDirectory() as folder:
            store=StateStore(Path(folder)/'state.sqlite3')
            key=store.commit(legacy_raw,parse_data(legacy_raw),'Old','2026-11-02','')
            snapshot=store.snapshot(key)
            backup={'format':'multicod-history','version':1,'snapshots':[dict(snapshot,csv=legacy_raw.decode('utf-8-sig'))],'workspace':{}}
            self.assertEqual(store.import_backup(backup,'admin',parse_data,FIELDS)['added'],0)
            self.assertEqual(store.snapshot(key)['csv'],legacy_raw)
        old=parse_data(legacy_raw)
        self.assertEqual(len(old),len(rows))
        self.assertTrue(all(r['owner_tribe_code']=='' and r['fp_prom_total']=='' for r in old))
        parent=next(r for r in rows if r['record_type']=='entity' and r['category']=='АС' and r['fp_children_json']!='[]')
        children=json.loads(parent['fp_children_json']);children[0]['parent_id']='CI999999'
        parent['fp_children_json']=json.dumps(children)
        with self.assertRaisesRegex(ValueError,'состав ФП'):parse_data(encode(rows,FIELDS))

if __name__=='__main__':unittest.main()
