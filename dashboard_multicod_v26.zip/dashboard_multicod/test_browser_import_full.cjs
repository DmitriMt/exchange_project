// Full, offline cross-check of the browser importer against shipped Python-prepared data.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const directory=process.env.MULTICOD_SOURCES||'/Users/evgeny/ChatGPT/Dash Мультицод+';
const expectedPath=process.env.MULTICOD_EXPECTED_CSV||path.join(__dirname,'data/dashboard.csv');
const modelOnly=process.env.MULTICOD_MODEL_ONLY==='1';
const readJson=n=>JSON.parse(fs.readFileSync(path.join(__dirname,n),'utf8'));
const fields=fs.readFileSync(path.join(__dirname,'data/dashboard.csv'),'utf8').replace(/^\uFEFF/,'').split(/\r?\n/)[0].split(';');
const runtime=fs.readFileSync(path.join(__dirname,'web/model_runtime.js'),'utf8'),core=fs.readFileSync(path.join(__dirname,'web/browser_import_core.js'),'utf8');
const context={Blob,File,DecompressionStream,TextDecoder,Uint8Array,Uint32Array,DataView,BigInt,Map,Set,JSON,Date,Number,String,Math,RegExp,Object,console,crypto:globalThis.crypto};vm.createContext(context);vm.runInContext(fs.readFileSync(path.join(__dirname,'vendor/pako_inflate.min.js'),'utf8')+'\nconst PSHE_MODEL='+JSON.stringify(readJson('model_v4_3.json'))+';\n'+runtime+'\n'+core+'\n'+fs.readFileSync(path.join(__dirname,'web/transition_core.js'),'utf8'),context);
(async()=>{
 const files={},names={catalog:fs.readdirSync(directory).find(n=>/^table_runup_DS_main_Katalog_IT-uslug_20261102_/.test(n)),wallet:'Кошельки.xlsx',pshe:fs.readdirSync(directory).find(n=>/^Калькулятор_ПШЕ.*\.xlsx$/.test(n)),as_list:'Выгрузка АС.xlsx',rsm1:'РСМ ДЭШ_1.xlsx',rsm2:'РСМ ДЭШ_2.xlsx',questionnaire:'Опросник перехода.xlsx'};
 if(modelOnly){delete names.pshe;delete names.as_list;}
 for(const [role,name]of Object.entries(names)){const blob=await fs.openAsBlob(path.join(directory,name));files[role]=new File([blob],name);}
 context.files=files;context.prepareDate=process.env.MULTICOD_DATE||'2026-11-03';context.config={fields,weights:readJson('model_weights.json'),structure:readJson('model_structure.json')};context.progress=s=>console.log(s);
 const result=await vm.runInContext("prepareBrowser(files,prepareDate,config,progress)",context);
 console.log('REPORT',JSON.stringify({...result.report,transition:result.report.transition?{...result.report.transition,outside:result.report.transition.outside.length}:null}));assert.equal(result.report.entities,1415);assert.equal(result.report.as_count,422);assert.equal(result.report.fp_count,993);assert.equal(result.report.fp_without_rsm,122);assert.equal(result.report.budget_rows,8699);assert.equal(result.report.outside_rows,1775);assert.equal(result.report.model_added,modelOnly?1415:167);
 context.expectedCsv=fs.readFileSync(expectedPath,'utf8');
 vm.runInContext('const LOCAL_FIELDS='+JSON.stringify(fields)+';\n'+fs.readFileSync(path.join(__dirname,'offline_adapter.js'),'utf8').split('let localRows=')[0],context);
 const expected=vm.runInContext('parseLocalCsv(expectedCsv)',context);assert.equal(expected.length,result.rows.length);
 const numeric=new Set(['budget_rub','cpu','ram_gb','disk_gb']);
 for(let i=0;i<expected.length;i++)for(const key of fields){const a=expected[i][key],b=result.rows[i][key];
  if(key==='in_as_list'){assert.equal(b,result.rows[i].record_type==='budget_outside'?'0':'1');continue;} // Deprecated flag: RUNUP now defines the roster.
  if(['fp_children_json','pshe_model_inputs'].includes(key)&&a&&b)assert.deepStrictEqual(JSON.parse(b),JSON.parse(a),key+' '+i);
  else if(numeric.has(key)&&a&&b){context.a=a;context.b=b;assert(vm.runInContext('(()=>{const x=bxDecimal(a),y=bxDecimal(b),s=Math.max(x.scale,y.scale);return x.n*10n**BigInt(s-x.scale)===y.n*10n**BigInt(s-y.scale);})()',context),key+' '+i);}
  else if(/^pshe_(change|run|vendor)_/.test(key)&&a&&b)assert(Math.abs(Number(a)-Number(b))<=Math.max(1e-9,Math.abs(Number(a))*1e-11),key+' '+i);
  else assert.equal(b,a,key+' '+i);
 }
 console.log('All '+expected.length+' rows and fields match the Python-prepared CSV.');
 const output=process.env.MULTICOD_BROWSER_RESULT||'/tmp/multicod_browser_import_v15.json';fs.writeFileSync(output,JSON.stringify(result));console.log('PASS full browser pipeline:',output);
})().catch(e=>{console.error(e);process.exitCode=1;});
