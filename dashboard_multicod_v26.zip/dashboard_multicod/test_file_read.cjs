const fs=require('fs'),vm=require('vm'),assert=require('assert');
const c={setTimeout,clearTimeout,TextDecoder,console};vm.createContext(c);vm.runInContext(fs.readFileSync(__dirname+'/web/file_read.js','utf8'),c);
(async()=>{
 const snapshot=vm.runInContext('snapshotLocalFile',c);const data=new Uint8Array([1,2,3,4]).buffer;let calls=0,readers=0;
 const ordinary={name:'Опросник.xlsx',size:4,type:'application/test',lastModified:123,arrayBuffer:async()=>{calls++;return data.slice(0);}};
 const copy=await snapshot(ordinary);assert.equal(calls,1);assert.equal(copy.bytes.byteLength,4);assert.equal(copy.name,ordinary.name);assert.equal(copy.lastModified,123);assert(!('slice' in copy));
 c.FileReader=class{readAsArrayBuffer(file){readers++;this.result=data.slice(0);queueMicrotask(()=>this.onload());}};
 const unavailable={...ordinary,arrayBuffer:async()=>{throw new Error('The I/O read operation failed.');}};
 const recovered=await snapshot(unavailable);assert.equal(readers,1);assert.equal(recovered.bytes.byteLength,4);
 c.FileReader=class{readAsArrayBuffer(){this.error=new Error('NotReadableError');queueMicrotask(()=>this.onerror());}};
 await assert.rejects(snapshot(unavailable),e=>e.name==='LocalFileReadError'&&e.message.includes('Загрузки')&&e.message.includes('не изменены'));
 let attempt=0;c.FileReader=undefined;const transient={...ordinary,arrayBuffer:async()=>{if(++attempt===1)throw new Error('I/O read failed');return data.slice(0);}};
 assert.equal((await snapshot(transient)).bytes.byteLength,4);assert.equal(attempt,2);
 await assert.rejects(snapshot({...ordinary,arrayBuffer:async()=>new ArrayBuffer(2)}),/Не удалось прочитать/);
 console.log('PASS: one-time memory snapshot, FileReader recovery, bounded retries, changed-size rejection and actionable Russian read errors.');
})().catch(e=>{console.error(e);process.exitCode=1;});
