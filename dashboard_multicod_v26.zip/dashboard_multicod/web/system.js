'use strict';
// The server owns shared data. The browser only owns presentation state.
let tableSettings={},gridInstances=[],preferenceReady=false,preferenceTimer=null,preferenceGeneration=0;
let overviewMeasure='budget_rub',groupMeasure='budget_rub',backupDirectory=null;
const postJson=(path,value)=>api(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(value)});
function numericCell(cell){
  const exact=cell.querySelector('[data-number]');if(exact)return Number(exact.dataset.number);
  const t=cell.textContent.trim().replace(/[\s\u00a0\u202f]/g,'').replace(',','.');
  return /^[-+]?\d+(\.\d+)?$/.test(t)?Number(t):null;
}
function matchesColumn(text,number,query){
  query=query.trim();if(!query)return true;
  const compare=query.match(/^(>=|<=|!=|>|<|=)\s*(.*)$/);
  if(compare){const op=compare[1],v=compare[2].replace(/\s/g,'').replace(',','.');
    if(number!==null&&v!==''&&Number.isFinite(Number(v))){const n=Number(v);return op==='>='?number>=n:op==='<='?number<=n:op==='>'?number>n:op==='<'?number<n:op==='!='?number!==n:number===n;}
    const equal=text.trim().toLocaleLowerCase('ru')===compare[2].trim().toLocaleLowerCase('ru');return op==='!='?!equal:op==='='&&equal;
  }
  const range=query.match(/^(-?[\d\s.,]+)\.\.(-?[\d\s.,]+)$/);if(range&&number!==null)return number>=Number(range[1].replace(/\s/g,'').replace(',','.'))&&number<=Number(range[2].replace(/\s/g,'').replace(',','.'));
  return text.toLocaleLowerCase('ru').includes(query.toLocaleLowerCase('ru'));
}
function gridData(grid){return [grid.headers,...grid.filtered.map(row=>Array.from(row.cells).map(cell=>numericCell(cell)??cell.textContent.trim()))];}
function enhanceTables(root=document){
  const occurrence={};
  root.querySelectorAll('table:not([data-grid])').forEach(t=>{
    const head=t.tHead?.rows[0];if(!head||!t.tBodies[0])return;
    const headers=Array.from(head.cells).map(h=>h.textContent.trim());
    const scope=t.closest('dialog')?'dialog:'+($('stateDialog')?.querySelector('h2')?.textContent||''):page;
    const parent=t.closest('details,.panel');const title=parent?.querySelector('h2,h3,summary')?.textContent.trim()||'';
    const base=scope+'|'+title+'|'+headers.join('|'),i=occurrence[base]||0;occurrence[base]=i+1;
    const key=base+'|'+i;t.dataset.grid=key;
    const saved=tableSettings[key]||{};const settings={filters:saved.filters&&typeof saved.filters==='object'?saved.filters:{},sort:Number.isInteger(saved.sort)&&saved.sort>=0&&saved.sort<headers.length?saved.sort:-1,direction:saved.direction===-1?-1:1};tableSettings[key]=settings;
    const body=t.tBodies[0],all=Array.from(body.rows).filter(r=>r.cells.length===headers.length&&r.cells[0].colSpan===1);
    const footer=all.filter(r=>/^Всего$/.test(r.cells[0].textContent.trim()));
    const records=all.filter(r=>!footer.includes(r));
    Array.from(body.rows).filter(r=>!all.includes(r)).forEach(r=>r.remove());
    const grid={key,headers,settings,records,filtered:records,position:0,table:t};gridInstances.push(grid);
    const filters=document.createElement('tr');filters.className='column-filters';
    head.parentNode.append(filters);
    headers.forEach((h,n)=>{
      const cell=head.cells[n],button=document.createElement('button');button.className='column-sort';button.textContent=h+' ↕';button.title='Сортировать по полю «'+h+'»';cell.textContent='';cell.append(button);
      button.onclick=()=>{settings.direction=settings.sort===n?-settings.direction:1;settings.sort=n;grid.position=0;apply();savePreferencesSoon();};
      const td=document.createElement('th'),input=document.createElement('input');input.type='search';input.placeholder='Фильтр';input.setAttribute('aria-label','Фильтр: '+h);input.title='Текст, =значение, !=значение, >10, <=20, 10..20';input.value=settings.filters[n]||'';td.append(input);filters.append(td);
      input.oninput=()=>{settings.filters[n]=input.value;grid.position=0;apply();savePreferencesSoon();};
    });
    const controls=document.createElement('div');controls.className='grid-controls';
    const status=document.createElement('span'),prev=document.createElement('button'),next=document.createElement('button'),reset=document.createElement('button'),download=document.createElement('button'),unsort=document.createElement('button');
    prev.textContent='Назад';next.textContent='Далее';reset.textContent='Сбросить фильтры таблицы';download.textContent='Скачать таблицу в Excel';
    unsort.textContent='Сбросить сортировку';unsort.onclick=()=>{settings.sort=-1;grid.position=0;apply();savePreferencesSoon();};controls.append(status,prev,next,reset,unsort,download);t.closest('.scroll')?.after(controls);
    function apply(){
      grid.filtered=records.filter(r=>Object.entries(settings.filters).every(([n,q])=>!q||matchesColumn(r.cells[n]?.textContent||'',r.cells[n]?numericCell(r.cells[n]):null,String(q))));
      if(settings.sort>=0){const n=settings.sort;grid.filtered.sort((a,b)=>{const av=numericCell(a.cells[n]),bv=numericCell(b.cells[n]);return settings.direction*(av!==null&&bv!==null?av-bv:a.cells[n].textContent.localeCompare(b.cells[n].textContent,'ru',{numeric:true}));});}
      records.forEach(r=>r.hidden=true);grid.position=Math.min(grid.position,Math.max(0,Math.ceil(grid.filtered.length/40)-1));
      grid.filtered.forEach((r,index)=>{body.append(r);r.hidden=index<grid.position*40||index>=(grid.position+1)*40;});
      footer.forEach(r=>{body.append(r);r.hidden=Object.values(settings.filters).some(Boolean);});
      status.textContent=`${grid.filtered.length?grid.position*40+1:0}–${Math.min((grid.position+1)*40,grid.filtered.length)} из ${grid.filtered.length} · до фильтров ${records.length}`;
      prev.disabled=grid.position===0;next.disabled=(grid.position+1)*40>=grid.filtered.length;
      Array.from(head.cells).forEach((h,n)=>{h.setAttribute('aria-sort',settings.sort===n?(settings.direction===1?'ascending':'descending'):'none');h.firstChild.textContent=headers[n]+(settings.sort===n?(settings.direction===1?' ↑':' ↓'):' ↕');});
      activeFilterPanel();
    }
    grid.apply=apply;prev.onclick=()=>{grid.position--;apply();};next.onclick=()=>{grid.position++;apply();};
    reset.onclick=()=>{settings.filters={};Array.from(filters.querySelectorAll('input')).forEach(v=>v.value='');apply();savePreferencesSoon();};
    download.onclick=()=>saveBlob(makeXlsx([{name:'Таблица',rows:gridData(grid)},exportParams(filtered(),false)]),'МультиЦОД_таблица.xlsx');
    apply();
  });
  document.querySelectorAll('.pager:not(.grid-controls)').forEach(el=>el.hidden=true);
}
const globalFilterLabels={block:'Бизнес-блок',dit:'ДИТ',category:'Тип объекта',criticality:'Критичность',search:'Поиск'};
function activeFilterPanel(){
  let panel=$('activeFilters');if(!panel){panel=document.createElement('div');panel.id='activeFilters';$('versionBar').before(panel);}
  panel.innerHTML='<strong>Установленные фильтры</strong>';let count=0;
  const chip=(text,fn)=>{count++;const b=document.createElement('button');b.className='filter-chip';b.textContent=text+' ×';b.onclick=fn;panel.append(b);};
  for(const [key,label]of Object.entries(globalFilterLabels))if($(key).value)chip(label+': '+$(key).value,()=>{$(key).value='';render();});
  if(planningStatus)chip('Статус плана: '+planningStatus,()=>{planningStatus='';render();});
  if(drill)chip('КТС: '+drill.value+(drill.dit?' · '+drill.dit:''),()=>{drill=null;render();});
  gridInstances.forEach(g=>Object.entries(g.settings.filters).forEach(([n,q])=>{if(q)chip((g.headers[n]||n)+': '+q,()=>{delete g.settings.filters[n];g.table.querySelectorAll('.column-filters input')[n].value='';g.apply();savePreferencesSoon();});}));
  if(!count){const s=document.createElement('span');s.textContent='Нет · показан весь выбранный срез';panel.append(s);}
  const reset=document.createElement('button');reset.className='primary';reset.textContent='Сбросить все фильтры';reset.onclick=resetAllFilters;panel.append(reset);
}
function resetAllFilters(){for(const key of stateFields)$(key).value='';$('asList').checked=false;planningStatus='';drill=null;for(const value of Object.values(tableSettings))value.filters={};offset=0;render();savePreferencesSoon();}
function preferenceValue(){return {filters:filtersValue(),tables:tableSettings,overviewMeasure,groupMeasure};}
function savePreferencesSoon(){if(!preferenceReady)return;clearTimeout(preferenceTimer);const generation=preferenceGeneration,user=currentUser,value=preferenceValue();preferenceTimer=setTimeout(()=>{if(generation!==preferenceGeneration||user!==currentUser)return;if(stateRepo instanceof ServerRepo)postJson('/api/preferences',value).catch(stateError);else stateRepo.batch([['settings','preferences:'+user,value]]).catch(stateError);},400);}
const systemCleanView=cleanView;
cleanView=function(v){const value=systemCleanView(v);if(v?.tables&&typeof v.tables==='object')value.tables=JSON.parse(JSON.stringify(v.tables));if(measures[v?.overviewMeasure])value.overviewMeasure=v.overviewMeasure;if(measures[v?.groupMeasure])value.groupMeasure=v.groupMeasure;return value;};
const systemFiltersValue=filtersValue;
filtersValue=function(){return {...systemFiltersValue(),tables:JSON.parse(JSON.stringify(tableSettings)),overviewMeasure,groupMeasure};};
const systemApplyView=applySavedView;
applySavedView=async function(value){tableSettings=value.tables||{};overviewMeasure=value.overviewMeasure||'budget_rub';groupMeasure=value.groupMeasure||'budget_rub';return systemApplyView(value);};
const systemStateInit=stateInit;
stateInit=async function(){preferenceReady=false;await systemStateInit();const value=stateRepo instanceof ServerRepo?await api('/api/preferences'):await stateRepo.get('settings','preferences:'+currentUser);tableSettings=value?.tables||{};overviewMeasure=value?.overviewMeasure||'budget_rub';groupMeasure=value?.groupMeasure||'budget_rub';if(value?.filters)await applySavedView({...value.filters,tables:tableSettings,overviewMeasure,groupMeasure});preferenceReady=true;render();};
const systemClear=clearUserPanels;
clearUserPanels=function(){preferenceReady=false;preferenceGeneration++;clearTimeout(preferenceTimer);tableSettings={};gridInstances=[];overviewMeasure=groupMeasure='budget_rub';backupDirectory=null;$('activeFilters')?.remove();for(const key of stateFields)$(key).value='';$('asList').checked=false;planningStatus='';drill=null;systemClear();};
function resourceControl(scope,value){return `<label class="local-resource">Показатель ресурсов<select data-resource="${scope}">${Object.entries(measures).map(([k,v])=>`<option value="${k}" ${k===value?'selected':''}>${esc(v.label)}, ${esc(v.unit)}</option>`).join('')}</select></label>`;}
const systemSummary=summary;
summary=function(es,bs){const saved=measure;measure=overviewMeasure;let html=systemSummary(es,bs);measure=saved;return html.replace('<div class="metric "><div class="label">'+(overviewMeasure==='budget_rub'?'Годовая стоимость КТС':measures[overviewMeasure].label),'<div class="metric ">'+resourceControl('overview',overviewMeasure)+'<div class="label">'+(overviewMeasure==='budget_rub'?'Годовая стоимость КТС':measures[overviewMeasure].label));};
const systemGroups=groups;
groups=function(es,bs){const saved=measure;measure=groupMeasure;const html=systemGroups(es,bs);measure=saved;return resourceControl('groups',groupMeasure)+html;};
const systemRender=render;
render=function(){gridInstances=[];systemRender();if(!document.querySelectorAll)return;const label=$('measure')?.closest('label');if(label)label.hidden=true;
  if(page==='kts')$('content').insertAdjacentHTML('afterbegin',resourceControl('kts',measure));
  document.querySelectorAll('[data-resource]').forEach(el=>el.onchange=()=>{if(el.dataset.resource==='overview')overviewMeasure=el.value;else if(el.dataset.resource==='groups')groupMeasure=el.value;else{measure=el.value;$('measure').value=measure;}render();});
  enhanceTables($('content'));activeFilterPanel();$('reset').textContent='Сбросить все фильтры';$('reset').onclick=resetAllFilters;
  document.querySelectorAll('[data-section="update"],nav [data-page="update"]').forEach(b=>b.hidden=!canLoad);
  $('uploadButton').hidden=!canLoad;if(stateRepo instanceof ServerRepo){$('user').textContent=currentUser+' · '+(currentRole==='operator'?'Оператор':canEdit?'Админ':'Пользователь');let b=$('administration');if(!b){b=document.createElement('button');b.id='administration';b.textContent='Администрирование';document.querySelector('.aside-bottom').append(b);}b.hidden=!canEdit;b.onclick=()=>openAdministration().catch(stateError);}
  savePreferencesSoon();};
const systemModal=stateModal;
stateModal=function(title,body){gridInstances=gridInstances.filter(g=>!g.table.closest('dialog'));const d=systemModal(title,body);enhanceTables(d);d.addEventListener('close',()=>{gridInstances=gridInstances.filter(g=>!g.table.closest('dialog'));activeFilterPanel();},{once:true});return d;};
// When column filters/sorting are active, exports follow the table's full filtered set, not its visible page.
const systemExport=exportWorkbook;
exportWorkbook=function(detailOnly=false){const grids=gridInstances.filter(g=>!g.table.closest('dialog')||detailOnly);if(grids.some(g=>Object.values(g.settings.filters).some(Boolean)||g.settings.sort>=0))return [...grids.map((g,i)=>({name:'Таблица '+(i+1),rows:gridData(g)})),{name:'Фильтры таблиц',rows:[['Таблица','Поле','Условие','Сортировка'],...grids.flatMap((g,i)=>Object.entries(g.settings.filters).filter(([,q])=>q).map(([n,q])=>[i+1,g.headers[n],q,g.settings.sort>=0?g.headers[g.settings.sort]+(g.settings.direction===1?' ↑':' ↓'):'']))]},exportParams(filtered(),detailOnly)];const original=measure;try{if(page==='overview')measure=overviewMeasure;else if(['volume','pshe'].includes(page))measure=groupMeasure;return systemExport(detailOnly);}finally{measure=original;}};
async function openAdministration(){
  const users=await api('/api/admin/users');stateModal('Администрирование',`<h3>Пользователи</h3><p>Пользователь читает и скачивает данные, сохраняет собственные фильтры и закладки. Оператор загружает исходные файлы, проверяет и добавляет срезы. Админ также редактирует планы и управляет пользователями.</p>${table(['Логин','Роль','Доступ','Действие'],users.map(u=>`<tr><td>${esc(u.name)}</td><td>${u.role==='admin'?'Админ':u.role==='operator'?'Оператор':'Пользователь'}</td><td>${u.active?'Включён':'Отключён'}</td><td><button data-user="${esc(u.name)}">Изменить</button></td></tr>`).join(''))}<form id="userEditor"><h3 id="userEditorTitle">Добавить пользователя</h3><label>Логин<input id="accountName" required maxlength="80" autocomplete="off"></label><label>Роль<select id="accountRole"><option value="user">Пользователь</option><option value="operator">Оператор</option><option value="admin">Админ</option></select></label><label>Пароль (от 12 символов; при изменении можно оставить пустым)<input id="accountPassword" type="password" autocomplete="new-password"></label><label><input type="checkbox" id="accountActive" checked> Доступ включён</label><button type="submit" class="primary">Сохранить пользователя</button></form><h3>Резервное копирование перед загрузкой</h3><p>Серверная папка: data/backups. Копии SQLite сохраняются перед добавлением срезов. Автоматическое удаление отключено.</p><button id="selectBackupDirectory">Выбрать папку на устройстве админа</button><p class="note">Если браузер не поддерживает выбор папки, перед каждой загрузкой потребуется скачать копию и выбрать сохранённый файл для проверки. Не закрывайте страницу до завершения записи.</p>`);
  document.querySelectorAll('[data-user]').forEach(b=>b.onclick=()=>{const u=users.find(u=>u.name===b.dataset.user);$('accountName').value=u.name;$('accountRole').value=u.role;$('accountActive').checked=Boolean(u.active);$('accountPassword').value='';$('userEditorTitle').textContent='Изменить пользователя';});
  $('userEditor').onsubmit=async e=>{e.preventDefault();try{await postJson('/api/admin/users',{name:$('accountName').value,role:$('accountRole').value,password:$('accountPassword').value,active:$('accountActive').checked});await openAdministration();message('Пользователь сохранён');}catch(e){stateError(e);}};
  $('selectBackupDirectory').onclick=async()=>{try{if(!window.showDirectoryPicker)throw new Error('Этот браузер использует скачивание и проверку сохранённого файла перед каждой загрузкой');backupDirectory=await window.showDirectoryPicker({mode:'readwrite'});await rememberBackupDirectory(backupDirectory);message('Папка резервных копий выбрана: '+backupDirectory.name);}catch(e){stateError(e);}};
}
async function backupHandleDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open('multicod-backup-folders',1);r.onupgradeneeded=()=>r.result.createObjectStore('folders');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
async function rememberBackupDirectory(handle){const db=await backupHandleDB();await new Promise((resolve,reject)=>{const t=db.transaction('folders','readwrite');t.objectStore('folders').put(handle,currentUser);t.oncomplete=resolve;t.onerror=()=>reject(t.error);});db.close();}
async function savedBackupDirectory(){try{const db=await backupHandleDB();const handle=await new Promise((resolve,reject)=>{const r=db.transaction('folders').objectStore('folders').get(currentUser);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});db.close();return handle;}catch{return null;}}
async function sha256(buffer){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',buffer)),b=>b.toString(16).padStart(2,'0')).join('');}
async function ensurePreloadBackup(base){
  if(!(stateRepo instanceof ServerRepo)||!canLoad)throw new Error('Добавлять данные могут оператор и админ серверной версии');
  const receipt=await postJson('/api/admin/backups/prepare',{base});
  const response=await fetch('/api/admin/backups/file/'+receipt.id,{headers:{Authorization:auth}});if(!response.ok)throw new Error('Не удалось получить серверную копию');const bytes=await response.arrayBuffer();
  if(bytes.byteLength!==receipt.bytes||await sha256(bytes)!==receipt.sha256)throw new Error('Серверная копия не прошла проверку');
  backupDirectory=backupDirectory||await savedBackupDirectory();let verified=false;
  if(backupDirectory){try{if(await backupDirectory.queryPermission({mode:'readwrite'})!=='granted'&&await backupDirectory.requestPermission({mode:'readwrite'})!=='granted')throw new Error('Нет доступа к папке');const h=await backupDirectory.getFileHandle(receipt.filename,{create:true}),w=await h.createWritable();await w.write(bytes);await w.close();const saved=await h.getFile();verified=saved.size===receipt.bytes&&await sha256(await saved.arrayBuffer())===receipt.sha256;}catch{verified=false;}}
  if(!verified)await new Promise((resolve,reject)=>{
    stateModal('Сохранить резервную копию перед загрузкой',`<p>Серверная копия создана. Сохраните её на устройство и выберите сохранённый файл для проверки. Новый срез добавится только после совпадения размера и контрольной суммы.</p><p class="note">Копия содержит всю БД, включая учётные записи. Храните её в закрытой папке админа.</p><button id="downloadDatabaseBackup" class="primary">1. Скачать копию БД</button><label>2. Выбрать сохранённую копию<input id="verifyDatabaseBackup" type="file" accept=".sqlite3"></label><p id="backupCheckMessage" role="status"></p>`);
    const dialog=$('stateDialog');const closed=()=>reject(new Error('Загрузка отменена: копия на устройстве не подтверждена'));dialog.addEventListener('close',closed,{once:true});
    $('downloadDatabaseBackup').onclick=()=>saveBlob(new Blob([bytes],{type:'application/octet-stream'}),receipt.filename);
    $('verifyDatabaseBackup').onchange=async()=>{try{const f=$('verifyDatabaseBackup').files[0];if(!f||f.size!==receipt.bytes||await sha256(await f.arrayBuffer())!==receipt.sha256)throw new Error('Выберите скачанную копию: файл не совпадает');dialog.removeEventListener('close',closed);dialog.close();resolve();}catch(e){$('backupCheckMessage').textContent=e.message;}};
  });
  await postJson('/api/admin/backups/ack',{id:receipt.id,sha256:receipt.sha256});return receipt.id;
}

const systemSameBookmark=sameBookmark;
sameBookmark=function(a,b){return systemSameBookmark(a,b)&&JSON.stringify(a?.tables||{})===JSON.stringify(b?.tables||{})&&(a?.overviewMeasure||'budget_rub')===(b?.overviewMeasure||'budget_rub')&&(a?.groupMeasure||'budget_rub')===(b?.groupMeasure||'budget_rub');};

const systemLogout=$('logout').onclick;
$('logout').onclick=()=>{if(preferenceReady&&stateRepo instanceof ServerRepo){const value=preferenceValue();fetch('/api/preferences',{method:'POST',keepalive:true,headers:{Authorization:auth,'Content-Type':'application/json'},body:JSON.stringify(value)}).catch(()=>{});}systemLogout?.();};

const systemChangeProfile=BrowserRepo.prototype.changeProfile;
BrowserRepo.prototype.changeProfile=async function(name){if(preferenceReady)await this.batch([['settings','preferences:'+this.profile,preferenceValue()]]);const result=await systemChangeProfile.call(this,name);const value=await this.get('settings','preferences:'+this.profile);tableSettings=value?.tables||{};overviewMeasure=value?.overviewMeasure||'budget_rub';groupMeasure=value?.groupMeasure||'budget_rub';for(const k of stateFields)$(k).value=value?.filters?.[k]||'';$('asList').checked=false;planningStatus=value?.filters?.planningStatus||'';drill=null;return result;};
