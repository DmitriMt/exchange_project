'use strict';
function registryInfo(){const current=entities.filter(e=>e.base_source==='RUNUP_QUESTIONNAIRE');return {valid:current.length===entities.length&&entities.length>0,total:entities.length,as:entities.filter(e=>e.category==='АС').length,fp:entities.filter(e=>e.category==='ФП').length,nonProm:entities.filter(e=>e.lifecycle!=='ПРОМ').length,missingCatalog:entities.filter(e=>e.catalog_presence==='0').length,unknownRsm:entities.filter(e=>!['0','1'].includes(e.rsm_presence)).length,file:current[0]?.transition_file||''};}
const registryColumns=['КЭ','Название RUNUP','Тип','ЖЦ RUNUP','Критичность RUNUP','ДИТ RUNUP','Каталог найден','РСМ','Базовый файл','Строка опросника'];
function registryValues(e){return [e.id_ke,e.name,e.category,e.lifecycle,e.criticality,e.dit,e.catalog_presence==='1'?'Да':e.catalog_presence==='0'?'Нет':'Нет проверки',e.rsm_presence==='1'?'Есть':e.rsm_presence==='0'?'Нет в обеих РСМ':'Не проверено',e.transition_file||'Прежний источник',e.transition_row?Number(e.transition_row):null];}
function registryDetails(es){return `<details id="baseRegistryDetails" class="object-fold"><summary>Выборка базового реестра RUNUP · ${fmt(es.length)} КЭ</summary><section class="panel"><h2>Состав определяется только опросником</h2><p>Все АС и ФП из файла, на всех этапах ЖЦ. Дополнительные источники не добавляют и не удаляют КЭ.</p>${table(registryColumns,es.map(e=>`<tr>${registryValues(e).map((v,i)=>`<td>${i===0?`<button class="table-link" data-volume-object="${esc(e.id_ke)}">${esc(v)}</button>`:typeof v==='number'?num(v,0):esc(v??'—')}</td>`).join('')}</tr>`).join(''))}</section></details>`;}
const registryRender=render;render=function(){registryRender();const info=registryInfo();let banner=$('baseRegistryBanner');if(!banner){banner=document.createElement('section');banner.id='baseRegistryBanner';banner.className='registry-banner';$('versionBar').before(banner);}banner.textContent=info.valid?`БАЗОВЫЙ ИСТОЧНИК: ОПРОСНИК RUNUP · ${info.file} · ${fmt(info.total)} КЭ (${fmt(info.as)} АС + ${fmt(info.fp)} ФП) · ${fmt(info.nonProm)} не в ПРОМ. Остальные источники только насыщают эти КЭ.`:'Исторический срез прежней концепции. Для базы из опросника RUNUP загрузите обязательный опросник и пересоберите срез.';if(!info.valid&&canLoad){const migrate=document.createElement('button');migrate.textContent='Пересобрать базу по опроснику RUNUP';migrate.onclick=()=>openQuestionnaireUpload().catch(stateError);banner.append(migrate);}if(page==='quality'){$('content').insertAdjacentHTML('beforeend',registryDetails(filtered()));const block=$('baseRegistryDetails');if(block?.querySelectorAll)enhanceTables(block);bindVolume();}const footer=document.querySelector('main>footer');if(footer)footer.textContent='Состав систем — только из опросника RUNUP. Отсутствие данных в источниках насыщения не исключает КЭ из базы. ФП без КТС — КЭ ФП не найден в обеих РСМ.';};
const registryExport=exportWorkbook;exportWorkbook=function(detail=false){const sheets=registryExport(detail);if(page==='overview'&&!sheets.some(s=>s.name==='Базовый реестр RUNUP'))sheets.push({name:'Базовый реестр RUNUP',rows:[registryColumns,...filtered().map(registryValues)]});return sheets;};
const registryParams=exportParams;exportParams=function(es,detail){const result=registryParams(es,detail);result.rows.push(['Основополагающий источник','Опросник RUNUP: все АС/ФП из файла, независимо от ЖЦ и наличия насыщения'],['Источники насыщения','Добавляют данные к КЭ опросника; не определяют состав базы']);return result;};

const registrySetDataset=setDataset;setDataset=function(data){registrySetDataset(data);const selected=$('criticality').value;$('criticality').innerHTML=opts(entities.map(e=>e.criticality),'Все классы из RUNUP');setFilterValue('criticality',selected);};

// Keep the immutable HTML payload separate from the dataset selected from browser history.
const htmlBaseId='html-embedded-baseline';
let htmlBaseOpened=false;
function htmlBaseData(){
 if(typeof HTML_BASE_CSV==='undefined')return null;
 const records=parseLocalCsv(HTML_BASE_CSV),date=records.find(r=>r.record_type==='entity')?.snapshot||'';
 return {id:htmlBaseId,date,at:LOCAL_UPDATED,name:'Данные, встроенные в этот HTML',rows:records,plans:{},stats:datasetStats(records)};
}
const htmlBaseGetSnapshot=BrowserRepo.prototype.getSnapshot;
BrowserRepo.prototype.getSnapshot=async function(id){if(id===htmlBaseId&&typeof HTML_BASE_CSV!=='undefined')return htmlBaseData();return htmlBaseGetSnapshot.call(this,id);};
function addHtmlBaseVersion(){
 const data=htmlBaseData();if(!data)return;
 if(!versions.some(v=>v.id===htmlBaseId)){const {rows,plans,...meta}=data;versions.push(meta);}
}
async function openHtmlBase(){addHtmlBaseVersion();await selectVersion(htmlBaseId);}
const htmlBaseStateInit=stateInit;
stateInit=async function(){
 await htmlBaseStateInit();
 if(!(stateRepo instanceof BrowserRepo)||typeof HTML_BASE_CSV==='undefined')return;
 const base=htmlBaseData(),different=csvEncode(rows)!==csvEncode(base.rows);
 if(different)addHtmlBaseVersion();
 if(!htmlBaseOpened){htmlBaseOpened=true;const stale=entities.some(e=>e.base_source!=='RUNUP_QUESTIONNAIRE')||entities.filter(e=>e.category==='ФП').every(e=>!['0','1'].includes(e.rsm_presence));
  if(different&&stale){await openHtmlBase();message('Открыт срез из нового HTML. Прежний срез сохранён в истории браузера.');}
 }
 render();
};
const htmlBaseRender=render;
render=function(){
 htmlBaseRender();if(!(stateRepo instanceof BrowserRepo)||typeof HTML_BASE_CSV==='undefined')return;
 const banner=$('baseRegistryBanner');if(!banner)return;
 if(viewVersion===htmlBaseId){const note=document.createElement('p');note.textContent='Открыты данные этого HTML. Просмотр и скачивание доступны; прежняя история браузера сохранена. Для редактирования добавьте срез через раздел обновления.';banner.append(note);}
 else if(versions.some(v=>v.id===htmlBaseId)){const button=document.createElement('button');button.textContent='Открыть обновлённые данные этого HTML';button.onclick=()=>openHtmlBase().catch(stateError);banner.append(button);}
};
