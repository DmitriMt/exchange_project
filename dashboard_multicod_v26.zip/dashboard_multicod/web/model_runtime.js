// v4.3 inference. Supplied model coefficients are added by build_local_html.py.
function modelNorm(v){return String(v??'').normalize('NFC').toLowerCase().replace(/ё/g,'е').replace(/\s+/g,' ').trim();}
function modelSemantic(numeric,kind){
  const n={...numeric},products=n.n_products,unknown=n.tech_unknown_products;
  const known=products!=null&&unknown!=null?products-unknown:null;
  const mean=n.tech_weight_sum!=null&&known>0?n.tech_weight_sum/known:null;
  const share=n.tech_complex_products!=null&&known>0?n.tech_complex_products/known:null;
  const total=n.catalog_prod_modules!=null&&n.catalog_prod_submodules!=null?n.catalog_prod_modules+n.catalog_prod_submodules:null;
  const density=total!=null&&n.n_servers>0?total/n.n_servers:null;
  Object.assign(n,{tech_mean_weight:mean,tech_complex_share:share,struct_total_modules:total,struct_modules_per_server:density,
    struct_modules_per_fp:total!=null&&n.catalog_prod_fp!=null?total/Math.max(n.catalog_prod_fp,1):null,
    interaction_servers_tech:n.n_servers!=null&&mean!=null?Math.log1p(n.n_servers)*mean:null,
    interaction_structure_tech:total!=null&&mean!=null?Math.log1p(total)*mean:null,
    as_tech_mean_weight:kind==='АС'?mean:0,as_struct_density:kind==='АС'?density:0});
  for(const [name,column,t] of [['servers_over_10','n_servers',10],['servers_over_100','n_servers',100],['servers_over_1000','n_servers',1000],['modules_over_10','struct_total_modules',10],['modules_over_100','struct_total_modules',100]])n[name]=n[column]!=null?Math.max((1+n[column])/(1+t)-1,0):null;
  return n;
}
function modelPredict(record,feat,head){
  const raw=feat.numeric||{},kind=record.category;
  const eligible=head.matched_types.includes(kind)&&((raw.resource_present&&['n_servers','n_dbs','n_environments'].filter(k=>raw[k]!=null).length>=2)||(head.configuration.allow_partial&&['catalog_prod_fp','catalog_prod_modules','catalog_prod_submodules'].filter(k=>raw[k]!=null).length>=2));
  if(!eligible)return {value:head.baseline[kind],method:'Средняя по типу · v4.3'};
  const n=modelSemantic(raw,kind);
  function linear(spec,beta){
    const x=spec.numeric.map(k=>n[k]!=null?Math.log1p(n[k]):null);
    x.push(...spec.numeric.map(k=>Number(n[k]==null)),...spec.products.map(p=>Number((feat.products||[]).includes(p))),Number(kind==='АС'),...spec.classes.map(c=>Number(record.criticality===c)));
    for(const [key,choices] of Object.entries(spec.categories||{}))for(const choice of choices)x.push(Number(modelNorm(key==='block'?record.dit:record[key])===choice));
    return beta[0]+x.reduce((s,v,i)=>s+((v??spec.median[i])-spec.mean[i])/spec.scale[i]*beta[i+1],0);
  }
  const clip=v=>Math.max(-30,Math.min(30,v));
  const p=1/(1+Math.exp(-clip(linear(head.probability_vectorizer,head.logistic))));
  return {value:p*Math.exp(clip(linear(head.amount_vectorizer,head.positive)))*(head.typed_smearing[kind]??head.smearing)*(head.amount_scale??1),method:'Ресурсная модель · v4.3'};
}
function fillPshe(records){
  for(const r of records){
    if(r.record_type!=='entity')continue;
    const needed=['pshe_change_main','pshe_run_main','pshe_change_prom','pshe_run_prom','pshe_change_standin','pshe_run_standin','pshe_vendor_standin'].some(k=>r[k]==='');
    if(!needed)continue;
    const inputs=r.pshe_model_inputs?JSON.parse(r.pshe_model_inputs):{};
    for(const [variant,suffix] of [['both','main'],['prom','prom']]){
      const methods=[];
      for(const [target,label] of [['own','change'],['run','run']]){
        const field=`pshe_${label}_${suffix}`;
        if(r[field]!=='')continue;
        const answer=variant==='prom'&&inputs.prom_absent?{value:0,method:'Нет ПРОМ-ресурсов · подтверждено РСМ'}:modelPredict(r,inputs[variant]||{},PSHE_MODEL.models[target]);
        r[field]=String(answer.value);methods.push(answer.method);
        if(suffix==='main')r[label==='change'?'pshe_source_change':'pshe_source_run']=answer.method;
      }
      if(methods.length)r[suffix==='main'?'pshe_status':'pshe_prom_status']=[...new Set(methods)].join(' / ');
    }
    for(const [target,label] of [['own','change'],['run','run'],['vendor','vendor']]){
      const field=`pshe_${label}_standin`;
      if(r[field]==='')r[field]=String(modelPredict(r,inputs.both||{},PSHE_MODEL.models[target]).value);
    }
  }
  return records;
}
