'use strict';
const BROWSER_JS_INFLATE_AVAILABLE=true;
// Materialize the selected file in the UI thread. Workers receive bytes, never a live OS/iCloud handle.
function localFileReadError(file,error){const message='Не удалось прочитать файл «'+(file?.name||'Excel')+'». Дождитесь сохранения в Excel и полной загрузки файла из облака. Если ошибка повторяется, сохраните копию в «Загрузки» и выберите её заново. Данные дашборда не изменены.';const wrapped=new Error(message);wrapped.name='LocalFileReadError';wrapped.cause=error;return wrapped;}
function localFileReader(file){return new Promise((resolve,reject)=>{if(typeof FileReader==='undefined'){reject(new Error('FileReader недоступен'));return;}const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(reader.error||new Error('Ошибка чтения файла'));reader.onabort=()=>reject(new Error('Чтение файла прервано'));reader.readAsArrayBuffer(file);});}
async function snapshotLocalFile(file,progress=()=>{}){
 if(!file||typeof file.size!=='number'||file.size<=0||file.size>300*1024*1024)throw new Error('Выберите непустой XLSX-файл до 300 МБ');
 let lastError=null;
 const readers=[()=>file.arrayBuffer(),()=>localFileReader(file),()=>file.arrayBuffer()];
 for(let attempt=0;attempt<readers.length;attempt++){
  progress((attempt?'Повторяем чтение файла: ':'Читаем локальную копию файла: ')+file.name);
  try{const bytes=await readers[attempt]();if(!bytes||bytes.byteLength!==file.size)throw new Error('Размер файла изменился во время чтения');return {name:String(file.name||'Опросник перехода.xlsx'),type:file.type||'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',lastModified:file.lastModified||0,size:file.size,bytes};}
  catch(error){lastError=error;if(attempt<readers.length-1)await new Promise(resolve=>setTimeout(resolve,150*(attempt+1)));}
 }
 throw localFileReadError(file,lastError);
}
function importReadError(message){return /I\/O read|NotReadableError|not readable|could not be read|cannot be read|Failed to read/i.test(String(message))?localFileReadError(null,new Error(String(message))):new Error(String(message));}
