'use strict';
const exportFields=['budget_rub','cpu','ram_gb','disk_gb','pshe_change_standin','pshe_run_standin','pshe_vendor_standin','pshe_change_prom','pshe_run_prom'];
const exportHeads=['КТС, руб./год','CPU, шт.','RAM, ГБ','Disk, ГБ','CHANGE, ПШЕ','RUN, ПШЕ','Вендоры CHANGE, руб. без НДС','CHANGE только ПРОМ, ПШЕ','RUN только ПРОМ, ПШЕ'];
function exportParams(es,detail){return {name:'Параметры и источники',widths:[40,100],rows:[['Параметр','Значение'],['Подраздел',sectionTitles[page]],['Дата экспорта',new Date().toLocaleString('ru-RU')],['Снимок каталога',[...new Set(es.map(e=>e.snapshot))].join(', ')],['Бизнес-блок',$('block').value||'Все'],['ДИТ',$('dit').value||'Все'],['Тип объекта',$('category').value||'АС и ФП'],['Критичность',$('criticality').value||'Все из RUNUP'],['Поиск',$('search').value],['Список Выгрузка АС',$('asList').checked?'Только список':'Весь периметр'],['Объектов в периметре',es.length],['Показатель КТС',measures[measure].label],['Показатель инфографики',chartMetrics[chartMetric].label],['Детализация',drill?drill.value+(drill.dit?' / '+drill.dit:''):'Нет'],['Загрузка Excel',detail?'Только открытая детализация':'Весь выбранный подраздел'],['Количество объектов','Опросник RUNUP: все АС и ФП из файла, на всех этапах ЖЦ; связи по КЭ.'],['КТС и мощности','Кошельки.xlsx, Sheet1: AN × 1000000; CPU W; RAM X; Disk Y+Z. Знаки возвратов сохранены.'],['ПШЕ и вендоры','Калькулятор_ПШЕ_v4_3_сравнение_Stand_IN.xlsx, Объекты: S/T/U, сценарий только ПРОМ V/W. Пропуски дополнены v4.3; средняя по типу при недостатке ресурсов.'],['Период','ПШЕ и вендоры без календарного года. Вендоры без НДС, не входят в КТС. Стоимость КТС годовая, без отбора исключительно 2027 года.'],['Объём экспорта','Все отобранные строки, включая скрытые пагинацией и ограничением топ-10.'],['Пропуски','Пустая ячейка означает отсутствие данных/строк источника. Числовой ноль сохранён как ноль.']]};}
function exportGrouped(es,bs,axis,name,charts=false){
  const names=[...new Set(es.map(e=>e[axis]))].sort((a,b)=>a.localeCompare(b,'ru'));
  const rows=[[axis==='dit'?'ДИТ':'Бизнес-блок','АС','ФП','Всего объектов','Доля АС внутри строки','Доля ФП внутри строки',...exportHeads],...names.map(n=>{const e=es.filter(r=>r[axis]===n),b=bs.filter(r=>r[axis]===n),as=e.filter(r=>r.category==='АС').length,fp=e.length-as;return [n,as,fp,e.length,as/e.length,fp/e.length,...exportFields.map(k=>sum(k.startsWith('pshe_')?e:b,k))];})];
  const sheet={name,rows,percentCols:[4,5]};
  if(charts&&rows.length>1){const idx=chartMetric==='as'?1:chartMetric==='fp'?2:6+exportFields.indexOf(chartMetric);sheet.charts=[chartMetric==='objects'?{type:'bar',percent:true,cols:[1,2],title:name+': соотношение АС и ФП внутри строки'}:{type:'bar',cols:[idx],title:name+': '+chartMetrics[chartMetric].label}];}
  return sheet;
}
function exportObjects(es,bs,name='Объекты'){
  return {name,rows:[['CI-ID','Наименование','Тип','Критичность','ДИТ','Бизнес-блок','Родительская АС','В списке АС',...exportHeads,'Метод ПШЕ','Источник только ПРОМ'],...es.map(e=>{const b=bs.filter(r=>r.id_ke===e.id_ke);return [e.id_ke,e.name,e.category,e.criticality,e.dit,e.business_block,e.parent_id,e.in_as_list==='1'?'Да':'Нет',...exportFields.map(k=>k.startsWith('pshe_')?xNum(e[k]):sum(b,k)),modelAdded(e)?e.pshe_status:'Калькулятор, S/T/U (модель)',e.pshe_prom_status];})],widths:[19,65,10,14,55,45,19,16,...exportHeads.map(()=>22),50,50]};
}
function exportBudget(es,bs,key,name){
  const names=[...new Set(bs.map(r=>r[key]))].sort(),data=names.map(n=>{const b=bs.filter(r=>r[key]===n);return [n,new Set(b.map(r=>r.id_ke)).size,...['budget_rub','cpu','ram_gb','disk_gb'].map(k=>sum(b,k))];});
  const valueIndex=2+['budget_rub','cpu','ram_gb','disk_gb'].indexOf(measure),negative=data.some(r=>r[valueIndex]<0);
  const rows=[[key==='stand'?'Стенд':'Тип потребления','Уникальных объектов','КТС, руб./год','CPU, шт.','RAM, ГБ','Disk, ГБ',...(negative?['Положительные итоги (выбранная метрика)','Отрицательные итоги по модулю']:[])],...data.map(r=>negative?[...r,Math.max(r[valueIndex],0),Math.max(-r[valueIndex],0)]:r)];
  return {name,rows,charts:rows.length<2?[]:negative?[{type:'pie',cols:[6],title:name+': положительные итоги'},{type:'pie',cols:[7],title:name+': отрицательные итоги по модулю'}]:[{type:'pie',cols:[valueIndex],title:name+': '+measures[measure].label}]};
}
function exportWorkbook(detailOnly=false){
  const es=filtered(),ids=new Set(es.map(e=>e.id_ke)),bs=budgets.filter(b=>ids.has(b.id_ke));let sheets=[];
  if(!detailOnly){
    if(page==='overview')sheets.push({name:'Обзор',rows:[['Показатель','Значение','Единицы'],['АС',es.filter(e=>e.category==='АС').length,'шт.'],['ФП',es.filter(e=>e.category==='ФП').length,'шт.'],['КТС',sum(bs,'budget_rub'),'руб./год'],['CPU',sum(bs,'cpu'),'шт.'],['RAM',sum(bs,'ram_gb'),'ГБ'],['Disk',sum(bs,'disk_gb'),'ГБ'],['CHANGE',sum(es,'pshe_change_standin'),'ПШЕ'],['RUN',sum(es,'pshe_run_standin'),'ПШЕ'],['Вендоры CHANGE',sum(es,'pshe_vendor_standin'),'руб. без НДС']]});
    if(page==='volume'||page==='pshe')sheets.push(exportGrouped(es,bs,'dit','По ДИТ',page==='volume'),exportGrouped(es,bs,'business_block','По бизнес-блокам',page==='volume'));
    if(page==='pshe')sheets.unshift({name:'Сценарии ПШЕ',rows:[['Сценарий','CHANGE, ПШЕ','RUN, ПШЕ','Вендоры CHANGE, руб. без НДС'],['ПРОМ + Stand-IN',sum(es,'pshe_change_standin'),sum(es,'pshe_run_standin'),sum(es,'pshe_vendor_standin')],['Только ПРОМ',sum(es,'pshe_change_prom'),sum(es,'pshe_run_prom'),null]],charts:[{type:'bar',cols:[1,2],title:'Расчётная потребность в ПШЕ по сценариям'}]});
    if(page==='kts')sheets.push(exportBudget(es,bs,'budget_consumption','Типы потребления'),exportBudget(es,bs,'stand','Стенды'));
    if(page==='objects'||page==='quality')sheets.push(exportObjects(page==='quality'?es.filter(modelAdded):es,bs,page==='quality'?'Дополнены моделью':'Объекты'));
    if(page!=='objects'&&page!=='quality')sheets.push(exportObjects(es,bs));
  }
  if(page==='kts'&&drill){
    const selected=bs.filter(b=>b[drill.key]===drill.value),selectedIds=new Set(selected.map(b=>b.id_ke));
    sheets.push(exportGrouped(es.filter(e=>selectedIds.has(e.id_ke)),selected,'dit','Детализация ДИТ'));
    const detail=drill.dit?selected.filter(b=>b.dit===drill.dit):selected,idset=new Set(detail.map(b=>b.id_ke));
    sheets.push(exportObjects(es.filter(e=>idset.has(e.id_ke)),detail,'Детализация объектов'));
  }
  if(!sheets.length)throw new Error('Нет открытого раздела для экспорта');
  sheets.push(exportParams(es,detailOnly));return sheets;
}
async function downloadExcel(detailOnly=false){
  const button=$(detailOnly?'exportDrillExcel':'exportExcel');if(button)button.disabled=true;
  try{const blob=makeXlsx(exportWorkbook(detailOnly)),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='МультиЦОД_'+sectionTitles[page]+(detailOnly?'_детализация':'')+'_'+new Date().toISOString().slice(0,10)+'.xlsx';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}catch(e){message('Не удалось создать Excel: '+e.message,true);}finally{if(button)button.disabled=false;}
}
function bindExcelExport(){
  if($('exportExcel'))$('exportExcel').onclick=()=>downloadExcel(false);
  const panel=document.querySelector('.drill-panel .section-title');
  if(panel&&!$('exportDrillExcel')){const b=document.createElement('button');b.id='exportDrillExcel';b.textContent='Скачать детализацию Excel';b.onclick=()=>downloadExcel(true);panel.append(b);}
}
