// Browser-only CSV reader for the self-contained debugging page.
function parseLocalCsv(text) {
  const matrix=[];let row=[],cell='',quoted=false,afterQuote=false;
  text=text.replace(/^\uFEFF/,'');
  for(let i=0;i<text.length;i++) {
    const c=text[i];
    if(quoted) {
      if(c==='"'&&text[i+1]==='"'){cell+='"';i++;}
      else if(c==='"'){quoted=false;afterQuote=true;}
      else cell+=c;
    } else if(c===';'||c==='\n'||c==='\r') {
      row.push(cell);cell='';afterQuote=false;
      if(c!==';'){if(c==='\r'&&text[i+1]==='\n')i++;matrix.push(row);row=[];}
    } else if(c==='"'&&cell===''&&!afterQuote) quoted=true;
    else {if(afterQuote||c==='"')throw new Error('Некорректные кавычки в CSV');cell+=c;}
  }
  if(quoted)throw new Error('Незакрытые кавычки в CSV');
  if(cell!==''||row.length||afterQuote){row.push(cell);matrix.push(row);}
  const inputFields=matrix.shift();if(JSON.stringify(inputFields)!==JSON.stringify(CSV_FIELDS)&&JSON.stringify(inputFields)!==JSON.stringify(CSV_FIELDS.slice(0,CSV_FIELDS.indexOf('owner_department')))&&JSON.stringify(inputFields)!==JSON.stringify(CSV_FIELDS.slice(0,CSV_FIELDS.indexOf('rsm_presence')))&&JSON.stringify(inputFields)!==JSON.stringify(CSV_FIELDS.slice(0,CSV_FIELDS.indexOf('transition_strategy')))&&JSON.stringify(inputFields)!==JSON.stringify(CSV_FIELDS.slice(0,CSV_FIELDS.indexOf('base_source'))))throw new Error('Неверные колонки CSV. Требуются UTF-8 и разделитель «;».');
  if(!matrix.length||matrix.length>100000)throw new Error('CSV пуст или превышает 100 000 строк');
  const result=matrix.map((r,i)=>{
    if(r.length!==inputFields.length)throw new Error('Неверное количество колонок: строка '+(i+2));
    const item=Object.fromEntries(CSV_FIELDS.map(k=>[k,inputFields.includes(k)?r[inputFields.indexOf(k)]:'']));if(!inputFields.includes('base_source')&&item.record_type==='entity')item.base_source='LEGACY_CATALOG';return item;
  });
  fillPshe(result);
  const ids=new Map(),budgetKeys=new Set();
  for(const r of result) {
    if(!['','0','1'].includes(r.rsm_presence)||r.rsm_rows&&!/^\d{1,12}$/.test(r.rsm_rows))throw new Error('Неверный признак РСМ');
    if(['0','1'].includes(r.rsm_presence)&&(!r.rsm_source||!r.rsm_rows||(r.rsm_presence==='0')!==(Number(r.rsm_rows)===0)))throw new Error('Признак РСМ не согласован с источником и числом строк');
    if(r.record_type==='entity')validateRegistryRow(r);
    validateTransitionRow(r);
    const audit=r.record_type==='budget_outside';
    if((!audit&&!/^CI\d+$/.test(r.id_ke))||!['entity','budget','budget_outside'].includes(r.record_type))throw new Error('Неверный CI-ID или тип строки');
    if(!audit&&(!['АС','ФП'].includes(r.category)||!r.criticality||!r.lifecycle))throw new Error('Объект вне периметра');
    if(!r.name||!r.dit||!r.business_block||!/^\d{4}-\d{2}-\d{2}$/.test(r.snapshot))throw new Error('Не заполнены поля объекта');
    for(const k of ['fp_prom_total','fp_scope_total','parent_fp_prom_total','parent_fp_scope_total'])if(r[k]&&!/^\d{1,7}$/.test(r[k]))throw new Error('Неверное количество ФП');
    for(const [total,part]of [['fp_prom_total','fp_scope_total'],['parent_fp_prom_total','parent_fp_scope_total']])if(r[total]&&r[part]&&Number(r[part])>Number(r[total]))throw new Error('Количество ФП в периметре больше полного состава');
    if(r.fp_children_json){let children;try{children=JSON.parse(r.fp_children_json);}catch{throw new Error('Некорректный состав ФП');}if(r.record_type!=='entity'||r.category!=='АС'||!Array.isArray(children)||r.fp_children_json.length>2000000)throw new Error('Некорректный состав ФП');const seen=new Set();for(const child of children){if(!child||typeof child!=='object'||Object.values(child).some(v=>typeof v!=='string')||!/^CI\d+$/.test(child.id_ke)||!child.name||child.category!=='ФП'||child.parent_id!==r.id_ke||seen.has(child.id_ke))throw new Error('Некорректная связь ФП с АС');seen.add(child.id_ke);}if(r.fp_prom_total&&children.length!==Number(r.fp_prom_total)||r.fp_scope_total&&children.filter(c=>['MC+','MC','BC'].includes(c.criticality)).length!==Number(r.fp_scope_total))throw new Error('Количество ФП не совпадает с составом');}
    if(!['','0','1'].includes(r.parent_in_scope))throw new Error('Неверный признак периметра родительской АС');
    if(!['0','1'].includes(r.in_as_list))throw new Error('Не задан признак списка АС');
    for(const k of ['budget_rub','cpu','ram_gb','disk_gb','pshe_change_main','pshe_run_main','pshe_change_prom','pshe_run_prom','pshe_change_standin','pshe_run_standin','pshe_vendor_standin']) {
      if(r[k]!==''&&(!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(r[k])||!Number.isFinite(Number(r[k]))||Math.abs(Number(r[k]))>1e18||(k.startsWith('pshe_')&&Number(r[k])<0)))throw new Error('Некорректное число: '+k);
    }
    if(r.record_type==='entity') {
      if(ids.has(r.id_ke))throw new Error('Повтор объекта: '+r.id_ke);
      if(['budget_rub','budget_consumption','stand','budget_source_id'].some(k=>r[k]))throw new Error('Бюджет должен находиться в отдельной строке');
      ids.set(r.id_ke,r);
    } else {
      if(!r.budget_source_id||budgetKeys.has(r.budget_source_id)||!r.stand||!r.budget_consumption||r.budget_rub==='')throw new Error('Неверная бюджетная строка');
      budgetKeys.add(r.budget_source_id);
      if(CSV_FIELDS.some(k=>k.startsWith('pshe_')&&r[k]))throw new Error('ПШЕ должны находиться только в строках объектов');
    }
  }
  if(!ids.size)throw new Error('Нет объектов');
  validateRegistryDataset([...ids.values()]);
  for(const r of result)if(r.record_type==='budget') {
    const e=ids.get(r.id_ke);
    if(!e||['name','category','parent_id','dit','business_block','criticality','lifecycle','snapshot'].some(k=>e[k]!==r[k]))throw new Error('Бюджет не соответствует объекту');
  }
  return result;
}

