'use strict';
Object.assign(sectionTitles,{update:'Обновление из Excel'});
let importJobs=[],currentImport='',importBusy=false,importProgress='',importWatchGeneration=0;
const requiredSourceRoles=['catalog','wallet','rsm1','rsm2','questionnaire'];
const sourceRoles={catalog:'Каталог ИТ-услуг',wallet:'Кошельки — бюджет КТС',pshe:'Калькулятор ПШЕ — необязательно',rsm1:'РСМ ДЭШ_1',rsm2:'РСМ ДЭШ_2',questionnaire:'Опросник RUNUP — базовый реестр'};
const oldAdvancedPage=advancedPage;
advancedPage=function(es,bs){return page==='update'?importPage():oldAdvancedPage(es,bs);};
const previousHistoryPage=historyPage;
historyPage=function(){const html=previousHistoryPage();return stateRepo instanceof ServerRepo&&canLoad?html.replace('<button id="refreshHistory">','<button id="restoreHistory">Добавить срез данных</button><input id="restoreFile" type="file" accept=".json" hidden><button id="refreshHistory">'):html;};
const oldCleanView=cleanView;
cleanView=function(v){const out=oldCleanView(v);if(out.page==='saved')out.page='overview';for(const key of ['planningStatus','auditTab','chartShowAll'])if(v&&key in v)out[key]=v[key];return out;};
const oldFiltersValue=filtersValue;
filtersValue=function(){return {...oldFiltersValue(),planningStatus,auditTab,chartShowAll};};
const oldApplySavedView=applySavedView;
applySavedView=async function(v){planningStatus=planStatuses.includes(v.planningStatus)||v.planningStatus==='empty'?v.planningStatus:'';auditTab=['missing','outside','negative'].includes(v.auditTab)?v.auditTab:'missing';chartShowAll=Boolean(v.chartShowAll);return oldApplySavedView(v);};
const oldRender=render;
render=function(){if(page==='saved')page='overview';oldRender();};
planPage=function(es){
  const plans=activePlans(),selected=es.filter(e=>!planningStatus||(planningStatus==='empty'?!plans[e.id_ke]?.status:plans[e.id_ke]?.status===planningStatus));
  const editable=canEdit&&!isHistorical(),accepted=es.filter(e=>plans[e.id_ke]?.status==='Принято').length,rolled=es.filter(e=>['Развёрнуто','Принято'].includes(plans[e.id_ke]?.status)).length;
  return `<section class="panel planning-guide"><div><h2>Управление планом развёртывания</h2><p>1. Найдите АС или ФП. 2. Нажмите «Задать план». 3. Укажите сроки, площадку, ответственного и статус, затем сохраните.</p><p class="note">${editable?'Изменения записываются в журнал. ПШЕ от плановых дат автоматически не пересчитываются.':'Редактирование доступно роли «Админ» на актуальной версии.'}</p></div><button id="pickPlanObject" class="primary" ${editable?'':'disabled'}>Выбрать объект для плана</button></section><div class="metrics">${metric('Развёрнуто',fmt(rolled),`из ${fmt(es.length)} объектов`)}${metric('Принято',fmt(accepted),es.length?fmt(accepted/es.length*100,1)+'% выбранного периметра':'Нет объектов')}${metric('Статус не задан',fmt(es.filter(e=>!plans[e.id_ke]?.status).length),'Нажмите «Задать план» в строке объекта')}</div><section class="panel"><div class="section-title"><h2>Реестр плана</h2><label>Статус<select id="planningStatus"><option value="">Все</option><option value="empty" ${planningStatus==='empty'?'selected':''}>Не задан</option>${planStatuses.map(s=>`<option ${planningStatus===s?'selected':''}>${esc(s)}</option>`).join('')}</select></label></div>${table(['АС / ФП','Год','Квартал','Целевая дата','Площадка','Ответственный','Статус','Действие'],selected.map(e=>{const p=plans[e.id_ke]||{};return `<tr><td class="name"><button class="table-link" data-object-id="${esc(e.id_ke)}">${esc(e.name)}</button><span class="subcaption">${esc(e.id_ke)} · ${esc(e.category)}</span></td>${['year','quarter','target_date','site','owner'].map(k=>`<td>${esc(p[k]||'—')}</td>`).join('')}<td>${esc(p.status||'Не задан')}</td><td><button data-edit-plan="${esc(e.id_ke)}" ${editable?'':'disabled'}>${p.status||p.year||p.owner?'Изменить план':'Задать план'}</button></td></tr>`;}).join(''))}${statePager(selected.length)}</section>`;
};
async function openPlanEditor(ci){await showObjectCard(ci);document.querySelector('#planForm')?.scrollIntoView({behavior:'smooth',block:'start'});$('plan_year')?.focus();}
function importPage(){
  if(stateRepo instanceof BrowserRepo)return '<section class="panel"><h2>Встроенный экспортер Excel</h2><p>Подготавливаем форму выбора исходных файлов.</p></section>';
  const disabled=!canLoad||importBusy;
  return `<section class="panel"><h2>Новый срез из исходных Excel</h2><p>Выберите дату и файлы. Экспортер соберёт данные, рассчитает ПШЕ встроенной серверной моделью v4.3 и предложит сохранить новую версию. Калькулятор ПШЕ можно приложить дополнительно.</p>${!canLoad?'<p class="quality-callout">Нужна роль «Оператор» или «Админ».</p>':''}<form id="excelImportForm"><fieldset ${disabled?'disabled':''}><label>Дата нового среза<input id="excelDate" type="date" value="${esc(versions[0]?.date||new Date().toISOString().slice(0,10))}" required></label><div class="source-grid">${Object.entries(sourceRoles).map(([key,label])=>`<label>${esc(label)}<input type="file" id="source_${key}" accept=".xlsx" ${requiredSourceRoles.includes(key)?'required':''}></label>`).join('')}</div><button class="primary" type="submit">Подготовить срез и проверить изменения</button></fieldset></form><p id="importProgress" role="status">${esc(importProgress)}</p><p class="note">Имена файлов могут меняться: каждый источник выбирается в своём поле. На дату среза устанавливается выбранная дата. Текущие данные не заменяются до подтверждения. Максимум 300 МБ на файл. Опросник RUNUP обязателен и определяет полный состав систем. Остальные файлы только дополняют эти КЭ.</p></section><section class="panel import-recent"><div class="section-title"><h2>Мои обработки</h2><button id="refreshImports">Обновить список</button></div>${table(['Дата / источник','Состояние','Действие'],importJobs.map(j=>`<tr><td>${esc(j.date)}<span class="subcaption">${new Date(j.created_at).toLocaleString('ru-RU')}</span></td><td>${esc(j.message)}</td><td>${j.status==='ready'||j.status==='committed'?`<button data-import-review="${esc(j.id)}">${j.status==='committed'?'Посмотреть срез':'Проверить и сохранить'}</button>`:j.status==='running'?`<button data-import-watch="${esc(j.id)}">Продолжить просмотр</button>`:j.status==='failed'?`<button data-import-rerun="${esc(j.id)}">Повторить обработку</button>`:''}</td></tr>`).join(''))}</section>`;
}
function importStatus(text){importProgress=text;if($('importProgress'))$('importProgress').textContent=text;}
async function refreshImports(){if(stateRepo instanceof ServerRepo&&canLoad)importJobs=await api('/api/import/jobs');}
async function watchImport(id){
  currentImport=id;importBusy=true;const generation=++importWatchGeneration;
  try{for(;;){const job=await api('/api/import/jobs/'+id);if(generation!==importWatchGeneration)return;importStatus(job.message);if(job.status==='failed')throw new Error(job.message);if(['ready','committed'].includes(job.status)){await refreshImports();if(page==='update')render();if(page==='update'&&!$('stateDialog')?.open)await reviewImport(id);else message('Срез подготовлен. Откройте «Обновление из Excel», чтобы проверить и сохранить его.');break;}await new Promise(resolve=>setTimeout(resolve,1500));}}
  finally{if(generation===importWatchGeneration){importBusy=false;if(page==='update')render();}}
}
async function submitImport(event){
  event.preventDefault();if(!canLoad||importBusy)return;
  const date=$('excelDate').value,files=Object.fromEntries(Object.keys(sourceRoles).map(k=>[k,$('source_'+k).files[0]]));
  if(!date||requiredSourceRoles.some(k=>!files[k]))throw new Error('Укажите дату и пять обязательных файлов');
  if(Object.values(files).filter(Boolean).some(f=>f.size>300*1024*1024))throw new Error('Один из файлов больше 300 МБ');
  importBusy=true;
  try{const job=await api('/api/import/jobs',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({date,base:liveVersion})});currentImport=job.id;
    for(const [role,file]of Object.entries(files).filter(([,file])=>file)){importStatus('Загружаем: '+sourceRoles[role]+' — '+file.name);await api('/api/import/jobs/'+job.id+'/files/'+role,{method:'POST',headers:{'Content-Type':'application/octet-stream','X-Source-Name':encodeURIComponent(file.name)},body:file});}
    await api('/api/import/jobs/'+job.id+'/run',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});await watchImport(job.id);
  }finally{importBusy=false;await refreshImports();if(page==='update')render();}
}
async function reviewImport(id){
  const result=await api('/api/import/jobs/'+id+'/result'),list=await stateRepo.list(),base=list[0]?.id||'',before=base?(await stateRepo.getSnapshot(base)).rows:[];
  stateModal('Excel-срез на '+result.job.date,previewHtml(datasetDiff(before,result.rows),'Результат обработки исходных файлов')+(result.job.report?.transition?`<p>План 3 ЗД указан: ${fmt(result.job.report.transition.planned)} · пустой ответ: ${fmt(result.job.report.transition.blank)} · нет КЭ: ${fmt(result.job.report.transition.not_listed)}</p>`:'')+`<details class="object-fold"><summary>Исходные файлы</summary>${table(['Источник','Файл','Размер, МБ'],Object.entries(result.job.files).map(([k,f])=>`<tr><td>${esc(sourceRoles[k])}</td><td>${esc(f.name)}<span class="subcaption">SHA-256: ${esc(f.sha256)}</span></td><td class="num">${fmt(f.bytes/1024/1024,1)}</td></tr>`).join(''))}</details><div class="dialog-actions"><button id="downloadPreparedCsv">Скачать подготовленный CSV</button>${result.job.status==='committed'?'<span>Этот срез уже сохранён в истории</span>':'<button id="commitExcelSlice" class="primary">Добавить срез на эту дату</button>'}</div>`);
  $('downloadPreparedCsv').onclick=()=>saveBlob(new Blob([csvEncode(result.rows)],{type:'text/csv;charset=utf-8'}),'МультиЦОД_'+result.job.date+'.csv');
  if($('commitExcelSlice'))$('commitExcelSlice').onclick=async()=>{const b=$('commitExcelSlice');b.disabled=true;try{const backup=await ensurePreloadBackup(base);await api('/api/import/jobs/'+id+'/commit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({base,backup_id:backup})});$('stateDialog').close();await stateInit();await refreshImports();page='history';render();message('Срез из Excel добавлен в историю на '+result.job.date);}catch(e){stateError(e);}finally{b.disabled=false;}};
}
function sameBookmark(a,b){const keys=[...stateFields,'asList','page','group','measure','chartMetric','planningStatus','auditTab','chartShowAll'];return keys.every(k=>String(a?.[k]??'')===String(b?.[k]??''));}
function bookmarkPanel(){
  const current=filtersValue(),tabs=workspace.views.map((v,i)=>({...v,index:i})).filter(v=>v.value.page===page);
  $('savedBar').innerHTML=`<div class="bookmark-head"><strong>Мои закладки · ${esc(sectionTitles[page])}</strong><span>${stateRepo instanceof BrowserRepo?'Локальный профиль: ':'Пользователь: '}${esc(currentUser)}</span>${stateRepo instanceof BrowserRepo?'<button id="changeProfile">Сменить профиль</button>':''}<button id="quickSaveView">＋ Сохранить закладку</button><button id="manageBookmarks">Управление</button></div><div class="bookmark-tabs" role="group" aria-label="Закладки текущего подраздела">${tabs.map(v=>`<button data-bookmark="${v.index}" class="${sameBookmark(v.value,current)?'active':''}">${esc(v.name)}</button>`).join('')||'<span class="note">В этом подразделе пока нет ваших закладок</span>'}</div>`;
  $('quickSaveView').onclick=()=>{stateModal('Новая закладка этого подраздела','<label>Название<input id="quickViewName" maxlength="100" placeholder="Мой ДИТ"></label><button id="quickViewConfirm" class="primary">Сохранить</button>');$('quickViewConfirm').onclick=async()=>{try{await saveCurrentView($('quickViewName').value);$('stateDialog').close();}catch(e){stateError(e);}};};
  document.querySelectorAll('[data-bookmark]').forEach(b=>b.onclick=()=>applySavedView(workspace.views[Number(b.dataset.bookmark)].value).catch(stateError));
  $('manageBookmarks').onclick=()=>{
    stateModal('Закладки · '+sectionTitles[page],tabs.map(v=>`<div class="saved-row"><strong>${esc(v.name)}</strong><div><button data-rename-bookmark="${v.index}">Переименовать</button><button data-remove-bookmark="${v.index}">Удалить</button></div></div>`).join('')||'<p>Закладок пока нет</p>');
    document.querySelectorAll('[data-rename-bookmark]').forEach(b=>b.onclick=()=>{const v=workspace.views[Number(b.dataset.renameBookmark)];stateModal('Переименовать закладку',`<input id="renameBookmark" maxlength="100" value="${esc(v.name)}"><button id="confirmRenameBookmark">Сохранить</button>`);$('confirmRenameBookmark').onclick=async()=>{try{const name=$('renameBookmark').value.trim();if(!name||name.length>100)throw new Error('Введите название до 100 символов');await stateRepo.updateView(v.name,'rename',name);workspace=await stateRepo.settings();$('stateDialog').close();render();}catch(e){stateError(e);}};});
    document.querySelectorAll('[data-remove-bookmark]').forEach(b=>b.onclick=()=>{const v=workspace.views[Number(b.dataset.removeBookmark)];stateModal('Удалить закладку',`<p>Удалить «${esc(v.name)}» из ваших закладок?</p><button id="confirmRemoveBookmark">Удалить</button>`);$('confirmRemoveBookmark').onclick=async()=>{try{await stateRepo.updateView(v.name,'delete');workspace=await stateRepo.settings();$('stateDialog').close();render();}catch(e){stateError(e);}};});
  };
  if($('changeProfile'))$('changeProfile').onclick=()=>{stateModal('Локальные профили',`<p class="note">Профили разделяют закладки, но не являются входом с паролем. На сервере используются отдельные учётные записи.</p><label>Выберите профиль<select id="localProfile">${(workspace.profiles||['Локальный пользователь']).map(v=>`<option ${v===currentUser?'selected':''}>${esc(v)}</option>`).join('')}</select></label><button id="selectLocalProfile">Переключить</button><label>Или создайте новый<input id="newLocalProfile" maxlength="80"></label><button id="createLocalProfile">Создать профиль</button>`);const change=async name=>{try{workspace=await stateRepo.changeProfile(name);currentUser=stateRepo.profile;$('stateDialog').close();render();}catch(e){stateError(e);}};$('selectLocalProfile').onclick=()=>change($('localProfile').value);$('createLocalProfile').onclick=()=>change($('newLocalProfile').value);};
}
const coreBindings=bindAdvanced;
bindAdvanced=function(){coreBindings();if(!stateReady)return;bookmarkPanel();
  document.querySelectorAll('[data-edit-plan]').forEach(b=>b.onclick=()=>openPlanEditor(b.dataset.editPlan).catch(stateError));
  if($('pickPlanObject'))$('pickPlanObject').onclick=()=>{const es=filtered();stateModal('Выберите объект для плана',`<label>CI-ID объекта<input id="planObjectId" list="planObjectChoices" placeholder="CI…"><datalist id="planObjectChoices">${es.map(e=>`<option value="${esc(e.id_ke)}">${esc(e.name)}</option>`).join('')}</datalist></label><button id="confirmPickPlanObject" class="primary">Открыть план</button>`);$('confirmPickPlanObject').onclick=()=>openPlanEditor($('planObjectId').value.trim()).catch(stateError);};
  if($('excelImportForm'))$('excelImportForm').onsubmit=e=>submitImport(e).catch(stateError);
  if($('refreshImports'))$('refreshImports').onclick=()=>refreshImports().then(()=>render()).catch(stateError);
  document.querySelectorAll('[data-import-review]').forEach(b=>b.onclick=()=>reviewImport(b.dataset.importReview).catch(stateError));
  document.querySelectorAll('[data-import-watch]').forEach(b=>b.onclick=()=>watchImport(b.dataset.importWatch).catch(stateError));
  document.querySelectorAll('[data-import-rerun]').forEach(b=>b.onclick=async()=>{try{await api('/api/import/jobs/'+b.dataset.importRerun+'/run',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});await watchImport(b.dataset.importRerun);}catch(e){stateError(e);}});
};
const originalStateInit=stateInit;
stateInit=async function(){await originalStateInit();if(stateRepo instanceof ServerRepo&&canLoad){await refreshImports();if(page==='update')render();}};
function clearUserPanels(){stateReady=false;workspace={plans:{},events:[],views:[]};versions=[];liveVersion=viewVersion='';importJobs=[];importBusy=false;importWatchGeneration++;$('savedBar').hidden=true;$('versionBar').hidden=true;if($('stateDialog')?.open)$('stateDialog').close();}
const existingLoad=load;
load=async function(){clearUserPanels();return existingLoad();};
const existingLogout=$('logout').onclick;
$('logout').onclick=()=>{clearUserPanels();existingLogout?.();};
const priorExport=exportWorkbook;
exportWorkbook=function(detailOnly=false){if(page!=='update')return priorExport(detailOnly);return [{name:'Обработки Excel',rows:[['Дата','Состояние','Пользователь','Создано'],...importJobs.map(j=>[j.date,j.message,j.owner,j.created_at])]},exportParams(filtered(),false)];};
