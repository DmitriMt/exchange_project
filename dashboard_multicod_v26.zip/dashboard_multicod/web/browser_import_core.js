'use strict';
// XLSX streaming reader and data preparation shared by the embedded worker and Node checks.
const bxDecode=s=>String(s??'').replace(/\r\n?/g,'\n').replace(/&(#x[0-9a-f]+|#\d+|amp|lt|gt|quot|apos);/gi,(_,v)=>v[0]==='#'?String.fromCodePoint(v[1].toLowerCase()==='x'?parseInt(v.slice(2),16):Number(v.slice(1))):({amp:'&',lt:'<',gt:'>',quot:'"',apos:"'"})[v]);
function bxAttrs(s){return Object.fromEntries([...s.matchAll(/([\w:.-]+)\s*=\s*("([^"]*)"|'([^']*)')/g)].map(m=>[m[1],bxDecode(m[3]??m[4])]));}
function bxText(s){return [...String(s).matchAll(/<(?:\w+:)?t(?:\s[^>]*)?>([\s\S]*?)<\/(?:\w+:)?t\s*>/g)].map(m=>bxDecode(m[1])).join('');}
const bxCrcTable=Uint32Array.from({length:256},(_,n)=>{for(let i=0;i<8;i++)n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
class BrowserXlsx{
 constructor(file){this.file=file;this.entries=new Map();this.strings=null;}
 async open(){
  const tail=new Uint8Array(await this.file.slice(Math.max(0,this.file.size-65557)).arrayBuffer()),v=new DataView(tail.buffer);let end=-1;
  for(let i=tail.length-22;i>=0;i--)if(v.getUint32(i,true)===0x06054b50&&i+22+v.getUint16(i+20,true)===tail.length){end=i;break;}
  if(end<0)throw new Error('Не распознан XLSX: '+this.file.name);
  const count=v.getUint16(end+10,true),size=v.getUint32(end+12,true),offset=v.getUint32(end+16,true);
  if(v.getUint16(end+4,true)||v.getUint16(end+6,true)||count===65535||offset===0xffffffff||size>32*1024*1024||offset+size>this.file.size)throw new Error('Неподдерживаемая структура ZIP/XLSX');
  const data=new Uint8Array(await this.file.slice(offset,offset+size).arrayBuffer()),d=new DataView(data.buffer);let p=0,total=0;
  for(let i=0;i<count;i++){
   if(p+46>data.length||d.getUint32(p,true)!==0x02014b50)throw new Error('Поврежден каталог XLSX');
   const nameSize=d.getUint16(p+28,true),extra=d.getUint16(p+30,true),comment=d.getUint16(p+32,true),name=new TextDecoder().decode(data.subarray(p+46,p+46+nameSize));
   const e={flags:d.getUint16(p+8,true),method:d.getUint16(p+10,true),crc:d.getUint32(p+16,true),size:d.getUint32(p+20,true),raw:d.getUint32(p+24,true),offset:d.getUint32(p+42,true)};
   total+=e.raw;if(e.flags&1||e.raw===0xffffffff||e.size===0xffffffff||e.offset===0xffffffff||total>8*1024**3||this.entries.has(name))throw new Error('Неподдерживаемый или слишком большой XLSX');
   this.entries.set(name,e);p+=46+nameSize+extra+comment;
  }
  if(!this.entries.has('xl/workbook.xml'))throw new Error('В файле нет книги Excel');return this;
 }
 async *chunks(name){
  const e=this.entries.get(name);if(!e)throw new Error('В XLSX отсутствует '+name);
  const header=new DataView(await this.file.slice(e.offset,e.offset+30).arrayBuffer());if(header.byteLength!==30||header.getUint32(0,true)!==0x04034b50)throw new Error('Повреждён XLSX');
  const start=e.offset+30+header.getUint16(26,true)+header.getUint16(28,true);if(start+e.size>this.file.size)throw new Error('XLSX передан не полностью');
  let crc=0xffffffff,length=0;
  for await(const value of this.decoded(e,start)){length+=value.length;if(length>e.raw)throw new Error('Превышен размер распаковки XLSX');for(const b of value)crc=bxCrcTable[(crc^b)&255]^(crc>>>8);yield value;}
  if(length!==e.raw||((crc^0xffffffff)>>>0)!==e.crc)throw new Error('Контрольная сумма XLSX не совпала: '+name);
 }
 async *decoded(e,start){
  if(![0,8].includes(e.method))throw new Error('Неподдерживаемое сжатие XLSX');
  const inflate=globalThis.pako||globalThis.self?.pako;let native=null,useJs=e.method===8&&Boolean(inflate?.Inflate)&&(this.forceJsInflate||this.file.size<=16*1024*1024||typeof DecompressionStream==='undefined');
  if(e.method===8&&!useJs){try{native=new DecompressionStream('deflate-raw');}catch(error){if(inflate?.Inflate)useJs=true;else throw error;}}
  if(useJs){
   const decoder=new inflate.Inflate({raw:true,chunkSize:64*1024}),queue=[];let produced=0;
   decoder.onData=value=>{produced+=value.length;if(produced>e.raw)throw new Error('Превышен размер распаковки XLSX');queue.push(value);};
   if(!e.size)decoder.push(new Uint8Array(0),true);
   for(let pos=0;pos<e.size;pos+=65536){const end=Math.min(e.size,pos+65536),input=new Uint8Array(await this.file.slice(start+pos,start+end).arrayBuffer());decoder.push(input,end===e.size);if(decoder.err)throw new Error('Не удалось распаковать XLSX: '+(decoder.msg||'повреждённые данные'));while(queue.length)yield queue.shift();}
   if(decoder.err)throw new Error('Ошибка распаковки XLSX');return;
  }
  let stream=this.file.slice(start,start+e.size).stream();if(native)stream=stream.pipeThrough(native);const reader=stream.getReader();try{for(;;){const {done,value}=await reader.read();if(done)break;yield value;}}finally{reader.releaseLock();}
 }
 async xml(name){let text='',decoder=new TextDecoder();for await(const chunk of this.chunks(name)){text+=decoder.decode(chunk,{stream:true});if(text.length>16*1024*1024)throw new Error('Слишком большой служебный XML');}return text+decoder.decode();}
 async *nodes(name,tag){
  const opening=new RegExp('<(?:\\w+:)?'+tag+'(?=[\\s/>])'),closing=new RegExp('</(?:\\w+:)?'+tag+'\\s*>');let buf='',decoder=new TextDecoder();
  for await(const chunk of this.chunks(name)){
   buf+=decoder.decode(chunk,{stream:true});
   for(;;){const start=buf.search(opening);if(start<0){if(buf.length>256)buf=buf.slice(-256);break;}if(start)buf=buf.slice(start);const endOpen=buf.indexOf('>');if(endOpen<0)break;
    let end;if(buf[endOpen-1]==='/')end=endOpen+1;else{const m=closing.exec(buf);if(!m)break;end=m.index+m[0].length;}
    const item=buf.slice(0,end);buf=buf.slice(end);yield item;
   }
   if(buf.length>16*1024*1024)throw new Error('Слишком большая строка XML');
  }
  buf+=decoder.decode();if(opening.test(buf))throw new Error('Незавершённая строка XML');
 }
 async sheet(name){
  if(typeof name==='number')return 'xl/worksheets/sheet'+name+'.xml';
  const workbook=await this.xml('xl/workbook.xml'),found=[...workbook.matchAll(/<(?:\w+:)?sheet\b([^>]*?)\/?\s*>/g)].map(m=>bxAttrs(m[1])).find(s=>s.name===name);
  if(!found)throw new Error('Нет листа «'+name+'» в '+this.file.name);
  const relations=await this.xml('xl/_rels/workbook.xml.rels'),rel=[...relations.matchAll(/<(?:\w+:)?Relationship\b([^>]*?)\/?\s*>/g)].map(m=>bxAttrs(m[1])).find(r=>r.Id===found['r:id']);
  if(!rel||rel.TargetMode==='External')throw new Error('Не распознан лист '+name);
  const parts=(rel.Target.startsWith('/')?rel.Target.slice(1):'xl/'+rel.Target).split('/'),out=[];for(const p of parts){if(p==='..')out.pop();else if(p&&p!=='.')out.push(p);}const path=out.join('/');if(!path.startsWith('xl/'))throw new Error('Неверный путь листа');return path;
 }
 async *rows(sheet=1,columns=null){
  const path=await this.sheet(sheet);if(this.strings===null){this.strings=[];if(this.entries.has('xl/sharedStrings.xml'))for await(const s of this.nodes('xl/sharedStrings.xml','si'))this.strings.push(bxText(s));}
  for await(const xml of this.nodes(path,'row')){
   const a=bxAttrs(xml.slice(0,xml.indexOf('>'))),row={};
   for(const m of xml.matchAll(/<(?:\w+:)?c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/(?:\w+:)?c\s*>)/g)){
    const attr=bxAttrs(m[1]),col=(attr.r||'').replace(/\d/g,'');if(columns&&!columns.has(col))continue;const content=m[2]||'',v=content.match(/<(?:\w+:)?v(?:\s[^>]*)?>([\s\S]*?)<\/(?:\w+:)?v\s*>/);
    if(attr.t==='e')throw new Error(this.file.name+': ошибка Excel '+attr.r);
    if(attr.t==='inlineStr')row[col]=bxText(content);else if(v){const value=bxDecode(v[1]);if(attr.t==='s'){const n=Number(value);if(!Number.isInteger(n)||n<0||n>=this.strings.length)throw new Error('Неверная строка XLSX');row[col]=this.strings[n];}else row[col]=value;}else row[col]='';
   }
   yield [Number(a.r),row];
  }
 }
}
function bxDecimal(value){const m=String(value||'0').match(/^([+-]?)(\d*)(?:\.(\d*))?(?:[eE]([+-]?\d+))?$/);if(!m||!(m[2]||m[3]))throw new Error('Некорректное число Excel: '+value);let scale=(m[3]||'').length-Number(m[4]||0),n=BigInt((m[1]==='-'?'-':'')+((m[2]||'0')+(m[3]||'')));if(Math.abs(scale)>100)throw new Error('Слишком большое число');if(scale<0){n*=10n**BigInt(-scale);scale=0;}return {n,scale};}
function bxFixed(n,scale){const sign=n<0n?'-':'';let s=(n<0n?-n:n).toString().padStart(scale+1,'0');return sign+(scale?s.slice(0,-scale)+'.'+s.slice(-scale):s);}
function bxMoney(v){const d=bxDecimal(v);return bxFixed(d.n*1000000n,d.scale);}
function bxDisk(y,z){const a=bxDecimal(y),b=bxDecimal(z),s=Math.max(a.scale,b.scale);return bxFixed(a.n*10n**BigInt(s-a.scale)+b.n*10n**BigInt(s-b.scale),s);}
function bxG15(value){if(value===0)return '0';const negative=value<0,parts=Math.abs(value).toExponential(14).split('e'),exp=Number(parts[1]),digits=parts[0].replace('.','').replace(/0+$/,'');let text;if(exp < -4||exp>=15){text=digits[0]+(digits.length>1?'.'+digits.slice(1):'')+'e'+(exp<0?'-':'+')+String(Math.abs(exp)).padStart(2,'0');}else{const point=exp+1;text=point<=0?'0.'+'0'.repeat(-point)+digits:point>=digits.length?digits+'0'.repeat(point-digits.length):digits.slice(0,point)+'.'+digits.slice(point);}return (negative?'-':'')+text;}
async function prepareBrowser(files,date,config,progress=()=>{}){
 if(!(globalThis.pako||globalThis.self?.pako))new DecompressionStream('deflate-raw');
 if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isFinite(Date.parse(date))||new Date(date+'T12:00:00Z').toISOString().slice(0,10)!==date)throw new Error('Укажите корректную дату');
 const required=['catalog','wallet','rsm1','rsm2','questionnaire'];for(const k of required)if(!files[k])throw new Error('Нужны пять обязательных Excel, включая базовый опросник RUNUP');const roles=[...required,...(files.pshe?['pshe']:[])];for(const k of roles)if(files[k].size>300*1024*1024)throw new Error('Максимум 300 МБ на файл');
 const manifest={};for(const role of roles){progress('Проверяем файл: '+files[role].name);const hash=await crypto.subtle.digest('SHA-256',await files[role].arrayBuffer());manifest[role]={name:files[role].name,bytes:files[role].size,sha256:Array.from(new Uint8Array(hash),x=>x.toString(16).padStart(2,'0')).join('')};}
 const fresh=()=>Object.fromEntries(config.fields.map(k=>[k,''])),classes={'Mission Critical+':'MC+','Mission Critical':'MC','Business Critical':'BC'},full=new Map(),entities=new Map();
 const parent=r=>(r.H||'').match(/\((CI\d+)\)/)?.[1]||((r.H||'').trim().match(/^(CI\d+)$/)?.[1]||'');
 progress('Читаем каталог ИТ-услуг');let book=await new BrowserXlsx(files.catalog).open(),header=false;
 const catColumns=new Set(['A','B','G','H','M','S','V','BF','BG','BJ','BK','BM']);
 for await(const [i,r]of book.rows(1,catColumns)){
  if(i===1){if(r.A!=='ID КЭ'||r.S!=='Уровень критичности'||r.V!=='Обеспечивающее подразделение'||r.BF!=='Владелец (Блок)'||r.BG!=='Владелец (подразделение)'||r.BK!=='Трайб/ГАК владелец'||r.BM!=='Код трайба/ГАК')throw new Error('Не распознан каталог ИТ-услуг');header=true;continue;}
  if(!header||!r.A||full.has(r.A))throw new Error('Каталог: отсутствует или повторяется КЭ');full.set(r.A,r);
 }
 if(!header||!full.size)throw new Error('Каталог для насыщения пуст');book=null;
 const questionnaire=await readTransitionFile(files.questionnaire,progress);
 for(const [ci,rec]of questionnaire.records){const c=full.get(ci)||{},e=registryCore(ci,rec,c,{...fresh(),snapshot:date,pshe_status:'Нет данных'});e.catalog_presence=full.has(ci)?'1':'0';entities.set(ci,e);full.set(ci,{...c,A:ci,B:rec.name,G:rec.category,H:rec.parent_id?'('+rec.parent_id+')':'',S:rec.criticality||'',M:rec.lifecycle||'',V:rec.dit||''});}
 const children=new Map();for(const r of full.values())if(r.G==='Функциональная подсистема'&&r.M==='Промышленная эксплуатация'&&full.get(parent(r))?.G==='Автоматизированные системы'){
  const id=parent(r);if(!children.has(id))children.set(id,[]);children.get(id).push({id_ke:r.A,name:r.B||'',category:'ФП',parent_id:id,business_block:r.BF||'',owner_department:r.BG||'',owner_department_code:r.BJ||'',owner_tribe:r.BK||'',owner_tribe_code:r.BM||'',lifecycle:'ПРОМ',criticality:classes[r.S]||r.S||''});
 }
 const counts=id=>{const c=children.get(id)||[];return [String(c.length),String(c.filter(c=>['MC+','MC','BC'].includes(c.criticality)).length)];};
 for(const e of entities.values()){
  const r=full.get(e.id_ke);Object.assign(e,{owner_department:r.BG||'',owner_department_code:r.BJ||'',owner_tribe:r.BK||'',owner_tribe_code:r.BM||''});
  if(e.category==='АС'){[e.fp_prom_total,e.fp_scope_total]=counts(e.id_ke);e.fp_children_json=JSON.stringify(children.get(e.id_ke)||[]);}else{const p=full.get(e.parent_id);if(p?.G==='Автоматизированные системы'){Object.assign(e,{parent_name:p.B||'',parent_business_block:p.BF||'',parent_owner_department:p.BG||'',parent_owner_tribe:p.BK||'',parent_owner_tribe_code:p.BM||'',parent_criticality:classes[p.S]||p.S||'',parent_lifecycle:p.M||'',parent_in_scope:classes[p.S]&&p.M==='Промышленная эксплуатация'?'1':'0'});[e.parent_fp_prom_total,e.parent_fp_scope_total]=counts(e.parent_id);}}
 }
 const listed=new Set(entities.keys());for(const e of entities.values())e.in_as_list='1';
 const psheSeen=new Set();if(files.pshe){progress('Читаем дополнительный калькулятор ПШЕ');book=await new BrowserXlsx(files.pshe).open();header=false;
 for await(const [i,r]of book.rows('Объекты',new Set(['B','C','I','J','P','Q','R','S','T','U','V','W','AB']))){
  if(i===7){if(r.B!=='КЭ'||!['S','T','U'].every(k=>(r[k]||'').includes('Stand-IN')))throw new Error('Не распознан калькулятор ПШЕ: нужны S/T/U');header=true;}if(i<=7||!r.B)continue;if(psheSeen.has(r.B))throw new Error('Повтор КЭ в ПШЕ: '+r.B);psheSeen.add(r.B);const e=entities.get(r.B);if(!e)continue;if(r.C!==e.category)throw new Error('Тип ПШЕ не совпал с каталогом: '+r.B);
  for(const [field,col]of [['pshe_change_main','I'],['pshe_run_main','J'],['pshe_change_prom','V'],['pshe_run_prom','W'],['pshe_change_standin','S'],['pshe_run_standin','T'],['pshe_vendor_standin','U']]){if(!r[col]||!Number.isFinite(Number(r[col]))||Number(r[col])<0)throw new Error('Пересчитайте и сохраните Excel: '+r.B+', поле '+col);e[field]=r[col];}
  Object.assign(e,{pshe_source_change:r.P||'',pshe_source_run:r.Q||'',pshe_status:r.R||'Есть в калькуляторе',pshe_prom_status:r.AB||''});
 }if(!header)throw new Error('Нет заголовка калькулятора ПШЕ');book=null;}
 const targets=new Map([...entities].filter(([,e])=>!e.pshe_change_main||!e.pshe_run_main)),empty=()=>({rows:0,servers:new Set(),dbs:new Set(),envs:new Set(),products:new Set()}),acc=new Map([...targets.keys()].map(id=>[id,{both:empty(),prom:empty()}]));const presence=new Map([...entities.keys()].map(id=>[id,0]));
 const names=['РСМ ДЭШ_1.xlsx','РСМ ДЭШ_2.xlsx'];
 for(const [index,role]of ['rsm1','rsm2'].entries()){
  progress('Читаем '+names[index]);book=await new BrowserXlsx(files[role]).open();header=false;let seen=0;
  for await(const [i,r]of book.rows(1,new Set(['D','L','N','O','P','T','W']))){
   if(i===1){if(r.D!=='АС КЭ'||r.L!=='ФП КЭ'||r.N!=='Стенд Тип')throw new Error('Не распознана '+names[index]);header=true;continue;}if(!header)throw new Error('РСМ без заголовка');
   for(const [category,col]of [['АС','D'],['ФП','L']]){const ci=(r[col]||'').trim();if(/^CI\d+$/.test(ci)&&entities.get(ci)?.category===category)presence.set(ci,presence.get(ci)+1);}
   const id=(r.L||'').startsWith('CI')?r.L:r.D,env=modelNorm(r.N),prod=env.startsWith('пром')&&!env.includes('stand')&&!env.includes('si')&&!env.includes('резерв'),stand=env.includes('stand')||env.includes('пром-si');
   if(acc.has(id)&&(prod||stand)&&!['выведен','выведена','decommissioned','retired'].includes(modelNorm(r.W)))for(const a of [acc.get(id).both,...(prod?[acc.get(id).prom]:[])]){a.rows++;a.envs.add(env);if((r.T||'').startsWith('CI'))a.servers.add(r.T);if((r.P||'').startsWith('CI'))a.dbs.add(JSON.stringify([env,r.P]));if(r.O&&r.O!=='-')a.products.add(modelNorm(r.O));}
   if(++seen%20000===0)progress(names[index]+': проверено '+seen.toLocaleString('ru-RU')+' строк');
  }if(!header)throw new Error('Пустая РСМ');book=null;
 }
 for(const e of entities.values()){const n=presence.get(e.id_ke);Object.assign(e,{rsm_presence:n?'1':'0',rsm_rows:String(n),rsm_source:names.join(' + ')+' · лист 1 · '+(e.category==='ФП'?'L «ФП КЭ»':'D «АС КЭ»')+' · все строки и стенды · SHA-256: '+names.map((name,i)=>name+'='+manifest[['rsm1','rsm2'][i]].sha256).join('; ')});}
 progress('Рассчитываем недостающие ПШЕ');
 for(const [id,e]of targets){
  const inputs={};for(const variant of ['both','prom']){const a=acc.get(id)[variant],products=[...a.products].sort(),values=products.filter(p=>Object.hasOwn(config.weights,p)).map(p=>config.weights[p]),known=products.filter(p=>Object.hasOwn(config.weights,p)).length,n={resource_present:Number(a.rows>0)};
   if(a.rows)Object.assign(n,{n_servers:a.servers.size,n_dbs:a.dbs.size,n_environments:a.envs.size,n_products:products.length});Object.assign(n,{tech_weight_sum:values.length?values.reduce((x,y)=>x+y,0):null,tech_weight_max:values.length?Math.max(...values):null,tech_complex_products:values.length?values.filter(v=>v>=2).length:null,tech_unknown_products:products.length?products.length-known:null,tech_mapping_coverage:products.length?known/products.length:null},config.structure[id]||{catalog_prod_fp:null,catalog_prod_modules:null,catalog_prod_submodules:null});inputs[variant]={numeric:n,products};
  }inputs.prom_absent=Boolean(acc.get(id).both.rows&&!acc.get(id).prom.rows);e.pshe_model_inputs=JSON.stringify(inputs);const missing=config.fields.filter(k=>/^pshe_(change|run|vendor)_/.test(k)&&!e[k]);fillPshe([e]);for(const k of missing)e[k]=bxG15(Number(e[k]));
 }
 progress('Собираем стоимость и мощности КТС');book=await new BrowserXlsx(files.wallet).open();const budgets=[],outside=[];header=false;
 for await(const [i,r]of book.rows(1,new Set(['B','H','I','K','N','O','P','W','X','Y','Z','AN']))){
  if(i===1){if(r.N!=='КЭ АС/ФП'||!(r.AN||'').includes('ИТОГО'))throw new Error('Не распознаны Кошельки');header=true;continue;}if(!header||!r.AN)throw new Error('Кошельки: отсутствует стоимость в строке '+i);
  const e=entities.get(r.N),b=fresh(),c=full.get(r.N)||{};if(e){for(const k of ['id_ke','name','category','parent_id','dit','business_block','criticality','lifecycle','snapshot','in_as_list'])b[k]=e[k];b.record_type='budget';}else Object.assign(b,{record_type:'budget_outside',id_ke:r.N||'(не указан)',name:r.O||'(не указано)',category:c.G||'Нет в каталоге',dit:c.V||r.I||'(не указан)',business_block:c.BF||r.K||'(не указан)',criticality:c.S||'(не указана)',lifecycle:c.M||'(не указан)',snapshot:date,in_as_list:listed.has(r.N)?'1':'0'});
  Object.assign(b,{budget_consumption:r.B||'(не указан)',stand:r.P||'(не указан)',budget_rub:bxMoney(r.AN),cpu:e?(r.W||''):(r.W||'0'),ram_gb:e?(r.X||''):(r.X||'0'),disk_gb:bxDisk(r.Y,r.Z),budget_source_id:'Кошельки:Sheet1:'+i+':'+(r.H||'')});(e?budgets:outside).push(b);
 }if(!header)throw new Error('Кошельки без заголовка');
 annotateRegistry([...entities.values()]);const rows=[...entities.values(),...budgets,...outside];const transition=applyTransition(rows,questionnaire);return {rows,manifest,report:{transition,entities:entities.size,as_count:[...entities.values()].filter(e=>e.category==='АС').length,fp_count:[...entities.values()].filter(e=>e.category==='ФП').length,fp_without_rsm:[...entities.values()].filter(e=>e.category==='ФП'&&e.rsm_presence==='0').length,model_added:targets.size,budget_rows:budgets.length,outside_rows:outside.length}};
}
