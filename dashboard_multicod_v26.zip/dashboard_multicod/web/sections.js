'use strict';
const sectionTitles={overview:'Обзор программы',volume:'Объём работ',kts:'КТС и мощности',pshe:'ПШЕ и вендоры',objects:'АС и подсистемы',quality:'Источники и расчёты'};
function sectionHome(){
  return `<div class="section-title"><div><h2>Подразделы программы</h2><p>Выберите раздел. Общие фильтры сохраняются при переходе.</p></div></div><div class="section-tiles"><button data-section="volume"><span class="tile-index">01</span><strong>Объём работ</strong><span>АС и ФП по владельцам, состав АС и связи между блоками и трайбами</span></button><button data-section="kts"><span class="tile-index">02</span><strong>КТС и мощности</strong><span>Круговые диаграммы типов потребления и стендов, детализация по ДИТ</span></button><button data-section="pshe"><span class="tile-index">03</span><strong>ПШЕ и вендоры</strong><span>CHANGE, RUN и стоимость вендоров, сравнение двух сценариев</span></button><button data-section="planning"><span class="tile-index">04</span><strong>План развёртывания</strong><span>Сроки, площадки, ответственные и статусы по каждой АС/ФП</span></button><button data-section="update"><span class="tile-index">05</span><strong>Обновить из Excel</strong><span>Собрать исходные файлы в новый срез на выбранную дату</span></button></div>`;
}
const pieColors=['#138a75','#6097c1','#d7a24b','#8a75b5','#46a6aa','#ca7c64','#8d9f5b','#72869b'];
function pieGroups(bs,key){
  const names=[...new Set(bs.map(b=>b[key]))];
  return names.map((name,i)=>{const b=bs.filter(r=>r[key]===name);return {name,value:sum(b,measure),objects:new Set(b.map(r=>r.id_ke)).size,color:pieColors[i%pieColors.length]};});
}
function pieRing(groups,key,label){
  const total=groups.reduce((s,r)=>s+Math.abs(r.value),0),radius=79,circ=2*Math.PI*radius;
  const compact=new Intl.NumberFormat('ru-RU',{notation:'compact',maximumFractionDigits:2}).format(total);
  let offset=0;
  const segments=groups.filter(r=>r.value!==0).map(r=>{
    const length=Math.abs(r.value)/total*circ,start=offset;offset+=length;
    return `<circle cx="120" cy="120" r="${radius}" fill="none" stroke="${r.color}" stroke-width="35" stroke-dasharray="${length} ${circ-length}" stroke-dashoffset="${-start}" transform="rotate(-90 120 120)" tabindex="0" role="button" data-drill-key="${key}" data-drill-value="${esc(r.name)}" aria-label="${esc(r.name)}: ${fmt(r.value,1)} ${esc(measures[measure].unit)}"><title>${esc(r.name)}: ${fmt(r.value,1)} (${fmt(Math.abs(r.value)/total*100,1)}%)</title></circle>`;
  }).join('');
  return `<div class="pie-ring-wrap">${label?`<h4>${esc(label)}</h4>`:''}<svg class="pie-ring" viewBox="0 0 240 240" aria-label="Круговая диаграмма: ${esc(label||measures[measure].label)}"><circle cx="120" cy="120" r="${radius}" fill="none" stroke="#edf2f5" stroke-width="35"/>${segments}<text x="120" y="116" text-anchor="middle" class="pie-total">${total?esc(compact):'0'}</text><text x="120" y="138" text-anchor="middle" class="pie-unit">${esc(measures[measure].unit)}</text></svg></div>`;
}
function budgetPie(bs,key,title){
  const groups=pieGroups(bs,key),positive=groups.filter(r=>r.value>0),negative=groups.filter(r=>r.value<0),net=sum(bs,measure);
  const posTotal=positive.reduce((s,r)=>s+r.value,0),negTotal=negative.reduce((s,r)=>s-r.value,0);
  const diagrams=!groups.length?'<div class="empty">Нет строк источника для выбранных фильтров</div>':negative.length?`${positive.length?pieRing(positive,key,'Положительные итоги групп'):''}${pieRing(negative,key,'Отрицательные итоги групп, по модулю')}`:pieRing(positive,key,'');
  return `<section class="panel pie-panel"><div class="panel-head"><h2>${esc(title)}</h2><p>${esc(measures[measure].label)} · ${esc(measures[measure].unit)} · нажмите сектор или строку</p></div><div class="pie-visuals">${diagrams}</div><div class="pie-legend">${groups.map(r=>{const base=r.value<0?negTotal:posTotal,percent=base?Math.abs(r.value)/base*100:0;return `<button class="pie-legend-row" data-drill-key="${key}" data-drill-value="${esc(r.name)}"><span class="pie-label"><svg width="10" height="10" aria-hidden="true"><rect width="10" height="10" rx="2" fill="${r.color}"/></svg>${esc(r.name)}</span><span class="pie-amount"><strong>${num(r.value,measure==='budget_rub'?0:1)}</strong><span>${fmt(percent,1)}% · ${fmt(r.objects)} объектов${r.value<0?' · отрицательный итог':''}</span></span></button>`;}).join('')}</div><div class="pie-net"><span>Всего${negative.length?' (сальдо)':''}</span><strong>${num(net,measure==='budget_rub'?0:1)} ${esc(measures[measure].unit)}</strong></div>${negative.length?'<p class="note">Положительные и отрицательные итоги показаны отдельными кругами. Доли рассчитаны внутри каждого круга; знаки в суммах сохранены.</p>':''}<p class="note">${sourceCaption()}</p><details class="object-fold"><summary>Таблица и числовые значения</summary>${budgetTable(bs,key,title)}</details></section>`;
}
function bindSections(){
  document.querySelectorAll('[data-section]').forEach(b=>b.onclick=()=>{page=b.dataset.section;offset=0;drill=null;render();});
  document.querySelectorAll('.pie-ring [data-drill-key]').forEach(b=>b.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();b.onclick();}});
}
