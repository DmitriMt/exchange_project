'use strict';
// Browser XLSX export: typed OOXML cells, native charts, and an uncompressed ZIP.
const xEsc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c])).replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g,'');
const xCol=n=>{let s='';for(n++;n;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s;};
const xNum=v=>v===''||v==null?null:Number(v);
function xZip(files){
  const enc=new TextEncoder(),parts=[],central=[];let offset=0;
  const crcTable=Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
  const pack=(size,fill)=>{const a=new Uint8Array(size);fill(new DataView(a.buffer));return a;};
  for(const [name,text]of files){
    const n=enc.encode(name),data=enc.encode(text);let crc=0xffffffff;for(const b of data)crc=crcTable[(crc^b)&255]^(crc>>>8);crc=(crc^0xffffffff)>>>0;
    const local=pack(30,v=>{v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x800,true);v.setUint16(12,33,true);v.setUint32(14,crc,true);v.setUint32(18,data.length,true);v.setUint32(22,data.length,true);v.setUint16(26,n.length,true);});
    const c=pack(46,v=>{v.setUint32(0,0x02014b50,true);v.setUint16(4,20,true);v.setUint16(6,20,true);v.setUint16(8,0x800,true);v.setUint16(14,33,true);v.setUint32(16,crc,true);v.setUint32(20,data.length,true);v.setUint32(24,data.length,true);v.setUint16(28,n.length,true);v.setUint32(42,offset,true);});
    parts.push(local,n,data);central.push(c,n);offset+=local.length+n.length+data.length;
  }
  const size=central.reduce((s,p)=>s+p.length,0),end=pack(22,v=>{v.setUint32(0,0x06054b50,true);v.setUint16(8,files.length,true);v.setUint16(10,files.length,true);v.setUint32(12,size,true);v.setUint32(16,offset,true);});
  return new Blob([...parts,...central,end],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
}
function xChart(sheet,spec){
  const ns='http://schemas.openxmlformats.org/drawingml/2006/chart',an='http://schemas.openxmlformats.org/drawingml/2006/main';
  const ref=col=>`'${sheet.name.replace(/'/g,"''")}'!$${xCol(col)}$2:$${xCol(col)}$${sheet.rows.length}`;
  const vals=col=>sheet.rows.slice(1).map(r=>r[col]);
  const strings=col=>`<c:strRef><c:f>${xEsc(ref(col))}</c:f><c:strCache><c:ptCount val="${sheet.rows.length-1}"/>${vals(col).map((v,i)=>`<c:pt idx="${i}"><c:v>${xEsc(v)}</c:v></c:pt>`).join('')}</c:strCache></c:strRef>`;
  const numbers=col=>`<c:numRef><c:f>${xEsc(ref(col))}</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="${sheet.rows.length-1}"/>${vals(col).map((v,i)=>v==null?'':`<c:pt idx="${i}"><c:v>${Number(v)}</c:v></c:pt>`).join('')}</c:numCache></c:numRef>`;
  const colors=['138A75','6394BF','D7A24B'];
  const series=spec.cols.map((col,i)=>`<c:ser><c:idx val="${i}"/><c:order val="${i}"/><c:tx><c:v>${xEsc(sheet.rows[0][col])}</c:v></c:tx>${spec.type==='pie'?'':`<c:spPr><a:solidFill><a:srgbClr val="${colors[i%3]}"/></a:solidFill></c:spPr>`}<c:cat>${strings(0)}</c:cat><c:val>${numbers(col)}</c:val></c:ser>`).join('');
  const pie=spec.type==='pie';
  const graph=pie?`<c:pieChart><c:varyColors val="1"/>${series}<c:dLbls><c:showLegendKey val="0"/><c:showVal val="0"/><c:showCatName val="0"/><c:showSerName val="0"/><c:showPercent val="1"/><c:showLeaderLines val="1"/></c:dLbls><c:firstSliceAng val="270"/></c:pieChart>`:`<c:barChart><c:barDir val="bar"/><c:grouping val="${spec.percent?'percentStacked':'clustered'}"/><c:varyColors val="0"/>${series}<c:gapWidth val="70"/>${spec.percent?'<c:overlap val="100"/>':''}<c:axId val="101"/><c:axId val="102"/></c:barChart><c:catAx><c:axId val="101"/><c:scaling><c:orientation val="maxMin"/></c:scaling><c:axPos val="l"/><c:tickLblPos val="nextTo"/><c:crossAx val="102"/><c:crosses val="autoZero"/></c:catAx><c:valAx><c:axId val="102"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:axPos val="b"/><c:majorGridlines/><c:numFmt formatCode="${spec.percent?'0%':'#,##0.0'}" sourceLinked="0"/><c:tickLblPos val="nextTo"/><c:crossAx val="101"/><c:crosses val="autoZero"/><c:crossBetween val="between"/></c:valAx>`;
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><c:chartSpace xmlns:c="${ns}" xmlns:a="${an}"><c:lang val="ru-RU"/><c:chart><c:title><c:tx><c:rich><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:defRPr lang="ru-RU"/></a:pPr><a:r><a:t>${xEsc(spec.title)}</a:t></a:r></a:p></c:rich></c:tx><c:overlay val="0"/></c:title><c:autoTitleDeleted val="0"/><c:plotArea><c:layout/>${graph}</c:plotArea><c:legend><c:legendPos val="b"/><c:overlay val="0"/></c:legend><c:plotVisOnly val="1"/><c:dispBlanksAs val="gap"/></c:chart></c:chartSpace>`;
}
function makeXlsx(sheets){
  const main='http://schemas.openxmlformats.org/spreadsheetml/2006/main',rel='http://schemas.openxmlformats.org/package/2006/relationships',docRel='http://schemas.openxmlformats.org/officeDocument/2006/relationships';
  const files=[],overrides=[];let chartId=0;
  const add=(path,text,type)=>{files.push([path,text]);if(type)overrides.push(`<Override PartName="/${path}" ContentType="${type}"/>`);};
  add('_rels/.rels',`<Relationships xmlns="${rel}"><Relationship Id="rId1" Type="${docRel}/officeDocument" Target="xl/workbook.xml"/></Relationships>`);
  add('xl/workbook.xml',`<workbook xmlns="${main}" xmlns:r="${docRel}"><bookViews><workbookView/></bookViews><sheets>${sheets.map((s,i)=>`<sheet name="${xEsc(s.name)}" sheetId="${i+1}" r:id="rId${i+1}"/>`).join('')}</sheets><calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>`,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml');
  add('xl/_rels/workbook.xml.rels',`<Relationships xmlns="${rel}">${sheets.map((s,i)=>`<Relationship Id="rId${i+1}" Type="${docRel}/worksheet" Target="worksheets/sheet${i+1}.xml"/>`).join('')}<Relationship Id="rId${sheets.length+1}" Type="${docRel}/styles" Target="styles.xml"/></Relationships>`);
  add('xl/styles.xml',`<styleSheet xmlns="${main}"><numFmts count="2"><numFmt numFmtId="164" formatCode="#,##0.00;[Red]-#,##0.00"/><numFmt numFmtId="165" formatCode="0.0%"/></numFmts><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF174F52"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="5"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"><alignment vertical="top" wrapText="1"/></xf><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFill="1" applyFont="1"><alignment vertical="center" wrapText="1"/></xf><xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="3" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`,'application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml');
  sheets.forEach((s,i)=>{
    const n=i+1,last=xCol(Math.max(0,s.rows[0].length-1)),charts=s.charts||[];
    const data=s.rows.map((r,y)=>`<row r="${y+1}" ht="${Math.max(y===0?36:30,Math.min(160,...r.map((v,x)=>typeof v==='string'?v.split('\n').reduce((n,t)=>n+Math.max(1,Math.ceil(t.length/(s.widths?.[x]??(x===0?55:20)))),0)*14+8:30)))}" customHeight="1">${r.map((v,x)=>{const addr=xCol(x)+(y+1),style=y===0?1:s.percentCols?.includes(x)?3:typeof v==='number'?(Number.isInteger(v)?4:2):0;return v==null?'':typeof v==='number'?`<c r="${addr}" s="${style}"><v>${Number.isFinite(v)?v:0}</v></c>`:`<c r="${addr}" s="${style}" t="inlineStr"><is><t xml:space="preserve">${xEsc(v)}</t></is></c>`;}).join('')}</row>`).join('');
    add(`xl/worksheets/sheet${n}.xml`,`<worksheet xmlns="${main}" xmlns:r="${docRel}"><dimension ref="A1:${last}${s.rows.length}"/><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="30"/><cols>${s.rows[0].map((h,j)=>`<col min="${j+1}" max="${j+1}" width="${s.widths?.[j]??(j===0?55:20)}" customWidth="1"/>`).join('')}</cols><sheetData>${data}</sheetData>${s.rows.length>1?`<autoFilter ref="A1:${last}${s.rows.length}"/>`:''}${charts.length?'<drawing r:id="rId1"/>':''}</worksheet>`,'application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml');
    if(charts.length){
      add(`xl/worksheets/_rels/sheet${n}.xml.rels`,`<Relationships xmlns="${rel}"><Relationship Id="rId1" Type="${docRel}/drawing" Target="../drawings/drawing${n}.xml"/></Relationships>`);
      const drawingRels=[],anchors=[];
      charts.forEach((spec,j)=>{chartId++;const id=chartId,from=s.rows[0].length+1;
        add(`xl/charts/chart${id}.xml`,xChart(s,spec),'application/vnd.openxmlformats-officedocument.drawingml.chart+xml');
        drawingRels.push(`<Relationship Id="rId${j+1}" Type="${docRel}/chart" Target="../charts/chart${id}.xml"/>`);
        anchors.push(`<xdr:twoCellAnchor><xdr:from><xdr:col>${from}</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>${j*27+1}</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from><xdr:to><xdr:col>${from+11}</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>${j*27+26}</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to><xdr:graphicFrame macro=""><xdr:nvGraphicFramePr><xdr:cNvPr id="${j+2}" name="Chart ${id}"/><xdr:cNvGraphicFramePr/></xdr:nvGraphicFramePr><xdr:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/></xdr:xfrm><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/chart"><c:chart xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" r:id="rId${j+1}"/></a:graphicData></a:graphic></xdr:graphicFrame><xdr:clientData/></xdr:twoCellAnchor>`);
      });
      add(`xl/drawings/drawing${n}.xml`,`<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="${docRel}">${anchors.join('')}</xdr:wsDr>`,'application/vnd.openxmlformats-officedocument.drawing+xml');
      add(`xl/drawings/_rels/drawing${n}.xml.rels`,`<Relationships xmlns="${rel}">${drawingRels.join('')}</Relationships>`);
    }
  });
  files.push(['[Content_Types].xml',`<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>${overrides.join('')}</Types>`]);
  return xZip(files);
}
