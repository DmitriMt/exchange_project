"""Read saved XLSX values without modifying source books; produce the dashboard CSV."""
import argparse
import collections
import csv
from decimal import Decimal, InvalidOperation
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET
import zipfile
import posixpath

from registry import REGISTRY_FIELDS, registry_entities
from transition import TRANSITION_FIELDS, read_questionnaire, apply_questionnaire
from rsm_presence import RSM_FIELDS, annotate_rsm
from ownership import OWNERSHIP_FIELDS, CATALOG_COLUMNS, enrich_ownership

NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
FIELDS = ['record_type', 'id_ke', 'name', 'category', 'parent_id', 'dit', 'business_block',
          'criticality', 'lifecycle', 'snapshot', 'budget_consumption', 'stand',
          'budget_rub', 'budget_source_id', 'pshe_change_main', 'pshe_run_main',
          'pshe_change_prom', 'pshe_run_prom', 'pshe_source_change', 'pshe_source_run',
          'pshe_status', 'pshe_prom_status', 'in_as_list', 'cpu', 'ram_gb', 'disk_gb', 'pshe_model_inputs',
          'pshe_change_standin', 'pshe_run_standin', 'pshe_vendor_standin']
LEGACY_FIELDS = FIELDS[:]
FIELDS = FIELDS + OWNERSHIP_FIELDS
V13_FIELDS = FIELDS[:]
FIELDS = FIELDS + RSM_FIELDS
V15_FIELDS = FIELDS[:]
FIELDS = FIELDS + TRANSITION_FIELDS
V16_FIELDS = FIELDS[:]
FIELDS = FIELDS + REGISTRY_FIELDS


def xlsx_rows(path, sheet=1):
    with zipfile.ZipFile(path) as book:
        sheet_path = f'xl/worksheets/sheet{sheet}.xml'
        if isinstance(sheet, str):
            workbook = ET.fromstring(book.read('xl/workbook.xml'))
            selected = next((s for s in workbook.find(NS + 'sheets') if s.get('name') == sheet), None)
            if selected is None:
                raise ValueError(f'{path.name}: нет листа «{sheet}»')
            rid = selected.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
            relationships = ET.fromstring(book.read('xl/_rels/workbook.xml.rels'))
            target = next(r.get('Target') for r in relationships if r.get('Id') == rid)
            sheet_path = target.lstrip('/') if target.startswith('/') else posixpath.normpath('xl/' + target)
        strings = []
        if 'xl/sharedStrings.xml' in book.namelist():
            with book.open('xl/sharedStrings.xml') as stream:
                for _, el in ET.iterparse(stream, events=('end',)):
                    if el.tag == NS + 'si':
                        strings.append(''.join(t.text or '' for t in el.iter(NS + 't')))
                        el.clear()
        with book.open(sheet_path) as stream:
            for _, el in ET.iterparse(stream, events=('end',)):
                if el.tag != NS + 'row':
                    continue
                row = {}
                for cell in el:
                    col = re.sub(r'\d', '', cell.get('r'))
                    value, inline = cell.find(NS + 'v'), cell.find(NS + 'is')
                    if inline is not None:
                        text = ''.join(t.text or '' for t in inline.iter(NS + 't'))
                    elif value is not None:
                        text = strings[int(value.text)] if cell.get('t') == 's' else value.text or ''
                    else:
                        text = ''
                    if cell.get('t') == 'e':
                        raise ValueError(f'{path.name}: Excel error at {cell.get("r")}: {text}')
                    row[col] = text
                idx = int(el.get('r'))
                el.clear()
                yield idx, row


def prepare(folder, destination, snapshot_date=None, progress=print):
    catalogs = list(folder.glob('table_runup_DS_main_Katalog_IT-uslug_*.xlsx'))
    if len(catalogs) != 1:
        raise ValueError('Положите ровно один актуальный каталог в папку источников')
    catalog = catalogs[0]
    calculators = list(folder.glob('Калькулятор_ПШЕ*.xlsx'))
    if len(calculators) > 1:
        raise ValueError('Допускается не более одного дополнительного калькулятора ПШЕ')
    criticality = {'Mission Critical+': 'MC+', 'Mission Critical': 'MC', 'Business Critical': 'BC'}
    entities, full_catalog = {}, {}
    snapshot = re.search(r'_(\d{8})_\d{6}', catalog.name).group(1)
    snapshot = f'{snapshot[:4]}-{snapshot[4:6]}-{snapshot[6:]}'
    if snapshot_date:
        from datetime import datetime
        datetime.strptime(snapshot_date, '%Y-%m-%d')
        snapshot = snapshot_date
    progress('Читаем каталог ИТ-услуг')
    for idx, r in xlsx_rows(catalog):
        if idx == 1:
            if not (r.get('A') == 'ID КЭ' and r.get('S') == 'Уровень критичности' and r.get('V') == 'Обеспечивающее подразделение' and r.get('BF') == 'Владелец (Блок)' and r.get('BG') == 'Владелец (подразделение)' and r.get('BK') == 'Трайб/ГАК владелец' and r.get('BM') == 'Код трайба/ГАК'):
                raise ValueError('Структура каталога ИТ-услуг не распознана')
            continue
        if r.get('A') in full_catalog:
            raise ValueError('Повтор CI-ID в каталоге: ' + str(r.get('A')))
        full_catalog[r['A']] = {k: r.get(k, '') for k in CATALOG_COLUMNS}
    questionnaires=list(folder.glob('Опросник перехода*.xlsx'))
    if len(questionnaires)!=1:
        raise ValueError('Базовый источник обязателен: один Опросник перехода*.xlsx')
    questionnaire=read_questionnaire(questionnaires[0])
    entities=registry_entities(questionnaire,full_catalog,snapshot)
    # Retained CSV column for compatibility; the current roster is RUNUP only.
    listed = set(entities)
    for entity in entities.values():
        entity['in_as_list'] = '1'
    annotate_rsm(entities, folder, destination.parent / 'rsm_presence_cache.json', progress)
    progress('Читаем дополнительный калькулятор ПШЕ' if calculators else 'Рассчитываем ПШЕ встроенной серверной моделью v4.3')
    pshe_seen = set()
    for idx, r in (xlsx_rows(calculators[0], 'Объекты') if calculators else []):
        if idx == 7 and (r.get('B') != 'КЭ' or not all('Stand-IN' in r.get(c, '') for c in ['S', 'T', 'U'])):
            raise ValueError('Структура калькулятора ПШЕ не распознана: нужны КЭ и S/T/U со Stand-IN')
        if idx <= 7 or not r.get('B'):
            continue
        ci = r['B']
        if ci in pshe_seen:
            raise ValueError('Duplicate PSHE ID: ' + ci)
        pshe_seen.add(ci)
        if ci not in entities:
            continue
        entity = entities[ci]
        if r.get('C') != entity['category']:
            raise ValueError('PSHE category mismatch: ' + ci)
        for field, col in [('pshe_change_main', 'I'), ('pshe_run_main', 'J'),
                           ('pshe_change_prom', 'V'), ('pshe_run_prom', 'W'),
                           ('pshe_change_standin', 'S'), ('pshe_run_standin', 'T'), ('pshe_vendor_standin', 'U')]:
            value = r.get(col, '')
            if value == '':
                raise ValueError(f'Калькулятор: {ci}, поле {col} пусто. Пересчитайте и сохраните Excel перед загрузкой.')
            try:
                if not Decimal(value).is_finite():
                    raise InvalidOperation
            except InvalidOperation:
                raise ValueError(f'Калькулятор: {ci}, поле {col} не является числом')
            entity[field] = value
        entity.update(pshe_source_change=r.get('P', ''), pshe_source_run=r.get('Q', ''),
                      pshe_status=r.get('R', '') or 'Есть в калькуляторе', pshe_prom_status=r.get('AB', ''))
    from model_enrichment import complete_pshe
    complete_pshe(entities, folder, cache_path=destination.parent / 'model_inputs_cache.json', progress=progress)
    progress('Собираем стоимость и мощности КТС')
    budgets, outside, excluded = [], [], collections.Counter()
    for idx, r in xlsx_rows(folder / 'Кошельки.xlsx'):
        if idx == 1:
            if r.get('N') != 'КЭ АС/ФП' or 'ИТОГО' not in r.get('AN', ''):
                raise ValueError('Структура Кошельков не распознана')
            continue
        ci = r.get('N', '')
        if not r.get('AN'):
            raise ValueError(f'Кошельки: нет стоимости в строке {idx}')
        if ci not in entities:
            excluded['rows_outside_perimeter'] += 1
            c = full_catalog.get(ci, {})
            outside.append(dict(record_type='budget_outside', id_ke=ci or '(не указан)', name=r.get('O') or '(не указано)',
                                category=c.get('G') or 'Нет в каталоге', parent_id='', dit=c.get('V') or r.get('I') or '(не указан)',
                                business_block=c.get('BF') or r.get('K') or '(не указан)', criticality=c.get('S') or '(не указана)',
                                lifecycle=c.get('M') or '(не указан)', snapshot=snapshot, in_as_list='1' if ci in listed else '0',
                                budget_consumption=r.get('B') or '(не указан)', stand=r.get('P') or '(не указан)',
                                budget_rub=str(Decimal(r.get('AN') or '0') * 1000000), cpu=r.get('W') or '0', ram_gb=r.get('X') or '0',
                                disk_gb=str(Decimal(r.get('Y') or '0') + Decimal(r.get('Z') or '0')),
                                budget_source_id=f'Кошельки:Sheet1:{idx}:{r.get("H", "")}'))
            continue
        if not r.get('AN'):
            raise ValueError(f'Нет стоимости в строке {idx} «Кошельков»')
        amount = Decimal(r['AN']) * Decimal(1000000)
        if not amount.is_finite():
            raise ValueError('Invalid budget')
        e = entities[ci]
        b = {k: e[k] for k in ['id_ke', 'name', 'category', 'parent_id', 'dit', 'business_block', 'criticality', 'lifecycle', 'snapshot', 'in_as_list']}
        b.update(record_type='budget', budget_consumption=r.get('B') or '(не указан)',
                 stand=r.get('P') or '(не указан)', budget_rub=format(amount, 'f'),
                 budget_source_id=f'Кошельки:Sheet1:{idx}:{r.get("H", "")}',
                 cpu=r.get('W', ''), ram_gb=r.get('X', ''),
                 disk_gb=str(Decimal(r.get('Y') or '0') + Decimal(r.get('Z') or '0')))
        budgets.append(b)
    transition_report=apply_questionnaire(list(entities.values()),questionnaire)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS, delimiter=';')
        writer.writeheader()
        writer.writerows(list(entities.values()) + budgets + outside)
    report = dict(transition=transition_report, fp_without_rsm=sum(e['category']=='ФП' and e['rsm_presence']=='0' for e in entities.values()), entities=len(entities), categories=dict(collections.Counter(e['category'] for e in entities.values())),
                  pshe_missing=dict(collections.Counter(e['category'] for e in entities.values() if e['id_ke'] not in pshe_seen)),
                  budget_rows=len(budgets), budget_objects=len(set(b['id_ke'] for b in budgets)),
                  budget_rub=str(sum(Decimal(b['budget_rub']) for b in budgets)),
                  consumption=dict(collections.Counter(b['budget_consumption'] for b in budgets)),
                  stands=dict(collections.Counter(b['stand'] for b in budgets)), excluded=dict(excluded),
                  in_as_list=sum(e['in_as_list'] == '1' for e in entities.values()),
                  pshe_remaining_missing=sum(not e.get('pshe_change_main') or not e.get('pshe_run_main') for e in entities.values()),
                  cpu=str(sum(Decimal(b['cpu'] or '0') for b in budgets)),
                  ram_gb=str(sum(Decimal(b['ram_gb'] or '0') for b in budgets)),
                  disk_gb=str(sum(Decimal(b['disk_gb'] or '0') for b in budgets)))
    destination.with_suffix('.report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
    progress('Срез подготовлен: ' + str(len(entities)) + ' объектов')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--date')
    args = parser.parse_args()
    print(json.dumps(prepare(args.source, args.output, args.date), ensure_ascii=False, indent=2))
