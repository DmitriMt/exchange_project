import unittest
from pathlib import Path
from registry import registry_entities,validate_registry_row
from transition import read_questionnaire
from server import parse_data,ROOT

class RegistryTests(unittest.TestCase):
    def test_questionnaire_is_exact_base_without_catalog_or_prod_filters(self):
        q=dict(file='Опросник.xlsx',sha256='a'*64,records={
          'CI1':dict(row=2,name='Имя RUNUP',category='Автоматизированные системы',criticality='Business Critical',lifecycle='Опытная эксплуатация',dit='ДИТ RUNUP',parent_id='',raw='',strategy=''),
          'CI2':dict(row=3,name='ФП без каталога',category='Функциональная подсистема',criticality='Business Critical',lifecycle='Опытная эксплуатация',dit='ДИТ RUNUP',parent_id='CI1',raw='',strategy=''),
          'CI3':dict(row=4,name='ФП ПРОМ',category='Функциональная подсистема',criticality='Mission Critical',lifecycle='Промышленная эксплуатация',dit='ДИТ RUNUP',parent_id='CI1',raw='A-A-P',strategy='A-A-P')})
        catalog={'CI1':dict(A='CI1',B='Не это имя',G='Автоматизированные системы',S='Mission Critical+',M='Промышленная эксплуатация',V='Не этот ДИТ',BF='Блок',BG='Владелец'),
                 'CI999':dict(A='CI999',B='Лишняя АС каталога',G='Автоматизированные системы',S='Mission Critical+',M='Промышленная эксплуатация')}
        e=registry_entities(q,catalog,'2026-11-03')
        self.assertEqual(set(e),set(q['records']))
        self.assertNotIn('CI999',e)
        self.assertEqual(e['CI1']['name'],'Имя RUNUP')
        self.assertEqual(e['CI1']['dit'],'ДИТ RUNUP')
        self.assertEqual(e['CI1']['criticality'],'BC')
        self.assertEqual(e['CI1']['lifecycle'],'Опытная эксплуатация')
        self.assertEqual(e['CI2']['catalog_presence'],'0')
        self.assertEqual(e['CI1']['fp_registry_total'],'2')
        for row in e.values():validate_registry_row(row)

    def test_built_base_equals_all_1415_questionnaire_ids(self):
        rows=parse_data((ROOT/'data/dashboard.csv').read_bytes())
        es=[r for r in rows if r['record_type']=='entity']
        q=read_questionnaire(Path('/Users/evgeny/ChatGPT/Dash Мультицод+/Опросник перехода.xlsx'))
        self.assertEqual({r['id_ke'] for r in es},set(q['records']))
        self.assertEqual(len(es),1415)
        self.assertEqual(sum(e['category']=='АС' for e in es),422)
        self.assertEqual(sum(e['category']=='ФП' for e in es),993)
        self.assertEqual(sum(e['category']=='ФП' and e['rsm_presence']=='0' for e in es),122)
        self.assertEqual(sum(e['lifecycle']!='ПРОМ' for e in es),143)
        self.assertTrue(all(e['base_source']=='RUNUP_QUESTIONNAIRE' for e in es))
        self.assertEqual(sum(int(e['fp_registry_total']) for e in es if e['category']=='АС'),993)
        for e in es:
            self.assertEqual(e['name'],q['records'][e['id_ke']]['name'])
            self.assertEqual(e['transition_row'],str(q['records'][e['id_ke']]['row']))

if __name__=='__main__':unittest.main()
