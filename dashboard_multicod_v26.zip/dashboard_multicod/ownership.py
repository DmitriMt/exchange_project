"""Snapshot-bound ownership and AS/FP composition, before perimeter filtering."""
import json
import collections
import re

OWNERSHIP_FIELDS = ['owner_department', 'owner_department_code', 'owner_tribe', 'owner_tribe_code',
                    'parent_name', 'parent_business_block', 'parent_owner_department',
                    'parent_owner_tribe', 'parent_owner_tribe_code', 'parent_criticality',
                    'parent_lifecycle', 'parent_in_scope', 'fp_prom_total', 'fp_scope_total',
                    'parent_fp_prom_total', 'parent_fp_scope_total', 'fp_children_json']
CATALOG_COLUMNS = ['A', 'B', 'G', 'H', 'M', 'S', 'V', 'BF', 'BG', 'BJ', 'BK', 'BM']
CRITICALITIES = {'Mission Critical+': 'MC+', 'Mission Critical': 'MC', 'Business Critical': 'BC'}


def parent_id(row):
    match = re.search(r'\((CI\d+)\)', row.get('H', ''))
    if not match:
        match = re.fullmatch(r'\s*(CI\d+)\s*', row.get('H', ''))
    return match.group(1) if match else ''


def enrich_ownership(entities, catalog):
    prom, scope, children = collections.Counter(), collections.Counter(), collections.defaultdict(list)
    for row in catalog.values():
        if row.get('G') == 'Функциональная подсистема' and row.get('M') == 'Промышленная эксплуатация':
            parent = parent_id(row)
            if parent and catalog.get(parent, {}).get('G') == 'Автоматизированные системы':
                prom[parent] += 1
                children[parent].append(dict(id_ke=row['A'], name=row.get('B', ''), category='ФП', parent_id=parent,
                                             business_block=row.get('BF', ''), owner_department=row.get('BG', ''),
                                             owner_department_code=row.get('BJ', ''), owner_tribe=row.get('BK', ''),
                                             owner_tribe_code=row.get('BM', ''), lifecycle='ПРОМ',
                                             criticality=CRITICALITIES.get(row.get('S'), row.get('S', ''))))
                if row.get('S') in CRITICALITIES:
                    scope[parent] += 1
    for ci, entity in entities.items():
        row = catalog.get(ci, {})
        entity.update({key: '' for key in OWNERSHIP_FIELDS})
        entity.update(owner_department=row.get('BG', ''), owner_department_code=row.get('BJ', ''),
                      owner_tribe=row.get('BK', ''), owner_tribe_code=row.get('BM', ''))
        if entity['category'] == 'АС':
            entity.update(fp_prom_total=str(prom[ci]), fp_scope_total=str(scope[ci]),
                          fp_children_json=json.dumps(children[ci], ensure_ascii=False, separators=(',', ':')))
        else:
            entity['parent_id'] = parent_id(row)
            parent = catalog.get(entity['parent_id'], {})
            if parent.get('G') != 'Автоматизированные системы':
                continue
            entity.update(parent_name=parent.get('B', ''), parent_business_block=parent.get('BF', ''),
                          parent_owner_department=parent.get('BG', ''), parent_owner_tribe=parent.get('BK', ''),
                          parent_owner_tribe_code=parent.get('BM', ''),
                          parent_criticality=CRITICALITIES.get(parent.get('S'), parent.get('S', '')),
                          parent_lifecycle=parent.get('M', ''),
                          parent_fp_prom_total=str(prom[entity['parent_id']]), parent_fp_scope_total=str(scope[entity['parent_id']]),
                          parent_in_scope='1' if parent.get('S') in CRITICALITIES and parent.get('M') == 'Промышленная эксплуатация' else '0')


def validate_ownership(row):
    for field in ('fp_prom_total', 'fp_scope_total', 'parent_fp_prom_total', 'parent_fp_scope_total'):
        if row.get(field) and not re.fullmatch(r'\d{1,7}', row[field]):
            raise ValueError('Неверное количество ФП: ' + field)
    for total, subset in [('fp_prom_total', 'fp_scope_total'), ('parent_fp_prom_total', 'parent_fp_scope_total')]:
        if row.get(total) and row.get(subset) and int(row[subset]) > int(row[total]):
            raise ValueError('Количество ФП в периметре больше общего состава')
    raw = row.get('fp_children_json')
    if not raw:
        return
    try:
        children = json.loads(raw)
        if row['record_type'] != 'entity' or row['category'] != 'АС' or not isinstance(children, list) or len(raw) > 2000000:
            raise ValueError()
        seen = set()
        for child in children:
            if not isinstance(child, dict) or any(not isinstance(v, str) for v in child.values()) or not re.fullmatch(r'CI\d+', child.get('id_ke', '')) or not child.get('name') or child.get('category') != 'ФП' or child.get('parent_id') != row['id_ke'] or child['id_ke'] in seen:
                raise ValueError()
            seen.add(child['id_ke'])
        if row.get('fp_prom_total') and len(children) != int(row['fp_prom_total']):
            raise ValueError()
        if row.get('fp_scope_total') and sum(c.get('criticality') in ('MC+', 'MC', 'BC') for c in children) != int(row['fp_scope_total']):
            raise ValueError()
    except (ValueError, TypeError, AttributeError):
        raise ValueError('Некорректный состав ФП: ' + row['id_ke'])
