import csv
import io
from pathlib import Path
import tempfile
import unittest
import zipfile
from xml.sax.saxutils import escape
from transition import read_questionnaire, apply_questionnaire, normalize_strategy, validate_transition
from prepare_data import FIELDS,V15_FIELDS
from server import parse_data,ROOT


def questionnaire(path,values):
    headers=['Обеспечивающее подразделение','Детализация','Название','ID КЭ','Тип','Категория','Критичность','ЖЦ','АС','ДИТ АС','Стратегия перехода в МультиЦОД +']
    rows=[headers,*values]
    xml='<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'+''.join('<row r="'+str(i)+'">'+''.join('<c r="'+chr(65+j)+str(i)+'" t="inlineStr"><is><t>'+escape(str(v or ''))+'</t></is></c>' for j,v in enumerate(row))+'</row>' for i,row in enumerate(rows,1))+'</sheetData></worksheet>'
    with zipfile.ZipFile(path,'w') as z:
        z.writestr('xl/workbook.xml','<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Опросник" r:id="rId1"/></sheets></workbook>')
        z.writestr('xl/_rels/workbook.xml.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Target="worksheets/sheet1.xml"/></Relationships>')
        z.writestr('xl/worksheets/sheet1.xml',xml)


def answer(ci,strategy='',category='Функциональная подсистема'):
    r=['']*11;r[2]='Объект '+ci;r[3]=ci;r[5]=category;r[10]=strategy;return r

class TransitionTests(unittest.TestCase):
    def test_classification_does_not_inherit_parent_and_resets_removed_answers(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)/'Опросник перехода.xlsx'
            questionnaire(p,[answer('CI1','a – a – a','Автоматизированные системы'),answer('CI2',''),answer('CI3','A-A-P'),answer('CI999','A-P-P')])
            rows=[dict(record_type='entity',id_ke=ci,category=cat,parent_id='CI1') for ci,cat in [('CI1','АС'),('CI2','ФП'),('CI3','ФП'),('CI4','ФП')]]
            report=apply_questionnaire(rows,read_questionnaire(p))
            self.assertEqual((report['planned'],report['blank'],report['not_listed']),(2,1,1))
            self.assertEqual(len(report['outside']),1)
            self.assertEqual(rows[1]['transition_strategy'],'')
            self.assertEqual(rows[0]['transition_strategy'],'A-A-A')
            for r in rows:validate_transition(r)
            questionnaire(p,[answer('CI2','A-P-P')])
            report=apply_questionnaire(rows,read_questionnaire(p))
            self.assertEqual(report['planned'],1)
            self.assertEqual(rows[0]['transition_status'],'not_listed')
            self.assertEqual(rows[0]['transition_strategy'],'')

    def test_bad_or_duplicate_answers_are_rejected_before_modification(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)/'bad.xlsx'
            questionnaire(p,[answer('CI1','A-A-A'),answer('CI1','A-P-P')])
            with self.assertRaisesRegex(ValueError,'повтор'):read_questionnaire(p)
            questionnaire(p,[answer('CI1','планируется')])
            with self.assertRaisesRegex(ValueError,'A-A-A'):read_questionnaire(p)
            questionnaire(p,[answer('CI1','A-A-A','Автоматизированные системы')])
            rows=[dict(record_type='entity',id_ke='CI1',category='ФП',transition_strategy='A-P-P')]
            with self.assertRaisesRegex(ValueError,'категория'):apply_questionnaire(rows,read_questionnaire(p))
            self.assertEqual(rows[0]['transition_strategy'],'A-P-P')

    def test_prior_csv_does_not_fabricate_strategies(self):
        rows=parse_data((ROOT/'data/dashboard.csv').read_bytes())
        out=io.StringIO();w=csv.DictWriter(out,V15_FIELDS,delimiter=';',extrasaction='ignore');w.writeheader();w.writerows(rows)
        old=parse_data(out.getvalue().encode('utf-8-sig'))
        self.assertTrue(all(r['transition_status']=='' for r in old))
        invalid=dict(next(r for r in rows if r['record_type']=='entity'),transition_status='planned',transition_strategy='A-A-A',transition_raw='')
        with self.assertRaises(ValueError):validate_transition(invalid)
        self.assertEqual(normalize_strategy('А-А-Р'),'A-A-P')

if __name__=='__main__':unittest.main()
