#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ ! -s private/users.json ]; then
  echo 'Первый запуск: задайте пароль пользователя operator.'
  python3 -B server.py --add-user operator --role admin
fi
echo 'Войдите под своей учётной записью. Для загрузки источников выберите «Обновление из Excel».'
(
  sleep 2
  open 'http://127.0.0.1:8080/'
) &
python3 -B server.py --host 127.0.0.1 --port 8080
