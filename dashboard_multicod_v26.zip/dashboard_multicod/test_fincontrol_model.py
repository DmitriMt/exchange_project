import copy
from decimal import Decimal
import json
from pathlib import Path
import tempfile
import unittest
import zipfile
from fincontrol_model import complete_fincontrol, evidence_for, signature_key, resource_evidence

SIG=[['РСМ ДЭШ_1.xlsx','a'*64],['РСМ ДЭШ_2.xlsx','b'*64]]
PROOF='; '.join(n+'='+s for n,s in SIG)

def entity(ci,category='АС',presence='1',base='RUNUP_QUESTIONNAIRE'):
    return dict(record_type='entity',id_ke=ci,category=category,rsm_presence=presence,rsm_source=PROOF,
                base_source=base,name=ci,criticality='MC',business_block='Блок',dit='ДИТ')

def resource(cpu,rows=1,prom=1,invalid=False):
    return dict(cpu=str(cpu),rows=rows,prom_rows=prom,invalid_cpu=invalid)

class CompletionTests(unittest.TestCase):
    def setUp(self):
        self.original=dict(id_ke='CI1',name='Сохранённый',criticality='MC',cpu_rsm=100,cpu_openshift=0,cpu_total=100,fte=9)
        self.baseline=dict(records=[self.original],total=dict(systems=1,fte=9,cpu_rsm=100,cpu_openshift=0,cpu_total=100),
                           model=dict(coefficient='0.01',formula='CPU × coefficient',openshift={'CI2':'10'}))
        self.evidence=dict(signature=SIG,resources={'АС':{'CI2':resource(100),'CI5':resource(500),'CI6':resource(900),'CI7':resource(20),'CI8':resource(20),'CI9':resource(20),'CI10':resource(0,prom=0),'CI11':resource(0,invalid=True)},'ФП':{'CI3':resource(50)}})

    def test_only_proven_intersection_and_existing_values_unchanged(self):
        rows=[entity('CI1',presence='0'),entity('CI2'),entity('CI3','ФП'),entity('CI4'),
              entity('CI6','ФП'),entity('CI7',base='LEGACY_CATALOG'),entity('CI8',presence=''),entity('CI9'),entity('CI10'),entity('CI11')]
        rows[7]['rsm_source']='другие файлы'
        before=copy.deepcopy(self.baseline)
        result=complete_fincontrol(self.baseline,rows,self.evidence)
        self.assertEqual(self.baseline,before)
        self.assertEqual(result['records'][0],self.original)
        new={r['id_ke']:r for r in result['completion']['added']}
        self.assertEqual(set(new),{'CI2','CI3','CI10'})
        self.assertAlmostEqual(new['CI2']['fte'],1.1)
        self.assertAlmostEqual(new['CI3']['fte'],.5)
        self.assertEqual(new['CI10']['fte'],0)
        self.assertTrue(new['CI10']['zero_reason'])
        self.assertAlmostEqual(result['total']['fte'],10.6)
        self.assertEqual(result['completion']['added_count'],3)
        self.assertEqual(result['records'],complete_fincontrol(self.baseline,rows,self.evidence)['records'])

    def test_missing_or_partial_or_mismatched_evidence_blocks_new_estimates(self):
        rows=[entity('CI2'),entity('CI3','ФП')]
        for evidence in [None,dict(signature=SIG[:1],resources=self.evidence['resources']),dict(signature=[['РСМ ДЭШ_1.xlsx','c'*64],SIG[1]],resources=self.evidence['resources'])]:
            result=complete_fincontrol(self.baseline,rows,evidence)
            self.assertEqual(result['completion']['added_count'],0)
            self.assertEqual(result['total']['fte'],9)
        with tempfile.TemporaryDirectory()as folder:
            target=Path(folder)/(signature_key(SIG)+'.json');target.write_text(json.dumps(self.evidence))
            self.assertIsNotNone(evidence_for(rows,folder))
            rows[0]['rsm_source']=''
            rows[1]['rsm_source']=''
            self.assertIsNone(evidence_for(rows,folder))

    def test_duplicate_ids_rejected(self):
        with self.assertRaises(ValueError):complete_fincontrol(self.baseline,[entity('CI2'),entity('CI2')],self.evidence)
        baseline=copy.deepcopy(self.baseline);baseline['records'].append(self.original)
        with self.assertRaises(ValueError):complete_fincontrol(baseline,[],self.evidence)

    def test_raw_rsm_own_keys_production_only_and_both_files(self):
        def book(path, rows):
            headers={'D':'АС КЭ','L':'ФП КЭ','N':'Стенд Тип','AK':'кол-во Ядер'}
            xml='<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'
            for i,row in enumerate([headers]+rows,1):
                xml+='<row r="'+str(i)+'">'+''.join('<c r="'+k+str(i)+'" t="inlineStr"><is><t>'+v+'</t></is></c>'for k,v in row.items())+'</row>'
            xml+='</sheetData></worksheet>'
            with zipfile.ZipFile(path,'w')as z:z.writestr('xl/worksheets/sheet1.xml',xml)
        with tempfile.TemporaryDirectory()as folder:
            root=Path(folder)
            book(root/SIG[0][0],[{'D':'CI2','L':'CI3','N':'ПРОМ (промышленная среда)','AK':'100'}, {'D':'CI2','N':'ПРОМ Stand-IN','AK':'999'}, {'L':'CI4','N':'DEV','AK':'888'}])
            book(root/SIG[1][0],[{'D':'CI2','N':'ПРОМ (промышленная среда)','AK':'25'}])
            evidence=resource_evidence(root,root/'evidence',lambda _:None)
            self.assertEqual(Decimal(evidence['resources']['АС']['CI2']['cpu']),125)
            self.assertEqual(Decimal(evidence['resources']['ФП']['CI3']['cpu']),100)
            self.assertEqual(evidence['resources']['ФП']['CI4']['prom_rows'],0)
            self.assertEqual(len(evidence['signature']),2)
            self.assertNotIn('CI3',evidence['resources']['АС'])
            self.assertNotIn('CI2',evidence['resources']['ФП'])

if __name__=='__main__':unittest.main()
