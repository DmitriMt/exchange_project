"""Import the saved financial-control summary from an XLSX workbook, without recalculation."""
import argparse
from datetime import datetime
import hashlib
import json
import math
import re
from fincontrol_model import model_reference
from pathlib import Path
import posixpath
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
NS = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}


def read_summary(source):
    with zipfile.ZipFile(source) as book:
        workbook = ET.fromstring(book.read('xl/workbook.xml'))
        sheet = next(s for s in workbook.find('s:sheets', NS)
                     if s.get('name') == 'Итоги для финконтроля')
        rel_id = sheet.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
        relationships = ET.fromstring(book.read('xl/_rels/workbook.xml.rels'))
        target = next(r.get('Target') for r in relationships if r.get('Id') == rel_id)
        target = target.lstrip('/') if target.startswith('/') else posixpath.normpath('xl/' + target)
        values = {}
        for cell in ET.fromstring(book.read(target)).iter('{' + NS['s'] + '}c'):
            value = cell.find('s:v', NS)
            if value is not None and cell.get('t') not in ('s', 'e', 'str'):
                values[cell.get('r')] = float(value.text)
    keys = ['systems', 'cpu_rsm', 'cpu_openshift', 'cpu_total', 'fte', 'share']

    def row(number):
        return {key: values[f'{column}{number}'] for column, key in zip('BCDEFG', keys)}

    classes = [dict(criticality=label, **row(number))
               for label, number in [('MC+', 7), ('MC', 8), ('BC', 9)]]
    total = row(10)
    import math
    for key in keys:
        if not math.isfinite(total[key]) or not math.isclose(sum(r[key] for r in classes), total[key], rel_tol=1e-9, abs_tol=1e-6):
            raise ValueError('Не сходится итог: ' + key)
    for item in classes + [total]:
        if not math.isclose(item['cpu_rsm'] + item['cpu_openshift'], item['cpu_total']):
            raise ValueError('Не сходится сумма CPU')
    records = read_records(source)
    for group in classes:
        selected = [r for r in records if r['criticality'] == group['criticality']]
        for key in ['systems', 'cpu_rsm', 'cpu_openshift', 'cpu_total', 'fte']:
            value = len(selected) if key == 'systems' else math.fsum(r[key] for r in selected)
            if not math.isclose(value, group[key], rel_tol=1e-9, abs_tol=1e-6):
                raise ValueError('Детализация не сходится со сводкой: ' + group['criticality'] + ' / ' + key)
    return dict(schema_version=2, title='Итог 2045', scope='MC+, MC и BC · промышленная среда',
                source_file=source.name, source_sheet='Итоги для финконтроля',
                source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                imported_on=datetime.now().astimezone().date().isoformat(), classes=classes, total=total,
                records=records, model=model_reference(source))


def read_records(source):
    with zipfile.ZipFile(source) as book:
        strings = []
        if 'xl/sharedStrings.xml' in book.namelist():
            for _, element in ET.iterparse(book.open('xl/sharedStrings.xml'), events=['end']):
                if element.tag == '{' + NS['s'] + '}si':
                    strings.append(''.join(element.itertext()))
                    element.clear()
        relationships = {r.get('Id'): r.get('Target') for r in ET.fromstring(book.read('xl/_rels/workbook.xml.rels'))}
        paths = {}
        for sheet in ET.fromstring(book.read('xl/workbook.xml')).find('s:sheets', NS):
            target = relationships[sheet.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')]
            paths[sheet.get('name').strip()] = target.lstrip('/') if target.startswith('/') else posixpath.normpath('xl/' + target)

        def rows(name):
            for _, element in ET.iterparse(book.open(paths[name]), events=['end']):
                if element.tag != '{' + NS['s'] + '}row':
                    continue
                result = {}
                for cell in element:
                    value = cell.find('s:v', NS)
                    inline = cell.find('s:is', NS)
                    value = value.text if value is not None else ''.join(inline.itertext()) if inline is not None else ''
                    if cell.get('t') == 's' and value:
                        value = strings[int(value)]
                    result[re.sub(r'[^A-Z]', '', cell.get('r', ''))] = value
                element.clear()
                yield result

        def number(value):
            result = float(value)
            if not math.isfinite(result) or result < 0:
                raise ValueError('Некорректное значение в детализации')
            return result

        cpu = {}
        for row in rows('ЦПУ по Банку ПРОМ+ош'):
            if re.fullmatch(r'CI\d+', row.get('A', '')):
                if row['A'] in cpu:
                    raise ValueError('Дубль КЭ в CPU')
                cpu[row['A']] = [number(row[k]) for k in ['C', 'D', 'E']]
        records, ids = [], set()
        classes = {'Mission Critical+': 'MC+', 'Mission Critical': 'MC', 'Business Critical': 'BC'}
        for row in rows('Весь банк на коэф-ах B2C'):
            ci, criticality = row.get('F', ''), classes.get(row.get('G'))
            if not re.fullmatch(r'CI\d+', ci) or not criticality:
                continue
            if ci in ids or ci not in cpu:
                raise ValueError('Дубль или отсутствие CPU для КЭ: ' + ci)
            ids.add(ci)
            rsm, openshift, total = cpu[ci]
            if not math.isclose(rsm + openshift, total) or not math.isclose(number(row['H']), total):
                raise ValueError('CPU не сходится для КЭ: ' + ci)
            records.append(dict(id_ke=ci, name=row.get('D', ''), business_block=row.get('E', ''),
                                criticality=criticality, cpu_rsm=rsm, cpu_openshift=openshift,
                                cpu_total=total, fte=number(row['I'])))
        return records



if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    args = parser.parse_args()
    payload = read_summary(args.source)
    destination = ROOT / 'data' / 'fincontrol.json'
    temporary = destination.with_suffix('.tmp')
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    temporary.replace(destination)
    print(destination)
