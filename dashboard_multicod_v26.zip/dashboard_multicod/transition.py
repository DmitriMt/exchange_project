"""Snapshot-bound three-availability-zone strategies from the questionnaire."""
import hashlib
from pathlib import Path
import re

TRANSITION_FIELDS = ['transition_strategy','transition_raw','transition_status','transition_file','transition_row','transition_sha256']
STRATEGIES = ('A-A-A','A-A-P','A-P-P')


def normalize_strategy(value):
    raw = str(value or '').strip()
    if not raw:
        return ''
    code = re.sub(r'[\s\-–—−]', '', raw.upper().translate(str.maketrans({'А':'A','Р':'P'})))
    if code not in ('AAA','AAP','APP'):
        raise ValueError('Допустимы стратегии A-A-A, A-A-P, A-P-P')
    return '-'.join(code)


def read_questionnaire(path):
    from prepare_data import xlsx_rows
    path = Path(path)
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    result = {}
    header = False
    for i, r in xlsx_rows(path, 'Опросник'):
        if i == 1:
            if r.get('D') != 'ID КЭ' or re.sub(r'\s+', '', r.get('K','')).casefold() != 'Стратегия перехода в МультиЦОД +'.replace(' ','').casefold():
                raise ValueError('Опросник: нужны D «ID КЭ» и K «Стратегия перехода в МультиЦОД +» на листе «Опросник»')
            header = True
            continue
        ci, raw = r.get('D','').strip(), r.get('K','').strip()
        if not ci and not raw and not r.get('C'):
            continue
        if not re.fullmatch(r'CI\d+', ci):
            raise ValueError(f'Опросник: неверный КЭ в строке {i}')
        if ci in result:
            raise ValueError(f'Опросник: повтор КЭ {ci}, строки {result[ci]["row"]} и {i}')
        try:
            strategy = normalize_strategy(raw)
        except ValueError as error:
            raise ValueError(f'Опросник: {ci}, строка {i}: {error}')
        result[ci] = dict(row=i, raw=raw, strategy=strategy, name=r.get('C',''), category=r.get('F',''),criticality=r.get('G',''),lifecycle=r.get('H',''),dit=r.get('A',''),parent_id=(re.search(r'\((CI\d+)\)',r.get('I','')) or re.fullmatch(r'\s*(CI\d+)\s*',r.get('I',''))).group(1) if (re.search(r'\((CI\d+)\)',r.get('I','')) or re.fullmatch(r'\s*(CI\d+)\s*',r.get('I',''))) else '')
    if not header or not result:
        raise ValueError('Опросник пуст или не содержит КЭ')
    return dict(records=result, file=path.name, sha256=digest)


def apply_questionnaire(rows, questionnaire):
    records = questionnaire['records']
    entities = {r['id_ke']:r for r in rows if r['record_type']=='entity'}
    for ci,e in entities.items():
        rec=records.get(ci)
        category={'Автоматизированные системы':'АС','Функциональная подсистема':'ФП'}.get(rec['category']) if rec else None
        if rec and rec['category'] and category != e['category']:
            raise ValueError('Опросник: категория не совпадает с каталогом для '+ci)
    for r in rows:
        r.update({key:'' for key in TRANSITION_FIELDS})
        if r['record_type'] != 'entity':
            continue
        rec=records.get(r['id_ke'])
        r.update(transition_file=questionnaire['file'],transition_sha256=questionnaire['sha256'])
        if rec:
            r.update(transition_strategy=rec['strategy'],transition_raw=rec['raw'],transition_row=str(rec['row']),transition_status='planned' if rec['strategy'] else 'blank')
        else:
            r['transition_status']='not_listed'
    return dict(total=len(records),matched=sum(ci in entities for ci in records),planned=sum(r['transition_status']=='planned' for r in entities.values()),blank=sum(r['transition_status']=='blank' for r in entities.values()),not_listed=sum(r['transition_status']=='not_listed' for r in entities.values()),outside=[dict(id_ke=ci,**rec) for ci,rec in records.items() if ci not in entities],file=questionnaire['file'],sha256=questionnaire['sha256'])


def validate_transition(r):
    status=r.get('transition_status','')
    if status not in ('','planned','blank','not_listed'):
        raise ValueError('Неверный статус стратегии перехода')
    if not status:
        if any(r.get(k) for k in TRANSITION_FIELDS):
            raise ValueError('Стратегия без результата проверки опросника')
        return
    if r['record_type']!='entity' or not r.get('transition_file') or not re.fullmatch(r'[a-f0-9]{64}',r.get('transition_sha256','')):
        raise ValueError('Не задан источник стратегии')
    if status in ('planned','blank') and not re.fullmatch(r'[2-9]|[1-9]\d{1,6}',r.get('transition_row','')):
        raise ValueError('Не задана строка опросника')
    if status=='planned':
        if r.get('transition_strategy') not in STRATEGIES or normalize_strategy(r.get('transition_raw')) != r['transition_strategy']:
            raise ValueError('Стратегия не согласована с ответом опросника')
    elif r.get('transition_strategy') or r.get('transition_raw') or (status=='not_listed' and r.get('transition_row')):
        raise ValueError('Нет ответа, но стратегия заполнена')
