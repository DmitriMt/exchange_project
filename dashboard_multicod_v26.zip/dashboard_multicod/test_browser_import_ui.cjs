// Run after build_local_html.py. Tests application state without network or browser storage.
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'../../outputs/dashboard-v26/МультиЦОД.html'),'utf8');
const script=html.match(/<script>\n([\s\S]*?)<\/script>/)[1],elements=new Map();
const el=()=>({value:'',checked:false,hidden:false,innerHTML:'',textContent:'',files:[],open:false,dataset:{},classList:{toggle(){}},querySelectorAll(){return [];},querySelector(){return null;},closest(){return null;},insertAdjacentHTML(){},remove(){},before(){},addEventListener(){},removeEventListener(){},after(){},append(){},click(){},focus(){},scrollIntoView(){},showModal(){this.open=true;},close(){this.open=false;}});
const document={getElementById(id){if(!elements.has(id))elements.set(id,el());return elements.get(id);},createElement:el,querySelector:s=>s.startsWith('.drill-panel')?null:el(),querySelectorAll:()=>[],body:{append(){}}};
const c={document,Intl,Date,TextDecoder,TextEncoder,Blob,structuredClone,setTimeout,clearTimeout,console,URL};
vm.createContext(c);vm.runInContext(script,c);

(async()=>{
 const read=e=>vm.runInContext(e,c),get=id=>document.getElementById(id);
 for(let i=0;i<30;i++){await new Promise(r=>setImmediate(r));if(read('stateReady'))break;}assert(read('stateReady'));
 c.crypto=globalThis.crypto;c.DecompressionStream=DecompressionStream;
 read("globalThis.noiseRows=structuredClone(rows);noiseRows.find(r=>r.record_type==='entity').pshe_change_main=String(Number(noiseRows.find(r=>r.record_type==='entity').pshe_change_main)*(1+1e-15))");assert.equal(read('datasetDiff(rows,noiseRows).changed.length'),0);
 read("page='update';render()");assert(get('content').innerHTML.includes('localExcelImportForm'));assert(!get('content').innerHTML.includes('Открыть локальный обработчик'));assert(html.includes('Экспортер Excel'));
 let complete=true;const workers=[];
 c.Worker=class{constructor(url){this.url=url;this.dead=false;workers.push(this);}terminate(){this.dead=true;}postMessage(payload){const {date}=payload;assert(!payload.files.questionnaire);assert.equal(payload.fileBuffers.questionnaire.bytes.byteLength,100);if(!complete)return;const source=read('structuredClone(rows)');for(const row of source)row.snapshot=date;queueMicrotask(()=>{if(!this.dead)this.onmessage({data:{type:'done',value:{rows:source,manifest:{catalog:{name:'каталог.xlsx',bytes:100,sha256:'abc'}},report:{entities:1415,as_count:422,fp_count:993,fp_without_rsm:122,model_added:167}}}});});}};
 const inputs=()=>{get('excelDate').value='2026-11-04';for(const role of ['catalog','wallet','rsm1','rsm2','questionnaire'])get('source_'+role).files=[new File([new Uint8Array(100)],role+'.xlsx')];};
 inputs();await read('runLocalExcel({preventDefault(){}})');assert(read('localExcelResult!==null'));assert.equal(read('versions.length'),1);assert(workers[0].dead);
 read('globalThis.savedDownload=null;saveBlob=(blob,name)=>{globalThis.savedDownload={blob,name};}');
 read('downloadLocalCsv()');assert((await read('savedDownload.blob').text()).includes('2026-11-04'));
 await read('reviewLocalExcel()');const applying=get('applyLocalPreparedCsv').onclick();
 for(let i=0;i<50&&!get('checkHtmlBeforeImport').onchange;i++)await new Promise(r=>setTimeout(r,5));
 assert(get('checkHtmlBeforeImport').onchange);assert.equal(read('versions.length'),1);
 get('checkHtmlBeforeImport').files=[new Blob(['{}'])];await get('checkHtmlBeforeImport').onchange();assert(get('htmlBackupStatus').textContent.includes('не совпадает'));assert.equal(read('versions.length'),1);
 get('saveHtmlBeforeImport').onclick();get('checkHtmlBeforeImport').files=[read('savedDownload.blob')];await get('checkHtmlBeforeImport').onchange();await applying;
 assert.equal((await read('stateRepo.list()')).length,2);assert.equal(read('entities[0].snapshot'),'2026-11-04');assert.equal(read('localExcelResult'),null);
 get('download').onclick();assert((await read('savedDownload.blob').text()).includes('2026-11-04')); // current version, never stale embedded CSV
 // Stop an in-flight worker; the old cleanup must not terminate a replacement worker.
 complete=false;read("page='update';render()");inputs();const cancelled=read('runLocalExcel({preventDefault(){}})');read('stopLocalExcel()');
 complete=true;inputs();const replacement=read('runLocalExcel({preventDefault(){}})');await assert.rejects(cancelled,/отменена/);await replacement;assert(read('localExcelResult!==null'));assert.equal((await read('stateRepo.list()')).length,2);
 assert.equal(read('importBusy'),false);assert.equal(read('localExcelWorker'),null);
 console.log('PASS: integrated HTML form/button, prepare without committing, CSV download, backup readback gate, atomic new dated slice, current CSV, cancellation and restart.');
})().catch(e=>{console.error(e);process.exitCode=1;});
