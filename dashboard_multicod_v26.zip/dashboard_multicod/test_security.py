import hashlib
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from security import Security
from state_store import StateStore
from server import password_hash

class SecurityTests(unittest.TestCase):
    def test_accounts_preferences_survive_restart_and_last_admin_protected(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)
            legacy = path / 'users.json'
            salt = 'ab' * 16
            legacy.write_text(json.dumps({'operator': dict(role='uploader', salt=salt, hash=password_hash('password-for-test', salt))}))
            store = StateStore(path / 'state.sqlite3')
            security = Security(store, legacy)
            self.assertEqual(security.account('operator')['role'], 'admin')
            security.preferences('operator', {'filters': {'dit': 'Test'}})
            security.save_user(dict(name='reader', role='user', password='password-for-test'), password_hash)
            security.save_user(dict(name='reader', role='user', active=False), password_hash)
            with self.assertRaisesRegex(ValueError, 'последнего'):
                security.save_user(dict(name='operator', role='user'), password_hash)
            restarted = Security(StateStore(path / 'state.sqlite3'), legacy)
            self.assertIsNone(restarted.account('reader'))
            self.assertEqual(restarted.preferences('operator')['filters']['dit'], 'Test')
            self.assertEqual(restarted.preferences('reader'), {})
            receipt = restarted.prepare('operator', '')
            copy = restarted.folder / receipt['filename']
            self.assertEqual(hashlib.sha256(copy.read_bytes()).hexdigest(), receipt['sha256'])
            with sqlite3.connect(str(copy)) as db:
                self.assertEqual(db.execute('PRAGMA quick_check').fetchone()[0], 'ok')
                self.assertEqual(db.execute('SELECT count(*) FROM accounts').fetchone()[0], 2)
            with self.assertRaises(ValueError):
                restarted.consume(receipt['id'], 'operator', '')
            with self.assertRaises(ValueError):
                restarted.acknowledge(receipt['id'], 'reader', receipt['sha256'])
            restarted.acknowledge(receipt['id'], 'operator', receipt['sha256'])
            restarted.consume(receipt['id'], 'operator', '')
            with self.assertRaises(ValueError):
                restarted.consume(receipt['id'], 'operator', '')
            stale = restarted.prepare('operator', '')
            restarted.acknowledge(stale['id'], 'operator', stale['sha256'])
            store.commit(b'fixture', [], 'New data', '2026-11-03', '')
            with self.assertRaises(ValueError):
                restarted.consume(stale['id'], 'operator', '')

if __name__ == '__main__':
    unittest.main()
