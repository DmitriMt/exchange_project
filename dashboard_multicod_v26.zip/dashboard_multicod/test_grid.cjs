// Exercise the full-row grid contract without network, file writes or a browser.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
class Element{
 constructor(text=''){this.textContent=text;this.children=[];this.hidden=false;this.dataset={};this.colSpan=1;this.attributes={};this.value='';}
 append(...nodes){for(const n of nodes){if(n.parentNode){const old=n.parentNode.children;const i=old.indexOf(n);if(i>=0)old.splice(i,1);}this.children.push(n);n.parentNode=this;}}
 setAttribute(k,v){this.attributes[k]=v;}
 get firstChild(){return this.children[0];}
 remove(){const a=this.parentNode?.children;if(a){const i=a.indexOf(this);if(i>=0)a.splice(i,1);}}
 querySelector(s){return s==='[data-number]'&&this.number!==undefined?{dataset:{number:String(this.number)}}:null;}
 querySelectorAll(s){const all=this.children.flatMap(n=>[n,...n.querySelectorAll('*')]);return s==='input'?all.filter(n=>n.type==='search'):all;}
 closest(s){if(s==='dialog')return null;if(s==='details,.panel')return null;if(s==='.scroll')return {after(){}};return null;}
}
function table(count=85){const t=new Element(),body=new Element(),thead=new Element(),head=new Element();head.cells=['Название','Количество','Класс'].map(x=>new Element(x));head.append(...head.cells);thead.append(head);thead.rows=[head];body.rows=[];for(let i=0;i<count;i++){const r=new Element();r.cells=[new Element('Объект '+i),new Element(String(i-20)),new Element(i%2?'MC':'BC')];r.cells[1].number=i-20;r.append(...r.cells);body.rows.push(r);body.append(r);}const total=new Element();total.cells=[new Element('Всего'),new Element('100'),new Element('')];body.rows.push(total);body.append(total);t.tHead=thead;t.tBodies=[body];t.querySelectorAll=s=>s==='.column-filters input'?thead.children[1].children.map(n=>n.children[0]):[];return t;}
const elements={logout:new Element()};const c={console,setTimeout,clearTimeout,Intl,document:{createElement:()=>new Element(),querySelectorAll:()=>[]},$:id=>elements[id],page:'objects',stateFields:[],measures:{budget_rub:{}},ServerRepo:class{},BrowserRepo:class{},filtered:()=>[],exportParams:()=>({name:'Параметры',rows:[]}),cleanView:v=>v,filtersValue:()=>({}),applySavedView:async()=>{},stateInit:async()=>{},clearUserPanels(){},summary(){},groups(){},render(){},stateModal(){},exportWorkbook(){return[];},sameBookmark(){return true;}};
vm.createContext(c);vm.runInContext(fs.readFileSync(__dirname+'/web/system.js','utf8'),c);vm.runInContext('activeFilterPanel=()=>{};savePreferencesSoon=()=>{}',c);
const a=table(),b=table(12);c.tables=[a,b];vm.runInContext('enhanceTables({querySelectorAll:()=>tables})',c);
const grids=vm.runInContext('gridInstances',c);assert.equal(grids.length,2);assert.equal(grids[0].filtered.length,85);assert.equal(grids[0].filtered.filter(r=>!r.hidden).length,40);assert.notEqual(grids[0].key,grids[1].key);
// A match beyond the old page's first forty rows must remain discoverable.
const input=a.tHead.rows[0].parentNode.children[1].children[0].children[0];input.value='=Объект 81';input.oninput();assert.equal(grids[0].filtered.length,1);assert.equal(grids[0].filtered[0].cells[0].textContent,'Объект 81');assert.equal(grids[1].filtered.length,12);
input.value='';input.oninput();const numeric=a.tHead.rows[0].parentNode.children[1].children[1].children[0];numeric.value='>40';numeric.oninput();assert.equal(grids[0].filtered.length,24);
a.tHead.rows[0].cells[1].firstChild.onclick();a.tHead.rows[0].cells[1].firstChild.onclick();assert.equal(grids[0].filtered[0].cells[1].number,64);
assert.equal(vm.runInContext('gridData(gridInstances[0]).length',c),25);assert.equal(vm.runInContext('gridData(gridInstances[0])[1][1]',c),64);
numeric.value='-10..10';numeric.oninput();assert.equal(grids[0].filtered.length,21);
assert(vm.runInContext("matchesColumn('MC',null,'!=BC')",c));assert(!vm.runInContext("matchesColumn('MC',null,'=BC')",c));
console.log('PASS: all-row column filters, independent tables, numeric/range/text comparisons, numeric sorting, pagination and typed filtered export.');
