"""Bundle the current dashboard and dataset into one file for offline debugging."""
import json
from datetime import datetime, timezone
from pathlib import Path
from prepare_data import FIELDS
from server import parse_data
from fincontrol_model import payload as fincontrol_payload

ROOT = Path(__file__).resolve().parent
csv_path = ROOT / 'data' / 'dashboard.csv'
raw = csv_path.read_bytes()
parse_data(raw)


def js_literal(value):
    return json.dumps(value, ensure_ascii=False).replace('<', '\\u003c').replace('\u2028', '\\u2028').replace('\u2029', '\\u2029')


script = (ROOT / 'web' / 'app.js').read_text()
script = '\n'.join(line for line in script.splitlines() if not line.startswith(("async function api(", "$('loginForm').addEventListener", "$('logout').onclick", "$('download').onclick")))
download = """
$('user').textContent='Локальная отладка';$('logout').hidden=true;
$('uploadButton').hidden=false;
load().catch(err=>message(err.message,true));
"""
bootstrap = ('const LOCAL_FIELDS=' + js_literal(FIELDS) + ';\n'
             + 'const LOCAL_UPDATED=' + js_literal(datetime.fromtimestamp(csv_path.stat().st_mtime, timezone.utc).isoformat()) + ';\n'
             + 'const FINCONTROL_BASE=' + js_literal(fincontrol_payload(json.loads((ROOT / 'data' / 'fincontrol.json').read_text()), parse_data(raw), ROOT / 'data' / 'fincontrol_resources')) + ';\n'
             + 'const HTML_BASE_CSV=' + js_literal(raw.decode('utf-8-sig')) + ';\nlet localCsv=HTML_BASE_CSV;\n')
adapter = (ROOT / 'offline_adapter.js').read_text()
model = 'const CSV_FIELDS=' + js_literal(FIELDS) + ';\nconst PSHE_MODEL=' + js_literal(json.loads((ROOT / 'model_v4_3.json').read_text())) + ';\n'
model += (ROOT / 'web' / 'model_runtime.js').read_text() + '\n' + (ROOT / 'web' / 'transition_core.js').read_text()
(ROOT / 'web' / 'model.js').write_text(model)
v2 = (ROOT / 'web' / 'v2.js').read_text()
charts = (ROOT / 'web' / 'charts.js').read_text()
sections = (ROOT / 'web' / 'sections.js').read_text()
excel = (ROOT / 'web' / 'excel.js').read_text() + '\n' + (ROOT / 'web' / 'export.js').read_text()
worker_config = dict(rsmCache=json.loads((ROOT/'data'/'rsm_presence_cache.json').read_text()) if (ROOT/'data'/'rsm_presence_cache.json').exists() else None, fields=FIELDS, weights=json.loads((ROOT / 'model_weights.json').read_text()), structure=json.loads((ROOT / 'model_structure.json').read_text()))
inflate_vendor='/* Pako 1.0.11, bundled unmodified.\n'+(ROOT/'vendor'/'pako-LICENSE.txt').read_text()+'\n*/\n'+(ROOT/'vendor'/'pako_inflate.min.js').read_text()+'\n'
worker = inflate_vendor + 'const PSHE_MODEL=' + js_literal(json.loads((ROOT / 'model_v4_3.json').read_text())) + ';\n'
worker += (ROOT / 'web' / 'model_runtime.js').read_text() + '\n' + (ROOT / 'web' / 'browser_import_core.js').read_text() + '\n' + (ROOT / 'web' / 'transition_core.js').read_text()
worker += '\nconst BROWSER_CONFIG=' + js_literal(worker_config) + ';\n'
worker += "self.onmessage=async ({data})=>{try{for(const [role,entry]of Object.entries(data.fileBuffers||{})){data.files=data.files||{};data.files[role]=new File([entry.bytes],entry.name,{type:entry.type,lastModified:entry.lastModified});}if(data.fileData)data.file=new File([data.fileData.bytes],data.fileData.name,{type:data.fileData.type,lastModified:data.fileData.lastModified});const progress=message=>self.postMessage({type:'progress',message});const value=data.mode==='questionnaire'?await prepareTransitionBrowser(data.rows,data.file,progress,BROWSER_CONFIG.rsmCache):await prepareBrowser(data.files,data.date,BROWSER_CONFIG,progress);self.postMessage({type:'done',value});}catch(error){self.postMessage({type:'error',message:error.message||String(error)});}};"
worker_script = 'const BROWSER_IMPORT_WORKER=' + js_literal(worker) + ';\n'
(ROOT / 'web' / 'browser_import_worker.js').write_text(worker_script)
questionnaire_worker=inflate_vendor+(ROOT / 'web' / 'browser_import_core.js').read_text()+'\n'+(ROOT / 'web' / 'transition_core.js').read_text()+"\nself.onmessage=async({data})=>{try{if(data.fileData)data.file=new File([data.fileData.bytes],data.fileData.name,{type:data.fileData.type,lastModified:data.fileData.lastModified});const value=await prepareTransitionBrowser(data.rows,data.file,message=>self.postMessage({type:'progress',message}),data.rsmCache||null);self.postMessage({type:'done',value});}catch(e){self.postMessage({type:'error',message:e.message});}};"
(ROOT / 'web' / 'questionnaire_worker.js').write_text(questionnaire_worker)
plan_worker = inflate_vendor + (ROOT/'web/browser_import_core.js').read_text() + '\n' + (ROOT/'web/plan_worker_handler.js').read_text()
(ROOT/'web/plan_import_worker.js').write_text(plan_worker)
initiative_worker=inflate_vendor+(ROOT/'web/browser_import_core.js').read_text()+'\n'+(ROOT/'web/initiative_worker_handler.js').read_text()
(ROOT/'web/initiative_import_worker.js').write_text(initiative_worker)
initiative_script='const INITIATIVE_CONFIG='+js_literal(json.loads((ROOT/'data/initiative_config.json').read_text()))+';\nconst INITIATIVE_IMPORT_WORKER='+js_literal(initiative_worker)+';\n'+(ROOT/'web/initiatives_core.js').read_text()+'\n'+(ROOT/'web/initiatives_ui.js').read_text()
plan_worker_literal='const PLAN_IMPORT_WORKER='+js_literal(plan_worker)+';\n'
state = (ROOT / 'web' / 'state.js').read_text() + '\n' + (ROOT / 'web' / 'workflows.js').read_text() + '\n' + (ROOT / 'web' / 'enhancements.js').read_text() + '\n' + (ROOT / 'web' / 'system.js').read_text() + '\n' + (ROOT / 'web' / 'volume.js').read_text() + '\n' + (ROOT / 'web' / 'no_kts.js').read_text() + '\n' + worker_script + (ROOT / 'web' / 'file_read.js').read_text() + '\n' + (ROOT / 'web' / 'browser_import_ui.js').read_text() + '\n' + (ROOT / 'web' / 'transition_ui.js').read_text() + '\n' + (ROOT / 'web' / 'registry_ui.js').read_text() + '\n' + (ROOT / 'web' / 'overview.js').read_text() + '\n' + plan_worker_literal + (ROOT / 'web' / 'plans_bulk.js').read_text() + '\n' + initiative_script
(ROOT / 'web' / 'csv.js').write_text(adapter.split('let localRows=')[0].replace('LOCAL_FIELDS', 'CSV_FIELDS'))
page = (ROOT / 'web' / 'index.html').read_text()
start, end = page.index('<div id="login"'), page.index('<div id="shell"')
page = page[:start] + page[end:]
page = page.replace('<div id="shell" hidden>', '<div id="shell">')
page = page.replace('<link rel="stylesheet" href="/style.css">', '<style>' + (ROOT / 'web' / 'style.css').read_text() + '</style>')
for name in ['app.js', 'model.js', 'v2.js', 'charts.js', 'sections.js', 'excel.js', 'export.js', 'csv.js', 'state.js', 'workflows.js', 'enhancements.js', 'system.js', 'volume.js', 'no_kts.js', 'browser_import_worker.js', 'file_read.js', 'browser_import_ui.js', 'transition_ui.js', 'registry_ui.js', 'overview.js', 'plans_bulk.js', 'initiatives_core.js', 'initiatives_ui.js']:
    page = page.replace(f'<script src="/{name}" defer></script>', '')
page = page.replace('<div class="statusline">', '<p class="note">Локальная версия: история, планы и представления сохраняются в браузере. Для переноса и резервного хранения скачайте историю. Проверка ролей выполняется только на сервере.</p><div class="statusline">')
page = page.replace('</body>', '<script>\n' + bootstrap + model + '\n' + adapter + '\n' + script + '\n' + v2 + '\n' + charts + '\n' + sections + '\n' + excel + '\n' + state + '\n' + download + '\n</script>\n</body>')
destination = ROOT.parents[1] / 'outputs' / 'dashboard-v32' / 'МультиЦОД.html'
destination.parent.mkdir(exist_ok=True, parents=True)
destination.write_text(page)
print(destination)
