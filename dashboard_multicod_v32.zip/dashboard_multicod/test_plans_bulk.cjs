// Run after build_local_html.py. Tests application state without network or browser storage.
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'../../outputs/dashboard-v32/МультиЦОД.html'),'utf8');
const script=html.match(/<script>\n([\s\S]*?)<\/script>/)[1],elements=new Map();
const el=()=>({value:'',checked:false,hidden:false,innerHTML:'',textContent:'',files:[],open:false,dataset:{},classList:{toggle(){}},querySelectorAll(){return [];},querySelector(){return null;},closest(){return null;},insertAdjacentHTML(){},remove(){},before(){},addEventListener(){},removeEventListener(){},after(){},append(){},click(){},focus(){},scrollIntoView(){},showModal(){this.open=true;},close(){this.open=false;}});
const document={getElementById(id){if(!elements.has(id))elements.set(id,el());return elements.get(id);},createElement:el,querySelector:s=>s.startsWith('.drill-panel')?null:el(),querySelectorAll:()=>[],body:{append(){}}};
const c={document,Intl,Date,TextDecoder,TextEncoder,Blob,structuredClone,setTimeout,clearTimeout,console,URL};
vm.createContext(c);vm.runInContext(script,c);


(async()=>{
 const read=e=>vm.runInContext(e,c),get=id=>document.getElementById(id);
 for(let i=0;i<60;i++){await new Promise(r=>setImmediate(r));if(read('stateReady'))break;}assert(read('stateReady'));
 read("page='operations';render()");
 const as=read("entities.find(e=>e.category==='АС')"),fp=read("entities.find(e=>e.category==='ФП')");
 await read('showObjectCard('+JSON.stringify(as.id_ke)+')');
 for(const [k,v]of Object.entries({year:'2026',quarter:'4',target_date:'2026-11-30',site:'',owner:'',status:'',notes:'Черновик'}))get('plan_'+k).value=v;
 await get('planForm').onsubmit({preventDefault(){}});
 assert.equal(read('operationalStats(filtered(),activePlans(),"2026-11-05").groups.entered.length'),1);
 assert.equal(read('operationalStats(filtered(),activePlans(),"2026-11-05").groups.prepared.length'),0);
 assert.equal(read('operationalStats(filtered(),activePlans(),"2026-11-05").groups.quarter.length'),1);
 assert.equal((await read('stateRepo.settings()')).plans[as.id_ke].year,'2026');assert.equal(read('ditOperationSummary(operationalRows().stats,operationalRows().records).total[5]'),1);
 read("page='overview';render()");assert.equal(read('exportWorkbook()[0].rows.find(r=>r[0]==="План внесён")[1]'),1);
 const sheets=read('planTemplateSheets()');assert.equal(sheets[0].rows.length,1416);assert.equal(sheets[0].rows[0].length,12);
 const headers=Array.from(read('planImportHeaders'));
 const line=(e,revision=0)=>[e.id_ke,e.category,e.name,'2026','4','30.11.2026','ЦОД','Ольга','Запланировано','',String(revision),'Обновить'];
 c.importRows=[[1,headers],[2,line(as,1)],[3,line(fp)]];
 const parsed=read('validatePlanImport(importRows,entities,workspace.plans)');assert.equal(parsed.errors.length,0);assert.equal(parsed.items.length,2);
 c.batchItems=parsed.items.map(({ci,value,revision})=>({ci,value,revision}));
 await read('stateRepo.savePlansBatch(batchItems,liveVersion)');await read('refreshPlanState()');
 assert.equal(read('operationalStats(filtered(),activePlans(),"2026-11-05").groups.entered.length'),2);
 assert.equal(read('operationalStats(filtered(),activePlans(),"2026-11-05").groups.prepared.length'),2);
 assert.equal(read('operationalStats(filtered(),activePlans(),"2026-11-05").groups.quarter.length'),2);
 const before=JSON.stringify(await read('stateRepo.settings()'));
 c.staleItems=[{ci:as.id_ke,value:{year:'2028'},revision:2},{ci:fp.id_ke,value:{year:'2028'},revision:99}];
 await assert.rejects(read('stateRepo.savePlansBatch(staleItems,liveVersion)'),/План изменён/);assert.equal(JSON.stringify(await read('stateRepo.settings()')),before);
 c.importRows=[[1,headers],[2,line(fp,1)],[3,line(fp,1)]];assert.equal(read('validatePlanImport(importRows,entities,workspace.plans).errors.length'),1);
 c.importRows=[[1,headers],[2,line({id_ke:'CI999999999',category:'ФП',name:'Новый'})]];assert.equal(read('validatePlanImport(importRows,entities,workspace.plans).errors.length'),1);
 c.importRows=[[1,headers],[2,[fp.id_ke,'ФП',fp.name,'','','','','','','','1','Обновить']]];assert.equal(read('validatePlanImport(importRows,entities,workspace.plans).skipped.length'),1);
 assert.equal(read('planImportDate("46326")'),'2026-10-31');
 const csv='\uFEFF'+headers.join(';')+'\r\n'+line(fp,1).map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(';');c.csvInput=csv;
 assert.equal(read('parsePlansCsv(csvInput).length'),2);
 // Generated XLSX goes through the actual bundled worker reader, including snapshot metadata.
 const blob=read('makeXlsx(planTemplateSheets())');const bytes=await blob.arrayBuffer();let result;
 const wc={Blob,File,TextDecoder,TextEncoder,Uint8Array,Uint32Array,DataView,BigInt,DecompressionStream,console,self:{postMessage(value){result=value}}};vm.createContext(wc);vm.runInContext(read('PLAN_IMPORT_WORKER'),wc);await wc.self.onmessage({data:{bytes,name:'Планы.xlsx'}});
 assert(!result.error,result.error);assert.equal(result.rows.length,1416);assert.equal(result.base,read('viewVersion'));
 console.log('PASS: saving a partial plan immediately refreshes dashboard; AS/FP batch import, atomic conflicts, duplicate/unknown CI validation, blank-row skip, dates, CSV and real XLSX template round-trip.');
})().catch(e=>{console.error(e);process.exitCode=1;});
