// Run after build_local_html.py. Tests application state without network or browser storage.
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'../../outputs/dashboard-v32/МультиЦОД.html'),'utf8');
const script=html.match(/<script>\n([\s\S]*?)<\/script>/)[1],elements=new Map();
const el=()=>({value:'',checked:false,hidden:false,innerHTML:'',textContent:'',files:[],open:false,dataset:{},classList:{toggle(){}},querySelectorAll(){return [];},querySelector(){return null;},closest(){return null;},insertAdjacentHTML(){},remove(){},before(){},addEventListener(){},removeEventListener(){},after(){},append(){},click(){},focus(){},scrollIntoView(){},showModal(){this.open=true;},close(){this.open=false;}});
const document={getElementById(id){if(!elements.has(id))elements.set(id,el());return elements.get(id);},createElement:el,querySelector:s=>s.startsWith('.drill-panel')?null:el(),querySelectorAll:()=>[],body:{append(){}}};
const c={document,Intl,Date,TextDecoder,TextEncoder,Blob,structuredClone,setTimeout,clearTimeout,console,URL};
vm.createContext(c);vm.runInContext(script,c);

(async()=>{
 const read=e=>vm.runInContext(e,c),get=id=>document.getElementById(id);
 for(let i=0;i<30;i++){await new Promise(r=>setImmediate(r));if(read('stateReady'))break;}
 assert(read('stateReady'));
 read("page='volume';resetAllFilters();render()");
 let markup=get('content').innerHTML;
 for(const label of ['Стоимость КТС','Вендоры CHANGE','Показатель ресурсов','CHANGE¹','RUN¹','₽'])assert(!markup.includes(label),label);
 assert(markup.includes('Собственный класс критичности'));assert(markup.includes('Реестр АС и ФП'));
 assert.equal(read('filtered().length'),1415);assert.equal(read("entities.filter(e=>e.category==='АС').reduce((s,e)=>s+Number(e.fp_registry_total),0)"),993);
 assert.equal(read("entities.filter(e=>e.category==='АС').reduce((s,e)=>s+Number(e.fp_prom_total),0)"),1951);
 console.log('Реальные связи ФП:',read("JSON.stringify(Object.fromEntries(['Тот же трайб','Другой трайб того же блока','Другой блок','Не определено'].map(k=>[k,entities.filter(e=>volumeRelation(e)===k).length])))"));
 const real=read('structuredClone(entities)');
 const ac={id_ke:'CI100',name:'АС А',category:'АС',business_block:'Блок А',owner_department:'Подразделение А',owner_department_code:'D1',owner_tribe:'Трайб 1',owner_tribe_code:'T1',criticality:'MC+',lifecycle:'ПРОМ',fp_prom_total:'4',fp_scope_total:'3',dit:'ДИТ',in_as_list:'1'};
 const fp=(id,block,tribe,criticality='BC')=>({id_ke:id,name:'ФП '+id,category:'ФП',business_block:block,owner_department:'Подразделение '+block,owner_department_code:block==='Блок А'?'D1':'D2',owner_tribe:'Трайб 1',owner_tribe_code:tribe,criticality,lifecycle:'ПРОМ',parent_id:'CI100',dit:'ДИТ',in_as_list:'1'});
 const one=fp('CI101','Блок А','T2'),two=fp('CI102','Блок Б','T1'),unknown=fp('CI103','Блок А',''),extra=fp('CI105','Блок Б','T3','Business Operational');
 ac.fp_children_json=JSON.stringify([one,two,unknown,extra]);ac.fp_registry_children_json=JSON.stringify([one,two,unknown]);ac.fp_registry_total='3';
 const other={...fp('CI104','Блок А','T1'),parent_id:'CI200',parent_name:'АС вне периметра',parent_business_block:'Блок Б',parent_owner_department:'Подразделение Б',parent_owner_tribe:'Трайб 2',parent_owner_tribe_code:'T2',parent_criticality:'Business Operational',parent_lifecycle:'Промышленная эксплуатация',parent_fp_scope_total:'1',parent_fp_prom_total:'1'};
 c.fixtures=[ac,one,two,unknown,other];read('entities=fixtures');
 assert.equal(read("volumeRelation(entities[1])"),'Другой трайб того же блока');
 assert.equal(read("volumeRelation(entities[2])"),'Другой блок');
 assert.equal(read("volumeRelation(entities[3])"),'Не определено');
 assert.equal(read("volumeLookup('CI200').name"),'АС вне периметра');
 assert.equal(read("volumeLookup('CI105')"),null);
 get('block').value='Блок А';read('render()');assert.equal(read('filtered().length'),4);
 assert.equal(read('volumeValues(entities[0],filtered())[8]'),3);assert.equal(read('volumeValues(entities[0],filtered())[9]'),3);assert.equal(read('volumeValues(entities[0],filtered())[10]'),2);
 assert.equal(read('volumeChildren(entities[0]).length'),3);
 await read("openVolumeObject('CI100',true)");assert(get('stateDialog').innerHTML.includes('Блок Б'));assert(!get('stateDialog').innerHTML.includes('Business Operational'));assert(!get('stateDialog').innerHTML.includes('ПШЕ'));
 await read("openVolumeObject('CI200')");assert(get('stateDialog').innerHTML.includes('вне основного периметра'));assert(get('stateDialog').innerHTML.includes('АС вне периметра'));
 read("volumeDepartment='code:D1';volumeTribe='code:T1';volumeRelationFilter='Другой блок';render()");
 assert.equal(read('filtered().length'),1);assert.equal(read('filtered()[0].id_ke'),'CI104');
 await read('saveCurrentView("Межблочные ФП")');read("volumeDepartment=volumeTribe=volumeRelationFilter=''");await read('applySavedView(workspace.views.find(v=>v.name==="Межблочные ФП").value)');assert.equal(read('filtered().length'),1);
 read('resetAllFilters()');assert.equal(read('filtered().length'),5);assert.equal(read("volumeDepartment+volumeTribe+volumeRelationFilter"),'');
 const sheets=read('exportWorkbook()');assert(sheets.length>=6);assert.equal(sheets[0].rows.length,6);
 for(const sheet of sheets)for(const row of sheet.rows)for(const value of row)if(typeof value==='string')assert(!/КТС|ПШЕ|бюджет|CPU|RAM|руб\/год|₽/.test(value));
 await read('makeXlsx(exportWorkbook())').arrayBuffer();
 // An old CSV remains valid; ownership is unknown, not silently borrowed from a newer date.
 c.realEntities=real;read('entities=realEntities');
 const legacyFields=read("LOCAL_FIELDS.slice(0,LOCAL_FIELDS.indexOf('owner_department'))");
 const records=read('structuredClone(rows)');
 const quote=v=>'"'+String(v??'').replace(/"/g,'""')+'"';
 c.legacyCsv='\uFEFF'+[legacyFields,...records.map(r=>legacyFields.map(k=>r[k]))].map(r=>r.map(quote).join(';')).join('\r\n');
 // Use actual BOM/newlines for the legacy byte format.
 c.legacyBackup={format:'multicod-history',version:1,snapshots:[{id:'legacy-snapshot',date:'2026-11-02',at:'2026-11-02T12:00:00Z',name:'Legacy',csv:c.legacyCsv,plans:{}}],workspace:{}};await read('globalThis.legacyRepo=new BrowserRepo(null);legacyRepo.restore(legacyBackup)');await read('legacyRepo.restore(legacyBackup)');assert.equal((await read('legacyRepo.list()')).length,1);
 const old=read('parseLocalCsv(legacyCsv)');assert.equal(old.length,records.length);assert(old.every(r=>r.owner_tribe_code===''&&r.fp_prom_total===''));
 const broken=records.find(r=>r.record_type==='entity'&&r.category==='АС'&&r.fp_children_json!=='[]');const children=JSON.parse(broken.fp_children_json);children[0].parent_id='CI999999';broken.fp_children_json=JSON.stringify(children);c.invalidRows=records;
 assert.throws(()=>read('parseLocalCsv(csvEncode(invalidRows))'),/связь ФП/);
 read("volumeDepartment='code:old';volumeTribe='code:old';volumeRelationFilter='Другой блок'");
 await read('stateRepo.changeProfile("Новый профиль объёма")');assert.equal(read('volumeDepartment+volumeTribe+volumeRelationFilter'),'');
 if(process.env.MULTICOD_VOLUME_XLSX){read("page='volume';resetAllFilters();render()");fs.writeFileSync(process.env.MULTICOD_VOLUME_XLSX,Buffer.from(await read('makeXlsx(exportWorkbook())').arrayBuffer()));}
 console.log('PASS: owner-only volume page, 422 AS/993 FP, complete PROM composition, cross-block/tribe relations, unknown codes, outside-perimeter parent, filters/bookmarks/profile isolation, natural-only Excel.');
})().catch(e=>{console.error(e);process.exitCode=1;});
