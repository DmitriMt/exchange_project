// Run after build_local_html.py. Tests application state without network or browser storage.
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'../../outputs/dashboard-v32/МультиЦОД.html'),'utf8');
const script=html.match(/<script>\n([\s\S]*?)<\/script>/)[1],elements=new Map();
const el=()=>({value:'',checked:false,hidden:false,innerHTML:'',textContent:'',files:[],open:false,dataset:{},classList:{toggle(){}},querySelectorAll(){return [];},querySelector(){return null;},closest(){return null;},insertAdjacentHTML(){},remove(){},before(){},addEventListener(){},removeEventListener(){},after(){},append(){},click(){},focus(){},scrollIntoView(){},showModal(){this.open=true;},close(){this.open=false;}});
const document={getElementById(id){if(!elements.has(id))elements.set(id,el());return elements.get(id);},createElement:el,querySelector:s=>s.startsWith('.drill-panel')?null:el(),querySelectorAll:()=>[],body:{append(){}}};
const c={document,Intl,Date,TextDecoder,TextEncoder,Blob,structuredClone,setTimeout,clearTimeout,console,URL};
vm.createContext(c);vm.runInContext(script,c);

(async()=>{
 const read=e=>vm.runInContext(e,c),get=id=>document.getElementById(id);
 for(let i=0;i<50;i++){await new Promise(r=>setImmediate(r));if(read('stateReady'))break;}
 read("stateRepo=new ServerRepo();currentRole='operator';canEdit=false;canLoad=true;page='update';render()");
 const form=read('importPage()');assert(!form.includes('source_as_list'));assert(form.includes('source_pshe'));assert(!/id="source_pshe"[^>]*required/.test(form));
 assert.equal((form.match(/accept=".xlsx" required/g)||[]).length,5);assert(!form.includes('<fieldset disabled'));
 read("page='overview';render()");assert.equal(get('administration').hidden,true);assert.equal(get('uploadButton').hidden,false);
 read("globalThis.uploaded=[];api=async(path,options)=>{if(path==='/api/import/jobs'&&options)return {id:'test-job'};if(path.includes('/files/'))uploaded.push(path.split('/').at(-1));return [];};watchImport=async()=>{};");
 get('excelDate').value='2026-11-04';for(const role of ['catalog','wallet','rsm1','rsm2','questionnaire'])get('source_'+role).files=[new Blob(['data'])];
 await read('submitImport({preventDefault(){}})');assert.deepEqual(Array.from(read('uploaded')).sort(),['catalog','wallet','rsm1','rsm2','questionnaire'].sort());
 get('source_pshe').files=[new Blob(['optional'])];await read('submitImport({preventDefault(){}})');assert(read('uploaded.includes("pshe")'));
 read("$('asList').checked=true");assert.equal(read('filtered().length'),1415);assert.equal(read('cleanView({asList:true}).asList'),false);
 console.log('PASS: operator UI enabled, administration hidden, exactly five required files; missing optional file safe; optional calculator uploads; obsolete AS filter ignored.');
})().catch(e=>{console.error(e);process.exitCode=1;});
