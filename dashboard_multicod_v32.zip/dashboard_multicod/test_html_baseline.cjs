// Run after build_local_html.py. Tests application state without network or browser storage.
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'../../outputs/dashboard-v32/МультиЦОД.html'),'utf8');
const script=html.match(/<script>\n([\s\S]*?)<\/script>/)[1],elements=new Map();
const el=()=>({value:'',checked:false,hidden:false,innerHTML:'',textContent:'',files:[],open:false,dataset:{},classList:{toggle(){}},querySelectorAll(){return [];},querySelector(){return null;},closest(){return null;},insertAdjacentHTML(){},remove(){},before(){},addEventListener(){},removeEventListener(){},after(){},append(){},click(){},focus(){},scrollIntoView(){},showModal(){this.open=true;},close(){this.open=false;}});
const document={getElementById(id){if(!elements.has(id))elements.set(id,el());return elements.get(id);},createElement:el,querySelector:s=>s.startsWith('.drill-panel')?null:el(),querySelectorAll:()=>[],body:{append(){}}};
const c={document,Intl,Date,TextDecoder,TextEncoder,Blob,structuredClone,setTimeout,clearTimeout,console,URL};
vm.createContext(c);vm.runInContext(script,c);

(async()=>{
 const read=e=>vm.runInContext(e,c),get=id=>document.getElementById(id);
 for(let i=0;i<50;i++){await new Promise(r=>setImmediate(r));if(read('stateReady'))break;}
 assert(read('stateReady'));
 read("globalThis.freshCsv=HTML_BASE_CSV;globalThis.staleRows=structuredClone(rows);for(const e of staleRows){e.snapshot='2026-11-02';if(e.record_type==='entity'){e.rsm_presence='';e.rsm_rows='';e.rsm_source='';}};stateRepo=new BrowserRepo(null);htmlBaseOpened=false");
 c.staleId=await read("stateRepo.commit(staleRows,'Старый срез','2026-11-02','')");
 await read('stateRepo.saveView("Мой раздел",{page:"noKts"})');
 await read('stateInit()');
 assert.equal(read('viewVersion'),read('htmlBaseId'));
 assert.equal(read('isHistorical()'),true);
 assert.equal(read('HTML_BASE_CSV'),read('freshCsv'));
 assert.equal((await read('stateRepo.list()')).length,1);
 assert.equal((await read('stateRepo.backup()')).snapshots.length,1);
 assert.equal(read('workspace.views[0].name'),'Мой раздел');
 read("page='noKts';resetAllFilters();render()");
 assert.equal(read('exportWorkbook()[0].rows.length'),123);
 assert(get('content').innerHTML.includes('во всём срезе'));
 get('category').value='АС';read('render()');
 assert(get('content').innerHTML.includes('id="noKtsResetFilters"'));
 get('noKtsResetFilters').onclick();assert.equal(read('exportWorkbook()[0].rows.length'),123);
 await read('selectVersion(staleId)');assert.equal(read('viewVersion'),c.staleId);
 assert.equal(read("entities.filter(e=>e.rsm_presence==='0').length"),0);
 await read('openHtmlBase()');assert.equal(read('exportWorkbook()[0].rows.length'),123);
 read("page='overview';render()");assert.equal((get('content').innerHTML.match(/class=\"metric /g)||[]).length,4);assert(!get('content').innerHTML.includes('transition-coverage'));assert(!get('content').innerHTML.includes('baseRegistryDetails'));assert(get('content').innerHTML.includes('Ход программы'));
 read("page='fincontrol';render()");assert(get('content').innerHTML.includes('Сводка расчёта'));assert.equal(read('financeScope(filtered()).total.systems'),1617);assert.equal(read('financeScope(filtered()).total.known'),1466);assert.equal(read('financeScope(filtered()).total.missing'),151);
 console.log('PASS: overview and financial-control summary/export; stale browser snapshot preserved; current HTML data opens with 122 FP; bookmarks kept; source CSV immutable; filters reset; Excel complete.');
})().catch(e=>{console.error(e);process.exitCode=1;});
