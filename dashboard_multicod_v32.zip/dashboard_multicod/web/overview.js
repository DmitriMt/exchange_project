'use strict';
Object.assign(sectionTitles,{fincontrol:'Потребность в ПШЕ',overview:'Обзор программы',pshe:'Сравнение моделей ПШЕ',operations:'Оперативный контроль'});
let fincontrolData=typeof FINCONTROL_BASE==='undefined'?null:FINCONTROL_BASE;
let fincontrolError='',operationView='all';
const overviewLoad=load;
load=async function(){
  if(typeof FINCONTROL_BASE==='undefined'){
    fincontrolData=null;fincontrolError='';
    try{fincontrolData=await api('/api/fincontrol');}catch(e){fincontrolError=e.message;}
  }
  return overviewLoad();
};
function programmeObjects(es){return es.filter(e=>['АС','ФП'].includes(e.category));}
function entityCounts(es){const types=['АС','ФП',...(es.some(e=>!['АС','ФП'].includes(e.category))?['Не определён']:[])];return `<span class="entity-counts">${types.map(type=>`<span><strong>${fmt(es.filter(e=>e.category===type).length)}</strong><small>${type==='Не определён'?'Тип не указан':type}</small></span>`).join('')}</span>`;}
const financeSelectVersion=selectVersion;
selectVersion=async function(id){
  if(stateRepo instanceof ServerRepo)fincontrolData=await api('/api/fincontrol/'+encodeURIComponent(id));
  return financeSelectVersion(id);
};

function financeScope(es){
  const input=(fincontrolData?.records||[]).filter(r=>{
    if(r.estimate_origin!=='calculated_runup_rsm')return true;
    const e=entities.find(e=>e.id_ke===r.id_ke);
    return e?.base_source==='RUNUP_QUESTIONNAIRE'&&e.rsm_presence==='1'&&r.rsm_signature?.every(([name,sha])=>e.rsm_source?.includes(name+'='+sha));
  });
  const index=new Map(input.map(r=>[r.id_ke,r]));
  const records=programmeObjects(es).map(e=>({entity:e,calculation:index.get(e.id_ke)||null}));
  // Retain the full source baseline. Lack of RUNUP enrichment never removes its FTE.
  const registryIds=new Set(entities.map(e=>e.id_ke)),selectedIds=new Set(records.map(r=>r.entity.id_ke));
  const q=$('search').value.trim().toLocaleLowerCase('ru');
  for(const r of input){
    if(registryIds.has(r.id_ke)||selectedIds.has(r.id_ke)||r.estimate_origin==='calculated_runup_rsm')continue;
    const e={id_ke:r.id_ke,name:r.name,category:r.category||'Не определён',criticality:r.criticality,dit:r.dit||'',business_block:r.business_block||'',outside_runup:true};
    if((!$('block').value||e.business_block===$('block').value)&&(!$('dit').value||e.dit===$('dit').value)&&(!$('category').value||e.category===$('category').value)&&(!$('criticality').value||e.criticality===$('criticality').value)&&(!q||(e.name+' '+e.id_ke).toLocaleLowerCase('ru').includes(q)))records.push({entity:e,calculation:r});
  }
  const known=records.filter(r=>r.calculation),missing=records.filter(r=>!r.calculation);
  const total={systems:records.length,known:known.length,missing:missing.length};
  for(const key of ['fte','cpu_rsm','cpu_openshift','cpu_total'])total[key]=known.reduce((v,r)=>v+r.calculation[key],0);
  const classes=[...new Set(records.map(r=>r.entity.criticality))].sort().map(criticality=>{
    const rs=records.filter(r=>r.entity.criticality===criticality),ks=rs.filter(r=>r.calculation);
    return {criticality,systems:rs.length,known:ks.length,missing:rs.length-ks.length,...Object.fromEntries(['fte','cpu_rsm','cpu_openshift','cpu_total'].map(k=>[k,ks.reduce((v,r)=>v+r.calculation[k],0)])),share:total.fte?ks.reduce((v,r)=>v+r.calculation.fte,0)/total.fte:0};
  });
  const mui=financeMui(records);total.mui=mui.total;
  for(const r of records)r.mui=mui.byCi.get(r.entity.id_ke)??null;
  for(const group of classes){const values=records.filter(r=>r.entity.criticality===group.criticality&&r.mui!==null).map(r=>r.mui);group.mui=values.length?values.reduce((a,b)=>a+b,0):null;}
  return {records,known,missing,total,classes,mui};
}
function financeAvailable(){return Array.isArray(fincontrolData?.records);}
function fincontrolEmpty(){return `<section class="panel"><h2>Потребность в ПШЕ</h2><p role="status">${esc(fincontrolError||'Для расчёта по выбранным АС и ФП загрузите пообъектную детализацию «Итог 2045».')}</p></section>`;}
function moscowToday(){return new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Moscow',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());}
function operationalDate(){return isHistorical()?entities.find(e=>e.snapshot)?.snapshot||moscowToday():moscowToday();}
function planPeriod(p){
  if(/^\d{4}-\d{2}-\d{2}$/.test(p.target_date||''))return {year:Number(p.target_date.slice(0,4)),quarter:Math.ceil(Number(p.target_date.slice(5,7))/3),deadline:p.target_date};
  const year=/^20\d\d$/.test(p.year||'')?Number(p.year):0,quarter=/^[1-4]$/.test(p.quarter||'')?Number(p.quarter):0;
  return {year,quarter:year?quarter:0,deadline:year?(quarter?new Date(Date.UTC(year,quarter*3,0)).toISOString().slice(0,10):`${year}-12-31`):''};
}
function operationalStats(es,plans,asOf){
  const year=Number(asOf.slice(0,4)),quarter=Math.ceil(Number(asOf.slice(5,7))/3);
  const records=programmeObjects(es).map(entity=>{
    const plan=plans[entity.id_ke]||{},period=planPeriod(plan),done=['Развёрнуто','Принято'].includes(plan.status);
    const prepared=Boolean(period.year&&period.quarter&&plan.owner?.trim()&&plan.site?.trim()&&plan.status);
    return {entity,plan,period,done,prepared,entered:planKeys.some(k=>String(plan[k]||'').trim()),strategy:transitionState(entity)==='planned',overdue:Boolean(period.deadline&&period.deadline<asOf&&!done)};
  });
  const groups={all:records,entered:records.filter(r=>r.entered),prepared:records.filter(r=>r.prepared),strategy:records.filter(r=>r.strategy),quarter:records.filter(r=>r.period.year===year&&r.period.quarter===quarter),year:records.filter(r=>r.period.year===year),done:records.filter(r=>r.done),overdue:records.filter(r=>r.overdue),unscheduled:records.filter(r=>!r.period.year),unowned:records.filter(r=>!r.plan.owner?.trim()),strategy_missing:records.filter(r=>!r.strategy),strategy_blank:records.filter(r=>transitionState(r.entity)==='blank'),strategy_not_listed:records.filter(r=>transitionState(r.entity)==='not_listed'),strategy_unloaded:records.filter(r=>transitionState(r.entity)==='unloaded')};
  return {records,groups,year,quarter,asOf};
}
function operationLabels(stats){return {all:'Все АС и ФП',entered:'План внесён',prepared:'План полностью подготовлен',strategy:'Есть стратегия перехода к 3 зонам доступности',quarter:`Развёртывание · ${stats.quarter} квартал ${stats.year}`,year:`Развёртывание · ${stats.year} год`,done:'Развёрнуто / принято',overdue:'Просрочено',unscheduled:'Без срока развёртывания',unowned:'Без ответственного',strategy_missing:'Без стратегии перехода к 3 зонам доступности',strategy_blank:'Пустая стратегия',strategy_not_listed:'Нет КЭ в опроснике',strategy_unloaded:'Стратегия не проверена'};}
function operationalPanel(es){
  const s=operationalStats(es,activePlans(),operationalDate()),labels=operationLabels(s),total=s.records.length;
  const captions={entered:'Заполнено хотя бы одно поле календарного плана',prepared:`из ${fmt(total)} АС и ФП · срок, площадка, ответственный и статус`,strategy:'Стратегия в опроснике RUNUP',quarter:`Осталось: ${fmt(s.groups.quarter.filter(r=>!r.done).length)} АС и ФП`,year:`Осталось: ${fmt(s.groups.year.filter(r=>!r.done).length)} АС и ФП`,done:`из ${fmt(total)} АС и ФП · по статусу плана`,overdue:'Срок истёк, развёртывание не завершено',unscheduled:'Не указан год или целевая дата',unowned:'Ответственный не указан в плане'};
  return `<section class="operations-overview"><div class="section-title"><div><h2>Ход программы</h2><p>АС и ФП выбранного периметра · на ${esc(s.asOf)}${isHistorical()?' · исторический срез':''}</p></div><button data-operation="all">Все объекты и планы ↗</button></div><div class="operations-grid">${['entered','prepared','strategy','quarter','year','done','overdue','unscheduled','unowned'].map(key=>`<button class="operation-card ${key==='overdue'&&s.groups[key].length?'attention':''}" data-operation="${key}"><span>${esc(labels[key])}</span>${entityCounts(s.groups[key].map(r=>r.entity))}<small>Всего ${fmt(s.groups[key].length)} · ${esc(captions[key])}</small></button>`).join('')}</div>${!s.groups.year.length?'<p class="overview-scope">На текущий год сроки АС и ФП в календарном плане не внесены. Это отсутствие плановых данных, а не подтверждение отсутствия работ.</p>':''}</section>`;
}
summary=function(es,bs){
  const f=financeScope(es),t=f.total;
  return `<div class="overview-heading"><p class="eyebrow">ПРОГРАММА МУЛЬТИЦОД+</p><h2>Ключевые показатели</h2><p>Единый периметр RUNUP · общие фильтры применены</p></div><div class="metrics overview-metrics">${metric('АС и ФП в программе',entityCounts(es),`Всего ${fmt(programmeObjects(es).length)} объектов RUNUP`,'accent')}${financeMuiMetric(f)}${metric('Стоимость КТС',sum(bs,'budget_rub')===null?'—':fmt(sum(bs,'budget_rub')/1e9,2)+' млрд ₽','Годовая стоимость выбранных АС и ФП')}${metric('Потребность в ПШЕ',financeAvailable()&&t.known?num(t.fte):'нет расчёта',`Исходный расчёт + досчёт RUNUP ∩ РСМ`)}${metric('Без расчёта ПШЕ',financeAvailable()?entityCounts(f.missing.map(r=>r.entity)):'—',`Всего ${fmt(t.missing)} · нет оценки по собственному КЭ`)}</div>`;
};
sectionHome=function(){
  const es=filtered(),t=financeScope(es).total;
  return `<div class="overview-finance-link"><span>Финансовый расчёт по текущим фильтрам: ${financeAvailable()&&t.known?fmt(t.fte,1)+' ПШЕ':'нет расчёта'} · ${fmt(t.missing)} АС и ФП без оценки</span><button data-section="fincontrol">Открыть расчёт ↗</button></div>${isHistorical()?'<p class="overview-scope">Исторический состав АС и ФП сопоставлен с текущей версией расчёта ПШЕ. Дата источника: '+esc(fincontrolData?.imported_on||'не загружен')+'.</p>':''}${operationalPanel(es)}`;
};
const financeHeaders=['Класс объекта','АС и ФП в выборке','С расчётом','Без расчёта','CPU РСМ','CPU OpenShift','CPU всего','ПШЕ','ПШЕ в МУИ'];
const financeValues=r=>[r.criticality,r.systems,r.known,r.missing,r.known?r.cpu_rsm:null,r.known?r.cpu_openshift:null,r.known?r.cpu_total:null,r.known?r.fte:null,r.mui??null];
function fincontrolPage(){
  if(!financeAvailable())return fincontrolEmpty();
  const d=fincontrolData,f=financeScope(filtered()),t=f.total,max=Math.max(1,...f.classes.map(r=>r.fte));
  return `<p class="section-context">Итоги и фильтры совпадают с обзором. Исходный «Итог 2045» сохранён целиком, включая объекты вне RUNUP. Новые оценки добавлены только по пересечению RUNUP и РСМ. АС и ФП включены на равных по собственным КЭ; оценка родителя не переносится на ФП. Источник оценки: ${esc(d.imported_on)}.</p><div class="metrics finance-metrics">${metric('Потребность в ПШЕ',t.known?fmt(t.fte,1):'нет расчёта','Модель «Итог 2045» · выбранные АС и ФП','accent')}${metric('АС и ФП с расчётом',entityCounts(f.known.map(r=>r.entity)),`Всего ${fmt(t.known)} из ${fmt(t.systems)} · без оценки: ${fmt(t.missing)}`)}${financeMuiMetric(f)}</div><div class="two-col"><section class="panel finance-chart"><div class="panel-head"><h2>Потребность по критичности</h2><p>Классы RUNUP; для объектов вне RUNUP — класс исходной книги</p></div>${f.classes.map(r=>`<div class="finance-bar"><div><strong>${esc(r.criticality)}</strong><span>${r.known?fmt(r.fte,1):'—'} ПШЕ <small>${fmt(r.share*100,1)}%</small></span></div><svg class="finance-track" viewBox="0 0 100 2" preserveAspectRatio="none" aria-hidden="true"><rect width="100" height="2" rx="1" fill="#edf3f1"/><rect width="${r.fte/max*100}" height="2" rx="1" fill="#16846c"/></svg></div>`).join('')}</section><section class="panel"><div class="panel-head"><h2>Ресурсная база</h2><p>Рассчитанные АС и ФП выбранного периметра</p></div>${[['РСМ',t.cpu_rsm],['OpenShift',t.cpu_openshift],['Всего',t.cpu_total]].map(([name,v])=>`<div class="finance-resource"><span>${name}</span><strong>${t.known?fmt(v):'—'}</strong></div>`).join('')}</section></div><section class="panel finance-table"><h2>Сводка расчёта</h2>${financeMuiCaption(f)}${table(financeHeaders,f.classes.concat([{criticality:'Итого',...t}]).map(r=>`<tr>${financeValues(r).map((v,i)=>`<td class="${i?'num':''}">${i?num(v,i===8?2:i===7?1:0):esc(v)}</td>`).join('')}</tr>`).join(''))}</section><details class="object-fold"><summary>Детализация объектов · ${fmt(t.systems)} АС и ФП</summary><div class="panel">${financeObjectTable(f.records)}</div></details>`;
}
function financeObjectTable(records){return table(['КЭ','Тип','Наименование','Класс объекта','Класс в расчёте','CPU','ПШЕ'],records.map(r=>`<tr><td>${esc(r.entity.id_ke)}</td><td>${esc(r.entity.category)}</td><td>${esc(r.entity.name)}</td><td>${esc(r.entity.criticality)}</td><td>${esc(r.calculation?.criticality||'—')}</td><td class="num">${num(r.calculation?.cpu_total??null,0)}</td><td class="num">${num(r.calculation?.fte??null,1)}</td></tr>`).join(''));}
function operationalRows(){
  const s=operationalStats(filtered(),activePlans(),operationalDate());
  let records=s.groups[operationView]||s.records;
  if(planningStatus)records=records.filter(r=>planningStatus==='empty'?!r.plan.status:r.plan.status===planningStatus);
  if(transitionFilter)records=records.filter(r=>transitionFilter==='missing'?!r.strategy:transitionFilter==='planned'?r.strategy:transitionState(r.entity)===transitionFilter);
  return {stats:s,records};
}
const operationHeads=['КЭ','Тип','Наименование','ДИТ','Стратегия перехода к 3 зонам доступности','Срок развёртывания','Площадка','Ответственный','Статус','План подготовлен'];
function operationValues(r){return [r.entity.id_ke,r.entity.category,r.entity.name,r.entity.dit||'Не указан',r.entity.transition_strategy||'Не указана',r.plan.target_date||(r.period.year?`${r.period.year}${r.period.quarter?' · '+r.period.quarter+' кв.':''}`:'Не указан'),r.plan.site||'Не указана',r.plan.owner||'Не указан',r.plan.status||'Не задан',r.prepared?'Да':'Нет'];}
const ditOperationKeys=['all','entered','prepared','strategy','quarter','year','done','overdue','unscheduled','unowned'];
function ditOperationSummary(stats,selected){
  const selectedIds=new Set(selected.map(r=>r.entity.id_ke));
  const names=[...new Set(stats.records.map(r=>r.entity.dit||'Не указан'))].sort((a,b)=>a.localeCompare(b,'ru'));
  const rows=names.map(name=>{
    const records=stats.records.filter(r=>(r.entity.dit||'Не указан')===name),ids=new Set(records.map(r=>r.entity.id_ke));
    return [name,records.filter(r=>r.entity.category==='АС').length,records.filter(r=>r.entity.category==='ФП').length,records.length,records.filter(r=>selectedIds.has(r.entity.id_ke)).length,...ditOperationKeys.slice(1).map(k=>stats.groups[k].filter(r=>ids.has(r.entity.id_ke)).length)];
  });
  const total=['Итого',...Array.from({length:ditOperationKeys.length+3},(_,i)=>rows.reduce((sum,r)=>sum+r[i+1],0))];
  return {headers:['ДИТ','АС','ФП','Всего','В текущем списке','План внесён','План полностью подготовлен','Стратегия перехода к 3 зонам доступности',`${stats.quarter} кв. ${stats.year}`,`${stats.year} год`,'Развёрнуто / принято','Просрочено','Без срока','Без ответственного'],rows,total};
}
function ditOperationsTable(stats,records){
  const d=ditOperationSummary(stats,records);
  return `<section class="panel dit-operations"><div class="section-title"><div><h2>Итоги по ДИТ</h2><p>Общие фильтры применены ко всем итогам. «В текущем списке» учитывает выбранный показатель, статус и стратегию.</p></div></div>${table(d.headers,d.rows.concat([d.total]).map((r,index)=>`<tr>${r.map((v,i)=>`<td class="${i?'num':''}">${i?num(v,0):index<d.rows.length?`<button class="table-link" data-operation-dit="${esc(v)}">${esc(v)}</button>`:`<strong>${esc(v)}</strong>`}</td>`).join('')}</tr>`).join(''))}</section>`;
}
function operationsPage(){
  const {stats:s,records}=operationalRows(),editable=canEdit&&!isHistorical();
  return `<p class="section-context">АС и ФП выбранного периметра · на ${esc(s.asOf)}${isHistorical()?' · исторические планы':''}. Стратегия перехода к 3 зонам доступности, сроки и статус развёртывания ведутся в едином реестре.</p><section class="panel operations-totals"><div><h2>Общий итог выбранного периметра</h2>${entityCounts(s.records.map(r=>r.entity))}<p class="note">Всего ${fmt(s.records.length)} объектов</p></div><div><h2>В текущем списке</h2>${entityCounts(records.map(r=>r.entity))}<p class="note">Всего ${fmt(records.length)} · ${esc(operationLabels(s)[operationView]||'Все объекты')}</p></div></section>${operationalPanel(filtered())}${ditOperationsTable(s,records)}<section class="panel operations-registry"><div class="section-title"><div><h2>Планы и стратегии АС и ФП</h2><p>${fmt(records.length)} из ${fmt(s.records.length)} объектов · ${esc(operationLabels(s)[operationView]||'Все объекты')}</p></div><button id="pickPlanObject" class="primary" ${editable?'':'disabled'}>Выбрать объект для плана</button></div><div class="operation-controls"><label>Показатель<select id="operationView">${Object.entries(operationLabels(s)).map(([k,v])=>`<option value="${k}" ${k===operationView?'selected':''}>${esc(v)}</option>`).join('')}</select></label><label>Статус развёртывания<select id="planningStatus"><option value="">Все статусы</option><option value="empty" ${planningStatus==='empty'?'selected':''}>Не задан</option>${planStatuses.map(status=>`<option ${planningStatus===status?'selected':''}>${esc(status)}</option>`).join('')}</select></label><label>Стратегия перехода к 3 зонам доступности<select id="operationStrategy"><option value="">Все стратегии</option>${Object.entries({planned:'Есть стратегия',missing:'Нет стратегии',blank:'Пустая стратегия',not_listed:'Нет КЭ в опроснике',unloaded:'Не проверено'}).map(([k,v])=>`<option value="${k}" ${transitionFilter===k?'selected':''}>${esc(v)}</option>`).join('')}</select></label></div><p class="note">План подготовлен — заполнены срок, площадка, ответственный и статус. Наличие стратегии A-A-A / A-A-P / A-P-P считается отдельно. Стратегии обновляются из опросника через меню «Действия».</p>${table([...operationHeads,'План'],records.map(r=>`<tr>${operationValues(r).map((v,i)=>`<td>${i===2?`<button class="table-link" data-operation-object="${esc(r.entity.id_ke)}">${esc(v)}</button>`:esc(v)}</td>`).join('')}<td><button data-edit-plan="${esc(r.entity.id_ke)}" ${editable?'':'disabled'}>${r.plan.year||r.plan.target_date||r.plan.status?'Изменить план':'Задать план'}</button></td></tr>`).join(''))}</section><details class="object-fold"><summary>Как считаются показатели</summary><div class="panel"><p>Квартал и год включают завершённые планы; «осталось» исключает статусы «Развёрнуто» и «Принято». Просрочка считается по целевой дате, последнему дню квартала либо года. План без срока не считается просроченным. Приостановленные планы сохраняют срок.</p><p>Каждая АС и каждая ФП учитывается по собственному КЭ. Стратегия и календарный план не наследуются от родителя. Текущая дата — по Москве; для истории используется дата среза. Пустые планы не заменяются предположениями.</p></div></details>`;
}

const overviewRender=render;
render=function(){
  if(page==='planning')page='operations';
  if(page==='transition'){
    page='operations';operationView='all';
  }
  if(page==='pshe')page='fincontrol';
  if(['fincontrol','operations','initiatives'].includes(page)){
    gridInstances=[];document.querySelector('header h1').textContent=sectionTitles[page];
    document.querySelectorAll('nav [data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page===page));
    $('content').innerHTML=page==='fincontrol'?fincontrolPage():page==='initiatives'?initiativesPage():operationsPage();
    bindAdvanced();enhanceTables($('content'));activeFilterPanel();bindSections();bindExcelExport();savePreferencesSoon();
    if($('operationStrategy'))$('operationStrategy').onchange=()=>{transitionFilter=$('operationStrategy').value;render();};
    document.querySelectorAll('[data-operation-dit]').forEach(b=>b.onclick=()=>{$('dit').value=b.dataset.operationDit;render();});
    if($('operationView'))$('operationView').onchange=()=>{operationView=$('operationView').value;render();};
    document.querySelectorAll('[data-operation-object]').forEach(b=>b.onclick=()=>showObjectCard(b.dataset.operationObject).catch(stateError));
  }else overviewRender();
  const questionnaireButton=$('loadQuestionnaireHeader');if(questionnaireButton){questionnaireButton.hidden=!canLoad;questionnaireButton.disabled=isHistorical();questionnaireButton.onclick=()=>openQuestionnaireUpload().catch(stateError);}
  if(document.body.dataset)document.body.dataset.page=page;
  document.querySelector('header .subtitle').textContent='Программа перехода в три зоны доступности';
  document.querySelectorAll('nav details').forEach(el=>{if(el.querySelector('.active'))el.open=true;});
  document.querySelectorAll('[data-operation]').forEach(b=>b.onclick=()=>{operationView=b.dataset.operation;page='operations';offset=0;render();});
};
const overviewExport=exportWorkbook;
function financeSheets(){
  const d=fincontrolData,f=financeScope(filtered()),t=f.total;
  return [{name:'Потребность ПШЕ',rows:[financeHeaders,...f.classes.concat([{criticality:'Итого',...t}]).map(financeValues)]},{name:'Объекты ПШЕ',rows:[['КЭ','Тип','Наименование','Класс объекта','Класс в расчёте','CPU РСМ','CPU OpenShift','CPU всего','ПШЕ','Есть расчёт','Формула','Причина нулевой оценки','Источники РСМ'],...f.records.map(r=>[r.entity.id_ke,r.entity.category,r.entity.name,r.entity.criticality,r.calculation?.criticality||'',r.calculation?.cpu_rsm??null,r.calculation?.cpu_openshift??null,r.calculation?.cpu_total??null,r.calculation?.fte??null,r.calculation?'Да':'Нет',r.calculation?.method||'',r.calculation?.zero_reason||'',JSON.stringify(r.calculation?.rsm_signature||[])])]},{name:'Источник ПШЕ',rows:[['Файл',d.source_file],['Лист',d.source_sheet],['SHA-256',d.source_sha256],['Дата импорта',d.imported_on],['Принцип','Исходная книга целиком + досчёт только по собственным КЭ RUNUP ∩ РСМ'],['Исходная книга, объектов',(d.baseline_total||d.total).systems],['Исходная книга, ПШЕ',(d.baseline_total||d.total).fte],['Досчёт, объектов',d.completion?.added_count||0],['Досчёт, ПШЕ',d.completion?.added_fte||0],['Всего с досчётом, ПШЕ',d.total.fte],['Коэффициент модели',d.model?.coefficient||''],['Период ПШЕ в МУИ',f.mui.period.label],['Отчёт МУИ',f.mui.report?.source||'Не загружен'],['Версия отчёта МУИ',f.mui.report?.revision||null],['Принцип ПШЕ в МУИ','Сумма заполненной численности одного выбранного периода по собственным сопоставленным КЭ АС и ФП в выборке'],['ПШЕ в МУИ — полный отчёт',f.mui.full],['ПШЕ в МУИ — вне выборки',f.mui.outside],['ПШЕ в МУИ — без сопоставления',f.mui.unresolved]]}];
}
exportWorkbook=function(detail=false){
  if(page==='operations'){
    const {stats:s,records}=operationalRows(),d=ditOperationSummary(s,records),params=transitionParams();params.rows.push(['Показатель оперативного контроля',operationLabels(s)[operationView]||'Все'],['Статус развёртывания',planningStatus||'Все']);
    return [{name:'Оперативный контроль',rows:[operationHeads,...records.map(operationValues)]},{name:'Показатели АС и ФП',rows:[['Показатель','АС','ФП','Всего'],...Object.entries(operationLabels(s)).map(([k,label])=>[label,s.groups[k].filter(r=>r.entity.category==='АС').length,s.groups[k].filter(r=>r.entity.category==='ФП').length,s.groups[k].length]),['Дата расчёта',s.asOf]]},{name:'Итоги по ДИТ',rows:[d.headers,...d.rows,d.total]},params];
  }
  if(page==='fincontrol')return financeAvailable()?financeSheets():[];
  if(page==='overview'){
    const es=filtered(),f=financeScope(es),s=operationalStats(es,activePlans(),operationalDate()),ids=new Set(es.map(e=>e.id_ke)),bs=budgets.filter(b=>ids.has(b.id_ke));
    return [{name:'Обзор программы',rows:[['Показатель','Значение'],['АС',es.filter(e=>e.category==='АС').length],['ФП',es.filter(e=>e.category==='ФП').length],['Всего АС и ФП RUNUP',programmeObjects(es).length],['Объектов финансового периметра',f.total.systems],['Потребность ПШЕ',f.total.known?f.total.fte:null],['ПШЕ в МУИ',f.total.mui],['Период ПШЕ в МУИ',f.mui.period.label],['АС и ФП без расчёта',f.total.missing],['КТС, руб./год',sum(bs,'budget_rub')],...Object.entries(operationLabels(s)).map(([k,label])=>[label,s.groups[k].length]),['Дата оперативных показателей',s.asOf]]},...(financeAvailable()?financeSheets():[]),{name:'Планы АС и ФП',rows:[operationHeads,...s.records.map(operationValues)]},exportParams(es,false)];
  }
  return overviewExport(detail);
};
