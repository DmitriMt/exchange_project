"""Cross-restart action receipts, process enforcement and team feature checks."""
import copy
import json
import secrets
import tempfile
import unittest
from pathlib import Path
from localpm import core
from localpm.application import Application,actual_snapshot
from localpm.maintenance import Maintenance,repeat_project
import test_board_application as board_tests
from test_board_application import DirectClient

class ProductTests(unittest.TestCase):
    setUp=board_tests.BoardApplicationTests.setUp
    worker=board_tests.BoardApplicationTests.worker
    put=board_tests.BoardApplicationTests.put
    fact=board_tests.BoardApplicationTests.fact
    def action(self,kind,data,operation=None,expected=201):
        return self.manager.call('POST','/api/projects/project-test/actions',{'operationId':operation or secrets.token_hex(12),'kind':kind,'data':data},expected)
    def test_comment_receipt_is_atomic_and_survives_service_restart(self):
        operation=secrets.token_hex(12);body={'text':'Проверка','taskId':'a'}
        first=self.action('comment',body,operation);self.assertEqual(first['actionReceipt']['id'],operation)
        self.action('comment',body,operation,200);self.assertEqual(len(self.app.repo.load('project-test')['comments']),1)
        self.action('comment',{'text':'Подмена','taskId':'a'},operation,409)
        self.app.close();self.app=Application(self.tmp.name);self.addCleanup(self.app.close)
        # New authenticated session after restart, same user, same operation.
        user=self.app.repo.users()[0];token=secrets.token_hex(32);csrf=secrets.token_hex(24)
        import time
        self.app.sessions[token]={'userId':user['id'],'csrf':csrf,'expires':time.time()+1000,'kind':'web'}
        self.manager=DirectClient(self.app);self.manager.cookie='localpm_py_session='+token;self.manager.csrf=csrf
        self.action('comment',body,operation,200);self.assertEqual(len(self.app.repo.load('project-test')['comments']),1)
    def test_stale_actual_conflicts_without_overwriting_new_facts(self):
        data={'taskId':'a','actual':self.fact(),'baseActual':actual_snapshot(self.doc['project']['tasks'][0])}
        current=self.put(self.doc,lambda p:p['tasks'][0].update(status='На приёмке'))
        self.action('actual',data,expected=409)
        self.assertEqual(self.app.repo.load('project-test')['project']['tasks'][0]['status'],'На приёмке')
    def test_process_can_accept_manager_facts_directly_but_keep_worker_proposals(self):
        self.doc=self.put(self.doc,lambda p:p.update(workflow={'approval':'contributors'}))
        data={'taskId':'a','actual':self.fact(),'baseActual':actual_snapshot(self.doc['project']['tasks'][0])}
        accepted=self.action('actual',data);self.assertEqual(accepted['updates'][-1]['status'],'accepted');self.assertEqual(accepted['project']['tasks'][0]['percent_complete'],25)
        user,client=self.worker();self.doc=self.manager.call('GET','/api/projects/project-test');self.doc=self.put(self.doc,lambda p:p['tasks'][0].update(assignee_id=user['id']))
        data['baseActual']=actual_snapshot(self.doc['project']['tasks'][0]);data['actual']['percent_complete']=35
        result=client.call('POST','/api/projects/project-test/actions',{'operationId':secrets.token_hex(12),'kind':'actual','data':data},201)
        self.assertEqual(result['updates'][-1]['status'],'pending');self.assertEqual(result['project']['tasks'][0]['percent_complete'],25)
    def test_editor_cannot_disable_process_and_api_cannot_bypass_required_fields(self):
        self.doc=self.put(self.doc,lambda p:p.update(workflow={'approval':'all','transitions':[{'from':'todo','to':'blocked','required':['blocker']}]}))
        user,client=self.worker('editor');project=copy.deepcopy(self.doc['project']);project['workflow']={'approval':'none'}
        result=client.call('PUT','/api/projects/project-test',{'project':project,'expectedVersion':self.doc['version'],'operationId':secrets.token_hex(12)})
        self.assertEqual(result['project']['workflow']['approval'],'all')
        self.manager.call('POST','/api/projects/project-test/updates',{'taskId':'a','actual':{**self.fact(),'status':'Заблокировано','kanban_column_id':'blocked','blocker':''}},422)
    def test_organization_calendar_groups_and_preferences_have_cas_and_permissions(self):
        user,worker=self.worker();settings=self.manager.call('GET','/api/organization');value={'groups':[{'id':'g','name':'Отдел','members':[user['id']]}],'availability':{user['id']:{'hours':[0,4,4,4,4,4,0],'absences':[]}},'templates':[],'emails':{}}
        worker.call('PUT','/api/organization',{'value':value,'expectedVersion':0},403)
        result=self.manager.call('PUT','/api/organization',{'value':value,'expectedVersion':settings['version']});self.assertEqual(result['version'],1)
        self.manager.call('PUT','/api/organization',{'value':value,'expectedVersion':0},409)
        worker.call('PUT','/api/preferences',{'value':{'density':'compact'},'expectedVersion':0});self.assertEqual(worker.call('GET','/api/preferences')['value']['density'],'compact');self.assertEqual(self.manager.call('GET','/api/preferences')['value'],{})
    def test_action_rechecks_access_even_after_a_successful_delivery(self):
        operation=secrets.token_hex(12);data={'text':'A','taskId':'a'};user,worker=self.worker()
        worker.call('POST','/api/projects/project-test/actions',{'operationId':operation,'kind':'comment','data':data},201)
        self.manager.call('DELETE','/api/projects/project-test/members/'+user['id'])
        worker.call('POST','/api/projects/project-test/actions',{'operationId':operation,'kind':'comment','data':data},403)
    def test_worklog_is_idempotent_and_watchers_receive_task_mentions(self):
        user,worker=self.worker();self.doc=self.put(self.doc,lambda p:p['tasks'][0].update(assignee_id=user['id']))
        worker.call('POST','/api/projects/project-test/actions',{'operationId':'watch-op','kind':'watch','data':{'taskId':'a','watching':True}})
        data={'taskId':'a','hours':2.5,'date':core.today(),'reason':'Анализ отклонения'};self.action('worklog',data,'time-op',200);self.action('worklog',data,'time-op',200)
        self.assertEqual(self.app.repo.load('project-test')['project']['tasks'][0]['spent_hours'],2.5)
        self.action('comment',{'taskId':'a','text':'Обновление'});self.assertTrue(worker.call('GET','/api/projects/project-test')['notifications'])
    def test_typed_fields_are_validated_before_project_update(self):
        self.doc=self.put(self.doc,lambda p:p.update(field_definitions=[{'id':'link','name':'Документ','type':'url'}]))
        project=copy.deepcopy(self.doc['project']);project['tasks'][0]['field_values']={'link':'javascript:alert(1)'}
        self.manager.call('PUT','/api/projects/project-test',{'project':project,'expectedVersion':self.doc['version'],'operationId':'bad-fields'},422)
        self.assertEqual(self.app.repo.load('project-test')['version'],self.doc['version'])
    def test_direct_plan_write_cannot_bypass_process_rules_or_employee_fact_approval(self):
        self.doc=self.put(self.doc,lambda p:p.update(workflow={'approval':'all','transitions':[{'from':'todo','to':'review','required':[]}]}))
        user,editor=self.worker('editor');p=copy.deepcopy(self.doc['project']);p['tasks'][0]['status']='На приёмке'
        editor.call('PUT','/api/projects/project-test',{'project':p,'expectedVersion':self.doc['version'],'operationId':'bypass-approval'},422)
        p['tasks'][0]['status']='Заблокировано'
        self.manager.call('PUT','/api/projects/project-test',{'project':p,'expectedVersion':self.doc['version'],'operationId':'bypass-transition'},422)
    def test_completed_status_cannot_be_written_without_actual_completion(self):
        p=copy.deepcopy(self.doc['project']);p['tasks'][0]['status']='Завершено'
        self.manager.call('PUT','/api/projects/project-test',{'project':p,'expectedVersion':self.doc['version'],'operationId':'bad-completion'},422)
    def test_scheduled_recurrence_matches_month_end_and_has_no_duplicates(self):
        template=copy.deepcopy(self.doc['project']);template['tasks']=template['tasks'][:1];template['dependencies']=[];template['start_date']='2026-01-30';template=core.calculate(template)
        project=copy.deepcopy(self.doc['project']);project['recurrences']=[{'id':'rule','unit':'month','interval':1,'start':'2026-01-31','template':template,'cursor':0}]
        first,added=repeat_project(project,'2026-03-31');self.assertEqual(added,3);self.assertEqual(repeat_project(first,'2026-03-31')[1],0);self.assertEqual(len({t['id'] for t in first['tasks']}),len(first['tasks']))
    def test_automatic_backup_is_restored_and_report_snapshot_does_not_change_plan_version(self):
        maintenance=Maintenance(self.app,backup_hours=24);before=self.app.repo.load('project-test')['version'];maintenance.schedules();self.assertEqual(self.app.repo.load('project-test')['version'],before)
        self.assertTrue(self.manager.call('GET','/api/projects/project-test/report-snapshots'));maintenance.backup();self.assertTrue(self.app.maintenance_status['lastVerified']);self.assertEqual(len(list((Path(self.tmp.name)/'backups').glob('auto-*.json'))),1)
    def test_health_diagnostics_and_paginated_tasks_do_not_expose_session_tokens(self):
        result=self.manager.call('GET','/api/sessions');self.assertNotIn(self.manager.cookie.split('=')[1],json.dumps(result))
        diagnostics=self.manager.call('GET','/api/diagnostics');self.assertEqual(diagnostics['database'],'ok');self.assertEqual(diagnostics['schemaVersion'],2)
        page=self.manager.call('GET','/api/projects/project-test/task-page/0');self.assertEqual(page['total'],len(self.doc['project']['tasks']))

if __name__=='__main__':unittest.main()
