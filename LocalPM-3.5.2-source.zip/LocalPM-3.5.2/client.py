#!/usr/bin/env python3
"""Optional loopback-only launcher for the standalone HTML. No API or database."""
import argparse
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
ROOT=Path(__file__).resolve().parent
class ClientHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path.split('?',1)[0] not in ['/','/index.html','/client.html']:
            self.send_error(404); return
        payload=(ROOT/'LocalPM-client.html').read_bytes(); self.send_response(200)
        self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(payload)))
        self.send_header('Cache-Control','no-cache'); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Referrer-Policy','no-referrer'); self.end_headers(); self.wfile.write(payload)
    def log_message(self,*args): pass

def main():
    parser=argparse.ArgumentParser(description='LocalPM standalone HTML launcher (loopback only)'); parser.add_argument('--port',type=int,default=9099); args=parser.parse_args()
    if not 1<=args.port<=65535: parser.error('Invalid port.')
    if not (ROOT/'LocalPM-client.html').is_file(): parser.error('Build the client first: python3 build.py')
    with ThreadingHTTPServer(('127.0.0.1',args.port),ClientHandler) as server:
        print(f'LocalPM client: http://127.0.0.1:{args.port}',flush=True)
        print('Only the HTML client is served; there is no local API or server database.',flush=True)
        try: server.serve_forever()
        except KeyboardInterrupt: pass
if __name__=='__main__': main()
