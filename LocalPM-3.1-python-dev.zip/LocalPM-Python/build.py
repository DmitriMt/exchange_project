#!/usr/bin/env python3
"""Offline frontend assembly using Python only; output matches the previous builder."""
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parent

def read(name): return (ROOT/name).read_text(encoding='utf-8')
def main():
    legacy=read('src/legacy-app.js')
    for name in ['render','displayRows','openTaskCard','startInlineEdit','showProjectSettings','initInteractions','renderGanttViewportSync','ganttHit','ganttHitZone']:
        pattern=r'function '+name+r'\('
        legacy,count=re.subn(pattern,'function legacy'+name[0].upper()+name[1:]+'(',legacy,count=1)
        if count!=1: raise ValueError('Не найдена функция '+name)
    legacy=legacy.replace('SCHEMA_VERSION=2','SCHEMA_VERSION=3').replace('v2.5','v3.0 · пилот').replace('РФ праздники','РФ: базовые праздники без переносов').replace('РФ: пятидневка + праздники','РФ: базовые праздники без переносов').replace('(архив на 30 дней)','(можно восстановить из архива)')
    extra='\n'.join(read(p) for p in ['src/enhancements.js','src/team.js','src/scroll-sync.js'])
    def replace(before,after):
        nonlocal legacy
        if before not in legacy: raise ValueError('Не найдена точка сборки: '+before[:80])
        legacy=legacy.replace(before,after,1)
    replace('var App={',extra+'\nvar App={')
    replace("document.addEventListener('DOMContentLoaded',function(){","installEnhancements3();\ndocument.addEventListener('DOMContentLoaded',function(){")
    replace('if(state.fileDirty&&!state.fileConnected){',"if((state.fileDirty&&(connectionMode==='server'||fileHandle))||(connectionMode==='local'&&!state.localSaved&&!state.localTabReadOnly)){")
    legacy=re.sub(r'\balert\(','inform3(',legacy)
    replace("if(confirm('Заменить рабочее пространство файлом базы?')){pushHistory();applyWorkspace(d,'replace',false);saveAll();updateDbChip();render()}",'showWorkspaceImport3(d)')
    replace("var tag=(e.target.tagName||'').toLowerCase();","if(document.querySelector('.modal'))return;var tag=(e.target.tagName||'').toLowerCase();")
    replace('var fullHeight=HEADER_H+rows.length*ROW_H+20;var viewportHeight=opts.viewportHeight||Math.max(240,container?container.clientHeight:600);','var metrics=!target?paneMetrics3():null;var fullHeight=metrics?metrics.height:HEADER_H+rows.length*ROW_H+20;var viewportHeight=opts.viewportHeight||(metrics?metrics.viewportHeight:600);')
    replace('var scrollTop=opts.scrollTop||0;','var scrollTop=opts.scrollTop==null?(!target&&container?container.scrollTop:0):opts.scrollTop;')
    styles=read('src/legacy-styles.css')+'\n'+read('src/team.css'); core=read('src/core.js')
    fatal="window.__fatal=function(message){console.error(message);var box=document.getElementById('error-banner');if(!box){box=document.createElement('aside');box.id='error-banner';box.setAttribute('role','alert');document.body.appendChild(box)}box.textContent='Ошибка: '+message+' Доступ к сохранению и экспорту остаётся в меню приложения.'};window.addEventListener('error',function(e){window.__fatal(e.message||'Неизвестная ошибка')});window.addEventListener('unhandledrejection',function(e){window.__fatal(e.reason?.message||String(e.reason))});"
    def inline_script(s): return re.sub(r'</script',lambda m:'<\\/script',s,flags=re.I)
    def html(inline):
        return '<!doctype html>\n<html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>LocalPM 3.0 — корпоративный планировщик</title>'+('<style>'+styles+'</style>' if inline else '<link rel="stylesheet" href="styles.css">')+'</head><body><div id="app"></div><div id="modal-root"></div><div id="print-area"></div><script>'+fatal+'</script>'+('<script>'+inline_script(core)+'</script><script>'+inline_script(legacy)+'</script>' if inline else '<script src="core.js"></script><script src="app.js"></script>')+'</body></html>'
    files={'web/core.js':core,'web/app.js':legacy,'web/styles.css':styles,'web/index.html':html(False),'LocalPM.html':html(True)}
    for name,content in files.items():
        p=ROOT/name; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(content,encoding='utf-8')
    print('Собраны web/ и автономный LocalPM.html средствами Python.')

if __name__=='__main__': main()
