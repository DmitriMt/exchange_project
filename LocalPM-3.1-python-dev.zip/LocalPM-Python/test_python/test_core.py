import copy
import datetime as dt
import hashlib
import json
import unittest
from pathlib import Path
from localpm import core

ROOT=Path(__file__).resolve().parents[1]
def sample():
    return {'id':'project-test','name':'Проект','start_date':'2026-10-05','status_date':'2026-10-26','calendar_id':'5day','createdAt':'2020-01-01T00:00:00.000Z','updatedAt':'2020-01-01T00:00:00.000Z','tasks':[{'id':'a','name':'A','duration_days':5},{'id':'b','name':'B','duration_days':2}],'dependencies':[{'id':'ab','pred_id':'a','succ_id':'b','type':'FS','lag_workdays':0}]}

class CoreTests(unittest.TestCase):
    def test_conformance_with_javascript(self):
        data=json.loads((ROOT/'test_python/fixtures/core_conformance.json').read_text())
        self.assertEqual(data['sourceSha256'],hashlib.sha256((ROOT/'src/core.js').read_bytes()).hexdigest())
        for fixture in data['cases']:
            with self.subTest(fixture['name']): self.assertEqual(core.calculate(fixture['input'],strict=True),fixture['expected'])
    def test_date_rollover(self):
        for value in ['2026-02-31','2025-02-29','2101-01-01','26-01-01']: self.assertIsNone(core.date(value))
        self.assertEqual(core.date('2024-02-29'),'2024-02-29')
    def test_invalid_duration(self):
        for value in [-1,.5,'x',True]:
            p=sample(); p['tasks'][0]['duration_days']=value
            with self.assertRaises(ValueError): core.calculate(p)
    def test_earlier_reschedule_and_purity(self):
        p=sample(); before=copy.deepcopy(p); out=core.calculate(p); self.assertEqual(p,before); self.assertEqual(out,core.calculate(out)); self.assertEqual(out['tasks'][1]['start_date'],'2026-10-12')
        p['tasks'][0]['duration_days']=1; self.assertEqual(core.calculate(p)['tasks'][1]['start_date'],'2026-10-06'); p['dependencies']=[]; self.assertEqual(core.calculate(p)['tasks'][1]['start_date'],'2026-10-05')
    def test_cycle_preserved(self):
        p=sample(); p['dependencies'].append({'id':'ba','pred_id':'b','succ_id':'a','type':'FS'})
        self.assertTrue(core.calculate(p)['cpmError']); self.assertEqual(len(p['dependencies']),2)
        with self.assertRaises(ValueError): core.calculate(p,strict=True)
    def test_parent_cycle(self):
        p=sample(); p['tasks'][0]['parent_id']='b'; p['tasks'][1]['parent_id']='a'
        with self.assertRaises(ValueError): core.calculate(p)
    def test_bad_ids_and_widths(self):
        for field,value in [('id',"x');bad"),('parent_id','missing')]:
            p=sample(); p['tasks'][0][field]=value
            with self.assertRaises(ValueError): core.normalize(p)
        p=sample(); p['view_settings']={'leftWidth':'bad'}
        with self.assertRaises(ValueError): core.normalize(p)
    def test_calendar_exceptions(self):
        c=core.calendar({'calendar_id':'rf','working_exceptions':['2026-11-04','2026-10-03'],'exceptions':['2026-10-05']})
        self.assertIn('2026-11-04',c.index); self.assertIn('2026-10-03',c.index); self.assertNotIn('2026-10-05',c.index)
    def test_actual_validation_and_baseline(self):
        p=core.calculate(sample()); old=copy.deepcopy(p); stamp=(dt.date.today()-dt.timedelta(days=10)).isoformat()
        out=core.actual(p,'a',{'actual_start':stamp,'percent_complete':50,'remaining_days':3})
        self.assertEqual(p,old); self.assertEqual(out['tasks'][0]['finish_date'],old['tasks'][0]['finish_date'])
        with self.assertRaises(ValueError): core.actual(p,'a',{'actual_start':'2099-01-01','percent_complete':50,'remaining_days':3})
        with self.assertRaises(ValueError): core.actual(p,'a',{'percent_complete':100,'remaining_days':0})
    def test_merge_independent_and_conflict(self):
        p=core.calculate(sample()); a=copy.deepcopy(p); b=copy.deepcopy(p); a['tasks'][0]['note']='a'; b['tasks'][1]['owner']='b'
        self.assertFalse(core.merge(p,a,b)['conflicts']); b['tasks'][0]['note']='other'; self.assertTrue(core.merge(p,a,b)['conflicts'])
    def test_merge_delete_against_edit(self):
        p=core.calculate(sample()); a=copy.deepcopy(p); b=copy.deepcopy(p); a['tasks'][0]['note']='a'; b['tasks']=b['tasks'][1:]; b['dependencies']=[]
        self.assertTrue(core.merge(p,a,b)['conflicts'])
    def test_empty_project(self): self.assertEqual(core.calculate({**sample(),'tasks':[],'dependencies':[]})['percent_complete'],0)
