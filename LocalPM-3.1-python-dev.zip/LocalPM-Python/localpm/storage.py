"""SQLite persistence and single-coordinator shared folder storage."""
from __future__ import annotations
import hashlib
import json
import os
import re
import secrets
import shutil
import socket
import sqlite3
import threading
from pathlib import Path
from . import core

class APIError(Exception):
    def __init__(self,status,message,**extra):
        super().__init__(message); self.status=status; self.extra=extra

def json_text(value,sort_keys=False):
    def clean(v):
        if isinstance(v,float) and v.is_integer(): return int(v)
        if isinstance(v,dict): return {k:clean(x) for k,x in v.items()}
        if isinstance(v,list): return [clean(x) for x in v]
        return v
    return json.dumps(clean(value),ensure_ascii=False,separators=(',',':'),allow_nan=False,sort_keys=sort_keys)

def atomic_write(file,value):
    file=Path(file); file.parent.mkdir(parents=True,exist_ok=True)
    tmp=file.with_name(file.name+'.'+secrets.token_hex(12)+'.tmp')
    try:
        fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w',encoding='utf-8') as stream:
            stream.write(value if isinstance(value,str) else json_text(value)); stream.flush(); os.fsync(stream.fileno())
        os.replace(tmp,file)
        if os.name!='nt':
            fd=os.open(file.parent,os.O_RDONLY)
            try: os.fsync(fd)
            finally: os.close(fd)
    finally:
        if tmp.exists(): tmp.unlink()

class Repository:
    def __init__(self,data_dir,shared_dir=None):
        self.data_dir=Path(data_dir).resolve(); self.shared_dir=Path(shared_dir).resolve() if shared_dir else None
        if self.shared_dir and (self.shared_dir==self.data_dir or self.shared_dir in self.data_dir.parents): raise APIError(422,'SQLite должна находиться вне общей папки, на локальном диске.')
        self.data_dir.mkdir(parents=True,exist_ok=True,mode=0o700)
        self.lock=threading.RLock(); self.owner=secrets.token_hex(24); self.closed=False
        self.db=sqlite3.connect(self.data_dir/'localpm.sqlite',check_same_thread=False,isolation_level=None,timeout=5)
        self.db.row_factory=sqlite3.Row
        self.db.executescript('''PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
        CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, name TEXT NOT NULL, hash TEXT NOT NULL, admin INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1, capacity REAL NOT NULL DEFAULT 8);
        CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY,version INTEGER NOT NULL,doc TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS versions(project_id TEXT NOT NULL,version INTEGER NOT NULL,doc TEXT NOT NULL,PRIMARY KEY(project_id,version));''')
        self.owner_dir=None
        if self.shared_dir:
            self.shared_dir.mkdir(parents=True,exist_ok=True); self.owner_dir=self.shared_dir/'.localpm-service-lock'
            try: self.owner_dir.mkdir()
            except FileExistsError:
                self.db.close(); raise APIError(503,'Общая папка уже занята сервисом LocalPM.')
            try:
                atomic_write(self.owner_dir/'owner.json',{'token':self.owner,'host':socket.gethostname(),'pid':os.getpid(),'startedAt':core.now()})
                (self.shared_dir/'projects').mkdir(exist_ok=True); (self.shared_dir/'versions').mkdir(exist_ok=True)
            except Exception:
                self.db.close(); shutil.rmtree(self.owner_dir,ignore_errors=True); raise
    def assert_owner(self):
        if not self.shared_dir: return
        try: token=json.loads((self.owner_dir/'owner.json').read_text())['token']
        except (OSError,ValueError,KeyError): raise APIError(503,'Сетевой диск недоступен или блокировка утрачена. Запись остановлена.')
        if token!=self.owner: raise APIError(503,'Владелец общей папки изменился. Запись остановлена.')
    def count_users(self): return self.db.execute('SELECT count(*) FROM users').fetchone()[0]
    def user(self,id):
        row=self.db.execute('SELECT * FROM users WHERE id=?',(id,)).fetchone(); return dict(row) if row else None
    def username(self,name):
        row=self.db.execute('SELECT * FROM users WHERE username=?',(name,)).fetchone(); return dict(row) if row else None
    def users(self,hashes=False):
        fields='*' if hashes else 'id,username,name,admin,active,capacity'
        return [dict(r) for r in self.db.execute('SELECT '+fields+' FROM users ORDER BY name')]
    def create_user(self,u,first=False):
        with self.lock:
            self.db.execute('BEGIN IMMEDIATE')
            try:
                if first and self.count_users(): raise APIError(409,'Первоначальная настройка уже выполнена.')
                self.db.execute('INSERT INTO users(id,username,name,hash,admin,active,capacity) VALUES(?,?,?,?,?,?,?)',tuple(u[k] for k in ['id','username','name','hash','admin','active','capacity']))
                self.db.execute('COMMIT')
            except Exception:
                self.db.execute('ROLLBACK'); raise
    def load(self,id):
        core.valid_id(id); self.assert_owner()
        if self.shared_dir:
            file=self.shared_dir/'projects'/(id+'.json')
            if not file.exists(): return None
            try: return json.loads(file.read_text(encoding='utf-8'))
            except (OSError,ValueError): raise APIError(503,'Повреждён или недоступен файл проекта '+id)
        r=self.db.execute('SELECT doc FROM projects WHERE id=?',(id,)).fetchone()
        return json.loads(r['doc']) if r else None
    def list(self):
        self.assert_owner()
        if self.shared_dir: return [self.load(p.stem) for p in sorted((self.shared_dir/'projects').glob('*.json'))]
        return [json.loads(r['doc']) for r in self.db.execute('SELECT doc FROM projects')]
    def save(self,doc,expected):
        id=core.valid_id(doc['project']['id'])
        with self.lock:
            self.assert_owner()
            if self.shared_dir:
                old=self.load(id)
                if (old['version'] if old else 0)!=expected: raise APIError(409,'Проект изменён другим участником.')
                if old: atomic_write(self.shared_dir/'versions'/id/(str(old['version'])+'.json'),old)
                atomic_write(self.shared_dir/'projects'/(id+'.json'),doc)
                versions=sorted((self.shared_dir/'versions'/id).glob('*.json'),key=lambda p:int(p.stem),reverse=True)
                for file in versions[20:]: file.unlink()
                return
            self.db.execute('BEGIN IMMEDIATE')
            try:
                old=self.load(id)
                if (old['version'] if old else 0)!=expected: raise APIError(409,'Проект изменён другим участником.')
                if old: self.db.execute('INSERT OR REPLACE INTO versions VALUES(?,?,?)',(id,old['version'],json_text(old)))
                self.db.execute('INSERT INTO projects VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET version=excluded.version,doc=excluded.doc',(id,doc['version'],json_text(doc)))
                self.db.execute('DELETE FROM versions WHERE project_id=? AND version NOT IN (SELECT version FROM versions WHERE project_id=? ORDER BY version DESC LIMIT 20)',(id,id)); self.db.execute('COMMIT')
            except Exception:
                self.db.execute('ROLLBACK'); raise
    def versions(self,id):
        core.valid_id(id); self.assert_owner()
        if self.shared_dir:
            return sorted([json.loads(p.read_text()) for p in (self.shared_dir/'versions'/id).glob('*.json')],key=lambda d:d['version'],reverse=True)
        return [json.loads(r['doc']) for r in self.db.execute('SELECT doc FROM versions WHERE project_id=? ORDER BY version DESC',(id,))]
    def backup(self):
        content={'format':'localpm-server-backup','version':1,'createdAt':core.now(),'users':self.users(hashes=True),'projects':self.list()}
        return {'content':content,'checksum':hashlib.sha256(json_text(content).encode()).hexdigest()}
    def restore(self,backup):
        if self.count_users() or self.list(): raise APIError(409,'Восстановление возможно только в пустое хранилище.')
        content=backup.get('content') if isinstance(backup,dict) else None
        if not isinstance(content,dict) or content.get('format')!='localpm-server-backup' or content.get('version')!=1 or backup.get('checksum')!=hashlib.sha256(json_text(content).encode()).hexdigest(): raise APIError(422,'Неверный формат или контрольная сумма копии.')
        users,projects=content.get('users'),content.get('projects')
        if not isinstance(users,list) or not isinstance(projects,list) or not any(u.get('admin') and u.get('active') for u in users): raise APIError(422,'Некорректный состав копии.')
        ids=set(); names=set()
        for u in users:
            core.valid_id(u['id'])
            if u['id'] in ids or u.get('username') in names or not re.fullmatch(r'[A-Za-z0-9_.-]{3,64}',u.get('username','')) or not isinstance(u.get('name'),str) or not re.fullmatch(r'pbkdf2\$600000\$[a-f0-9]{32}\$[a-f0-9]{64}',u.get('hash','')): raise APIError(422,'Некорректный пользователь в копии.')
            ids.add(u['id']); names.add(u['username']); core.number(u.get('capacity',8),'Доступность',1,24)
        project_ids=set()
        for d in projects:
            core.calculate(d['project'],strict=True); id=d['project']['id']
            if id in project_ids or type(d.get('version')) is not int or d['version']<1 or not isinstance(d.get('acl'),dict) or not any(k in ids and v=='manager' for k,v in d['acl'].items()): raise APIError(422,'Некорректный проект в копии.')
            if any(k not in ids or v not in ['manager','editor','contributor','viewer'] for k,v in d['acl'].items()): raise APIError(422,'Некорректные права в копии.')
            project_ids.add(id)
        with self.lock:
            self.db.execute('BEGIN IMMEDIATE')
            try:
                for u in users: self.db.execute('INSERT INTO users VALUES(?,?,?,?,?,?,?)',(u['id'],u['username'],u['name'],u['hash'],int(bool(u['admin'])),int(bool(u['active'])),u.get('capacity',8)))
                if not self.shared_dir:
                    for d in projects: self.db.execute('INSERT INTO projects VALUES(?,?,?)',(d['project']['id'],d['version'],json_text(d)))
                self.db.execute('COMMIT')
            except Exception:
                self.db.execute('ROLLBACK'); raise
            if self.shared_dir:
                for d in projects: self.save(d,0)
    def close(self):
        with self.lock:
            if self.closed: return
            self.closed=True
            if self.owner_dir:
                try: self.assert_owner(); shutil.rmtree(self.owner_dir)
                except (OSError,APIError): pass
            self.db.close()
