"""LocalPM HTTP-independent API, compatible with the existing browser client."""
from __future__ import annotations
import base64
import hashlib
import hmac
import re
import secrets
import threading
import time
from http.cookies import SimpleCookie
from . import core, __version__
from .storage import APIError, Repository, atomic_write, json_text

ROLES={'manager','editor','contributor','viewer'}
COOKIE='localpm_py_session'

def password_hash(password,salt=None):
    if not isinstance(password,str) or not 10<=len(password)<=256: raise APIError(422,'Пароль должен содержать 10–256 символов.')
    salt=salt or secrets.token_hex(16)
    digest=hashlib.pbkdf2_hmac('sha256',password.encode('utf-8'),salt.encode('ascii'),600000,32).hex()
    return f'pbkdf2$600000${salt}${digest}'

def verify_password(password,stored):
    if not isinstance(password,str) or len(password)>256 or not re.fullmatch(r'pbkdf2\$600000\$[a-f0-9]{32}\$[a-f0-9]{64}',stored): return False
    return hmac.compare_digest(password_hash(password,stored.split('$')[2]),stored) if len(password)>=10 else False

def public_user(u): return {k:(bool(u[k]) if k in ['admin','active'] else u[k]) for k in ['id','username','name','admin','active','capacity']}
def role(doc,user): return 'manager' if user['admin'] else doc['acl'].get(user['id'])
def managers(doc): return [id for id,r in doc['acl'].items() if r=='manager']
def actual_snapshot(t): return {'actual_start':t.get('actual_start') or '','actual_finish':t.get('actual_finish') or '','percent_complete':t['percent_complete'],'remaining_days':t.get('remaining_days')}
def notify(doc,ids,text,task_id=None):
    for id in set(ids):
        if id in doc['acl']: doc.setdefault('notifications',[]).append({'id':core.uid(),'user_id':id,'text':text,'task_id':task_id,'createdAt':core.now(),'read_at':None})
    doc['notifications']=doc.get('notifications',[])[-2000:]

def response_doc(doc,user):
    r=role(doc,user)
    return {'project':doc['project'],'version':doc['version'],'role':r,'acl':doc['acl'],'comments':doc.get('comments',[]),'updates':[u for u in doc.get('updates',[]) if r in ['manager','editor'] or u['user_id']==user['id']],'changeRequests':[{k:v for k,v in u.items() if k not in ['baseProject','proposedProject']} for u in doc.get('changeRequests',[]) if r=='manager' or u['user_id']==user['id']],'attachments':[{k:v for k,v in a.items() if k!='data'} for a in doc.get('attachments',[])],'notifications':[n for n in doc.get('notifications',[]) if n['user_id']==user['id']],'audit':doc.get('audit',[])[-100:] if r in ['manager','editor'] else []}

class Application:
    def __init__(self,data_dir,shared_dir=None,bootstrap_code=None,dev=False,public_origin=None,allowed_host=None):
        self.repo=Repository(data_dir,shared_dir); self.lock=threading.RLock(); self.sessions={}; self.attempts={}; self.started=time.monotonic(); self.last_backup=None
        self.bootstrap_code=bootstrap_code or secrets.token_hex(12); self.dev=dev; self.public_origin=public_origin; self.allowed_host=allowed_host
    def close(self): self.repo.close()
    def document(self,id,user,allowed=None):
        doc=self.repo.load(id)
        if doc is None: raise APIError(404,'Проект не найден.')
        r=role(doc,user)
        if not r or (allowed and r not in allowed): raise APIError(403,'Недостаточно прав.')
        return doc
    def session(self,headers):
        cookie=SimpleCookie()
        try: cookie.load(headers.get('Cookie',''))
        except Exception: raise APIError(401,'Войдите в систему.')
        token=cookie[COOKIE].value if COOKIE in cookie else ''; session=self.sessions.get(token)
        if not session or session['expires']<time.time():
            self.sessions.pop(token,None); raise APIError(401,'Войдите в систему.')
        user=self.repo.user(session['userId'])
        if not user or not user['active']: raise APIError(401,'Учётная запись отключена.')
        session['expires']=time.time()+8*3600
        return token,session,user
    def mutate(self,doc,user,action,change,operation=None):
        copy=core.clone(doc); expected=doc['version']; change(copy)
        copy['version']=expected+1; copy['project']['revision']=copy['version']; copy['project']['updatedAt']=core.now()
        copy.setdefault('audit',[]).append({'at':core.now(),'user_id':user['id'],'user':user['name'],'action':action}); copy['audit']=copy['audit'][-2000:]
        if operation: copy.setdefault('operations',[]).append(operation); copy['operations']=copy['operations'][-300:]
        self.repo.save(copy,expected); return copy
    def validate_user(self,b,first=False):
        if not isinstance(b.get('username'),str) or not re.fullmatch(r'[A-Za-z0-9_.-]{3,64}',b['username']) or not isinstance(b.get('name'),str) or not b['name'].strip(): raise APIError(422,'Укажите логин и имя.')
        return {'id':core.uid(),'username':b['username'],'name':b['name'].strip()[:200],'hash':password_hash(b.get('password')),'admin':int(first or b.get('admin') is True),'active':1,'capacity':core.number(b.get('capacity',8),'Часов в дне',1,24)}
    def validate_assignments(self,p,acl):
        active={u['id'] for u in self.repo.users() if u['active']}
        if any(t.get('assignee_id') and (t['assignee_id'] not in active or t['assignee_id'] not in acl) for t in p['tasks']): raise APIError(422,'Исполнитель должен быть активным участником проекта.')
    def check_origin(self,method,headers,secure):
        host=headers.get('Host','')
        if not re.fullmatch(r'(?:[A-Za-z0-9.\-]+|\[[a-fA-F0-9:]+\])(?::\d+)?',host): raise APIError(400,'Недопустимый Host.')
        local=bool(re.fullmatch(r'(?:localhost|127\.0\.0\.1|\[::1\])(?::\d+)?',host))
        if (self.allowed_host and host!=self.allowed_host) or (not self.allowed_host and not self.dev and not local): raise APIError(403,'Этот адрес сервера не разрешён.')
        if method not in ['GET','HEAD']:
            expected=self.public_origin or ('https' if secure else 'http')+'://'+host
            origin=headers.get('Origin')
            if (origin and origin!=expected) or headers.get('Sec-Fetch-Site')=='cross-site': raise APIError(403,'Источник запроса не разрешён.')
    def handle(self,method,path,headers,b,remote='127.0.0.1',secure=False):
        with self.lock: return self._handle(method,path,headers,b,remote,secure)
    def _handle(self,method,path,headers,b,remote,secure):
        self.check_origin(method,headers,secure)
        extra={}; now=time.time()
        if path=='/api/status' and method=='GET': return 200,{'version':__version__,'setupRequired':not self.repo.count_users(),'storage':'shared-folder' if self.repo.shared_dir else 'server-database','backend':'python','mode':'development' if self.dev else 'standard'},extra
        if path=='/api/setup' and method=='POST':
            if self.repo.count_users(): raise APIError(409,'Первоначальная настройка уже выполнена.')
            if not isinstance(b.get('code'),str) or not hmac.compare_digest(b['code'],self.bootstrap_code): raise APIError(403,'Неверный код первоначальной настройки.')
            self.repo.create_user(self.validate_user(b,first=True),first=True); return 201,{'ok':True},extra
        if path=='/api/login' and method=='POST':
            key=remote+':'+str(b.get('username',''))[:64]; attempt=self.attempts.get(key,{'n':0,'since':now})
            if now-attempt['since']>600: attempt={'n':0,'since':now}
            if attempt['n']>=8: raise APIError(429,'Слишком много попыток. Повторите через 10 минут.')
            if len(self.attempts)>10000: self.attempts={k:v for k,v in self.attempts.items() if now-v['since']<600};
            if len(self.attempts)>10000: raise APIError(429,'Слишком много попыток входа.')
            attempt['n']+=1; self.attempts[key]=attempt; u=self.repo.username(str(b.get('username','')))
            if not u or not u['active'] or not verify_password(b.get('password'),u['hash']): raise APIError(401,'Неверный логин или пароль.')
            self.attempts.pop(key,None); self.sessions={k:v for k,v in self.sessions.items() if v['expires']>=now}
            if len(self.sessions)>=10000: raise APIError(503,'Достигнут лимит сессий.')
            token,csrf=secrets.token_hex(32),secrets.token_hex(24); self.sessions[token]={'userId':u['id'],'csrf':csrf,'expires':now+8*3600}
            extra['Set-Cookie']=f'{COOKIE}={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800'+('; Secure' if secure or (self.public_origin or '').startswith('https:') else '')
            return 200,{'user':public_user(u),'csrf':csrf},extra
        token,session,user=self.session(headers)
        if method not in ['GET','HEAD'] and not hmac.compare_digest(headers.get('X-LocalPM-CSRF',''),session['csrf']): raise APIError(403,'Обновите страницу: проверка сессии не пройдена.')
        if path=='/api/session' and method=='GET': return 200,{'user':public_user(user),'csrf':session['csrf']},extra
        if path=='/api/logout' and method=='POST': self.sessions.pop(token,None); return 200,{'ok':True},{'Set-Cookie':f'{COOKIE}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'}
        if path=='/api/users' and method=='GET': return 200,[public_user(u) for u in self.repo.users() if user['admin'] or u['active']],extra
        if path=='/api/users' and method=='POST':
            if not user['admin']: raise APIError(403,'Требуется администратор.')
            u=self.validate_user(b); self.repo.create_user(u); return 201,public_user(u),extra
        match=re.fullmatch(r'/api/users/([A-Za-z0-9_.:-]+)',path)
        if match and method=='PATCH':
            if not user['admin']: raise APIError(403,'Требуется администратор.')
            target=self.repo.user(match[1])
            if not target: raise APIError(404,'Сотрудник не найден.')
            if b.get('active') is False and target['admin'] and len([u for u in self.repo.users() if u['admin'] and u['active']])<=1: raise APIError(422,'Нельзя отключить последнего администратора.')
            hash=password_hash(b['password']) if b.get('password') else target['hash']; active=int(b['active']) if type(b.get('active')) is bool else target['active']
            self.repo.db.execute('UPDATE users SET active=?,hash=? WHERE id=?',(active,hash,target['id'])); self.sessions={k:v for k,v in self.sessions.items() if v['userId']!=target['id']}
            return 200,public_user(self.repo.user(target['id'])),extra
        if path=='/api/health' and method=='GET':
            if not user['admin']: raise APIError(403,'Требуется администратор.')
            self.repo.assert_owner(); return 200,{'status':'ok','version':__version__,'backend':'python','uptimeSeconds':round(time.monotonic()-self.started),'storage':'shared-folder' if self.repo.shared_dir else 'server-database','projects':len(self.repo.list()),'users':self.repo.count_users(),'sessions':len(self.sessions),'lastBackup':self.last_backup},extra
        if path=='/api/backup' and method=='POST':
            if not user['admin']: raise APIError(403,'Требуется администратор.')
            backup=self.repo.backup(); atomic_write(self.repo.data_dir/'backups'/('backup-'+core.now().replace(':','-')+'.json'),backup); self.last_backup=backup['content']['createdAt']
            return 200,backup,extra
        if path=='/api/projects' and method=='GET': return 200,[response_doc(d,user) for d in self.repo.list() if role(d,user)],extra
        if path=='/api/projects' and method=='POST':
            p=core.calculate(b.get('project'),strict=True)
            if self.repo.load(p['id']): raise APIError(409,'Проект с таким ID уже есть.')
            self.validate_assignments(p,{user['id']:'manager'}); p['revision']=1; p['updatedAt']=core.now()
            doc={'project':p,'version':1,'acl':{user['id']:'manager'},'comments':[],'updates':[],'attachments':[],'notifications':[],'audit':[{'at':core.now(),'user_id':user['id'],'user':user['name'],'action':'Проект создан'}],'operations':[]}
            self.repo.save(doc,0); return 201,response_doc(doc,user),extra
        match=re.fullmatch(r'/api/projects/([A-Za-z0-9_.:-]+)(?:/(.*))?',path)
        if not match: raise APIError(404,'Метод не найден.')
        id,tail=match[1],match[2] or ''; doc=self.document(id,user)
        def allowed(roles):
            if role(doc,user) not in roles: raise APIError(403,'Недостаточно прав.')
        def result(d,status=200): return status,response_doc(d,user),extra
        if not tail and method=='GET': return result(doc)
        if not tail and method=='PUT':
            allowed(['manager','editor']); op=core.valid_id(b.get('operationId')); payload=b.get('project'); op_hash=hashlib.sha256(json_text(payload,sort_keys=True).encode()).hexdigest()
            replay=next((o for o in doc.get('operations',[]) if isinstance(o,dict) and o.get('id')==op),None)
            if replay:
                if replay['hash']!=(op_hash if replay.get('hashFormat')=='canonical-json-v1' else hashlib.sha256(json_text(payload).encode()).hexdigest()): raise APIError(409,'ID операции повторно использован с другими данными.')
                return result(doc)
            if b.get('expectedVersion')!=doc['version']: raise APIError(409,'Есть более свежая версия проекта.',currentVersion=doc['version'])
            if not isinstance(payload,dict) or payload.get('id')!=id: raise APIError(422,'ID проекта не совпадает.')
            p=core.calculate(payload,strict=True); self.validate_assignments(p,doc['acl'])
            if role(doc,user)=='editor' and doc['project'].get('require_plan_approval'):
                if len([r for r in doc.get('changeRequests',[]) if r['status']=='pending'])>=10: raise APIError(422,'Сначала рассмотрите предыдущие изменения плана.')
                p['require_plan_approval']=True; request_id=core.uid()
                def proposal(d):
                    d.setdefault('changeRequests',[]).append({'id':request_id,'user_id':user['id'],'user':user['name'],'createdAt':core.now(),'baseVersion':d['version'],'baseProject':core.clone(d['project']),'proposedProject':p,'status':'pending','summary':core.diff(d['project'],p)[:200]}); notify(d,managers(d),user['name']+' предложил изменения плана.')
                doc=self.mutate(doc,user,'Изменения плана отправлены на согласование',proposal,{'id':op,'hash':op_hash,'hashFormat':'canonical-json-v1'}); out=response_doc(doc,user); out['planSubmission']=request_id; return 202,out,extra
            if role(doc,user)!='manager': p['require_plan_approval']=bool(doc['project'].get('require_plan_approval'))
            previous={t['id']:t for t in doc['project']['tasks']}
            def update(d):
                d['project']=p
                for t in p['tasks']:
                    if t.get('assignee_id') and previous.get(t['id'],{}).get('assignee_id')!=t['assignee_id']: notify(d,[t['assignee_id']],'Назначена задача: '+t['name'],t['id'])
            return result(self.mutate(doc,user,'План обновлён',update,{'id':op,'hash':op_hash,'hashFormat':'canonical-json-v1'}))
        if tail=='members' and method=='POST':
            allowed(['manager']); target=self.repo.user(b.get('userId',''))
            if b.get('role') not in ROLES or not target or not target['active']: raise APIError(422,'Проверьте участника и роль.')
            if doc['acl'].get(target['id'])=='manager' and b['role']!='manager' and len(managers(doc))<=1: raise APIError(422,'В проекте должен остаться руководитель.')
            def member(d): d['acl'][target['id']]=b['role']; notify(d,[target['id']],'Изменены права в проекте «'+d['project']['name']+'».')
            return result(self.mutate(doc,user,'Права участника изменены',member))
        remove=re.fullmatch(r'members/([A-Za-z0-9_.:-]+)',tail)
        if remove and method=='DELETE':
            allowed(['manager']); target=remove[1]
            if target not in doc['acl']: raise APIError(404,'Участник не найден.')
            if doc['acl'][target]=='manager' and len(managers(doc))<=1: raise APIError(422,'В проекте должен остаться руководитель.')
            def remove_member(d):
                del d['acl'][target]
                for t in d['project']['tasks']:
                    if t.get('assignee_id')==target: t['assignee_id']=None
            return result(self.mutate(doc,user,'Участник удалён из проекта',remove_member))
        if tail=='comments' and method=='POST':
            allowed(['manager','editor','contributor']); content=b.get('text'); task_id=b.get('taskId')
            if not isinstance(content,str) or not content.strip() or len(content)>10000 or (task_id and not any(t['id']==task_id for t in doc['project']['tasks'])): raise APIError(422,'Проверьте комментарий.')
            mentions=b.get('mentions') or []
            if not isinstance(mentions,list) or any(not isinstance(x,str) for x in mentions): raise APIError(422,'Некорректные упоминания.')
            def comment(d):
                d.setdefault('comments',[]).append({'id':core.uid(),'task_id':task_id,'user_id':user['id'],'user':user['name'],'text':content,'createdAt':core.now()}); d['comments']=d['comments'][-2000:]
                notify(d,[x for x in managers(d)+mentions if x!=user['id']],user['name']+': '+content[:150],task_id)
            return result(self.mutate(doc,user,'Добавлен комментарий',comment),201)
        if tail=='updates' and method=='POST':
            allowed(['manager','editor','contributor']); t=next((t for t in doc['project']['tasks'] if t['id']==b.get('taskId')),None)
            if not t: raise APIError(404,'Задача не найдена.')
            if role(doc,user)=='contributor' and t.get('assignee_id')!=user['id']: raise APIError(403,'Можно обновлять только свои задачи.')
            if b.get('operationId') and any(u.get('operationId')==b['operationId'] and u['user_id']==user['id'] for u in doc.get('updates',[])): return result(doc)
            core.actual(doc['project'],t['id'],b.get('actual') or {})
            def actual_proposal(d):
                updates=d.get('updates',[])
                if len([u for u in updates if u['status']=='pending' and u['user_id']==user['id']])>=100: raise APIError(422,'Не более 100 необработанных обновлений.')
                d['updates']=[u for u in updates if u['status']=='pending']+[u for u in updates if u['status']!='pending'][-1000:]
                d['updates'].append({'id':core.uid(),'operationId':b.get('operationId'),'task_id':t['id'],'user_id':user['id'],'user':user['name'],'actual':b['actual'],'comment':str(b.get('comment') or '')[:3000],'baseActual':actual_snapshot(t),'createdAt':core.now(),'status':'pending'})
                notify(d,managers(d),user['name']+' отправил факт по задаче «'+t['name']+'».',t['id'])
            return result(self.mutate(doc,user,'Отправлено обновление факта',actual_proposal),201)
        review=re.fullmatch(r'(updates|changes)/([A-Za-z0-9_.:-]+)/review',tail)
        if review and method=='POST':
            allowed(['manager']); key='updates' if review[1]=='updates' else 'changeRequests'; pending=next((r for r in doc.get(key,[]) if r['id']==review[2]),None)
            if not pending or pending['status']!='pending': raise APIError(409,'Запрос уже рассмотрен или не найден.')
            if b.get('decision') not in ['accepted','rejected']: raise APIError(422,'Укажите решение.')
            next_project=None
            if b['decision']=='accepted':
                if key=='updates':
                    t=next((t for t in doc['project']['tasks'] if t['id']==pending['task_id']),None)
                    if not t or actual_snapshot(t)!=pending['baseActual']: raise APIError(409,'Факт задачи изменился после отправки.')
                    next_project=core.actual(doc['project'],pending['task_id'],pending['actual'])
                else:
                    merged=core.merge(pending['baseProject'],doc['project'],pending['proposedProject'])
                    if merged['conflicts']: raise APIError(409,'План изменился в тех же полях. Отклоните запрос и обновите предложение.')
                    next_project=merged['project']; self.validate_assignments(next_project,doc['acl'])
            def decide(d):
                r=next(x for x in d[key] if x['id']==pending['id']); r.update(status=b['decision'],reviewedBy=user['name'],reviewedAt=core.now(),reviewComment=str(b.get('comment') or '')[:3000])
                if next_project is not None: d['project']=next_project
                r.pop('baseProject',None); r.pop('proposedProject',None)
                if key=='changeRequests': d[key]=d[key][-100:]
                notify(d,[r['user_id']],'Обновление принято.' if b['decision']=='accepted' else 'Обновление отклонено.',r.get('task_id'))
            return result(self.mutate(doc,user,'Рассмотрено предложение',decide))
        if tail=='attachments' and method=='POST':
            allowed(['manager','editor','contributor'])
            if b.get('type') not in ['application/pdf','text/plain','image/png','image/jpeg'] or not isinstance(b.get('data'),str) or len(b['data'])>2800000: raise APIError(422,'Допустимы PDF, TXT, PNG, JPEG до 2 МБ.')
            try: binary=base64.b64decode(b['data'],validate=True)
            except (ValueError,TypeError): raise APIError(422,'Некорректное содержимое вложения.')
            attachments=doc.get('attachments',[])
            if len(binary)>2*1024*1024: raise APIError(422,'Максимальный размер вложения 2 МБ.')
            if len(attachments)>=100 or sum(a['bytes'] for a in attachments)+len(binary)>10*1024*1024: raise APIError(422,'Лимит вложений: 100 файлов и 10 МБ.')
            if b.get('taskId') and not any(t['id']==b['taskId'] for t in doc['project']['tasks']): raise APIError(422,'Неизвестная задача.')
            def attachment(d): d.setdefault('attachments',[]).append({'id':core.uid(),'task_id':b.get('taskId'),'name':re.sub(r'[\r\n"\\/]','_',str(b.get('name') or 'document'))[:150],'type':b['type'],'data':b['data'],'user':user['name'],'createdAt':core.now(),'bytes':len(binary)})
            return result(self.mutate(doc,user,'Добавлено вложение',attachment),201)
        attachment=re.fullmatch(r'attachments/([A-Za-z0-9_.:-]+)',tail)
        if attachment and method=='GET':
            a=next((a for a in doc.get('attachments',[]) if a['id']==attachment[1]),None)
            if not a: raise APIError(404,'Вложение не найдено.')
            from urllib.parse import quote
            return 200,base64.b64decode(a['data']),{'Content-Type':'application/octet-stream','Content-Disposition':"attachment; filename*=UTF-8''"+quote(a['name'],safe='')}
        if tail=='notifications/read' and method=='POST':
            def read(d):
                for n in d.get('notifications',[]):
                    if n['user_id']==user['id']: n['read_at']=core.now()
            return result(self.mutate(doc,user,'Уведомления прочитаны',read))
        if tail=='history' and method=='GET':
            allowed(['manager','editor']); return 200,[{'version':d['version'],'updatedAt':d['project']['updatedAt'],'name':d['project']['name']} for d in self.repo.versions(id)],extra
        if tail=='restore' and method=='POST':
            allowed(['manager'])
            if b.get('expectedVersion')!=doc['version']: raise APIError(409,'Обновите проект перед восстановлением.')
            old=next((v for v in self.repo.versions(id) if v['version']==b.get('version')),None)
            if not old: raise APIError(404,'Версия не найдена.')
            project=core.calculate(old['project'],strict=True); self.validate_assignments(project,doc['acl'])
            return result(self.mutate(doc,user,'Восстановлена версия '+str(b['version']),lambda d:d.update(project=project)))
        raise APIError(404,'Метод не найден.')
