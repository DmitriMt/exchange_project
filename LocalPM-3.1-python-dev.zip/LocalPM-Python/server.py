#!/usr/bin/env python3
"""Run LocalPM with Python 3.11+, no Node.js or third-party Python packages."""
import argparse
import json
import logging
import signal
import ssl
import sys
import threading
from pathlib import Path
from localpm.application import Application
from localpm.http_server import Server
from localpm.storage import APIError,atomic_write

ROOT=Path(__file__).resolve().parent

def main(argv=None):
    parser=argparse.ArgumentParser(description='LocalPM Python server')
    parser.add_argument('--host',default='127.0.0.1'); parser.add_argument('--port',type=int,default=8787)
    parser.add_argument('--data-dir',default=str(ROOT/'data-python')); parser.add_argument('--shared-dir')
    parser.add_argument('--dev',action='store_true',help='Explicitly allow LAN development HTTP; no debug execution console')
    parser.add_argument('--public-origin'); parser.add_argument('--allowed-host'); parser.add_argument('--tls-key'); parser.add_argument('--tls-cert')
    parser.add_argument('--restore'); parser.add_argument('--setup-code-file',help='Write setup code to a private local file, never served over HTTP')
    args=parser.parse_args(argv)
    if sys.version_info<(3,11): parser.error('Нужен Python 3.11 или новее.')
    if bool(args.tls_key)!=bool(args.tls_cert): parser.error('Укажите одновременно --tls-key и --tls-cert.')
    if not 0<=args.port<=65535: parser.error('Некорректный порт.')
    if args.public_origin and not args.public_origin.startswith('https://'): parser.error('--public-origin должен использовать https://')
    if args.host not in ['127.0.0.1','localhost','::1'] and not args.dev and not args.tls_cert and not args.public_origin:
        parser.error('Для сетевого доступа нужен HTTPS либо явный --dev.')
    if not args.allowed_host and not args.dev and args.public_origin:
        from urllib.parse import urlsplit
        args.allowed_host=urlsplit(args.public_origin).netloc
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    app=None; server=None
    try:
        app=Application(args.data_dir,args.shared_dir,dev=args.dev,public_origin=args.public_origin,allowed_host=args.allowed_host)
        if args.restore: app.repo.restore(json.loads(Path(args.restore).read_text(encoding='utf-8')))
        server=Server((args.host,args.port),app,ROOT/'web')
        if args.tls_cert:
            context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); context.minimum_version=ssl.TLSVersion.TLSv1_2; context.load_cert_chain(args.tls_cert,args.tls_key)
            server.socket=context.wrap_socket(server.socket,server_side=True)
        scheme='https' if args.tls_cert else 'http'; print(f'LocalPM Python: {scheme}://{args.host}:{server.server_port}',flush=True)
        print('Данные: '+str(app.repo.data_dir),flush=True)
        if args.dev: print('Режим разработки, HTTP разрешён явно. Авторизация, роли и CSRF включены.',flush=True)
        if not app.repo.count_users():
            print('Код первоначальной настройки: '+app.bootstrap_code,flush=True)
            if args.setup_code_file: atomic_write(args.setup_code_file,app.bootstrap_code+'\n')
        def stop(signum,frame): threading.Thread(target=server.shutdown,daemon=True).start()
        signal.signal(signal.SIGINT,stop); signal.signal(signal.SIGTERM,stop)
        server.serve_forever(poll_interval=.2)
    except (OSError,APIError,ValueError) as e:
        print('Не удалось запустить LocalPM: '+str(e),file=sys.stderr); return 1
    finally:
        if server: server.server_close()
        if app: app.close()
    return 0

if __name__=='__main__': raise SystemExit(main())
