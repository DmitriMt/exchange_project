'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=__dirname,read=p=>fs.readFileSync(path.join(root,p),'utf8');
let legacy=read('src/legacy-app.js');
for(const name of ['render','displayRows','openTaskCard','startInlineEdit','showProjectSettings','initInteractions'])legacy=legacy.replace(new RegExp('function '+name+'\\('),'function legacy'+name[0].toUpperCase()+name.slice(1)+'(');
legacy=legacy.replace("SCHEMA_VERSION=2","SCHEMA_VERSION=3").replaceAll('v2.5','v3.0 · пилот').replaceAll('РФ праздники','РФ: базовые праздники без переносов').replaceAll('РФ: пятидневка + праздники','РФ: базовые праздники без переносов').replaceAll('(архив на 30 дней)','(можно восстановить из архива)');
const extra=read('src/enhancements.js')+'\n'+read('src/team.js');
legacy=legacy.replace('var App={',extra+'\nvar App={');
legacy=legacy.replace("document.addEventListener('DOMContentLoaded',function(){","installEnhancements3();\ndocument.addEventListener('DOMContentLoaded',function(){");
legacy=legacy.replace('if(state.fileDirty&&!state.fileConnected){','if((state.fileDirty&&(connectionMode===\'server\'||fileHandle))||(connectionMode===\'local\'&&!state.localSaved&&!state.localTabReadOnly)){');
legacy=legacy.replace(/\balert\(/g,'inform3(');
legacy=legacy.replace("if(confirm('Заменить рабочее пространство файлом базы?')){pushHistory();applyWorkspace(d,'replace',false);saveAll();updateDbChip();render()}","showWorkspaceImport3(d)");
legacy=legacy.replace("var tag=(e.target.tagName||'').toLowerCase();","if(document.querySelector('.modal'))return;var tag=(e.target.tagName||'').toLowerCase();");
new vm.Script(legacy);new vm.Script(read('src/core.js'));
const styles=read('src/legacy-styles.css')+'\n'+read('src/team.css');
const fatal=`window.__fatal=function(message){console.error(message);var box=document.getElementById('error-banner');if(!box){box=document.createElement('aside');box.id='error-banner';box.setAttribute('role','alert');document.body.appendChild(box)}box.textContent='Ошибка: '+message+' Доступ к сохранению и экспорту остаётся в меню приложения.'};window.addEventListener('error',function(e){window.__fatal(e.message||'Неизвестная ошибка')});window.addEventListener('unhandledrejection',function(e){window.__fatal(e.reason?.message||String(e.reason))});`;
function html(inline){return '<!doctype html>\n<html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>LocalPM 3.0 — корпоративный планировщик</title>'+(inline?'<style>'+styles+'</style>':'<link rel="stylesheet" href="styles.css">')+'</head><body><div id="app"></div><div id="modal-root"></div><div id="print-area"></div><script>'+fatal+'</script>'+(inline?'<script>'+read('src/core.js').replace(/<\/script/gi,'<\\/script')+'</script><script>'+legacy.replace(/<\/script/gi,'<\\/script')+'</script>':'<script src="core.js"></script><script src="app.js"></script>')+'</body></html>'}
fs.mkdirSync(path.join(root,'web'),{recursive:true});fs.writeFileSync(path.join(root,'web/core.js'),read('src/core.js'));fs.writeFileSync(path.join(root,'web/app.js'),legacy);fs.writeFileSync(path.join(root,'web/styles.css'),styles);fs.writeFileSync(path.join(root,'web/index.html'),html(false));fs.writeFileSync(path.join(root,'LocalPM.html'),html(true));console.log('LocalPM: собраны серверный интерфейс и автономный LocalPM.html.');
