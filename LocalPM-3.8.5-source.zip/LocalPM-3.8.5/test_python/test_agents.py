"""Agent credentials, bounded reads and audit records against real SQLite storage."""
import copy
import hashlib
import secrets
import time
import unittest
from localpm.application import Application
from localpm.agent_access import csrf
from localpm.storage import APIError,json_text
from localpm_mcp.tools import PLAN_FIELDS,validate,InvalidArguments
from task_rules import LIMITS
import test_board_application as board_tests
from test_core import sample

class AgentTests(unittest.TestCase):
    setUp=board_tests.BoardApplicationTests.setUp
    worker=board_tests.BoardApplicationTests.worker
    def key(self,access='read',client=None):
        return (client or self.manager).call('POST','/api/agent-keys',{'name':'Test agent','projects':['project-test'],'access':access,'days':30},201)
    def request(self,key,method,path,body=None,expected=200):
        secret=key['key'];headers={'Host':'127.0.0.1','Origin':'http://127.0.0.1','X-LocalPM-Client':'desktop-v1','X-LocalPM-Source':'mcp','Authorization':'Bearer '+secret,'X-LocalPM-CSRF':csrf(secret)}
        try: status,payload,_=self.app.handle(method,path,headers,body or {})
        except APIError as e: status,payload=e.status,{'error':str(e)}
        if status!=expected: raise AssertionError(f'{status} != {expected}: {payload}')
        return payload
    def patch(self,version=None):
        return {'expectedVersion':version or self.doc['version'],'operationId':secrets.token_hex(16),'changes':[{'task_id':'a','fields':{'note':'Agent change'}}]}
    def test_key_is_hashed_scoped_and_read_only(self):
        key=self.key();stored=self.app.repo.setting('agent-keys',[])['value']
        self.assertNotIn(key['key'],json_text(stored));self.assertEqual(stored[0]['hash'],hashlib.sha256(key['key'].encode()).hexdigest())
        second=sample();second['id']='other-project';self.manager.call('POST','/api/projects',{'project':second},201)
        self.assertEqual([p['id'] for p in self.request(key,'GET','/api/projects/index')],['project-test'])
        self.request(key,'POST','/api/agent-read',{'resource':'project','project_id':'other-project'},403)
        self.request(key,'GET','/api/users',expected=403)
        self.request(key,'POST','/api/projects/project-test/task-changes',self.patch(),403)
        self.request(key,'POST','/api/agent-keys',{},403)
        preview=self.request(key,'POST','/api/projects/project-test/task-changes',{**self.patch(),'dryRun':True})
        self.assertTrue(preview['dryRun']);self.assertEqual(self.app.repo.load('project-test')['version'],self.doc['version'])
    def test_write_key_records_attribution_and_retries_do_not_duplicate(self):
        key=self.key('write');patch=self.patch()
        result=self.request(key,'POST','/api/projects/project-test/task-changes',patch)
        self.assertNotIn('project',result);self.assertEqual(result['project_id'],'project-test')
        replay=self.request(key,'POST','/api/projects/project-test/task-changes',patch);self.assertTrue(replay['replayed'])
        history=self.request(key,'POST','/api/agent-read',{'resource':'audit','project_id':'project-test','source':'mcp'})
        self.assertEqual(history['total'],1);event=history['items'][0]
        self.assertEqual(event['agent'],'Test agent');self.assertEqual(event['key_id'],key['id']);self.assertEqual(event['operation_id'],patch['operationId']);self.assertIn('finish',event['preview']);self.assertNotIn(key['key'],json_text(history))
    def test_write_key_can_comment_but_cannot_manage_members(self):
        key=self.key('write')
        body={'kind':'comment','operationId':secrets.token_hex(16),'data':{'text':'Agent comment','taskId':'a'}}
        result=self.request(key,'POST','/api/projects/project-test/actions',body,201);self.assertIn('receipt',result)
        self.request(key,'POST','/api/projects/project-test/members',{},403)
        self.request(key,'POST','/api/backup',{},403)
    def test_key_survives_restart_and_revocation_is_immediate(self):
        key=self.key();self.app.close();self.app=Application(self.tmp.name);self.addCleanup(self.app.close)
        self.request(key,'GET','/api/session')
        setting=self.app.repo.setting('agent-keys',[]);setting['value'][0]['revokedAt']=time.time();self.app.repo.save_setting('agent-keys',setting['value'],setting['version'])
        self.request(key,'GET','/api/session',expected=401)
    def test_expired_key_and_disabled_user_are_rejected(self):
        key=self.key();setting=self.app.repo.setting('agent-keys',[]);setting['value'][0]['expires']=0;self.app.repo.save_setting('agent-keys',setting['value'],setting['version'])
        self.request(key,'GET','/api/session',expected=401)
        key=self.key();user=self.app.repo.username('manager');self.app.repo.db.execute('UPDATE users SET active=0 WHERE id=?',(user['id'],))
        self.request(key,'GET','/api/session',expected=401)
    def test_key_cannot_bypass_current_user_role(self):
        user,client=self.worker('viewer');key=self.key('write',client)
        self.request(key,'POST','/api/projects/project-test/task-changes',self.patch(self.doc['version']),403)
        self.manager.call('DELETE','/api/projects/project-test/members/'+user['id'])
        self.request(key,'POST','/api/agent-read',{'resource':'project','project_id':'project-test'},403)
    def test_server_filters_large_projects_and_detects_page_version_changes(self):
        doc=self.app.repo.load('project-test');doc['project']['dependencies']=[]
        doc['project']['tasks']=[{'id':f'big-{i}','name':f'Task {i}','duration_days':1,'note':'x'*28000,'external_number':f'П-{i+1}','sort_order':i} for i in range(470)]
        before=doc['version'];doc['version']+=1;self.app.repo.save(doc,before)
        key=self.key();args={'resource':'tasks','project_id':'project-test','limit':1,'query':'Task 469'}
        page=self.request(key,'POST','/api/agent-read',args)
        self.assertEqual(page['total'],1);self.assertEqual(page['items'][0]['id'],'big-469');self.assertLess(len(json_text(page)),5000)
        self.request(key,'POST','/api/agent-read',{**args,'expected_version':before},409)
        page=self.request(key,'POST','/api/agent-read',{'resource':'tasks','project_id':'project-test','offset':1,'limit':2})
        self.assertEqual(len(page['items']),2);self.assertEqual(page['next_offset'],3)
    def test_rules_reject_invalid_metadata_before_saving(self):
        for fields in [{'tags':['x'*(LIMITS['tagLength']+1)]},{'tags':['x']*(LIMITS['tagCount']+1)},{'priority':LIMITS['priorityMax']+1},{'author':'x'*(LIMITS['authorLength']+1)}]:
            for name,value in fields.items(): self.assertRaises(InvalidArguments,validate,value,PLAN_FIELDS[name])
            project=copy.deepcopy(self.doc['project']);project['tasks'][0].update(fields)
            self.manager.call('PUT','/api/projects/project-test',{'project':project,'expectedVersion':self.doc['version'],'operationId':secrets.token_hex(16)},422)
        self.assertEqual(self.app.repo.load('project-test')['version'],self.doc['version'])

if __name__=='__main__': unittest.main()
