import io
import json
import unittest
import test_board_application as board_tests
from localpm import wsgi
from localpm.http_server import MAX_BODY

class WSGITests(unittest.TestCase):
    setUp=board_tests.BoardApplicationTests.setUp
    def request(self,method,path,body=None,headers=None):
        self.app.public_origin='https://pm.internal.test';self.app.allowed_host='pm.internal.test';self.app.client_origins={'http://127.0.0.1:9102'}
        old=wsgi._state;wsgi._state=(self.app,None);raw=json.dumps(body or {}).encode();result={}
        env={'HTTP_HOST':'pm.internal.test','REQUEST_METHOD':method,'PATH_INFO':path,'CONTENT_TYPE':'application/json','CONTENT_LENGTH':str(len(raw)),'HTTP_COOKIE':self.manager.cookie,'HTTP_X_LOCALPM_CSRF':self.manager.csrf,'wsgi.input':io.BytesIO(raw),'REMOTE_ADDR':'127.0.0.1',**(headers or {})}
        def start(status,headers):result.update(status=int(status.split()[0]),headers=dict(headers))
        try:result['body']=b''.join(wsgi.application(env,start))
        finally:wsgi._state=old
        return result
    def test_wsgi_preserves_case_insensitive_cookie_and_csrf_headers(self):
        result=self.request('PUT','/api/preferences',{'value':{'density':'compact'},'expectedVersion':0});self.assertEqual(result['status'],200);self.assertEqual(json.loads(result['body'])['value']['density'],'compact')
    def test_wsgi_rejects_cross_origin_writes_and_missing_csrf(self):
        self.assertEqual(self.request('PUT','/api/preferences',{},headers={'HTTP_ORIGIN':'https://other.test'})['status'],403)
        self.assertEqual(self.request('PUT','/api/preferences',{},headers={'HTTP_X_LOCALPM_CSRF':''})['status'],403)
    def test_wsgi_preflight_allows_only_explicit_client_origins(self):
        headers={'HTTP_ORIGIN':'http://127.0.0.1:9102','HTTP_ACCESS_CONTROL_REQUEST_METHOD':'POST','HTTP_ACCESS_CONTROL_REQUEST_HEADERS':'x-localpm-client, content-type, x-localpm-csrf'}
        result=self.request('OPTIONS','/api/projects',headers=headers);self.assertEqual(result['status'],204);self.assertEqual(result['headers']['Access-Control-Allow-Origin'],headers['HTTP_ORIGIN'])
        headers['HTTP_ORIGIN']='https://unapproved.test';self.assertEqual(self.request('OPTIONS','/api/projects',headers=headers)['status'],403)
    def test_wsgi_bounded_body_and_static_allowlist(self):
        self.assertEqual(self.request('POST','/api/preferences',headers={'CONTENT_LENGTH':str(MAX_BODY+1)})['status'],413)
        self.assertEqual(self.request('GET','/../server.py')['status'],404)
        self.assertEqual(self.request('GET','/')['status'],200)

if __name__=='__main__':unittest.main()
