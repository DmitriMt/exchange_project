#!/usr/bin/env python3
"""Explicit frontend module assembly using Python and the standard library."""
from pathlib import Path
import re, json

ROOT=Path(__file__).resolve().parent
VERSION=(ROOT/'VERSION').read_text(encoding='utf-8').strip()

def read(name): return (ROOT/name).read_text(encoding='utf-8')
def main():
    manifest=json.loads(read('frontend.json'))
    legacy='window.LOCALPM_VERSION='+json.dumps(VERSION)+';\n(function(){\n'+'\n'.join(read(p) for p in manifest['app'])+'\n})();'
    styles='\n'.join(read(p) for p in manifest['styles'])
    core='globalThis.LocalPMTaskRuleData='+read('task-rules.json').strip()+';\n'+'\n'.join(read(p) for p in manifest['core'])
    fatal="window.__fatal=function(message){console.error(message);var box=document.getElementById('error-banner');if(!box){box=document.createElement('aside');box.id='error-banner';box.setAttribute('role','alert');document.body.appendChild(box)}box.textContent='Ошибка: '+message+' Доступ к сохранению и экспорту остаётся в меню приложения.'};window.addEventListener('error',function(e){window.__fatal(e.message||'Неизвестная ошибка')});window.addEventListener('unhandledrejection',function(e){window.__fatal(e.reason?.message||String(e.reason))});"
    def inline_script(s): return re.sub(r'</script',lambda m:'<\\/script',s,flags=re.I)
    def html(inline):
        return '<!doctype html>\n<html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>LocalPM '+VERSION+' — корпоративный планировщик</title>'+('<style>'+styles+'</style>' if inline else '<link rel="stylesheet" href="styles.css">')+'</head><body><div id="app"></div><div id="modal-root"></div><div id="print-area"></div><script>'+fatal+'</script>'+('<script>'+inline_script(core)+'</script><script>'+inline_script(legacy)+'</script>' if inline else '<script src="core.js"></script><script src="app.js"></script>')+'</body></html>'
    policy=lambda network: '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; script-src \'unsafe-inline\'; style-src \'unsafe-inline\'; img-src data: blob:; connect-src '+network+'; object-src \'none\'; base-uri \'none\'; form-action \'none\'">'
    client_html=html(True).replace('<script>'+fatal,'<script>window.LOCALPM_CLIENT=true;'+fatal).replace('<title>',policy('http: https:')+'<title>',1)
    offline_html=html(True).replace('<script>'+fatal,'<script>window.LOCALPM_LOCAL_ONLY=true;'+fatal).replace('<title>',policy("'none'")+'<title>',1)
    files={'web/core.js':core,'web/app.js':legacy,'web/styles.css':styles,'web/index.html':html(False),'web/client.html':client_html,'LocalPM.html':client_html,'LocalPM-local.html':client_html,'LocalPM-client.html':client_html,'LocalPM-offline.html':offline_html}
    for name,content in files.items():
        p=ROOT/name; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(content,encoding='utf-8')
    print('Собраны web/, автономный клиент и отдельная версия без сети.')

if __name__=='__main__': main()
