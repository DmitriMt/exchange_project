'use strict';
// Expected values come from JavaScript; Python verifies them independently.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),C=require('../src/core.js');
const file=path.join(root,'test_python/fixtures/core_conformance.json');
const data=JSON.parse(fs.readFileSync(file,'utf8'));
data.sourceSha256=crypto.createHash('sha256').update(fs.readFileSync(path.join(root,data.source))).digest('hex');
for(const fixture of data.cases)fixture.expected=C.calculate(fixture.input,{strict:true});
fs.writeFileSync(file,JSON.stringify(data,null,2)+'\n');
console.log('Обновлены независимые JavaScript-эталоны: '+data.cases.length);
