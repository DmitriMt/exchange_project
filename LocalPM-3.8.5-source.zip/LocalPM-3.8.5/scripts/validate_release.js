'use strict';
/* Offline syntax and startup audit. Uses only Node.js built-ins and isolated test adapters. */
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict'),{createRequire}=require('node:module');
const root=path.resolve(__dirname,'..');
const read=name=>fs.readFileSync(path.join(root,name),'utf8');
const report={version:read('VERSION').trim(),sourceScripts:0,html:[],selfCheck:false,appTargets:0,modalTargets:0,compiledInlineHandlers:0,builtInTests:null};
for(const dir of ['src','test','scripts'])for(const name of fs.readdirSync(path.join(root,dir),{recursive:true}).filter(n=>n.endsWith('.js'))){new vm.Script(read(dir+'/'+name),{filename:dir+'/'+name});report.sourceScripts++;}
for(const name of ['LocalPM-client.html','LocalPM-offline.html']){
 const html=read(name);let count=0;
 for(const m of html.matchAll(/<script>([\s\S]*?)<\/script>/g))new vm.Script(m[1],{filename:name+'-script-'+(++count)});
 assert.equal(count,3);assert(!/<script\b[^>]*\bsrc=/i.test(html));assert(!/<link\b[^>]*\brel=["']stylesheet/i.test(html));
 report.html.push({name,inlineScripts:count,syntax:'passed',externalDependencies:false});
}
const prefix=read('test/ui-regression.test.js').split('function loadProject(f)')[0];
const f=vm.runInNewContext(prefix+';fixture();',{require:createRequire(path.join(root,'test/ui-regression.test.js')),__dirname:path.join(root,'test'),console,Blob,TextEncoder,TextDecoder,URL,URLSearchParams,performance});
f.ctx.__fatal=message=>{throw Error(message)};assert.equal(f.a.selfCheck(),true);report.selfCheck=true;
const code=read('web/app.js'),keys=[...new Set(Array.from(code.matchAll(/\bApp\.([A-Za-z_$][\w$]*)/g),m=>m[1]))];
for(const key of keys)assert(key in f.ctx.App,'Undefined App property: '+key);report.appTargets=keys.length;
const methods=[...new Set(Array.from(code.matchAll(/\bApp\.([A-Za-z_$][\w$]*)\s*\(/g),m=>m[1]))];
for(const key of methods)assert.equal(typeof f.ctx.App[key],'function','Not callable: '+key);
const modal=[...new Set(Array.from(code.matchAll(/modalButton3\(['"][^'"]*['"],\s*['"]([A-Za-z_$][\w$]*)\(/g),m=>m[1]))];
for(const key of modal)assert.equal(typeof f.ctx.App[key],'function','Undefined modal command: '+key);report.modalTargets=modal.length;
const C=f.ctx.LocalPMCore,p=C.calculate({id:'startup-audit',name:'Проверка запуска',start_date:'2026-10-05',calendar_id:'5day',tasks:[{id:'s',name:'Этап'},{id:'a',name:'Задача',parent_id:'s'}],dependencies:[]});
f.ctx.state.projects=[p];f.ctx.state.currentProjectId=p.id;
const decode=s=>s.replace(/&quot;/g,'"').replace(/&#39;|&apos;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&');
for(const html of [f.a.renderProjectsScreen(),f.a.renderProjectScreen()])for(const m of html.matchAll(/\bon(?:click|change|input|keydown|submit)="([^"]*)"/g)){
 new vm.Script('(function(event){'+decode(m[1])+'})');report.compiledInlineHandlers++;
}
f.ctx.App.runTests();const tests=f.ctx.__testReport;assert(tests.length>=31);assert.equal(tests.filter(t=>!t.ok).length,0,JSON.stringify(tests.filter(t=>!t.ok)));report.builtInTests={total:tests.length,passed:tests.length};
report.invalidShorthandPropertyInitializer=false;
const target=process.argv[2];if(target)fs.writeFileSync(path.resolve(target),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
