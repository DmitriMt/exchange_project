'use strict';
// Both entry points use the same builder, so Python and npm cannot drift apart.
const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
const root=__dirname;
const localPython=path.resolve(root,'../../.venv',process.platform==='win32'?'Scripts/python.exe':'bin/python');
const candidates=process.env.PYTHON?[process.env.PYTHON]:[...(fs.existsSync(localPython)?[localPython]:[]),'python3','python'];
for(const python of candidates){
 const result=spawnSync(python,[path.join(root,'build.py')],{cwd:root,stdio:'inherit'});
 if(result.error?.code==='ENOENT')continue;
 if(result.error){console.error(result.error.message);process.exit(1)}
 process.exit(result.status??1);
}
console.error('Нужен Python 3.11+. Укажите его путь в переменной PYTHON.');
process.exit(1);
