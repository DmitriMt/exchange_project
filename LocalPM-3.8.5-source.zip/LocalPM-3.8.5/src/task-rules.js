/* Limits originate in task-rules.json; build.py embeds the same data for browsers. */
(function(root,factory){const api=factory(typeof module==='object'&&module.exports?require('../task-rules.json'):root.LocalPMTaskRuleData);if(typeof module==='object'&&module.exports)module.exports=api;else root.LocalPMTaskRules=api})(typeof globalThis!=='undefined'?globalThis:this,function(limits){
 'use strict';
 function metadata(task){
  const priority=task.priority===undefined?0:task.priority;
  if(typeof priority!=='number'||!Number.isFinite(priority)||priority<0||priority>limits.priorityMax)throw Error('Приоритет должен быть от 0 до '+limits.priorityMax+'.');
  const tags=task.tags===undefined?[]:task.tags;
  if(!Array.isArray(tags)||tags.length>limits.tagCount||tags.some(t=>typeof t!=='string'||Array.from(t).length>limits.tagLength))throw Error('Некорректные метки.');
  const author=task.author===undefined?'':task.author;
  if(typeof author!=='string'||Array.from(author).length>limits.authorLength)throw Error('Некорректный инициатор.');
 }
 return {limits:Object.freeze(limits),metadata};
});
