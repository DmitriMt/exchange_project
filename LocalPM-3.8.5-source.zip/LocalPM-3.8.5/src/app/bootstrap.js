var App={};App.state=state;App.goProjects=goProjects;App.openProject=openProject;App.deleteProject=deleteProject;App.archiveProject=archiveProject;App.unarchive=unarchive;App.copyProject=copyProject;App.toggleArchive=toggleArchive;App.showNewProjectModal=showNewProjectModal;App.saveNewProject=saveNewProject;App.showProjectSettings=showProjectSettings;App.saveProjectSettings=saveProjectSettings;App.toggleCollapse=toggleCollapse;App.collapseAll=collapseAll;App.expandTo=expandTo;App.addTask=addTask;App.addSubtask=addSubtask;App.createGroup=createGroup;App.deleteTask=deleteTask;App.moveTask=moveTask;App.indentTask=indentTask;App.outdentTask=outdentTask;App.openTaskCard=openTaskCard;App.saveTaskCard=saveTaskCard;App.setAuto=function(){setScheduling(false)};App.setManual=function(){setScheduling(true)};App.copySel=copySelection;App.pasteSel=pasteClipboard;App.undo=undo;App.redo=redo;App.showImportWizard=showImportWizard;App.importPreview=importPreview;App.importApply=importApply;App.exportExcel=exportExcel;App.exportPNG=exportPNG;App.showPrint=showPrint;App.setScale=setScale;App.setViewFlag=setViewFlag;App.searchNext=searchNext;App.setSearch=setSearch;App.setGroupBy=setGroupBy;App.showFilters=showFilters;App.applyFilters=applyFilters;App.resetFilters=resetFilters;App.saveBaseline=saveBaseline;App.showProblems=showProblems;App.autoFit=function(){autoFitColumns(null)};App.saveNow=saveNow;App.saveToFileNow=saveToFileNow;App.showDbModal=showDbModal;App.showDbSetupModal=showDbSetupModal;App.showAppearance=showAppearance;App.saveAppearance=saveAppearance;App.backup=createBackup;App.wsExport=wsExport;App.wsImport=wsImport;App.wsImportApply=wsImportApply;App.connectFile=connectFile;App.createFile=createFile;App.disconnectFile=disconnectFile;App.allowPending=allowPending;App.dbOpenInput=openFileViaInput;App.dbRefresh=refreshFromFile;App.dbSave=saveToFileNow;App.dbRecheck=dbRecheck;App.dbTemplate=dbTemplate;App.transferOut=transferOut;App.transferBuild=transferBuild;App.transferImport=transferImport;App.showTransferIn=showTransferIn;App.returnAccept=returnAccept;App.returnReject=returnReject;App.runTests=runTests;App.printProtocol=printProtocol;App.toggleTheme=toggleTheme;App.closeModal=closeModal;App.ghostAdd=ghostAdd;;
function setScale(v){state.scale=v;var p=currentProject();if(p){p.view_settings=p.view_settings||{};p.view_settings.scale=v;saveCurrentProject()}render()}
installEnhancements3();
installLeadRequirements3();
installProduct4();
installProductTools4();
installLargeProject4();
installKeyboard8();
installLocalFiles8();
installCollaboration4();
document.addEventListener('DOMContentLoaded',function(){
  try{
    if(!selfCheck()){return}
    initCalendar();
    loadOwners();
    applyTheme();
    initInteractions();
    initWorkspace().then(function(){
      render();
      if((state.pendingHandle||state.dbMissing)&&!ssGet('localpm_db_skip')){
        showDbSetupModal();
      }
    }).catch(function(err){
      console.error(err);
      window.__fatal('init: '+String(err&&err.message?err.message:err));
    });
    window.addEventListener('resize',function(){
      if(state.screen==='project'){renderGantt(null,{})}
    });
    window.addEventListener('beforeunload',function(e){
      if((state.fileDirty&&(connectionMode==='server'||fileHandle))||(connectionMode==='local'&&!state.localSaved&&!state.localTabReadOnly)){
        e.preventDefault();
        e.returnValue='';
      }
    });
  }catch(err){
    console.error(err);
    window.__fatal('boot: '+String(err&&err.message?err.message:err));
  }
});
window.App=App;
window.state=state;

