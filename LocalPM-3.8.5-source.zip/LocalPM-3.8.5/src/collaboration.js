/* Collaboration, agent credentials and activity. No generated source rewriting. */
var collaboration4={busy:false,timer:0,stopped:false,status:'',pending:[]};
function collaborationProtected4(){
 var tag=(document.activeElement?.tagName||'').toLowerCase();
 return state.fileDirty||serverSaveBusy||apiBusy3||state.writing||!!document.querySelector('.modal')||['input','textarea','select'].includes(tag)||!!document.activeElement?.isContentEditable||!!rowDrag3||(typeof ganttDrag!=='undefined'&&!!ganttDrag)||
  (typeof actionQueue4!=='undefined'&&actionQueue4?.actions?.some(function(a){return a.status!=='sent'}));
}
function collaborationStatus4(message){collaboration4.status=message;var badge=el('collaboration-status4');if(badge)badge.textContent=message||'Обновления включены'}
function collaborationSchedule4(){clearTimeout(collaboration4.timer);collaboration4.timer=0;if(connectionMode!=='server'||collaboration4.stopped)return;collaboration4.timer=setTimeout(async function(){await pollCollaboration4();collaborationSchedule4()},5000)}
async function pollCollaboration4(){
 if(connectionMode!=='server'||collaboration4.busy||collaboration4.stopped||document.hidden||serverSaveBusy||apiBusy3)return;
 var epoch=connectionEpoch3,user=signedInUser?.id;collaboration4.busy=true;
 function current(){return connectionMode==='server'&&epoch===connectionEpoch3&&user===signedInUser?.id}
 try{
  var index=await api3('/api/projects/index');if(!current())return;
  if(!Array.isArray(index))throw Error('Не удалось проверить общую базу.');
  var pending=[],changed=false,ids=new Set(index.map(function(p){return p.id}));
  for(var item of index){
   if(!current())return;
   var local=state.projects.find(function(p){return p.id===item.id}),doc=serverDocs.get(item.id);
   var unread=doc?.notifications?.filter(function(n){return !n.read_at}).length||0;
   if(doc&&serverVersions.get(item.id)===item.version&&unread===(item.unread||0))continue;
   if(collaborationProtected4()){pending.push(item.id);continue}
   var fingerprint=local?semantic(local):null,remote=await api3('/api/projects/'+item.id);
   if(!current())return;
   var latest=state.projects.find(function(p){return p.id===item.id});
   if(collaborationProtected4()||(latest?semantic(latest):null)!==fingerprint){pending.push(item.id);continue}
   consumeDoc3(remote,false);changed=true;
  }
  if(!current())return;
  for(var id of Array.from(serverDocs.keys())){
   if(ids.has(id))continue;
   if(collaborationProtected4()){pending.push(id);continue}
   state.projects=state.projects.filter(function(p){return p.id!==id});serverDocs.delete(id);serverHashes.delete(id);serverVersions.delete(id);changed=true;
   if(state.currentProjectId===id){state.currentProjectId=null;state.screen='projects'}
  }
  collaboration4.pending=pending;
  collaborationStatus4(pending.length?'Есть обновления коллег. Завершите правки и обновите проект.':'Общая база актуальна');
  if(changed){pmHist.undo=[];pmHist.redo=[];await persistLocal();if(current()&&!collaborationProtected4())render()}
 }catch(error){
  if(!current())return;
  if(error.status===401){collaboration4.stopped=true;collaborationStatus4('Сессия завершена. Подключитесь заново.')}
  else collaborationStatus4('Нет обновлений: '+error.message);
 }finally{collaboration4.busy=false}
}
async function showAgentKeys4(){
 if(connectionMode!=='server')return inform3('Подключитесь к общей базе.');
 try{var keys=await api3('/api/agent-keys');showModal('Доступ агентов',
  '<p>Ключ действует от вашего имени, только в выбранных проектах. Права вашей учётной записи сохраняются.</p>'+table3(['Агент','Доступ','Действует до','Состояние'],keys.map(function(k){return [esc(k.name),k.access==='write'?'Чтение и запись':'Чтение',new Date(k.expires*1000).toLocaleDateString('ru-RU'),k.revokedAt?'Отозван':k.expires*1000<Date.now()?'Истёк':modalButton3('Отозвать',"revokeAgentKey4('"+k.id+"')")] }))+
  '<div class="form-grid"><div class="form-field"><label for="agent-name4">Имя агента</label><input id="agent-name4" maxlength="80" value="Помощник"></div><div class="form-field"><label for="agent-days4">Срок, дней</label><input id="agent-days4" type="number" min="1" max="365" value="30"></div><div class="form-field"><label for="agent-access4">Разрешения</label><select id="agent-access4"><option value="read">Только чтение</option><option value="write">Чтение и запись</option></select></div></div><h4>Разрешённые проекты</h4>'+state.projects.filter(function(p){return serverDocs.has(p.id)}).map(function(p){return '<label class="checkbox"><input type="checkbox" data-agent-project4="'+esc(p.id)+'"'+(p.id===state.currentProjectId?' checked':'')+'>'+esc(p.name)+'</label>'}).join(''),
  modalButton3('Закрыть','closeModal()')+modalButton3('Создать ключ','createAgentKey4()',true))
 }catch(error){inform3(error.message)}
}
async function createAgentKey4(){
 try{var projects=Array.from(document.querySelectorAll('[data-agent-project4]:checked')).map(function(input){return input.dataset.agentProject4});
  var result=await api3('/api/agent-keys','POST',{name:el('agent-name4').value,days:Number(el('agent-days4').value),access:el('agent-access4').value,projects:projects});
  showModal('Ключ создан','<p>Скопируйте ключ сейчас: повторно он не показывается. Храните его как пароль.</p><div class="form-field"><label for="agent-secret4">Ключ агента</label><textarea id="agent-secret4" readonly autocomplete="off">'+esc(result.key)+'</textarea></div><p>При входе MCP используйте параметр <code>--api-key-file</code> с путём к закрытому текстовому файлу ключа. На macOS/Linux доступ к файлу должен быть только у вас.</p>',modalButton3('Закрыть','closeModal()'));
 }catch(error){inform3(error.message)}
}
async function revokeAgentKey4(id){if(!await askConfirm3('Отозвать ключ агента? Его доступ прекратится сразу.'))return;try{await api3('/api/agent-keys/revoke','POST',{id:id});await showAgentKeys4()}catch(error){inform3(error.message)}}
async function showAgentActivity4(offset){
 var p=currentProject();if(!p||connectionMode!=='server')return;
 try{var result=await api3('/api/agent-read','POST',{resource:'audit',project_id:p.id,source:'mcp',offset:offset||0,limit:25});
  showModal('Действия агентов',table3(['Дата','Агент','Действие','Операция и результат'],result.items.map(function(r){return [new Date(r.at).toLocaleString('ru-RU'),esc(r.agent||r.user),esc(r.action),'<small>'+esc(r.operation_id||'')+'</small>'+(r.preview?'<p>Окончание: '+esc(r.preview.finish||'')+' · Прогноз: '+esc(r.preview.forecast||'')+'</p>':'')+(r.changes?.length?'<p>'+r.changes.map(function(c){var labels={name:'Название',note:'Примечание',duration_days:'Длительность',priority:'Приоритет',author:'Инициатор',tags:'Метки',assignee_id:'Исполнитель',owner:'Ответственный',parent_id:'Родительская задача',sort_order:'Порядок',schedule_calendar:'Календарь',constraint_snet:'Ограничение начала',start_date:'Начало',finish_date:'Окончание',deadline:'Целевой срок',effort_hours:'Трудозатраты',is_manual:'Ручное планирование',is_milestone:'Веха',field_values:'Пользовательские поля',task_type:'Тип задачи'};return esc(c.task_name||c.task_id)+': '+esc(c.fields.map(function(k){return labels[k]||(/^custom[1-5]$/.test(k)?'Дополнительное поле '+k.slice(-1):k)}).join(', '))}).join('<br>')+'</p>':'')]}))+(result.total?'':'<p>Действий агентов пока нет.</p>'),modalButton3('Закрыть','closeModal()')+(offset?modalButton3('Назад','showAgentActivity4('+Math.max(0,offset-25)+')'):'')+(result.next_offset!==null?modalButton3('Далее','showAgentActivity4('+result.next_offset+')'):''));
 }catch(error){inform3(error.message)}
}
function installCollaboration4(){
 var activate=activateServer3;activateServer3=async function(){await activate.apply(this,arguments);collaboration4.stopped=false;collaboration4.pending=[];collaborationSchedule4()};
 var leave=leaveServer3;leaveServer3=async function(){await leave.apply(this,arguments);if(connectionMode!=='server'){clearTimeout(collaboration4.timer);collaboration4.timer=0;collaboration4.status='';collaboration4.pending=[]}};
 var shell=productShell4;productShell4=function(){shell();if(connectionMode!=='server')return;var root=el('app'),bottom=root?.querySelector('.product-sidebar-bottom'),header=root?.querySelector('.product-header');
  if(bottom){bottom.append(button4('Доступ агентов',showAgentKeys4));if(currentProject()&&canPlan3())bottom.append(button4('Действия агентов',function(){showAgentActivity4(0)}))}
  if(header){var badge=button4(collaboration4.status||'Обновления включены',function(){refreshServer3()});badge.id='collaboration-status4';badge.setAttribute('role','status');badge.setAttribute('aria-live','polite');header.append(badge)}
 };
 window.addEventListener('focus',function(){pollCollaboration4()});document.addEventListener('visibilitychange',function(){if(!document.hidden)pollCollaboration4()});
 window.addEventListener('pagehide',function(){collaboration4.stopped=true;clearTimeout(collaboration4.timer)});
 Object.assign(App,{leaveServer3,showAgentKeys4,createAgentKey4,revokeAgentKey4,showAgentActivity4,pollCollaboration4});
}
